import React, { useEffect, useMemo, useRef } from 'react';
import {
  Animated,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';
import type { AssistantLanguage } from '@/assistant/offlineBrain';
import type { AssistantMemory } from '@/assistant/localMemory';
import { OFFLINE_100_FEATURE_COUNT } from '@/assistant/offline100Features';

type Message = {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  time: number;
};

type VoiceHistoryItem = { id: string; text: string; time: number };

type Props = {
  language: AssistantLanguage;
  messages: Message[];
  draft: string;
  setDraft: (value: string) => void;
  isListening: boolean;
  continuousVoice: boolean;
  isSending: boolean;
  isSpeaking: boolean;
  online: boolean;
  voiceHistory: VoiceHistoryItem[];
  memory: AssistantMemory;
  voiceGender: 'female' | 'male';
  assistantName: string;
  wakeWordEnabled: boolean;
  accountLoggedIn: boolean;
  onVoice: () => void;
  onSend: (text: string) => void;
  onMenu: () => void;
  onSettings: () => void;
  onAccount: () => void;
  onFeatures: () => void;
};

function formatTime(timestamp: number, language: AssistantLanguage) {
  try {
    return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
      hour: 'numeric', minute: '2-digit',
    }).format(timestamp);
  } catch {
    return '—';
  }
}

function NativeAvatar({ compact = false }: { compact?: boolean }) {
  const size = compact ? 52 : 150;
  return (
    <Svg width={size} height={size} viewBox="0 0 150 150">
      <Defs>
        <LinearGradient id="avatarFace" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFF1F2" />
          <Stop offset="0.55" stopColor="#FF9AA4" />
          <Stop offset="1" stopColor="#8F1724" />
        </LinearGradient>
        <LinearGradient id="avatarHair" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FF6674" />
          <Stop offset="0.5" stopColor="#B80F25" />
          <Stop offset="1" stopColor="#FF2638" />
        </LinearGradient>
      </Defs>
      <Circle cx="75" cy="75" r="72" fill="#170507" stroke="#FF2638" strokeWidth="2" />
      <Path d="M29 126c7-32 26-47 46-47s39 15 46 47" fill="#26070B" stroke="#FF2638" strokeWidth="2" />
      <Path d="M39 68c0-30 17-48 36-48 25 0 38 20 36 48-5-10-11-17-20-20-14 12-28 16-52 20Z" fill="url(#avatarHair)" />
      <Path d="M46 67c0-21 12-34 29-34 18 0 29 14 29 34 0 22-11 37-29 37S46 89 46 67Z" fill="url(#avatarFace)" stroke="#FF7D89" strokeWidth="1.5" />
      <Path d="M50 59c8-20 19-24 32-23 8 1 16 5 22 13-11-3-20-7-28-13-7 12-15 19-26 23Z" fill="#26070B" />
      <Circle cx="64" cy="70" r="3" fill="#120305" />
      <Circle cx="87" cy="70" r="3" fill="#120305" />
      <Path d="M67 86c6 5 12 5 18 0" fill="none" stroke="#8A1B28" strokeWidth="2" strokeLinecap="round" />
      <Path d="M45 108c10 9 20 13 30 13s21-4 31-13" fill="none" stroke="#FF2638" strokeWidth="3" opacity="0.9" />
      <Circle cx="24" cy="35" r="2" fill="#FF5362" />
      <Circle cx="126" cy="46" r="2" fill="#FF5262" />
    </Svg>
  );
}

function MiniBrain() {
  return (
    <Svg width={62} height={62} viewBox="0 0 62 62">
      <Circle cx="31" cy="31" r="27" fill="#190609" stroke="#FF2638" strokeWidth="2" />
      <Path d="M31 15v32M19 23c4-5 8-5 12-2M43 23c-4-5-8-5-12-2M19 38c4 5 8 5 12 2M43 38c-4 5-8 5-12 2" fill="none" stroke="#FF6674" strokeWidth="2" strokeLinecap="round" />
      <Circle cx="31" cy="31" r="4" fill="#FF9AA4" />
    </Svg>
  );
}

function GlowCard({ children, style }: { children: React.ReactNode; style?: any }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

function PanelTitle({ icon, title, action, onAction }: { icon: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.panelTitleRow}>
      <View style={styles.panelTitleLeft}>
        <View style={styles.panelIcon}><Text style={styles.panelIconText}>{icon}</Text></View>
        <Text numberOfLines={1} style={styles.panelTitle}>{title}</Text>
      </View>
      {action ? <Pressable onPress={onAction}><Text style={styles.panelAction}>{action}</Text></Pressable> : null}
    </View>
  );
}

function Gauge({ label, value, type = 'blue' }: { label: string; value: string; type?: 'green' | 'blue' | 'purple' | 'yellow' }) {
  const color = type === 'green' ? '#32FF92' : type === 'purple' ? '#FF6674' : type === 'yellow' ? '#FFD53D' : '#FF3548';
  return (
    <View style={styles.gaugeBox}>
      <Text numberOfLines={1} style={styles.gaugeLabel}>{label}</Text>
      <View style={[styles.gaugeRing, { borderColor: color }]}>
        <Text style={[styles.gaugeValue, { color }]}>{value}</Text>
      </View>
    </View>
  );
}

function ActivityRow({ icon, text, time }: { icon: string; text: string; time: string }) {
  return (
    <View style={styles.activityRow}>
      <View style={styles.activityIcon}><Text>{icon}</Text></View>
      <Text numberOfLines={1} style={styles.activityText}>{text}</Text>
      <Text style={styles.activityTime}>{time}</Text>
    </View>
  );
}

export function ExactReferenceDashboard({
  language,
  messages,
  draft,
  setDraft,
  isListening,
  continuousVoice,
  isSending,
  isSpeaking,
  online,
  voiceHistory,
  memory,
  voiceGender,
  assistantName,
  wakeWordEnabled,
  accountLoggedIn,
  onVoice,
  onSend,
  onMenu,
  onSettings,
  onAccount,
  onFeatures,
}: Props) {
  const { width } = useWindowDimensions();
  const bn = language === 'bn';
  const [typed, setTyped] = React.useState(draft);
  const pulse = useRef(new Animated.Value(0)).current;
  const rotation = useRef(new Animated.Value(0)).current;
  const wave = useRef(new Animated.Value(0)).current;
  const [clock, setClock] = React.useState(new Date());

  useEffect(() => setTyped(draft), [draft]);
  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    const spin = Animated.loop(Animated.timing(rotation, { toValue: 1, duration: 9000, useNativeDriver: true }));
    const waveLoop = Animated.loop(Animated.sequence([
      Animated.timing(wave, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(wave, { toValue: 0, duration: 700, useNativeDriver: true }),
    ]));
    spin.start();
    waveLoop.start();
    return () => { spin.stop(); waveLoop.stop(); };
  }, [rotation, wave]);
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: isListening || isSending || isSpeaking ? 450 : 1200, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: isListening || isSending || isSpeaking ? 450 : 1200, useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [isListening, isSending, isSpeaking, pulse]);

  const send = (value: string) => {
    const text = value.trim();
    if (!text || isSending) return;
    setDraft(text);
    setTyped(text);
    onSend(text);
  };

  const status = isListening ? (bn ? 'শুনছি…' : 'Listening…') : isSending ? (bn ? 'ভাবছি…' : 'Thinking…') : isSpeaking ? (bn ? 'বলছি…' : 'Speaking…') : (bn ? 'প্রস্তুত' : 'Ready');
  const activeTasks = Number(isListening) + Number(isSending) + Number(isSpeaking);
  const confidence = isSending ? 92 : messages.length ? 98 : 96;
  const memoryCount = Math.min(memory.facts.length, 200);
  const recent = messages.filter(m => m.role === 'user').slice(-5).reverse();
  const replyCount = messages.filter(m => m.role === 'assistant').length;
  const listeningScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, isListening ? 1.12 : 1.04] });
  const rotationDeg = rotation.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const colGap = 10;
  const usable = Math.max(330, width - 16);
  const leftWidth = usable;
  const rightWidth = usable;
  const centerWidth = usable;

  const quick = bn
    ? [['📞', 'কল', 'কল করো'], ['💬', 'মেসেজ', 'একটা মেসেজ পাঠাও'], ['🟢', 'WhatsApp', 'WhatsApp খোলো'], ['💬', 'Messenger', 'Messenger খোলো'], ['◉', 'IMO', 'IMO খোলো'], ['▦', 'Open App', 'একটা অ্যাপ খোলো'], ['⚙', 'Settings', 'সেটিংস খোলো'], ['▣', 'Screen', 'স্ক্রিন কন্ট্রোল খোলো']]
    : [['📞', 'Call', 'Call someone'], ['💬', 'Message', 'Send a message'], ['🟢', 'WhatsApp', 'Open WhatsApp'], ['💬', 'Messenger', 'Open Messenger'], ['◉', 'IMO', 'Open IMO'], ['▦', 'Open App', 'Open an app'], ['⚙', 'Settings', 'Open settings'], ['▣', 'Screen', 'Open screen controls']];

  return (
    <View style={styles.root}>
      <View pointerEvents="none" style={styles.background}>
        {Array.from({ length: 24 }).map((_, i) => (
          <View key={i} style={[styles.star, { left: `${(i * 37) % 100}%`, top: `${(i * 61) % 100}%`, opacity: 0.18 + (i % 4) * 0.13 }]} />
        ))}
        <View style={styles.gridGlow} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={[styles.content, { paddingBottom: 150 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.topHeader}>
          <View style={styles.brandBlock}>
            <View style={styles.brandIcon}><Text style={styles.brandA}>A</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.brandTitle}>{assistantName}</Text>
              <Text style={styles.brandSub}>{bn ? 'তোমার Personal AI Assistant • স্মার্ট • দ্রুত • সর্বদা প্রস্তুত' : 'Your Personal AI Assistant • Smart • Fast • Always Ready'}</Text>
              <Text style={styles.brandTiny}>{bn ? 'Always With You • Offline First • Super Smart' : 'Always With You • Offline First • Super Smart'}</Text>
            </View>
          </View>
          <Animated.View style={[styles.listeningPill, { transform: [{ scale: listeningScale }] }]}>
            <View style={styles.waveBars}>{[7, 14, 23, 12, 19, 10, 16].map((h, i) => <View key={i} style={[styles.headerWaveBar, { height: h }]} />)}</View>
            <View style={{ flex: 1 }}>
              <Text style={styles.listeningTitle}>{status}</Text>
              <Text style={styles.listeningSub}>{bn ? 'কিছু বলো…' : 'Say something…'}</Text>
            </View>
          </Animated.View>
          <Pressable onPress={onVoice} style={styles.voicePill}><NativeAvatar compact /><Text style={styles.pillText}>Voice: {voiceGender === 'female' ? 'Female' : 'Male'}</Text></Pressable>
          <Pressable onPress={() => send(bn ? 'বাংলা ও English' : 'English and Bengali')} style={styles.langPill}><Text style={styles.pillText}>🌐 {bn ? 'Bengali + English' : 'English + Bengali'}</Text></Pressable>
          <View style={styles.headerActions}>
            <Pressable onPress={onMenu} style={styles.settingsButton} accessibilityRole="button" accessibilityLabel={bn ? 'আরও অপশন' : 'More options'}><Text style={styles.settingsGlyph}>⋮</Text></Pressable>
            <Pressable onPress={onSettings} style={styles.settingsButton} accessibilityRole="button" accessibilityLabel={bn ? 'সেটিংস' : 'Settings'}><Text style={styles.settingsGlyph}>⚙</Text></Pressable>
          </View>
        </View>

        <View style={[styles.columns, { gap: colGap }]}>
          <View style={{ width: leftWidth, gap: 5 }}>
            <GlowCard>
              <PanelTitle icon="◉" title={bn ? 'System Overview' : 'System Overview'} />
              <View style={styles.onlineBadge}><View style={styles.greenDot} /><Text style={styles.onlineText}>{online ? 'Online' : 'Offline'}</Text></View>
              <View style={styles.gaugeGrid}>
                <Gauge label={bn ? 'AI Confidence' : 'AI Confidence'} value={`${confidence}%`} type="green" />
                <Gauge label={bn ? 'Active Tasks' : 'Active Tasks'} value={String(activeTasks)} />
                <Gauge label={bn ? 'Resolved Today' : 'Resolved Today'} value={String(replyCount)} type="purple" />
              </View>
              <View style={styles.smallGrid}>
                <MiniStat icon="☼" label="Latency" value={isSending ? '0.8s' : '0.6s'} />
                <MiniStat icon="▣" label="Memory" value={`${memoryCount}%`} />
                <MiniStat icon="▣" label="Battery" value="—" />
              </View>
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="♟" title={bn ? 'Recent Activity' : 'Recent Activity'} action="View All" onAction={onMenu} />
              {recent.length ? recent.map((m, i) => <ActivityRow key={m.id} icon={i === 0 ? '🟢' : i === 1 ? '▶' : '⚙'} text={m.text} time={formatTime(m.time, language)} />) : <Text style={styles.empty}>{bn ? 'এখনও activity নেই' : 'No activity yet'}</Text>}
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="⬡" title={bn ? 'Quick Commands' : 'Quick Commands'} />
              <View style={styles.quickGrid}>
                {quick.map(([icon, title, command]) => (
                  <Pressable key={title} onPress={() => send(command)} style={styles.quickButton}>
                    <Text style={styles.quickIcon}>{icon}</Text><Text numberOfLines={1} style={styles.quickText}>{title}</Text><Text style={styles.quickArrow}>›</Text>
                  </Pressable>
                ))}
              </View>
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="◇" title={bn ? `Memory (${memoryCount}/200)` : `Memory (${memoryCount}/200)`} action="Manage" onAction={onMenu} />
              <View style={styles.memoryTabs}><Text style={styles.memoryTabActive}>◷ Recent</Text><Text style={styles.memoryTab}>☆ Important</Text><Text style={styles.memoryTab}>♙ Personal</Text><Text style={styles.memoryTab}>▣ Notes</Text></View>
              <View style={styles.searchMemory}><Text style={styles.searchIcon}>⌕</Text><Text style={styles.searchText}>{bn ? 'Search your memory…' : 'Search your memory…'}</Text></View>
              {memory.facts.slice(-3).map((fact, i) => <Text key={`${fact}-${i}`} numberOfLines={1} style={styles.memoryFact}>● {fact}</Text>)}
              {!memory.facts.length ? <Text style={styles.memoryFact}>● {bn ? 'কোনো saved memory নেই' : 'No saved memory yet'}</Text> : null}
            </GlowCard>
          </View>

          <View style={{ width: centerWidth, gap: 5 }}>
            <GlowCard style={styles.centerHeroCard}>
              <View style={styles.centerBubbleLeft}><Text style={styles.bubbleText}>{bn ? `আমি ${assistantName}…\nতোমার সাথে সবসময়\nপ্রস্তুত… ✨` : `I am ${assistantName}…\nAlways ready for you… ✨`}</Text></View>
              <View style={styles.centerBubbleRight}><Text style={styles.bubbleText}>{bn ? 'যেকোনো কাজ\nবলো, আমি\nকরে দেব…' : 'Tell me any task,\nand I will do it…'}</Text></View>
              <View style={styles.heroVisual}>
                <Animated.View pointerEvents="none" style={[styles.orbitRing, { transform: [{ rotate: rotationDeg }] }]} />
                <Animated.View pointerEvents="none" style={[styles.orbitRingInner, { transform: [{ rotate: rotationDeg }] }]} />
                <View style={styles.avatarStage}><View style={styles.avatarGlow} /><Animated.View style={{ transform: [{ scale: listeningScale }] }}><NativeAvatar /></Animated.View></View>
                <View pointerEvents="none" style={styles.liveWave}>
                  {Array.from({ length: 13 }).map((_, i) => (
                    <Animated.View key={i} style={[styles.waveBar, { height: 10 + ((i % 5) * 5), transform: [{ scaleY: wave.interpolate({ inputRange: [0, 1], outputRange: [0.45 + (i % 3) * 0.12, 1 + (i % 4) * 0.18] }) }] }]} />
                  ))}
                </View>
              </View>
              <View style={styles.centerOrbit}><View style={styles.orbitCore}><Text style={styles.orbitA}>A</Text></View></View>
              <View style={styles.sideChipLeft}><Text>◈</Text><Text>AI Assistant</Text></View>
              <View style={styles.sideChipRight}><Text>◉</Text><Text>Files</Text></View>
              <View style={styles.sideStackLeft}>{['▦ Apps', '▣ Messages', '☎ Calls', '◫ Tools'].map(t => <Pressable key={t} onPress={() => send(t)} style={styles.sideChip}><Text style={styles.sideChipText}>{t}</Text></Pressable>)}</View>
              <View style={styles.sideStackRight}>{['▣ Notes', '◌ Reminders', '◎ Web', '◈ More'].map(t => <Pressable key={t} onPress={() => send(t)} style={styles.sideChip}><Text style={styles.sideChipText}>{t}</Text></Pressable>)}</View>
            </GlowCard>

            <View style={styles.centerGaugeRow}>
              <Gauge label="AI Confidence" value={`${confidence}%`} type="green" />
              <Gauge label="Active Tasks" value={String(activeTasks)} />
              <Gauge label="Latency" value={isSending ? '0.8s' : '0.6s'} type="yellow" />
              <Gauge label="System Status" value={online ? 'Online' : 'Offline'} type="green" />
            </View>

            <View style={styles.centerTwoCards}>
              <GlowCard style={{ flex: 1 }}>
                <PanelTitle icon="♟" title={bn ? 'Recent Activity' : 'Recent Activity'} action="View All" onAction={onMenu} />
                {voiceHistory.slice(0, 4).map(item => <ActivityRow key={item.id} icon="🎙" text={item.text} time={formatTime(item.time, language)} />)}
                {!voiceHistory.length ? <Text style={styles.empty}>{bn ? 'Voice command history নেই' : 'No voice command history'}</Text> : null}
              </GlowCard>
              <GlowCard style={styles.voiceAssistantCard}>
                <Text style={styles.voiceCardTitle}>{bn ? 'Voice Assistant' : 'Voice Assistant'}</Text>
                <Pressable onPress={onVoice} style={styles.bigMic}><Text style={styles.bigMicText}>🎙</Text></Pressable>
                <Text style={styles.voiceHint}>{bn ? `Tap to speak\nor say “Hey ${assistantName}”` : `Tap to speak\nor say “Hey ${assistantName}”`}</Text>
              </GlowCard>
            </View>

            <View style={styles.stateStrip}>
              {[["Listening", isListening], ["Thinking", isSending], ["Processing", isSending], ["Speaking", isSpeaking]].map(([label, active]) => <View key={String(label)} style={[styles.stateChip, active ? styles.stateActive : null]}><Text style={styles.stateText}>{String(label)}</Text></View>)}
            </View>
          </View>

          <View style={{ width: rightWidth, gap: 5 }}>
            <GlowCard>
              <PanelTitle icon="♙" title={bn ? 'AI Analysis' : 'AI Analysis'} action={bn ? 'Deep Analysis (Offline)' : 'Deep Analysis (Offline)'} />
              {['Command understood', 'Intent detected', 'Action planning…', 'Executing task…'].map((item, i) => <View key={item} style={styles.checkRow}><View style={styles.check}><Text>✓</Text></View><Text numberOfLines={1} style={styles.checkText}>{bn ? ['Command understood', 'Intent detected', 'Action planning…', 'Executing task…'][i] : item}</Text></View>)}
              <MiniBrain />
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="◌" title={bn ? 'Live Metrics' : 'Live Metrics'} />
              <View style={styles.chart}><View style={styles.chartLine1} /><View style={styles.chartLine2} /><View style={styles.chartLine3} /></View>
              <View style={styles.metricFour}><MiniMetric label="CPU" value="—" /><MiniMetric label="RAM" value={`${memoryCount}%`} /><MiniMetric label="Storage" value="—" /><MiniMetric label="Temp." value="—" /></View>
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="●" title={bn ? 'System Status' : 'System Status'} />
              {[
                ['Offline Brain', 'Active', true],
                ['Voice Engine', isListening ? 'Listening' : 'Active', true],
                ['Internet', online ? 'Connected (Optional)' : 'Offline', online],
                ['Apps Access', 'Active', true],
                ['Permissions', 'All Granted', true],
              ].map(([label, value, good]) => <View key={String(label)} style={styles.systemRow}><View style={[styles.statusDot, { backgroundColor: good ? '#2EFF89' : '#FFB52E' }]} /><Text style={styles.systemLabel}>{label}</Text><Text numberOfLines={1} style={styles.systemValue}>{String(value)}</Text></View>)}
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="▣" title={bn ? 'Latest Command' : 'Latest Command'} action="View All" onAction={onMenu} />
              {messages.slice(-3).reverse().map(m => <ActivityRow key={m.id} icon={m.role === 'user' ? '🟢' : 'A'} text={m.text} time={formatTime(m.time, language)} />)}
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="♧" title={bn ? 'Notifications' : 'Notifications'} action="View All" onAction={onMenu} />
              <ActivityRow icon="🔔" text={accountLoggedIn ? 'Account connected' : 'Login required'} time={formatTime(clock.getTime(), language)} />
              <ActivityRow icon="⚙" text={`${OFFLINE_100_FEATURE_COUNT}/100 offline features`} time="Now" />
              <ActivityRow icon="🔋" text={wakeWordEnabled ? 'Background voice ready' : 'Background voice off'} time="Now" />
            </GlowCard>

            <GlowCard>
              <PanelTitle icon="◉" title={bn ? 'Background Mode' : 'Background Mode'} />
              <View style={styles.backgroundMode}><View style={styles.backgroundOrb}><Text style={styles.backgroundA}>A</Text></View><Text style={styles.backgroundText}>{wakeWordEnabled ? (bn ? 'Abir background-এ চলছে' : 'Abir is running in background') : (bn ? 'Background mode বন্ধ' : 'Background mode off')}</Text><View style={[styles.toggleDot, wakeWordEnabled && styles.toggleOn]} /></View>
            </GlowCard>

            <Pressable onPress={onFeatures} style={styles.featureBanner}><Text style={styles.featureBadge}>100/100</Text><Text style={styles.featureTitle}>{bn ? 'Offline Feature Pack' : 'Offline Feature Pack'}</Text><Text style={styles.featureSub}>{bn ? 'সব ১০০টি feature দেখুন →' : 'View all 100 features →'}</Text></Pressable>
          </View>
        </View>
      </ScrollView>

      <View style={styles.composerWrap}>
        <View style={styles.composer}>
          <View style={styles.composerWave}>{[8, 15, 24, 12, 20, 10, 17].map((h, i) => <View key={i} style={[styles.waveBar, { height: h }]} />)}</View>
          <View style={{ flex: 1 }}>
            <TextInput value={typed} onChangeText={v => { setTyped(v); setDraft(v); }} onSubmitEditing={() => send(typed)} placeholder={bn ? `Hello, I’m ${assistantName}!  কীভাবে সাহায্য করব?` : `Hello, I’m ${assistantName}!  How can I help you today?`} placeholderTextColor="#B98A90" style={styles.composerInput} returnKeyType="send" />
            <Text style={styles.composerStatus}>{status}</Text>
          </View>
          <Pressable onPress={onVoice} style={styles.composerMic}><Text>🎙</Text></Pressable>
          <Pressable onPress={() => send(typed)} style={styles.composerSend}><Text>➤</Text></Pressable>
        </View>
        <View style={styles.bottomNav}>
          <NavItem icon="⌂" label="Home" active />
          <NavItem icon="▢" label="Chat" onPress={() => send('চ্যাট মোড')} />
          <NavItem icon="⌘" label="Tools" onPress={onMenu} />
          <NavItem icon="◇" label="Memory" onPress={onMenu} />
          <NavItem icon="▣" label="Files" onPress={onMenu} />
          <NavItem icon="⚙" label="Settings" onPress={onSettings} />
        </View>
      </View>
    </View>
  );
}

function NavItem({ icon, label, active, onPress }: { icon: string; label: string; active?: boolean; onPress?: () => void }) {
  return <Pressable onPress={onPress} style={[styles.navItem, active && styles.navActive]}><Text style={styles.navIcon}>{icon}</Text><Text style={[styles.navLabel, active && styles.navLabelActive]}>{label}</Text></Pressable>;
}

function MiniStat({ icon, label, value }: { icon: string; label: string; value: string }) {
  return <View style={styles.miniStat}><Text style={styles.miniStatIcon}>{icon}</Text><View style={{ flex: 1 }}><Text style={styles.miniStatLabel}>{label}</Text><Text style={styles.miniStatValue}>{value}</Text></View></View>;
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return <View style={styles.miniMetric}><Text style={styles.miniMetricLabel}>{label}</Text><Text style={styles.miniMetricValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({

  heroVisual: { alignItems: 'center', justifyContent: 'center', position: 'relative', minHeight: 190 },
  orbitRing: { position: 'absolute', width: 178, height: 178, borderRadius: 89, borderWidth: 2, borderColor: 'rgba(48,220,255,0.55)', borderStyle: 'dashed' },
  orbitRingInner: { position: 'absolute', width: 158, height: 158, borderRadius: 79, borderWidth: 1, borderColor: 'rgba(181,71,255,0.75)' },
  liveWave: { position: 'absolute', bottom: 4, flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 18, backgroundColor: 'rgba(3,12,35,0.82)', borderWidth: 1, borderColor: 'rgba(64,224,255,0.45)' },
  waveBar: { width: 3, borderRadius: 3, backgroundColor: '#FF3548' },
  root: { flex: 1, backgroundColor: '#050505' },
  background: { ...StyleSheet.absoluteFillObject, overflow: 'hidden', backgroundColor: '#050505' },
  star: { position: 'absolute', width: 2, height: 2, borderRadius: 1, backgroundColor: '#FF5262', shadowColor: '#FF2638', shadowOpacity: 0.9, shadowRadius: 7 },
  gridGlow: { position: 'absolute', left: '10%', right: '10%', top: '18%', height: '50%', borderRadius: 300, borderWidth: 1, borderColor: '#4A0B12', opacity: 0.8 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 12, paddingTop: 10 },
  topHeader: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 12, flexWrap: 'wrap' },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  brandBlock: { width: '43%', flexDirection: 'row', alignItems: 'center', gap: 4 },
  brandIcon: { width: 37, height: 37, borderRadius: 12, borderWidth: 1, borderColor: '#FF3548', backgroundColor: '#22080D', alignItems: 'center', justifyContent: 'center', shadowColor: '#FF2638', shadowOpacity: 0.9, shadowRadius: 10, elevation: 7 },
  brandA: { color: '#FFECEE', fontSize: 22, fontWeight: '900', textShadowColor: '#FF5362', textShadowRadius: 7 },
  brandTitle: { color: '#FFF4F5', fontSize: 22, fontWeight: '900' },
  brandSub: { color: '#E7C3C7', fontSize: 10.2, fontWeight: '700' },
  brandTiny: { color: '#B9878D', fontSize: 7.8, marginTop: 1 },
  listeningPill: { width: '46%', minHeight: 49, borderRadius: 27, borderWidth: 1.5, borderColor: '#FF2638', backgroundColor: '#130507', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, shadowColor: '#FF2638', shadowOpacity: 0.6, shadowRadius: 12, elevation: 8 },
  waveBars: { width: 31, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 2, marginRight: 4 },
  headerWaveBar: { width: 2, borderRadius: 2, backgroundColor: '#FF5A68', shadowColor: '#FF5A68', shadowOpacity: 0.9, shadowRadius: 5 },
  listeningTitle: { color: '#F6FBFF', fontSize: 16.5, fontWeight: '900' },
  listeningSub: { color: '#C88B91', fontSize: 11.2, marginTop: 1 },
  voicePill: { width: '31%', minHeight: 39, borderRadius: 20, borderWidth: 1, borderColor: '#7A1722', backgroundColor: '#180609', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, gap: 2 },
  langPill: { width: '31%', minHeight: 39, borderRadius: 20, borderWidth: 1, borderColor: '#7A1722', backgroundColor: '#180609', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  pillText: { color: '#FCE5E7', fontSize: 9.6, fontWeight: '800', textAlign: 'center' },
  settingsButton: { width: 42, height: 42, borderRadius: 12, borderWidth: 1, borderColor: '#8A1B28', backgroundColor: '#180609', alignItems: 'center', justifyContent: 'center' },
  settingsGlyph: { color: '#FFE7E9', fontSize: 22 },
  columns: { flexDirection: 'column', alignItems: 'stretch' },
  card: { borderWidth: 1, borderColor: '#8F1724', borderRadius: 18, backgroundColor: 'rgba(14,4,6,0.96)', padding: 12, overflow: 'hidden', shadowColor: '#FF2638', shadowOpacity: 0.22, shadowRadius: 9, elevation: 5 },
  panelTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 },
  panelTitleLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 3 },
  panelIcon: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#4A0B12', borderWidth: 1, borderColor: '#FF3548', alignItems: 'center', justifyContent: 'center' },
  panelIconText: { color: '#FF7B86', fontSize: 12, fontWeight: '900' },
  panelTitle: { color: '#FFECEE', fontSize: 11.2, fontWeight: '900' },
  panelAction: { color: '#FF6572', fontSize: 8.6, fontWeight: '800' },
  onlineBadge: { position: 'absolute', right: 5, top: 5, borderRadius: 10, paddingHorizontal: 4, paddingVertical: 2, borderWidth: 1, borderColor: '#2EFF89', backgroundColor: '#10251A', flexDirection: 'row', gap: 2, alignItems: 'center' },
  greenDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#39F58D' },
  onlineText: { color: '#65FFA8', fontSize: 7.8, fontWeight: '900' },
  gaugeGrid: { flexDirection: 'row', gap: 3, marginTop: 13 },
  gaugeBox: { flex: 1, minWidth: 0, borderWidth: 1, borderColor: '#711722', borderRadius: 7, paddingVertical: 8, alignItems: 'center', backgroundColor: '#170609' },
  gaugeLabel: { color: '#E5B8BD', fontSize: 7.2, fontWeight: '700', marginBottom: 3 },
  gaugeRing: { width: 33, height: 33, borderRadius: 17, borderWidth: 3, alignItems: 'center', justifyContent: 'center', backgroundColor: '#22080D' },
  gaugeValue: { fontSize: 11.2, fontWeight: '900' },
  smallGrid: { flexDirection: 'row', gap: 3, marginTop: 3 },
  miniStat: { flex: 1, borderWidth: 1, borderColor: '#63131D', borderRadius: 6, padding: 3, flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#120507' },
  miniStatIcon: { color: '#FF5A68', fontSize: 12 },
  miniStatLabel: { color: '#B9878D', fontSize: 6.4 },
  miniStatValue: { color: '#FFECEE', fontSize: 10.5, fontWeight: '800', marginTop: 1 },
  activityRow: { minHeight: 42, borderTopWidth: 1, borderTopColor: '#4A1018', flexDirection: 'row', alignItems: 'center', gap: 3 },
  activityIcon: { width: 16, height: 16, borderRadius: 5, backgroundColor: '#350B11', alignItems: 'center', justifyContent: 'center' },
  activityText: { flex: 1, color: '#F4DADD', fontSize: 8.1, fontWeight: '600' },
  activityTime: { color: '#B57D84', fontSize: 7.1 },
  empty: { color: '#A8787E', fontSize: 9, paddingVertical: 8, textAlign: 'center' },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 3 },
  quickButton: { width: '48.7%', minHeight: 54, borderWidth: 1, borderColor: '#741621', borderRadius: 7, backgroundColor: '#1C070A', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 4, gap: 3 },
  quickIcon: { width: 15, height: 15, textAlign: 'center', color: '#FF7480', fontSize: 12 },
  quickText: { flex: 1, color: '#FCE5E7', fontSize: 8.2, fontWeight: '800' },
  quickArrow: { color: '#FF5362', fontSize: 15 },
  memoryTabs: { flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 4, borderBottomWidth: 1, borderBottomColor: '#4A1018' },
  memoryTab: { color: '#A8797F', fontSize: 6.9 },
  memoryTabActive: { color: '#FFD0D5', fontSize: 6.9, fontWeight: '900' },
  searchMemory: { height: 22, borderWidth: 1, borderColor: '#741621', borderRadius: 11, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, marginVertical: 4 },
  searchIcon: { color: '#FF5362', fontSize: 15 },
  searchText: { color: '#A8797F', fontSize: 7.9, marginLeft: 4 },
  memoryFact: { color: '#F2DADD', fontSize: 7.9, lineHeight: 11 },
  centerHeroCard: { minHeight: 390, padding: 4, alignItems: 'center', justifyContent: 'flex-end', position: 'relative', backgroundColor: 'rgba(4,13,34,0.94)' },
  centerBubbleLeft: { position: 'absolute', left: 4, top: 34, maxWidth: '43%', borderWidth: 1, borderColor: '#FF3548', backgroundColor: '#25080D', borderRadius: 10, padding: 4, shadowColor: '#FF2638', shadowOpacity: 0.6, shadowRadius: 8 },
  centerBubbleRight: { position: 'absolute', right: 4, top: 54, maxWidth: '43%', borderWidth: 1, borderColor: '#FF3548', backgroundColor: '#25080D', borderRadius: 10, padding: 4, shadowColor: '#FF2638', shadowOpacity: 0.6, shadowRadius: 8 },
  bubbleText: { color: '#FFE9EB', fontSize: 9.6, lineHeight: 10, fontWeight: '700' },
  avatarStage: { marginTop: 25, alignItems: 'center', justifyContent: 'center', shadowColor: '#FF2638', shadowOpacity: 0.9, shadowRadius: 30, elevation: 15 },
  avatarGlow: { position: 'absolute', width: 140, height: 140, borderRadius: 70, backgroundColor: '#4A0B12', opacity: 0.55 },
  centerOrbit: { width: 98, height: 42, borderRadius: 21, borderWidth: 2, borderColor: '#FF3548', alignItems: 'center', justifyContent: 'center', marginTop: -4, transform: [{ rotateX: '58deg' }], shadowColor: '#FF3EFF', shadowOpacity: 0.7, shadowRadius: 15 },
  orbitCore: { width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderColor: '#FF5362', backgroundColor: '#1A0609', alignItems: 'center', justifyContent: 'center', transform: [{ rotateX: '-58deg' }] },
  orbitA: { color: '#FFECEE', fontSize: 22, fontWeight: '900', textShadowColor: '#FF5362', textShadowRadius: 10 },
  sideChipLeft: { position: 'absolute', left: 4, top: 10, flexDirection: 'row', gap: 3, alignItems: 'center', borderWidth: 1, borderColor: '#761722', backgroundColor: '#22080D', borderRadius: 7, padding: 3 },
  sideChipRight: { position: 'absolute', right: 4, top: 13, flexDirection: 'row', gap: 3, alignItems: 'center', borderWidth: 1, borderColor: '#761722', backgroundColor: '#22080D', borderRadius: 7, padding: 3 },
  sideStackLeft: { position: 'absolute', left: 2, top: 94, gap: 3 },
  sideStackRight: { position: 'absolute', right: 2, top: 113, gap: 3 },
  sideChip: { borderWidth: 1, borderColor: '#741621', backgroundColor: '#1B070A', borderRadius: 6, paddingVertical: 4, paddingHorizontal: 5, minWidth: 50 },
  sideChipText: { color: '#F1DADD', fontSize: 7.8, fontWeight: '800' },
  centerGaugeRow: { flexDirection: 'row', gap: 3 },
  centerTwoCards: { flexDirection: 'row', gap: 4 },
  voiceAssistantCard: { width: '31%', alignItems: 'center' },
  voiceCardTitle: { color: '#FFECEE', fontSize: 9.4, fontWeight: '900', marginBottom: 3 },
  bigMic: { width: 45, height: 45, borderRadius: 23, borderWidth: 2, borderColor: '#FF3548', backgroundColor: '#25080D', alignItems: 'center', justifyContent: 'center', shadowColor: '#FF5362', shadowOpacity: 0.7, shadowRadius: 10 },
  bigMicText: { fontSize: 22 },
  voiceHint: { color: '#C88B91', fontSize: 7.5, textAlign: 'center', lineHeight: 8, marginTop: 4 },
  stateStrip: { flexDirection: 'row', gap: 3 },
  stateChip: { flex: 1, minHeight: 30, borderWidth: 1, borderColor: '#741621', borderRadius: 8, backgroundColor: '#07162E', alignItems: 'center', justifyContent: 'center' },
  stateActive: { borderColor: '#FF3548', backgroundColor: '#25080D', shadowColor: '#FF3548', shadowOpacity: 0.45, shadowRadius: 8 },
  stateText: { color: '#F1DADD', fontSize: 8.4, fontWeight: '900' },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 3 },
  check: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#17452B', borderWidth: 1, borderColor: '#39F58D', alignItems: 'center', justifyContent: 'center' },
  checkText: { color: '#F2DADD', fontSize: 8.1, flex: 1 },
  chart: { height: 50, borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#4A1018', position: 'relative', overflow: 'hidden', backgroundColor: '#170609' },
  chartLine1: { position: 'absolute', left: '-5%', right: '-5%', top: 25, height: 2, backgroundColor: '#39F58D', transform: [{ rotate: '-10deg' }] },
  chartLine2: { position: 'absolute', left: '-5%', right: '-5%', top: 21, height: 2, backgroundColor: '#FF5362', transform: [{ rotate: '13deg' }] },
  chartLine3: { position: 'absolute', left: '-5%', right: '-5%', top: 31, height: 2, backgroundColor: '#FF3548', transform: [{ rotate: '-5deg' }] },
  metricFour: { flexDirection: 'row', marginTop: 4 },
  miniMetric: { flex: 1, borderRightWidth: 1, borderRightColor: '#4A1018', alignItems: 'center' },
  miniMetricLabel: { color: '#B9878D', fontSize: 6.8 },
  miniMetricValue: { color: '#FFECEE', fontSize: 10.2, fontWeight: '900', marginTop: 1 },
  systemRow: { minHeight: 23, borderTopWidth: 1, borderTopColor: '#4A1018', flexDirection: 'row', alignItems: 'center', gap: 4 },
  statusDot: { width: 8, height: 8, borderRadius: 4, shadowColor: '#3BFF9A', shadowOpacity: 0.9, shadowRadius: 6 },
  systemLabel: { flex: 1, color: '#AFC9E2', fontSize: 7.6 },
  systemValue: { color: '#38FF9C', fontSize: 7.6, fontWeight: '900', maxWidth: '55%' },
  backgroundMode: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  backgroundOrb: { width: 31, height: 31, borderRadius: 16, borderWidth: 1, borderColor: '#C14CFF', backgroundColor: '#081A3A', alignItems: 'center', justifyContent: 'center' },
  backgroundA: { color: '#E9D9FF', fontSize: 22, fontWeight: '900' },
  backgroundText: { flex: 1, color: '#AFC7DF', fontSize: 7.8, lineHeight: 8 },
  toggleDot: { width: 24, height: 13, borderRadius: 7, backgroundColor: '#17304E', borderWidth: 1, borderColor: '#2A5C89' },
  toggleOn: { backgroundColor: '#24C8FF', borderColor: '#6DEBFF' },
  featureBanner: { borderWidth: 1, borderColor: '#A74EFF', borderRadius: 10, backgroundColor: '#190A3D', padding: 6, shadowColor: '#A74EFF', shadowOpacity: 0.5, shadowRadius: 10 },
  featureBadge: { alignSelf: 'flex-start', color: '#FFE8FF', fontSize: 9, fontWeight: '900', backgroundColor: '#5A1A9A', borderRadius: 7, paddingHorizontal: 4, paddingVertical: 2 },
  featureTitle: { color: '#F7E9FF', fontSize: 10.8, fontWeight: '900', marginTop: 3 },
  featureSub: { color: '#BE8FEA', fontSize: 8.1, marginTop: 2 },
  composerWrap: { position: 'absolute', left: 5, right: 5, bottom: 3 },
  composer: { minHeight: 54, borderRadius: 28, borderWidth: 1.5, borderColor: '#2ACDFF', backgroundColor: '#061B3D', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, shadowColor: '#2ACDFF', shadowOpacity: 0.55, shadowRadius: 14, elevation: 10 },
  composerWave: { width: 32, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 2, marginRight: 4 },
  composerInput: { color: '#EAF8FF', fontSize: 13.5, fontWeight: '800', padding: 0, height: 26 },
  composerStatus: { color: '#7EA9D0', fontSize: 7.9 },
  composerMic: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: '#1C77B7', backgroundColor: '#0A2850', alignItems: 'center', justifyContent: 'center' },
  composerSend: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: '#2CCEFF', backgroundColor: '#0B3C67', alignItems: 'center', justifyContent: 'center', marginLeft: 3 },
  bottomNav: { height: 50, marginTop: 3, borderRadius: 24, borderWidth: 1, borderColor: '#1A63A1', backgroundColor: '#031229', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', height: 44, borderRadius: 18 },
  navActive: { backgroundColor: '#0B3A6A' },
  navIcon: { color: '#A7D4F7', fontSize: 18 },
  navLabel: { color: '#6E93B5', fontSize: 8.1, marginTop: 1, fontWeight: '800' },
  navLabelActive: { color: '#FFF1F2' },
});
