import { Platform, PermissionsAndroid } from 'react-native';
import { listenForText } from './voiceInput';
import {
  enrollSpeakerSample,
  verifyLiveSpeaker,
  type SpeakerVerificationResult,
} from './speakerVerification';
import { startWakeWord, stopWakeWord, pauseWakeWord, resumeWakeWord, setWakeWordOverlayStatus, cancelSpeechRecognition } from './androidActions';

// One owner controls the native background microphone service. The desired
// state survives temporary foreground microphone sessions.
let backgroundVoiceDesired = false;

export async function startBackgroundVoice(): Promise<boolean> {
  if (Platform.OS !== 'android') return false;
  try {
    const started = await startWakeWord();
    backgroundVoiceDesired = Boolean(started);
    return Boolean(started);
  } catch {
    backgroundVoiceDesired = false;
    return false;
  }
}

export async function pauseBackgroundVoice(): Promise<boolean> {
  if (Platform.OS !== 'android' || !backgroundVoiceDesired) return true;
  try { return await pauseWakeWord(); } catch { return false; }
}

export async function setBackgroundVoiceOverlayStatus(
  status: 'listening' | 'thinking' | 'working' | 'speaking' | 'idle' | 'recovering',
): Promise<boolean> {
  if (Platform.OS !== 'android' || !backgroundVoiceDesired) return false;
  try { return await setWakeWordOverlayStatus(status); } catch { return false; }
}

export async function stopBackgroundVoice(): Promise<boolean> {
  backgroundVoiceDesired = false;
  if (Platform.OS !== 'android') return true;
  try { return await stopWakeWord(); } catch { return false; }
}

export async function cancelForegroundVoiceInput(): Promise<boolean> {
  if (Platform.OS !== 'android') return true;
  try { return await cancelSpeechRecognition(); } catch { return false; }
}

export async function resumeBackgroundVoice(): Promise<boolean> {
  if (!backgroundVoiceDesired || Platform.OS !== 'android') return false;
  try { return await resumeWakeWord(); } catch { return false; }
}

export function isBackgroundVoiceDesired(): boolean {
  return backgroundVoiceDesired;
}
import type { AssistantLanguage } from './offlineBrain';

/**
 * Abir AI's single JavaScript microphone gate.
 *
 * Every foreground voice operation (conversation + owner voice verification)
 * passes through this gate. The background foreground-service is paused, not
 * destroyed, before foreground recognition so there is one microphone owner
 * and Android can continue the same service when the app moves behind another app.
 */
let activeOperation: Promise<unknown> = Promise.resolve();

async function acquireMicrophone(): Promise<() => void> {
  let release!: () => void;
  const previous = activeOperation;
  activeOperation = new Promise<void>(resolve => { release = resolve; });
  await previous;

  if (Platform.OS === 'android') {
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
      release();
      throw new Error('Microphone permission is required.');
    }
    // The native background wake-word recognizer must never own the mic while
    // a foreground operation is running. Keep its foreground service alive.
    await pauseBackgroundVoice().catch(() => {});
  }

  return release;
}

async function exclusive<T>(operation: () => Promise<T>): Promise<T> {
  const release = await acquireMicrophone();
  try {
    return await operation();
  } finally {
    release();
  }
}

export async function listenWithUnifiedVoiceManager(
  language: AssistantLanguage,
): Promise<string | null> {
  return exclusive(() => listenForText(language));
}

export async function enrollOwnerVoiceWithUnifiedManager() {
  try { return await exclusive(() => enrollSpeakerSample()); }
  finally { if (backgroundVoiceDesired) await resumeBackgroundVoice(); }
}

export async function verifyOwnerVoiceWithUnifiedManager(): Promise<SpeakerVerificationResult> {
  try { return await exclusive(() => verifyLiveSpeaker()); }
  finally { if (backgroundVoiceDesired) await resumeBackgroundVoice(); }
}
