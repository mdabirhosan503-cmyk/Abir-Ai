# Abir AI 3.8 Power Mode

- Stronger Bengali/English mixed command normalization.
- Conversation context is passed to offline and online reasoning for follow-ups.
- App-specific WhatsApp/Messenger/IMO call flow uses Android Accessibility with user permission.
- App Lock accepts the phone security credential path when available; Abir does not store biometric templates.
- Voice selection scores exact locale, gender metadata, and enhanced voices.
- General Android Settings is intentionally not exposed.
- Online coding mode is strengthened for complete multi-file project output.
