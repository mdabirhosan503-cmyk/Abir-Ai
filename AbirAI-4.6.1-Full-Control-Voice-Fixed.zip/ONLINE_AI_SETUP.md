# Abir AI — Gemini Online + Offline Hybrid

Abir AI now uses Google's Gemini `generateContent` API for online answers and automatically falls back to the existing offline brain when the internet or Gemini is unavailable.

## Build-time variables

- `EXPO_PUBLIC_GEMINI_API_KEY` — supplied from the GitHub Actions secret `GEMINI_API_KEY`.
- `EXPO_PUBLIC_GEMINI_MODEL` — optional; defaults to `gemini-2.5-flash`.

Google's current Gemini API documentation lists `gemini-2.5-flash` as a stable model and the pricing page lists a Free Tier for it, subject to Google's quotas and eligibility. Check Google's current limits before heavy use.

## GitHub Actions

The build step that runs the Expo/Android build must have:

```yaml
env:
  EXPO_PUBLIC_GEMINI_API_KEY: ${{ secrets.GEMINI_API_KEY }}
  EXPO_PUBLIC_GEMINI_MODEL: gemini-2.5-flash
```

Do not put the actual API key in source files, commits, or chat messages.

## Security note

Because `EXPO_PUBLIC_*` values are bundled into a client APK, a determined person can extract the key from the APK. This direct-Gemini setup is suitable for a personal/test APK. For a public APK, use a small backend/proxy and keep the Gemini key only on the server.
