# Abir AI 3.3.0 Final

Offline-first Android Assistant.

## Voice
- On-device Android speech recognition is preferred when available.
- Bengali and English offline recognition are both attempted for mixed-language speech.
- Recognition alternatives are ranked by command relevance instead of blindly taking the first result.
- Wake-word variants include Abir/আবির/এবির/আদিরাবির and common combined spellings.
- Voice mode forces spoken replies so the assistant can be used hands-free.

## Understanding
- More tolerant Bangla/English mixed phrasing and filler words.
- More natural app-opening and device-control phrases.
- Offline brain does not describe itself as an “offline AI”; it identifies as an Android Assistant that works both offline and online.

## Controls
- Existing Accessibility/global actions, app launching, screen reading, volume and system settings are retained.
- Android security boundaries still apply; the app does not bypass protected permissions or security controls.

## Memory
- Existing 200-item persistent memory limit is retained.

## Version
- Expo version: 3.3.0
- Android versionCode: 11


## 3.4.0 Voice + Natural Understanding Upgrade
- Offline intent repair now understands polite/indirect Bengali and mixed Bangla-English command phrasing instead of requiring exact command wording.
- Online Gemini prompt now explicitly handles conversational, indirect, incomplete, and mixed-language phrasing.
- Voice input tries true Android on-device recognition first, then both Bengali and English locales, ranks multiple candidates, and automatically retries the other locale.
- Wake-word service uses Android's true on-device recognizer when the device supports it, with a normal recognizer fallback.
- TTS now uses the configured voice selection, avoids language/voice conflicts, and retries with the closest available voice when needed.
- Added one-tap male/female voice preference toggle in the header.
- Added voice-first "repeat that" and "stop speaking" commands.
- Existing offline/online operation, Android controls, camera vision, app lock, wake word, and 200-item local memory are retained.


## 3.5.0 Final UI/Background polish
- Login/Account control moved to the top header for quick access; removed the duplicate bottom floating ID button.
- Header account button visibly shows configured/login state.
- Wake-word foreground service now returns START_STICKY and can be recreated by Android after process/service termination when the OS permits it.
- Existing offline/online voice, Android controls, camera, app lock, and local memory features remain enabled.
- Android battery/microphone/privacy policies can still limit true 24/7 background listening; the app does not bypass those protections.

## 3.6.0 Power Control + Boss
- Abir executes device actions only after an explicit user command; it does not autonomously decide to perform phone actions.
- General Android Settings is intentionally NOT exposed as an assistant action.
- Wi-Fi, Bluetooth, and mobile-data commands open the Android-provided control panel where direct app toggling is restricted by Android.
- Shutdown/restart/reboot commands open the Android power menu because ordinary apps cannot silently reboot or power off the device.
- Existing Accessibility global actions remain available only for explicit commands.
- Conversational and online Gemini replies address the user as “বস” (or “Boss” in English).
- Version: 3.6.0
- Android versionCode: 15


## 3.6.1 Coding + Boss Offline
- Offline replies always address the user as বস/Boss.
- Added offline basic coding assistance for Python, HTML, JavaScript and Kotlin/Android.
- Online Gemini is instructed to provide coding, explanations and debugging help.
- Device actions remain explicit-command only; general Settings control remains excluded.
