# Abir AI 3.9.0 — Universal Screen Control

Adds Android Accessibility-based UI automation for supported apps:
- open an installed app
- find a search control
- type text into an EditText/search field
- submit search using IME Enter or a search button
- try to open the first relevant result
- generic type, tap-by-text, Enter, and scroll helpers

Example: “YouTube থেকে কোরআন তেলাওয়াত চালাও”

This requires the user to enable Abir AI in Android Accessibility settings. UI automation can vary between app versions and screens.
