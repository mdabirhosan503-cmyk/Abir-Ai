import * as Speech from 'expo-speech';
import type { AssistantLanguage } from './offlineBrain';
import type { VoiceGenderPreference } from './voicePreferences';

export type SpeechVoice = Speech.Voice;

export type SelectedVoice = {
  voice: SpeechVoice | null;
  genderMatched: boolean;
  languageMatched: boolean;
};

function genderMatch(voice: SpeechVoice, requested: VoiceGenderPreference) {
  const metadata = `${voice.name} ${voice.identifier}`.toLowerCase();
  const terms =
    requested === 'male'
      ? /(?:^|[^a-z])(male|man|masculine|m)(?:$|[^a-z])|(?:[_-])(male|m)(?:[_-]|$)/
      : /(?:^|[^a-z])(female|woman|feminine|f)(?:$|[^a-z])|(?:[_-])(female|f)(?:[_-]|$)/;
  return terms.test(metadata);
}

function matchesLanguage(voice: SpeechVoice, language: AssistantLanguage) {
  const wanted = language === 'bn' ? 'bn' : 'en';
  return voice.language.toLowerCase().startsWith(wanted);
}

export function chooseSpeechVoice(
  voices: SpeechVoice[],
  requested: VoiceGenderPreference,
  language: AssistantLanguage,
): SelectedVoice {
  if (!voices.length) {
    return { voice: null, genderMatched: false, languageMatched: false };
  }

  const sorted = [...voices].sort((left, right) => {
    const score = (voice: SpeechVoice) =>
      (matchesLanguage(voice, language) ? 10 : 0) +
      (genderMatch(voice, requested) ? 4 : 0) +
      (voice.quality === Speech.VoiceQuality.Enhanced ? 2 : 0) +
      (voice.language.toLowerCase() === (language === 'bn' ? 'bn-bd' : 'en-us') ? 3 : 0);
    return score(right) - score(left);
  });
  const voice = sorted[0];
  return {
    voice,
    languageMatched: matchesLanguage(voice, language),
    genderMatched: genderMatch(voice, requested),
  };
}

export async function loadSpeechVoices(): Promise<SpeechVoice[]> {
  try {
    return await Speech.getAvailableVoicesAsync();
  } catch {
    return [];
  }
}

export function voiceFallbackMessage(
  preference: VoiceGenderPreference,
  language: AssistantLanguage,
) {
  const gender = preference === 'male'
    ? language === 'bn' ? 'পুরুষ' : 'male'
    : language === 'bn' ? 'নারী' : 'female';
  return language === 'bn'
    ? `এই ফোনে ${gender} কণ্ঠের তথ্য পাওয়া যায়নি। কাছের উপলভ্য ভাষার ভয়েস ব্যবহার করছি।`
    : `This phone doesn’t identify a ${gender} voice for that language. I’m using the closest available voice.`;
}
