import AsyncStorage from '@react-native-async-storage/async-storage';

const MEMORY_STORAGE_KEY = 'abir-ai-local-memory-v1';
// Abir AI keeps at most 200 persistent remembered facts.
// When a 201st fact is added, the oldest fact is automatically removed.
export const MAX_MEMORY_ITEMS = 200;
const MAX_TOPICS = 5;
const MAX_MEMORY_TEXT = 180;

export type AssistantMemory = {
  facts: string[];
  recentTopics: string[];
};

export const EMPTY_MEMORY: AssistantMemory = {
  facts: [],
  recentTopics: [],
};

export function isAssistantMemory(value: unknown): value is AssistantMemory {
  if (!value || typeof value !== 'object') return false;
  const memory = value as Partial<AssistantMemory>;
  return (
    Array.isArray(memory.facts) &&
    Array.isArray(memory.recentTopics) &&
    memory.facts.every((item) => typeof item === 'string') &&
    memory.recentTopics.every((item) => typeof item === 'string')
  );
}

export async function loadLocalMemory(): Promise<AssistantMemory> {
  const saved = await AsyncStorage.getItem(MEMORY_STORAGE_KEY);
  if (!saved) return EMPTY_MEMORY;

  try {
    const parsed: unknown = JSON.parse(saved);
    return isAssistantMemory(parsed)
      ? {
          facts: parsed.facts.slice(-MAX_MEMORY_ITEMS),
          recentTopics: parsed.recentTopics.slice(-MAX_TOPICS),
        }
      : EMPTY_MEMORY;
  } catch {
    return EMPTY_MEMORY;
  }
}

export async function saveLocalMemory(memory: AssistantMemory) {
  await AsyncStorage.setItem(
    MEMORY_STORAGE_KEY,
    JSON.stringify({
      facts: memory.facts.slice(-MAX_MEMORY_ITEMS),
      recentTopics: memory.recentTopics.slice(-MAX_TOPICS),
    }),
  );
}

export async function clearLocalMemory() {
  await AsyncStorage.removeItem(MEMORY_STORAGE_KEY);
}

function cleanFact(value: string) {
  return value
    .trim()
    .replace(/^(?:that|যে)\s+/i, '')
    .replace(/[.!?।]+$/g, '')
    .slice(0, MAX_MEMORY_TEXT);
}

export function handleMemoryCommand(
  text: string,
  current: AssistantMemory,
): { memory: AssistantMemory; reply: string; handled: boolean } | null {
  const remember = text.match(
    /^(?:please\s+)?remember(?:\s+that)?\s+(.+)$/i,
  );
  const rememberBn = text.match(/^(?:মনে রাখো|মনে রেখো|মনে রাখবে)\s+(.+)$/);
  const directPreference = text.match(
    /^(?:my name is|i (?:like|prefer)|my favorite \w+ is)\s+(.+)$/i,
  );
  const directPreferenceBn = text.match(
    /^(?:আমার নাম|আমার পছন্দ(?:ের)?\s+\S+\s+হলো|আমি .{1,60} পছন্দ করি)\s*(.*)$/u,
  );
  const rememberedFact =
    remember?.[1] ??
    rememberBn?.[1] ??
    directPreference?.[0] ??
    directPreferenceBn?.[0];

  if (rememberedFact) {
    const fact = cleanFact(rememberedFact);
    if (!fact) return null;
    const withoutDuplicate = current.facts.filter(
      (item) => item.toLocaleLowerCase() !== fact.toLocaleLowerCase(),
    );
    const memory = {
      ...current,
      facts: [...withoutDuplicate, fact].slice(-MAX_MEMORY_ITEMS),
    };
    return {
      memory,
      handled: true,
      reply: /[\u0980-\u09FF]/.test(text)
        ? `ঠিক আছে, এটা শুধু এই ডিভাইসেই মনে রাখলাম: “${fact}”`
        : `Got it. I saved this only on this device: “${fact}”`,
    };
  }

  if (/^(?:what do you remember|তুমি কী মনে রেখেছ|কি মনে রেখেছ|কী মনে রেখেছ)\??$/i.test(text.trim())) {
    const items = current.facts.length
      ? current.facts.map((fact) => `• ${fact}`).join('\n')
      : /[\u0980-\u09FF]/.test(text)
        ? 'এখনো আলাদা করে কোনো পছন্দ বা তথ্য মনে রাখিনি।'
        : 'I haven’t saved any preferences or facts yet.';
    return {
      memory: current,
      handled: true,
      reply: items,
    };
  }

  const forget = text.match(/^(?:forget|ভুলে যাও|মুছে ফেলো)\s+(.+)$/i);
  if (forget) {
    const needle = cleanFact(forget[1]).toLocaleLowerCase();
    const remaining = current.facts.filter(
      (fact) => !fact.toLocaleLowerCase().includes(needle),
    );
    const memory = { ...current, facts: remaining };
    return {
      memory,
      handled: true,
      reply: remaining.length === current.facts.length
        ? 'ওই তথ্যটা খুঁজে পেলাম না। সেটিংস থেকে সব স্মৃতি মুছতে পারো।'
        : 'ঠিক আছে, ওই তথ্যটা এই ডিভাইসের স্মৃতি থেকে মুছে দিলাম।',
    };
  }

  return null;
}

export function addRecentTopic(
  current: AssistantMemory,
  text: string,
): AssistantMemory {
  const topic = text.trim().replace(/\s+/g, ' ').slice(0, MAX_MEMORY_TEXT);
  if (topic.length < 3 || /[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(topic)) {
    return current;
  }
  if (
    /(?:password|passcode|pin|otp|secret|token|পাসওয়ার্ড|পিন|ওটিপি|গোপন কোড)/i.test(
      topic,
    ) ||
    /^(?:open|launch|start|call|phone|dial|ওপেন|খোলো|চালু|কল|ফোন)\b/i.test(
      topic,
    )
  ) {
    return current;
  }
  const topics = current.recentTopics.filter((item) => item !== topic);
  return { ...current, recentTopics: [...topics, topic].slice(-MAX_TOPICS) };
}
