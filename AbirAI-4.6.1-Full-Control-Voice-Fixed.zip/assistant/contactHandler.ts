import {
  editSimilarity,
  normalizeName,
  phonetic,
} from './appNameMatcher';

export type ContactPhone = {
  contactId: string;
  displayName: string;
  phoneNumber: string;
  phoneLabel: string;
};

function contactScore(query: string, contact: ContactPhone) {
  const q = normalizeName(query);
  const name = normalizeName(contact.displayName);
  if (!q || !name) return 0;
  if (q === name || q.replace(/\s/g, '') === name.replace(/\s/g, '')) return 1;
  if (name.startsWith(q) || q.startsWith(name)) return 0.9;

  const qPhonetic = phonetic(q);
  const namePhonetic = phonetic(name);
  const phoneticScore =
    qPhonetic.length >= 3 && namePhonetic.length >= 3
      ? editSimilarity(qPhonetic, namePhonetic)
      : 0;
  const normalizedScore =
    q.replace(/\s/g, '').length >= 4 && name.replace(/\s/g, '').length >= 4
      ? editSimilarity(q.replace(/\s/g, ''), name.replace(/\s/g, ''))
      : 0;
  return Math.max(phoneticScore, normalizedScore);
}

export function matchContacts(query: string, contacts: ContactPhone[]) {
  const scored = contacts
    .map((contact) => ({ contact, score: contactScore(query, contact) }))
    .filter(({ score }) => score >= 0.64)
    .sort((a, b) => b.score - a.score);
  if (!scored.length) return [];

  const topScore = scored[0].score;
  const deduplicated = new Map<string, ContactPhone>();
  scored
    .filter(({ score }) => topScore - score <= 0.1)
    .forEach(({ contact }) =>
      deduplicated.set(`${contact.contactId}:${contact.phoneNumber}`, contact),
    );
  return [...deduplicated.values()].slice(0, 8);
}

export function selectContactChoice(
  input: string,
  candidates: ContactPhone[],
): ContactPhone | null {
  const normalized = normalizeName(input)
    .replace(/[০-৯]/g, (digit) => String('০১২৩৪৫৬৭৮৯'.indexOf(digit)))
    .replace(/\s*(?:number|no|নম্বর|টা|তম)\s*/g, ' ')
    .trim();
  const numeric = normalized.match(/^(?:#\s*)?(\d{1,2})$/);
  if (numeric) return candidates[Number(numeric[1]) - 1] ?? null;

  const ordinalMap: Record<string, number> = {
    first: 0,
    one: 0,
    প্রথম: 0,
    second: 1,
    two: 1,
    দ্বিতীয়: 1,
    দ্বিতীয়: 1,
    third: 2,
    three: 2,
    তৃতীয়: 2,
    তৃতীয়: 2,
  };
  const ordinal = ordinalMap[normalized];
  if (ordinal !== undefined) return candidates[ordinal] ?? null;

  const matches = matchContacts(input, candidates);
  return matches.length === 1 ? matches[0] : null;
}

export function formatContactChoicePrompt(
  contacts: ContactPhone[],
  language: 'bn' | 'en',
) {
  const list = contacts
    .map((contact, index) => {
      const tail = contact.phoneNumber.replace(/\D/g, '').slice(-4);
      const type = contact.phoneLabel ? ` · ${contact.phoneLabel}` : '';
      return `${index + 1}. ${contact.displayName}${type} · •••• ${tail}`;
    })
    .join('\n');

  return language === 'bn'
    ? `একাধিক মিল পেয়েছি। কোন নম্বরে কল করব? নাম বা নম্বর বেছে নাও:\n${list}`
    : `I found several matching numbers. Which one should I call? Choose a name or number:\n${list}`;
}

export function formatCallConfirmation(
  contact: ContactPhone,
  language: 'bn' | 'en',
) {
  const tail = contact.phoneNumber.replace(/\D/g, '').slice(-4);
  return language === 'bn'
    ? `${contact.displayName}${contact.phoneLabel ? ` (${contact.phoneLabel})` : ''}-কে কল করব? নম্বরের শেষ চার সংখ্যা ${tail}। নিশ্চিত করতে “হ্যাঁ”, বাতিল করতে “না” বলো।`
    : `Call ${contact.displayName}${contact.phoneLabel ? ` (${contact.phoneLabel})` : ''} ending in ${tail}? Reply “yes” to continue or “no” to cancel.`;
}
