export type MessageRequest = {
  app: 'messenger' | 'imo';
  recipient: string;
  message: string;
};

function clean(value: string) {
  return value.trim().replace(/^["“”'‘’]|["“”'‘’]$/g, '').replace(/\s+/g, ' ');
}

export function extractMessageRequest(text: string): MessageRequest | null {
  const t = text.trim();
  const bn = t.match(/^(?:মেসেঞ্জার|messenger)\s*(?:এ|তে|-এ|-তে)?\s+(.+?)\s*কে?\s+(?:মেসেজ|বার্তা)\s+(?:দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|করো)\s*[:：-]?\s*(.+)$/iu)
    || t.match(/^(?:ইমু|imo)\s*(?:এ|তে|-এ|-তে)?\s+(.+?)\s*কে?\s+(?:মেসেজ|বার্তা)\s+(?:দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|করো)\s*[:：-]?\s*(.+)$/iu);
  if (bn) {
    const app = /^(?:ইমু|imo)/iu.test(t) ? 'imo' : 'messenger';
    const recipient = clean(bn[1].replace(/\s+কে$/u, ''));
    const message = clean(bn[2]);
    if (recipient && message) return { app, recipient, message };
  }
  const en = t.match(/^(?:send|message|text)\s+(?:a\s+)?message\s+to\s+(.+?)\s+(?:on|via|in)\s+(messenger|imo)\s*[:,-]?\s+(.+)$/i)
    || t.match(/^(?:send|message|text)\s+(.+?)\s+(?:on|via|in)\s+(messenger|imo)\s*[:,-]?\s+(.+)$/i);
  if (en) {
    const recipient = clean(en[1]);
    const app = en[2].toLowerCase() === 'imo' ? 'imo' : 'messenger';
    const message = clean(en[3]);
    if (recipient && message) return { app, recipient, message };
  }
  return null;
}

export function messageAutomationReply(request: MessageRequest, language: 'bn' | 'en', result: 'sent' | 'not-enabled' | 'failed') {
  if (result === 'sent') return language === 'bn'
    ? `${request.app === 'imo' ? 'IMO' : 'Messenger'}-এ ${request.recipient}-কে মেসেজ পাঠিয়ে দিয়েছি।`
    : `I sent the message to ${request.recipient} on ${request.app === 'imo' ? 'IMO' : 'Messenger'}.`;
  if (result === 'not-enabled') return language === 'bn'
    ? 'মেসেজ পাঠাতে Android Accessibility Service চালু করতে হবে। Settings খুলে অনুমতি দাও।'
    : 'Android Accessibility Service must be enabled. Open Settings and allow Abir AI.';
  return language === 'bn'
    ? `${request.app === 'imo' ? 'IMO' : 'Messenger'}-এ ${request.recipient}-কে মেসেজ পাঠানো যায়নি।`
    : `I could not send the message to ${request.recipient}.`;
}
