const { withAndroidManifest } = require('expo/config-plugins');

const MAIN_ACTION = 'android.intent.action.MAIN';
const LAUNCHER_CATEGORY = 'android.intent.category.LAUNCHER';
const REQUIRED_PERMISSIONS = [
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.CALL_PHONE',
  'android.permission.READ_CONTACTS',
  'android.permission.RECORD_AUDIO',
];

function hasAndroidName(nodes, name) {
  return Array.isArray(nodes) && nodes.some((node) => node?.$?.['android:name'] === name);
}

module.exports = function withAppDiscoveryQueries(config) {
  return withAndroidManifest(config, (configWithManifest) => {
    const manifest = configWithManifest.modResults.manifest;
    const queries = Array.isArray(manifest.queries) ? manifest.queries : [];
    const alreadyPresent = queries.some((query) =>
      (query.intent ?? []).some(
        (intent) =>
          hasAndroidName(intent.action, MAIN_ACTION) &&
          hasAndroidName(intent.category, LAUNCHER_CATEGORY),
      ),
    );

    if (!alreadyPresent) {
      manifest.queries = [
        ...queries,
        {
          intent: [
            {
              action: [{ $: { 'android:name': MAIN_ACTION } }],
              category: [{ $: { 'android:name': LAUNCHER_CATEGORY } }],
            },
          ],
        },
      ];
    }

    const permissions = Array.isArray(manifest['uses-permission'])
      ? manifest['uses-permission']
      : [];
    for (const permission of REQUIRED_PERMISSIONS) {
      const present = permissions.some(
        (item) => item?.$?.['android:name'] === permission,
      );
      if (!present) {
        permissions.push({ $: { 'android:name': permission } });
      }
    }
    manifest['uses-permission'] = permissions;

    return configWithManifest;
  });
};
