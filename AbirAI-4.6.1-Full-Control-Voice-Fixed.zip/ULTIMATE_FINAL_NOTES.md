# Abir AI 4.1.0 — Ultimate Final

Final polish pass:
- More tolerant Bangla/mixed speech normalization.
- Better command-word ranking for offline speech recognition.
- More natural offline greeting identity.
- Voice playback tuning for Bengali/English.
- App-lock lifecycle guard to reduce repeated/early lock failures.
- Existing universal screen control and power controls retained.
- Existing Accessibility, calling, camera, Gemini, memory, and app automation retained.

Background:
The wake-word/foreground service remains the always-available voice entry point, subject to Android battery/background restrictions. Android may stop background services on some devices; battery optimization/auto-start settings may still need user permission.

Safety/security:
No Android security bypass is added. Protected OS settings remain subject to Android's permission model.
