# Abir AI 4.0.0 — Power Control

Adds stronger Android controls without exposing the general Android Settings screen:
- volume up/down/mute
- set media volume by percentage
- flashlight on/off
- media play/pause/next/previous
- normal/vibrate ringer mode
- back/home/recents/notifications/quick settings/power menu/lock/screenshot/split-screen
- screen reading, typing, tapping, scrolling, and universal in-app search automation
- installed-app launching and call/contact flows

Important Android limits:
- Modern Android protects some radios/settings from silent third-party toggling. Wi-Fi/Bluetooth/mobile-data commands therefore use the OS control panel rather than bypassing Android security.
- Accessibility must be explicitly enabled by the user for screen automation.
- No general Settings screen automation or security-bypass logic is included.
