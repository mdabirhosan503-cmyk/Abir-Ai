import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantMemory } from './localMemory';

export type EmotionState = 'calm' | 'happy' | 'frustrated' | 'worried' | 'sad' | 'excited' | 'neutral';
export type DecisionOption = { name: string; score: number; reason: string };

const FEEDBACK_KEY = 'abir-ai-intelligence-feedback-v1';
const MAX_FEEDBACK = 50;

type FeedbackItem = { text: string; positive: boolean; time: number };

const BN = /[\u0980-\u09FF]/u;
const clean = (text: string) => text.normalize('NFKC').replace(/\s+/g, ' ').trim();

export function detectEmotion(text: string): EmotionState {
  const t = clean(text).toLowerCase();
  if (/(?:ভালো লাগছে|খুশি|দারুণ|অসাধারণ|great|awesome|happy|excited|yay|ধন্যবাদ|thanks)/iu.test(t)) return 'happy';
  if (/(?:রাগ|বিরক্ত|বিরক্ত লাগছে|frustrat|angry|annoyed|fed up|ঘৃণা)/iu.test(t)) return 'frustrated';
  if (/(?:চিন্তা|ভয়|ভয়|দুশ্চিন্তা|worried|anxious|afraid|scared|tension)/iu.test(t)) return 'worried';
  if (/(?:মন খারাপ|দুঃখ|কষ্ট|sad|unhappy|upset|lonely)/iu.test(t)) return 'sad';
  if (/(?:দারুণ হবে|উত্তেজিত|exciting|excited|can't wait|অপেক্ষা করতে পারছি না)/iu.test(t)) return 'excited';
  return 'neutral';
}

export function emotionOpening(language: 'bn' | 'en', emotion: EmotionState): string {
  if (language === 'bn') {
    switch (emotion) {
      case 'happy': return 'বস, তোমার কথায় ভালো লাগার অনুভূতি আছে—চলো এটাকে আরও ভালোভাবে এগিয়ে নিই।';
      case 'frustrated': return 'বস, বুঝতে পারছি বিষয়টা বিরক্তিকর লাগছে। আমি ধাপে ধাপে সহজ সমাধান বের করছি।';
      case 'worried': return 'বস, চিন্তার জায়গাটা আগে পরিষ্কার করি। তারপর সবচেয়ে নিরাপদ ও ভালো বিকল্পটা দেখি।';
      case 'sad': return 'বস, তোমার কথায় মন খারাপের ইঙ্গিত আছে। আমি শান্তভাবে পাশে থেকে বিষয়টা গুছিয়ে নিতে সাহায্য করছি।';
      case 'excited': return 'বস, তোমার আগ্রহটা পরিষ্কার—চলো ভালো দিকগুলো যাচাই করে এগোই।';
      default: return '';
    }
  }
  switch (emotion) {
    case 'happy': return 'Boss, I can hear the positive energy in that. Let’s build on it thoughtfully.';
    case 'frustrated': return 'Boss, I can tell this is frustrating. I’ll break it down and look for the simplest useful path.';
    case 'worried': return 'Boss, let’s separate the risks from the facts first, then choose the safest useful option.';
    case 'sad': return 'Boss, that sounds difficult. I’ll keep this calm and practical and help you work through it.';
    case 'excited': return 'Boss, I can tell you’re excited. Let’s check the important details before moving ahead.';
    default: return '';
  }
}

function isDecisionRequest(text: string): boolean {
  return /(?:কোনটা ভালো|কোনটা ভাল|কোনটা নেব|কোনটা করা ভালো|কোনটা করব|কি করা উচিত|কী করা উচিত|সেরা কোনটা|পরামর্শ দাও|তোমার মতামত|তুমি হলে|which is better|what should i do|which one should|recommend|best option|pros and cons|compare)/iu.test(text);
}

function splitOptions(text: string): string[] {
  const parts = text
    .replace(/^(?:তাহলে|এখন|আমার|আমি|তুমি|which|what|should|recommend|please)\s+/iu, '')
    .split(/\s+(?:বা|অথবা|নাকি|versus|vs\.?|or)\s+/iu)
    .map(clean)
    .filter(Boolean);
  return [...new Set(parts)].slice(0, 4);
}

export function analyzeDecision(text: string, language: 'bn' | 'en'): { text: string; options: DecisionOption[] } | null {
  if (!isDecisionRequest(text)) return null;
  const options = splitOptions(text);
  if (options.length < 2) {
    return {
      text: language === 'bn'
        ? 'বস, সিদ্ধান্তটা আরও ভালোভাবে দিতে হলে অন্তত দুইটা বিকল্প দরকার। যেমন: “A নাকি B—কোনটা ভালো?”'
        : 'Boss, I can compare the choices, but I need at least two options. For example: “A or B—which is better?”',
      options: [],
    };
  }
  const scored = options.map((name) => {
    let score = 50;
    const risk = /(?:delete|remove|wipe|factory reset|password|pin|otp|unknown|unsafe|ঝুঁকি|মুছে|ডিলিট|রিসেট)/iu.test(name);
    const vague = name.split(/\s+/).length < 2;
    if (risk) score -= 18;
    if (vague) score -= 2;
    const reason = risk
      ? (language === 'bn' ? 'এটিতে ঝুঁকি বা স্থায়ী পরিবর্তনের সম্ভাবনা আছে।' : 'This may involve risk or an irreversible change.')
      : (language === 'bn' ? 'তুলনামূলকভাবে সহজে যাচাই ও পরিবর্তন করা যায়।' : 'This is relatively easy to verify and adjust.');
    return { name, score, reason };
  }).sort((a, b) => b.score - a.score);
  const winner = scored[0];
  const lines = language === 'bn'
    ? [
        'বস, আমি বিকল্পগুলো তুলনা করে দেখলাম।',
        ...scored.map((o, i) => `${i + 1}. ${o.name} — ${o.score}/100 — ${o.reason}`),
        `\nআমার প্রাথমিক সুপারিশ: ${winner.name}। কারণ: ${winner.reason}`,
        'চূড়ান্ত সিদ্ধান্ত নেওয়ার আগে যদি খরচ, সময় বা অন্য কোনো শর্ত গুরুত্বপূর্ণ হয়, সেটা বললে আমি আবার হিসাব মিলিয়ে দেব।',
      ]
    : [
        'Boss, I compared the options using a local risk-and-reversibility check.',
        ...scored.map((o, i) => `${i + 1}. ${o.name} — ${o.score}/100 — ${o.reason}`),
        `\nMy initial recommendation: ${winner.name}. Reason: ${winner.reason}`,
        'If cost, time, or another constraint matters, tell me and I’ll recalculate the recommendation.',
      ];
  return { text: lines.join('\n'), options: scored };
}

export function buildSelfReview(language: 'bn' | 'en', answer: string): string {
  const trimmed = answer.trim();
  if (!trimmed) return language === 'bn' ? 'উত্তর তৈরি হয়নি।' : 'No answer was produced.';
  const checks = [
    trimmed.length > 20,
    !/(?:আমি নিশ্চিত|definitely|always|never)/iu.test(trimmed) || trimmed.length > 80,
    /(?:কারণ|because|কারণ:|reason)/iu.test(trimmed) || trimmed.length < 140,
  ];
  const score = Math.round((checks.filter(Boolean).length / checks.length) * 100);
  return language === 'bn'
    ? `Self-review: ${score}/100। আমি উত্তরটি সংক্ষিপ্ততা, অতিরিক্ত নিশ্চিত দাবি এবং কারণ ব্যাখ্যার দিক থেকে যাচাই করেছি।`
    : `Self-review: ${score}/100. I checked the answer for concision, overconfident claims, and whether a reason was provided.`;
}

export function planIntelligently(text: string, language: 'bn' | 'en'): string | null {
  const parts = clean(text).split(/\s*(?:এবং তারপর|তারপর|এরপর|পরে|and then|then|after that|next|;|, then)\s*/iu).filter(Boolean).slice(0, 8);
  if (parts.length < 2) return null;
  return language === 'bn'
    ? `বস, আমি কাজটাকে ${parts.length} ধাপে ভাগ করলাম:\n${parts.map((p, i) => `${i + 1}. ${p}`).join('\n')}\n\nপ্রতিটি ধাপের ফল যাচাই করে পরের ধাপে যাওয়া হবে।`
    : `Boss, I split this into ${parts.length} steps:\n${parts.map((p, i) => `${i + 1}. ${p}`).join('\n')}\n\nI’ll verify each step before relying on the next one.`;
}

export async function saveIntelligenceFeedback(text: string, positive: boolean): Promise<void> {
  try {
    const raw = await AsyncStorage.getItem(FEEDBACK_KEY);
    const previous: FeedbackItem[] = raw ? JSON.parse(raw) : [];
    const next = [...previous, { text: clean(text).slice(0, 180), positive, time: Date.now() }].slice(-MAX_FEEDBACK);
    await AsyncStorage.setItem(FEEDBACK_KEY, JSON.stringify(next));
  } catch {
    // Feedback is optional; never break the assistant because storage failed.
  }
}

export async function getFeedbackSummary(language: 'bn' | 'en'): Promise<string> {
  try {
    const raw = await AsyncStorage.getItem(FEEDBACK_KEY);
    const items: FeedbackItem[] = raw ? JSON.parse(raw) : [];
    const positive = items.filter((x) => x.positive).length;
    const negative = items.length - positive;
    return language === 'bn'
      ? `বস, আমার local feedback memory-তে ${items.length}টি feedback আছে—ভালো ${positive}, উন্নতি দরকার ${negative}। এই feedback ভবিষ্যৎ local suggestion-এর ধরন সামঞ্জস্য করতে ব্যবহার করা হবে।`
      : `Boss, local feedback memory contains ${items.length} feedback items: ${positive} positive and ${negative} needing improvement. I use this to tune future local suggestions.`;
  } catch {
    return language === 'bn' ? 'বস, feedback memory এখন পড়া যাচ্ছে না।' : 'Boss, feedback memory is not available right now.';
  }
}

export function memoryIntelligenceHint(language: 'bn' | 'en', memory?: AssistantMemory): string {
  const facts = memory?.facts?.length ?? 0;
  const topics = memory?.recentTopics?.length ?? 0;
  return language === 'bn'
    ? `Memory intelligence: ${facts}টি saved fact এবং ${topics}টি recent topic ব্যবহারযোগ্য। ব্যক্তিগত তথ্যের নতুন অনুমান করা হবে না।`
    : `Memory intelligence: ${facts} saved facts and ${topics} recent topics are available. No new personal facts will be invented.`;
}

export function enhanceOfflineReply(args: {
  text: string;
  language: 'bn' | 'en';
  requestText: string;
  intent: string;
  memory?: AssistantMemory;
  plannedTasks?: string[];
}): string {
  const { text, language, requestText, intent, memory, plannedTasks } = args;
  if (['open-app', 'device-action', 'call-contact', 'call-via-app', 'clear-history', 'screen-control', 'universal-screen-control'].includes(intent)) return text;

  const emotion = detectEmotion(requestText);
  const opening = emotionOpening(language, emotion);
  const decision = analyzeDecision(requestText, language);
  const plan = plannedTasks?.length && plannedTasks.length > 1 ? (language === 'bn'
    ? `\n\nপরিকল্পনা: ${plannedTasks.map((p, i) => `${i + 1}. ${p}`).join(' → ')}`
    : `\n\nPlan: ${plannedTasks.map((p, i) => `${i + 1}. ${p}`).join(' → ')}`) : '';
  const selfReview = /(?:নিজের উত্তর যাচাই|self review|self-review|check your answer|উত্তর যাচাই)/iu.test(requestText)
    ? `\n\n${buildSelfReview(language, text)}`
    : '';
  const feedback = /(?:ভালো হয়েছে|ভালো হয়েছে|ঠিক হয়েছে|ঠিক হয়েছে|good answer|helpful|খারাপ উত্তর|ভুল উত্তর|not helpful|bad answer)/iu.test(requestText)
    ? saveIntelligenceFeedback(requestText, !/(?:খারাপ|ভুল|not helpful|bad)/iu.test(requestText))
    : Promise.resolve();
  void feedback;
  const memoryHint = /(?:memory intelligence|মেমোরি ইন্টেলিজেন্স|কি মনে রেখেছ|কী মনে রেখেছ|what do you remember)/iu.test(requestText)
    ? `\n\n${memoryIntelligenceHint(language, memory)}`
    : '';

  if (decision?.text) return `${opening ? `${opening}\n\n` : ''}${decision.text}${plan}${selfReview}${memoryHint}`;
  return `${opening ? `${opening}\n\n` : ''}${text}${plan}${selfReview}${memoryHint}`;
}

export function getProactiveSuggestion(language: 'bn' | 'en', memory?: AssistantMemory): string {
  const topic = memory?.recentTopics?.[memory.recentTopics.length - 1];
  if (language === 'bn') {
    return topic
      ? `বস, তোমার সাম্প্রতিক বিষয় “${topic}”। চাইলে আমি এটাকে ছোট ছোট ধাপে সাজিয়ে দিতে পারি এবং কোন ধাপ আগে করলে ভালো হবে তা তুলনা করে বলতে পারি।`
      : 'বস, চাইলে আমি তোমার বর্তমান কাজগুলোকে অগ্রাধিকার দিয়ে সাজিয়ে দিতে পারি এবং কোনটা আগে করা ভালো তা কারণসহ বলতে পারি।';
  }
  return topic
    ? `Boss, your recent topic is “${topic}”. I can break it into steps and compare which step is best to do first.`
    : 'Boss, I can prioritize your current tasks and explain which one is best to do first.';
}
