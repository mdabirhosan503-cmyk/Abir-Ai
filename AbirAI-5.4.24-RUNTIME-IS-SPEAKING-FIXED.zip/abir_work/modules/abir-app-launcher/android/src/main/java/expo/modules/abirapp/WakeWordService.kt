package expo.modules.abirapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ValueAnimator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout
import android.net.Uri
import java.util.Locale

/**
 * Abir AI background voice engine.
 *
 * Important design rule: the service owns the microphone only while the app is
 * backgrounded. Foreground JS voice stops this service before opening its own
 * recognizer. The service never creates a second recognizer while one is alive.
 *
 * Android does not allow an app to silently bypass OEM/background restrictions.
 * We therefore use a microphone foreground service, a persistent notification,
 * an optional overlay, and a PendingIntent to reliably return to the app.
 */
class WakeWordService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private var recognizer: SpeechRecognizer? = null
  private var stopping = false
  private var commandMode = false
  private var wakeLock: PowerManager.WakeLock? = null
  private var overlay: View? = null
  private var overlayAnimator: ValueAnimator? = null
  private var windowManager: WindowManager? = null
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var localeIndex = 0
  private var lastWakeAt = 0L
  private var restartDelay = 700L
  private var currentStatus = "idle"
  private var overlayVisible = true

  private val locales = listOf("bn-BD", "bn-IN", "en-US")
  private val restartRunnable = Runnable { startRecognition() }

  override fun onCreate() {
    super.onCreate()
    stopping = false
    createNotificationChannel()
    initTts()
    acquireWakeLock()
    startForegroundServiceNotification("Ready • বললে শুনব")
    showVoiceOverlay("idle")
    startRecognition()
  }

  private fun acquireWakeLock() {
    try {
      val power = getSystemService(POWER_SERVICE) as PowerManager
      wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AbirAI:VoiceEngine").apply {
        setReferenceCounted(false)
        acquire()
      }
    } catch (_: Exception) {}
  }

  private fun initTts() {
    try {
      tts = TextToSpeech(applicationContext) { status ->
        ttsReady = status == TextToSpeech.SUCCESS
      }
    } catch (_: Exception) {
      ttsReady = false
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = getSystemService(NotificationManager::class.java)
      manager.createNotificationChannel(
        NotificationChannel(
          CHANNEL_ID,
          "Abir AI background voice",
          NotificationManager.IMPORTANCE_LOW,
        ).apply {
          description = "Keeps Abir AI voice ready in the background."
          setShowBadge(false)
        },
      )
    }
  }

  private fun appPendingIntent(command: String = ""): PendingIntent? {
    return try {
      val uri = Uri.parse("abir-ai://wake").buildUpon().apply {
        if (command.isNotBlank()) appendQueryParameter("text", command)
      }.build()
      val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        setPackage(packageName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
      }
      PendingIntent.getActivity(
        this,
        (System.currentTimeMillis() and 0x7fffffff).toInt(),
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun startForegroundServiceNotification(status: String) {
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      Notification.Builder(this, CHANNEL_ID)
    } else {
      @Suppress("DEPRECATION")
      Notification.Builder(this)
    }
    builder
      .setContentTitle("Abir AI • Voice")
      .setContentText(status)
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setOngoing(true)
      .setCategory(Notification.CATEGORY_SERVICE)
      .setOnlyAlertOnce(true)
      .setContentIntent(appPendingIntent())
      .setStyle(Notification.BigTextStyle().bigText("Abir AI background voice active. “আবির / Abir” বললে সক্রিয় হবে।"))
    startForeground(NOTIFICATION_ID, builder.build())
  }

  private fun updateNotification(status: String) {
    startForegroundServiceNotification(status)
  }

  private fun normalize(text: String): String = text
    .trim()
    .lowercase(Locale.ROOT)
    .replace(Regex("\\s+"), " ")

  private fun containsWakeWord(text: String): Boolean {
    val value = normalize(text)
    val patterns = listOf(
      "abir", "a beer", "a bir", "এবির", "আবির", "আবীর", "আদির আবির", "আদিরাবির",
    )
    return patterns.any { value.contains(it) }
  }

  private fun stripWakeWord(text: String): String {
    var value = text.trim()
    val patterns = listOf(
      Regex("(?i).*?\\babir\\b"), Regex("(?i).*?\\ba\\s+beer\\b"),
      Regex("(?i).*?\\ba\\s+bir\\b"), Regex("এবির"), Regex("আবির"), Regex("আবীর"),
      Regex("আদির\\s*আবির"), Regex("আদিরাবির"),
    )
    for (pattern in patterns) {
      val next = value.replaceFirst(pattern, "")
      if (next != value) value = next
    }
    return value.trim(' ', ',', '-', '—', ':', '।')
  }

  private fun showVoiceOverlay(status: String) {
    currentStatus = status
    if (!overlayVisible) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
    try {
      val wm = windowManager ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { windowManager = it }
      overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
      overlayAnimator?.cancel()
      overlayAnimator = null

      val density = resources.displayMetrics.density
      val active = status != "idle"
      val accent = when (status) {
        "listening" -> Color.rgb(42, 220, 255)
        "thinking", "working" -> Color.rgb(173, 104, 255)
        "speaking" -> Color.rgb(45, 245, 174)
        else -> Color.rgb(75, 145, 220)
      }
      val root = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding((4 * density).toInt(), (3 * density).toInt(), (4 * density).toInt(), (2 * density).toInt())
        isClickable = true
        setOnClickListener { openAbir("") }
      }
      val orb = TextView(this).apply {
        text = "A"
        gravity = Gravity.CENTER
        textSize = 23f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
          shape = GradientDrawable.OVAL
          setColor(Color.rgb(5, 22, 54))
          setStroke((2 * density).toInt(), accent)
        }
        elevation = 18f * density
        layoutParams = LinearLayout.LayoutParams((54 * density).toInt(), (54 * density).toInt())
      }
      val label = TextView(this).apply {
        text = when (status) {
          "listening" -> "● LISTENING"
          "thinking" -> "◌ THINKING"
          "working" -> "⚙ WORKING"
          "speaking" -> "♫ SPEAKING"
          "recovering" -> "↻ RECOVERING"
          else -> "● READY"
        }
        setTextColor(Color.WHITE)
        textSize = 8.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding((7 * density).toInt(), (3 * density).toInt(), (7 * density).toInt(), (3 * density).toInt())
        background = GradientDrawable().apply {
          setColor(Color.argb(235, 4, 15, 38))
          setStroke((1 * density).toInt(), accent)
          cornerRadius = 12f * density
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
          topMargin = (2 * density).toInt()
        }
      }
      root.addView(orb)
      root.addView(label)

      @Suppress("DEPRECATION")
      val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
      val params = WindowManager.LayoutParams(
        (76 * density).toInt(),
        (82 * density).toInt(),
        type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT,
      ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = (76 * density).toInt()
      }
      wm.addView(root, params)
      overlay = root
      root.translationY = 24f * density
      root.animate().translationY(0f).setDuration(260L).start()

      // Keep the compact orb visible in every background state; pulse faster
      // only while it is actively listening, thinking, working or speaking.
      val animator = ValueAnimator.ofFloat(0.94f, if (active) 1.10f else 1.035f).apply {
        duration = if (active) 560L else 1500L
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener { value ->
          val scale = value.animatedValue as Float
          orb.scaleX = scale
          orb.scaleY = scale
          orb.alpha = if (active) 0.86f + (scale - 0.94f) else 0.96f
        }
      }
      overlayAnimator = animator
      animator.start()

    } catch (_: Exception) {}
  }

  private fun statusLabel(status: String): String = when (status) {
    "listening" -> "শুনছি…"
    "thinking" -> "বুঝছি…"
    "working" -> "কাজ করছি…"
    "speaking" -> "বলছি…"
    "recovering" -> "আবার সংযোগ করছি…"
    else -> status
  }

  private fun speakAck() {
    val speaker = tts ?: return
    if (!ttsReady) {
      showVoiceOverlay("recovering")
      handler.postDelayed({ if (!stopping) listenForCommand() }, 350L)
      return
    }
    showVoiceOverlay("speaking")
    updateNotification("Speaking • হ্যাঁ বস, বলো")
    try {
      val result = speaker.setLanguage(Locale.forLanguageTag("bn-BD"))
      if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
        speaker.setLanguage(Locale.US)
      }
      speaker.setSpeechRate(0.9f)
      speaker.setPitch(0.98f)
      speaker.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { handler.postDelayed({ if (!stopping) { showVoiceOverlay("listening"); listenForCommand() } }, 220L) }
        override fun onError(id: String?) { handler.postDelayed({ if (!stopping) { showVoiceOverlay("listening"); listenForCommand() } }, 220L) }
      })
      val id = "wake-${System.nanoTime()}"
      val resultCode = speaker.speak("হ্যাঁ বস, বলো।", TextToSpeech.QUEUE_FLUSH, Bundle(), id)
      if (resultCode != TextToSpeech.SUCCESS) handler.postDelayed({ if (!stopping) { showVoiceOverlay("listening"); listenForCommand() } }, 250L)
    } catch (_: Exception) {
      handler.postDelayed({ if (!stopping) { showVoiceOverlay("listening"); listenForCommand() } }, 250L)
    }
  }

  private fun openAbir(command: String) {
    val pending = appPendingIntent(command)
    if (pending != null) {
      try {
        pending.send()
        return
      } catch (_: Exception) {}
    }
    try {
      val fallback = packageManager.getLaunchIntentForPackage(packageName)?.apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
      }
      if (fallback != null) startActivity(fallback)
    } catch (_: Exception) {}
  }

  private fun createRecognizer(locale: String, preferOffline: Boolean): SpeechRecognizer? {
    if (!SpeechRecognizer.isRecognitionAvailable(this)) return null
    return try {
      val onDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
      if (preferOffline && onDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
      else SpeechRecognizer.createSpeechRecognizer(this)
    } catch (_: Exception) { null }
  }

  private fun startRecognition() {
    if (stopping || commandMode) return
    handler.removeCallbacks(restartRunnable)
    try { recognizer?.cancel() } catch (_: Exception) {}
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null

    val locale = locales[localeIndex % locales.size]
    localeIndex = (localeIndex + 1) % locales.size
    val onDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
    val instance = createRecognizer(locale, onDevice) ?: run {
      scheduleRestart(5000L)
      return
    }
    recognizer = instance

    instance.setRecognitionListener(object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) {
        restartDelay = 700L
        showVoiceOverlay("listening")
        updateNotification("Listening for “Abir” • $locale")
      }
      override fun onBeginningOfSpeech() { showVoiceOverlay("listening") }
      override fun onRmsChanged(rmsdB: Float) {}
      override fun onBufferReceived(buffer: ByteArray?) {}
      override fun onEndOfSpeech() {}
      override fun onError(error: Int) {
        if (stopping) return
        recognizer?.let { try { it.destroy() } catch (_: Exception) {} }
        recognizer = null
        restartDelay = (restartDelay * 1.6).toLong().coerceAtMost(5000L)
        showVoiceOverlay("recovering")
        updateNotification("Voice recovering…")
        scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1800L else restartDelay)
      }
      override fun onResults(results: Bundle?) {
        if (stopping) return
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val match = matches.firstOrNull { containsWakeWord(it) }
        if (match == null) {
          scheduleRestart(180L)
          return
        }
        val now = System.currentTimeMillis()
        if (now - lastWakeAt < 1800L) {
          scheduleRestart(500L)
          return
        }
        lastWakeAt = now
        commandMode = true
        val command = stripWakeWord(match)
        showVoiceOverlay("thinking")
        updateNotification("Abir activated • শুনছি…")
        try { recognizer?.cancel() } catch (_: Exception) {}
        if (command.isNotBlank()) {
          showVoiceOverlay("working")
          openAbir(command)
          handler.postDelayed({ commandMode = false; if (!stopping) { showVoiceOverlay("idle"); startRecognition() } }, 1800L)
        } else {
          speakAck()
        }
      }
      override fun onPartialResults(partialResults: Bundle?) {}
      override fun onEvent(eventType: Int, params: Bundle?) {}
    })

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, onDevice)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 350L)
    }
    try {
      instance.startListening(intent)
    } catch (_: Exception) {
      try { instance.destroy() } catch (_: Exception) {}
      recognizer = null
      scheduleRestart(1200L)
    }
  }

  private fun listenForCommand() {
    if (stopping) return
    try { recognizer?.cancel() } catch (_: Exception) {}
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null

    val locale = locales[localeIndex % locales.size]
    localeIndex = (localeIndex + 1) % locales.size
    val onDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
    val instance = createRecognizer(locale, onDevice) ?: run {
      commandMode = false
      scheduleRestart(1200L)
      return
    }
    recognizer = instance
    instance.setRecognitionListener(object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) { showVoiceOverlay("listening"); updateNotification("Listening…") }
      override fun onBeginningOfSpeech() { showVoiceOverlay("listening") }
      override fun onRmsChanged(rmsdB: Float) {}
      override fun onBufferReceived(buffer: ByteArray?) {}
      override fun onEndOfSpeech() {}
      override fun onError(error: Int) {
        commandMode = false
        showVoiceOverlay("recovering")
        updateNotification("Ready • বললে শুনব")
        scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1600L else 700L)
      }
      override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val command = matches.firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        commandMode = false
        if (command.isNotBlank()) {
          showVoiceOverlay("working")
          updateNotification("Command received")
          openAbir(command)
          handler.postDelayed({ if (!stopping) { showVoiceOverlay("idle"); updateNotification("Ready • বললে শুনব"); startRecognition() } }, 1800L)
        } else {
          showVoiceOverlay("idle")
          updateNotification("Ready • আবার বলো")
          scheduleRestart(500L)
        }
      }
      override fun onPartialResults(partialResults: Bundle?) {}
      override fun onEvent(eventType: Int, params: Bundle?) {}
    })

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, onDevice)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1900L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 450L)
    }
    try { instance.startListening(intent) } catch (_: Exception) { commandMode = false; scheduleRestart(1000L) }
  }

  private fun scheduleRestart(delay: Long) {
    if (stopping) return
    handler.removeCallbacks(restartRunnable)
    handler.postDelayed(restartRunnable, delay.coerceAtLeast(150L))
  }

  private fun pauseRecognition() {
    commandMode = false
    handler.removeCallbacks(restartRunnable)
    try { recognizer?.cancel() } catch (_: Exception) {}
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null
    updateNotification("Paused • foreground voice manager owns microphone")
  }

  private fun resumeRecognition() {
    if (stopping) stopping = false
    if (recognizer == null && !commandMode) startRecognition()
  }

  private fun hideVoiceOverlay() {
    overlayAnimator?.cancel()
    overlayAnimator = null
    try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
    overlay = null
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_PAUSE -> pauseRecognition()
      ACTION_RESUME -> resumeRecognition()
      ACTION_OVERLAY_SHOW -> { overlayVisible = true; showVoiceOverlay(currentStatus) }
      ACTION_OVERLAY_HIDE -> { overlayVisible = false; hideVoiceOverlay() }
      ACTION_STOP -> { stopping = true; stopSelf() }
      else -> resumeRecognition()
    }
    return START_STICKY
  }

  override fun onTaskRemoved(rootIntent: Intent?) {
    if (!stopping) {
      scheduleRestart(500L)
    }
    super.onTaskRemoved(rootIntent)
  }

  override fun onDestroy() {
    stopping = true
    commandMode = false
    handler.removeCallbacksAndMessages(null)
    try { recognizer?.cancel() } catch (_: Exception) {}
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null
    try { tts?.stop() } catch (_: Exception) {}
    try { tts?.shutdown() } catch (_: Exception) {}
    tts = null
    try { overlayAnimator?.cancel() } catch (_: Exception) {}
    overlayAnimator = null
    hideVoiceOverlay()
    try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
    wakeLock = null
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  companion object {
    const val ACTION_START = "expo.modules.abirapp.action.START_WAKE_WORD"
    const val ACTION_PAUSE = "expo.modules.abirapp.action.PAUSE_WAKE_WORD"
    const val ACTION_RESUME = "expo.modules.abirapp.action.RESUME_WAKE_WORD"
    const val ACTION_OVERLAY_SHOW = "expo.modules.abirapp.action.OVERLAY_SHOW"
    const val ACTION_OVERLAY_HIDE = "expo.modules.abirapp.action.OVERLAY_HIDE"
    const val ACTION_STOP = "expo.modules.abirapp.action.STOP_WAKE_WORD"
    private const val CHANNEL_ID = "abir_ai_wake_word"
    private const val NOTIFICATION_ID = 4401
  }
}
