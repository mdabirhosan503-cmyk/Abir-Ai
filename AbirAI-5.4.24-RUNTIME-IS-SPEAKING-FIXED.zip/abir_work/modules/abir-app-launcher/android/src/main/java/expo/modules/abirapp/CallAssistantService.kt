package expo.modules.abirapp

import android.telecom.Call
import android.telecom.InCallService
import android.os.Build
import android.telecom.PhoneAccountHandle
import org.json.JSONObject

/**
 * Handles the system/SIM call side of Abir's Call Assistant.
 *
 * Android only binds this service when the app has the required phone role.
 * It can answer/control the call, but ordinary third-party apps are not
 * granted unrestricted access to the two-way cellular call audio.
 */
class CallAssistantService : InCallService() {
  companion object {
    @Volatile private var currentCall: Call? = null
    @Volatile private var currentState: Int = Call.STATE_DISCONNECTED
    @Volatile private var currentHandle: String? = null

    fun answerCurrentCall(): Boolean {
      val call = currentCall ?: return false
      return try {
        call.answer(0)
        true
      } catch (_: Exception) { false }
    }

    fun disconnectCurrentCall(): Boolean {
      val call = currentCall ?: return false
      return try {
        call.disconnect()
        true
      } catch (_: Exception) { false }
    }

    fun hasCall(): Boolean = currentCall != null

    fun currentCallInfoJson(): String? {
      val call = currentCall ?: return null
      return try {
        JSONObject().apply {
          put("state", currentState)
          put("stateName", when (currentState) {
            Call.STATE_RINGING -> "ringing"
            Call.STATE_ACTIVE -> "active"
            Call.STATE_DIALING -> "dialing"
            Call.STATE_CONNECTING -> "connecting"
            Call.STATE_DISCONNECTED -> "disconnected"
            else -> "unknown"
          })
          put("handle", currentHandle ?: "")
        }.toString()
      } catch (_: Exception) { null }
    }
  }

  override fun onCallAdded(call: Call) {
    super.onCallAdded(call)
    currentCall = call
    currentState = call.details?.state ?: Call.STATE_NEW
    currentHandle = call.details?.handle?.schemeSpecificPart

    // Only auto-answer when the user explicitly enabled Call Assistant.
    if (CallAssistantPrefs.enabled(this) && isIncoming(call)) {
      try {
        call.answer(0)
      } catch (_: Exception) {}
    }

    call.registerCallback(object : Call.Callback() {
      override fun onStateChanged(call: Call, state: Int) {
        currentState = state
        if (state == Call.STATE_DISCONNECTED) {
          if (currentCall === call) {
            currentCall = null
            currentHandle = null
            currentState = Call.STATE_DISCONNECTED
          }
        }
      }
    })
  }

  override fun onCallRemoved(call: Call) {
    if (currentCall === call) {
      currentCall = null
      currentHandle = null
      currentState = Call.STATE_DISCONNECTED
    }
    super.onCallRemoved(call)
  }

  private fun isIncoming(call: Call): Boolean =
    call.details?.state == Call.STATE_RINGING
}
