package expo.modules.abirapp

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent
import android.os.Bundle
import java.util.concurrent.atomic.AtomicLong

/**
 * Reads notification metadata only after the user explicitly enables
 * Notification Access for Abir AI. It keeps the newest notification in
 * memory for the app and exposes a reply action when the source app offers
 * an Android RemoteInput action.
 */
class AbirNotificationListenerService : NotificationListenerService() {
  companion object {
    @Volatile private var latest: NotificationInfo? = null
    @Volatile private var latestReply: ReplyTarget? = null
    private val sequence = AtomicLong(0)

    data class NotificationInfo(
      val id: Long,
      val packageName: String,
      val title: String,
      val text: String,
      val postedAt: Long,
      val sequence: Long,
    )

    data class ReplyTarget(
      val action: Notification.Action,
      val packageName: String,
    )

    fun latestInfo(): NotificationInfo? = latest

    fun hasReplyAction(): Boolean = latestReply != null

    fun replyToLatest(context: android.content.Context, message: String): Boolean {
      val target = latestReply ?: return false
      val remoteInputs = target.action.remoteInputs ?: return false
      if (remoteInputs.isEmpty()) return false

      return try {
        val intent = Intent()
        val results = Bundle()
        remoteInputs.forEach { input -> results.putCharSequence(input.resultKey, message) }
        android.app.RemoteInput.addResultsToIntent(remoteInputs, intent, results)
        target.action.actionIntent.send(context, 0, intent)
        true
      } catch (_: Exception) {
        false
      }
    }

    fun clearLatest() {
      latest = null
      latestReply = null
    }
  }

  override fun onNotificationPosted(sbn: StatusBarNotification) {
    super.onNotificationPosted(sbn)

    val notification = sbn.notification ?: return
    val extras = notification.extras ?: return

    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
    val text = (
      extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
        ?: extras.getCharSequence(Notification.EXTRA_TEXT)
        ?: extras.getCharSequence(Notification.EXTRA_SUMMARY)
    )?.toString()?.trim().orEmpty()

    if (title.isBlank() && text.isBlank()) return

    val seq = sequence.incrementAndGet()
    latest = NotificationInfo(
      id = sbn.id.toLong(),
      packageName = sbn.packageName ?: "",
      title = title.take(160),
      text = text.take(2000),
      postedAt = System.currentTimeMillis(),
      sequence = seq,
    )

    latestReply = notification.actions
      ?.asSequence()
      ?.firstOrNull { action -> !action.remoteInputs.isNullOrEmpty() }
      ?.let { ReplyTarget(it, sbn.packageName ?: "") }
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification) {
    super.onNotificationRemoved(sbn)
  }
}
