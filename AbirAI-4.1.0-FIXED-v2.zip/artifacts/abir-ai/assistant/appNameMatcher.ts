export type LaunchableApp = {
  label: string;
  packageName: string;
  activityName: string;
};

export function normalizeName(value: string) {
  return value
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\u200c\u200d]/g, '')
    .replace(/[^\w\u0980-\u09FF]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const bengaliToLatin: Record<string, string> = {
  'অ': 'a', 'আ': 'a', 'ই': 'i', 'ঈ': 'i', 'উ': 'u', 'ঊ': 'u', 'ঋ': 'ri',
  'এ': 'e', 'ঐ': 'oi', 'ও': 'o', 'ঔ': 'ou',
  'ক': 'k', 'খ': 'kh', 'গ': 'g', 'ঘ': 'gh', 'ঙ': 'ng',
  'চ': 'ch', 'ছ': 'chh', 'জ': 'j', 'ঝ': 'jh', 'ঞ': 'ny',
  'ট': 't', 'ঠ': 'th', 'ড': 'd', 'ঢ': 'dh', 'ণ': 'n',
  'ত': 't', 'থ': 'th', 'দ': 'd', 'ধ': 'dh', 'ন': 'n',
  'প': 'p', 'ফ': 'f', 'ব': 'b', 'ভ': 'bh', 'ম': 'm',
  'য': 'y', 'র': 'r', 'ল': 'l', 'শ': 'sh', 'ষ': 'sh',
  'স': 's', 'হ': 'h', 'ড়': 'r', 'ঢ়': 'rh', 'য়': 'y',
  'ং': 'ng', 'ঃ': 'h', 'ঁ': 'n', 'ৎ': 't',
  'া': 'a', 'ি': 'i', 'ী': 'i', 'ু': 'u', 'ূ': 'u',
  'ৃ': 'ri', 'ে': 'e', 'ৈ': 'oi', 'ো': 'o', 'ৌ': 'ou',
  '্': '',
};

function transliterate(value: string) {
  return Array.from(value)
    .map((character) => bengaliToLatin[character] ?? character)
    .join('');
}

export function phonetic(value: string) {
  return transliterate(value)
    .toLowerCase()
    .replace(/ph/g, 'f')
    .replace(/wh/g, 'w')
    .replace(/c(?=[eiy])/g, 's')
    .replace(/[cq]/g, 'k')
    .replace(/x/g, 'ks')
    .replace(/v/g, 'b')
    .replace(/[aeiou]/g, '')
    .replace(/(.)\1+/g, '$1');
}

export function editSimilarity(left: string, right: string) {
  const a = Array.from(left);
  const b = Array.from(right);
  if (!a.length || !b.length) return 0;
  if (a.length > b.length) return editSimilarity(right, left);

  let previous = Array.from({ length: a.length + 1 }, (_, index) => index);
  for (let row = 1; row <= b.length; row += 1) {
    const current = [row];
    for (let column = 1; column <= a.length; column += 1) {
      current[column] = Math.min(
        current[column - 1] + 1,
        previous[column] + 1,
        previous[column - 1] + (a[column - 1] === b[row - 1] ? 0 : 1),
      );
    }
    previous = current;
  }
  return 1 - previous[a.length] / Math.max(a.length, b.length);
}

// Bengali aliases augment matching; installed candidates remain entirely dynamic.
const commonBengaliNames: Record<string, string[]> = {
  whatsapp: ['হোয়াটসঅ্যাপ', 'হোয়াটসঅ্যাপ', 'হোয়াটসাপ', 'হোয়াটসাপ'],
  facebook: ['ফেসবুক'],
  youtube: ['ইউটিউব'],
  chrome: ['ক্রোম'],
  instagram: ['ইনস্টাগ্রাম'],
  messenger: ['মেসেঞ্জার'],
  gmail: ['জিমেইল'],
  telegram: ['টেলিগ্রাম'],
  tiktok: ['টিকটক'],
};

function appNameVariants(app: LaunchableApp) {
  const label = normalizeName(app.label);
  const packageParts = app.packageName.split('.');
  const variants = [
    label,
    normalizeName(packageParts.join(' ')),
    normalizeName(packageParts.slice(-2).join(' ')),
  ];

  for (const [englishName, bengaliNames] of Object.entries(commonBengaliNames)) {
    if (label.replace(/\s/g, '').includes(englishName)) {
      variants.push(...bengaliNames.map(normalizeName));
    }
  }

  return variants;
}

function nameScore(query: string, app: LaunchableApp) {
  const normalizedQuery = normalizeName(query);
  const compactQuery = normalizedQuery.replace(/\s/g, '');
  const queryPhonetic = phonetic(normalizedQuery);
  const labels = appNameVariants(app);
  let best = 0;

  for (const label of labels) {
    const compactLabel = label.replace(/\s/g, '');
    if (normalizedQuery === label || compactQuery === compactLabel) return 1;
    if (compactQuery.length >= 3 && compactLabel.includes(compactQuery)) {
      best = Math.max(best, 0.94);
    } else if (compactLabel.length >= 3 && compactQuery.includes(compactLabel)) {
      best = Math.max(best, 0.91);
    }

    const labelPhonetic = phonetic(label);
    if (queryPhonetic.length >= 4 && labelPhonetic.length >= 4) {
      best = Math.max(best, editSimilarity(queryPhonetic, labelPhonetic));
    }

    if (compactQuery.length >= 5 && compactLabel.length >= 5) {
      best = Math.max(best, editSimilarity(compactQuery, compactLabel));
    }
  }

  return best;
}

export function matchInstalledApps(
  query: string,
  apps: LaunchableApp[],
): LaunchableApp[] {
  const scored = apps
    .map((app) => ({ app, score: nameScore(query, app) }))
    .filter(({ score }) => score >= 0.68)
    .sort((left, right) => right.score - left.score);
  if (!scored.length) return [];

  // An exact app-name match must win over broader names such as
  // "YouTube" vs "YouTube Music".
  const exactMatches = scored
    .filter(({ score }) => score === 1)
    .map(({ app }) => app);
  if (exactMatches.length) return exactMatches.slice(0, 8);

  const topScore = scored[0].score;
  return scored
    .filter(({ score }) => topScore - score <= 0.08)
    .slice(0, 8)
    .map(({ app }) => app);
}

function choiceIndex(input: string, count: number) {
  const normalized = normalizeName(input)
    .replace(/[০-৯]/g, (digit) => String('০১২৩৪৫৬৭৮৯'.indexOf(digit)))
    .replace(/\s*(?:number|no|নম্বর|টা|তম)\s*/g, ' ')
    .trim();
  const numeric = normalized.match(/^(?:#\s*)?(\d{1,2})$/);
  if (numeric) {
    const index = Number(numeric[1]) - 1;
    return index >= 0 && index < count ? index : null;
  }

  const ordinals = [
    /^(?:first|one|প্রথম|এক|১ম)(?: one|টা|টি)?$/,
    /^(?:second|two|দ্বিতীয়|দ্বিতীয়|দুই|২য়|২য়)(?: one|টা|টি)?$/,
    /^(?:third|three|তৃতীয়|তৃতীয়|তিন|৩য়|৩য়)(?: one|টা|টি)?$/,
    /^(?:fourth|four|চার|চতুর্থ)(?: one|টা|টি)?$/,
    /^(?:fifth|five|পাঁচ|পঞ্চম)(?: one|টা|টি)?$/,
  ];
  const index = ordinals.findIndex((pattern) => pattern.test(normalized));
  return index >= 0 && index < count ? index : null;
}

export function selectAppChoice(
  input: string,
  candidates: LaunchableApp[],
): LaunchableApp | null {
  const index = choiceIndex(input, candidates.length);
  if (index !== null) return candidates[index] ?? null;

  const matches = matchInstalledApps(input, candidates);
  return matches.length === 1 ? matches[0] : null;
}

export function appChoicePrompt(
  candidates: LaunchableApp[],
  language: 'bn' | 'en',
) {
  const listed = candidates
    .map((app, index) => {
      const packageTail = app.packageName.split('.').slice(-2).join('.');
      return `${index + 1}. ${app.label} (${packageTail})`;
    })
    .join('\n');

  return language === 'bn'
    ? `একাধিক অ্যাপ মিলে গেছে। কোনটি খুলব? নাম বলো বা নম্বর লিখো:\n${listed}`
    : `I found multiple matching apps. Which one should I open? Say the name or reply with a number:\n${listed}`;
}

export function noMatchingAppReply(query: string) {
  return `I couldn’t find an installed app named “${query}” with a launchable activity.`;
}
