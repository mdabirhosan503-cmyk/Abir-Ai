
function normalizeCommonSpeechVariants(value: string) {
  return value
    .replace(/ইউটিউব/giu, 'youtube')
    .replace(/হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ/giu, 'whatsapp')
    .replace(/মেসেঞ্জার/giu, 'messenger')
    .replace(/ইমো/giu, 'imo')
    .replace(/গুগল ক্রোম/giu, 'chrome')
    .replace(/খুলে দাও|খুলে দেন|খুলে দিবা|খুলে দিবেন/giu, 'খোলো')
    .replace(/চালিয়ে দাও|চালিয়ে দাও|চালু করে দাও|চালু করো/giu, 'চালাও')
    .replace(/করে দাও|দিয়ে দাও|দিয়ে দাও/giu, 'দাও');
}

export function normalizeAssistantCommand(text: string) {
  return normalizeCommonSpeechVariants(text)
    .normalize('NFKC')
    .replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)))
    .replace(/[!?।,;:]+/g, ' ')
    // Conversational Bengali/English → compact command language.
    // This lets offline mode understand polite, indirect phrases instead of
    // requiring the user to speak like a fixed command list.
    .replace(/(?:একটু|দয়া করে|দয়া করে|অনুগ্রহ করে|প্লিজ|please|kindly|ভাই|শুনো|শুনুন|hey|hello|hi)\b/gi, ' ')
    // Common Bangla written in Latin letters. Keep this conservative so names/apps are not damaged.
    .replace(/\b(?:khulo|khulbe|open koro|open kore dao|chalu koro|chalu kore dao)\b/gi, 'খোলো')
    .replace(/\b(?:call dao|call koro|phone dao|phone koro|dial dao|dial koro)\b/gi, 'কল দাও')
    .replace(/\b(?:pichone jao|pichhone jao|back jao)\b/gi, 'পিছনে যাও')
    .replace(/\b(?:home e jao|home jao)\b/gi, 'হোমে যাও')
    .replace(/\b(?:recent apps|recent app)\b/gi, 'recent apps')
    .replace(/(?:খুলে\s+(?:দিতে|দেওয়ার|দেওয়ার)\s+পারবে|খুলে\s+দাও|খুলে\s+দিন|খুলে\s+দিও)/giu, 'খোলো')
    .replace(/(?:চালু\s+করে\s+(?:দিতে|দেওয়ার|দেওয়ার)\s+পারবে|চালু\s+করে\s+দাও|চালু\s+করে\s+দিন)/giu, 'চালু করো')
    .replace(/(?:করতে\s+পারবে|করতে\s+পারো|করতে\s+পারি|করতে\s+পারবেন)/giu, 'করো')
    .replace(/(?:দিতে\s+পারবে|দিতে\s+পারো|দিতে\s+পারবেন)/giu, 'দাও')
    .replace(/(?:পারবে\s+কি|পারবে|পারো|পারবেন)\b/giu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}


export type UniversalSearchRequest = {
  appQuery: string;
  searchQuery: string;
};

export function extractUniversalSearchRequest(text: string): UniversalSearchRequest | null {
  const cleaned = normalizeAssistantCommand(text)
    .replace(/(?:একটা|একটি|একটু|please|kindly|আমাকে|আমার জন্য|for me)/giu, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const bn = cleaned.match(
    /^(.*?)\s*(?:থেকে|এ|তে|এর মধ্যে)\s+(.+?)(?:\s+(?:চালাও|চালু করো|প্লে করো|প্লে করে দাও|ছাড়ো|ছাড়ো|চালিয়ে দাও|চালিয়ে দাও|সার্চ করো|সার্চ দাও|খুঁজো|খুঁজে দাও|খুঁজে বের করো|open করো))?$/iu,
  );
  if (bn?.[1] && bn?.[2]) {
    const appQuery = bn[1].trim();
    const searchQuery = bn[2]
      .replace(/(?:চালাও|চালু করো|প্লে করো|প্লে করে দাও|ছাড়ো|ছাড়ো|চালিয়ে দাও|চালিয়ে দাও|সার্চ করো|সার্চ দাও|খুঁজো|খুঁজে দাও|খুঁজে বের করো|open করো)$/iu, '')
      .trim();
    if (appQuery && searchQuery) return { appQuery, searchQuery };
  }

  const en = cleaned.match(
    /^(?:play|search|find|look\s+for|open)\s+(.+?)\s+(?:on|in|inside)\s+(.+?)$/iu,
  );
  if (en?.[1] && en?.[2]) {
    return { appQuery: en[2].trim(), searchQuery: en[1].trim() };
  }

  return null;
}

export function extractAppQuery(text: string) {
  const cleaned = normalizeAssistantCommand(text);
  const openingRequested =
    /(?:\bopen\b|\blaunch\b|\bstart\b|\bgo\s+to\b|\bshow\b|\brun\b|ওপেন|খোলো|খুলুন|খুলে|চালু|ঢুকো|যাও|দেখাও|চালাও)/i.test(cleaned);
  if (!openingRequested) return null;

  const query = cleaned
    .replace(/(?:hey|hello|hi|please|kindly|can you|could you|would you|abir|abira|adiraabir|adira abir|এবির|আবির|আদিরাবির|আদির আবির|আদিরাবিরকে)/gi, ' ')
    .replace(/(?:আমাকে|একটু|দয়া করে|দয়া করে|ভাই|প্লিজ|অনুগ্রহ করে|এখন|এখানে|আমার জন্য|আমার|please|kindly|for me|now|the|my|app)/gi, ' ')
    .replace(/(?:open|launch|start|go\s+to|show|run)/gi, ' ')
    .replace(/(?:ওপেন|খুলে দাও|খুলে দিন|খুলে দিও|খুলুন|খোলো|খুলে|চালু করে দাও|চালু করো|চালু করুন|চালু|চালাও|ঢুকো|দেখাও|যাও|দাও|দিন|দিয়ে দাও|দিতে|করতে|পারবে|পারো|পারবেন|কি|কী|অ্যাপটি|অ্যাপ|টা|টি|টাকে|এখন|এখানে)/gi, ' ')
    .replace(/[?!।,;:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractCallQuery(text: string) {
  const english = text.match(
    /^\s*(?:please\s+)?(?:call|phone|dial|ring)\s+(?:my\s+)?(.+?)\s*$/i,
  );

  // Natural Bengali forms, e.g.
  // "Ashik নামে নাম্বারে কল দাও", "Ashik-কে কল করো",
  // "Ashik এর কাছে ফোন দাও", "আম্মুকে কল করো".
  const bengali = text.match(
    /^\s*(?:আমাকে\s+)?(.+?)(?:\s+নামে)?(?:\s+নাম্বারে|\s+নম্বরে|\s+এর\s+কাছে|\s+কে)?\s+(?:কল|ফোন|ডায়াল|ডায়াল)(?:\s+(?:দাও|দিন|দিতে পারো|করো|করুন|করবে|দিতে পারবে))?\s*$/u,
  );

  const prefix = text.match(
    /^\s*(?:আমাকে\s*)?(?:কল|ফোন|ডায়াল|ডায়াল)\s+(?:(?:করো|করুন|দাও|দিন)\s+)?(.+?)\s*$/u,
  );

  const mixed = text.match(/^\s*(?:call|phone|dial)\s+(?:dao|koro|de|please)?\s*(.+?)\s*$/i);
  const rawQuery = english?.[1] ?? bengali?.[1] ?? prefix?.[1] ?? mixed?.[1];
  if (!rawQuery) return null;

  const query = rawQuery
    .replace(/\b(?:please|now|my)\b/gi, ' ')
    .replace(/[-–—]?\s*কে$/u, ' ')
    .replace(
      /(?:দয়া করে|দয়া করে|একটু|আমার|নামে|নাম্বারে|নম্বরে|এর|কাছে|কে|কল|ফোন|ডায়াল|ডায়াল|করো|করুন|দাও|দিন|দিতে পারো|দিতে পারবে|করবে|এখন)/gu,
      ' ',
    )
    .replace(/[?!।,.:;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractDirectPhoneNumber(text: string) {
  const normalizedDigits = text.replace(/[০-৯]/g, (digit) =>
    String('০১২৩৪৫৬৭৮৯'.indexOf(digit)),
  );

  const match = normalizedDigits.match(/(?:^|\s|["“'‘(])((?:\+?\d[\d\s().-]{6,}\d))(?:$|\s|["”'’)]|[-–—]|(?:-?এ|-?তে|-?একে))/u);
  if (!match) return null;

  const number = match[1].replace(/[^+\d]/g, '');
  const digitsOnly = number.replace(/\D/g, '');
  if (digitsOnly.length < 8 || digitsOnly.length > 15) return null;
  return number;
}
