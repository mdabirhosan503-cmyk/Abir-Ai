package expo.modules.abirapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class AbirAccessibilityService : AccessibilityService() {
  companion object {
    @Volatile private var instance: AbirAccessibilityService? = null
    fun isRunning(): Boolean = instance != null
    fun sendMessage(packageName: String, recipient: String, message: String, callback: (Boolean) -> Unit) {
      val service = instance ?: run { callback(false); return }
      service.startMessageFlow(packageName, recipient, message, callback)
    }
    fun callContact(appName: String, recipient: String, callback: (Boolean) -> Unit) {
      val service = instance ?: run { callback(false); return }
      service.startCallFlow(appName, recipient, callback)
    }
    fun performGlobal(action: String): Boolean {
      val service = instance ?: return false
      val id = when (action.lowercase(Locale.ROOT)) {
        "back" -> GLOBAL_ACTION_BACK
        "home" -> GLOBAL_ACTION_HOME
        "recents" -> GLOBAL_ACTION_RECENTS
        "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
        "quick-settings" -> GLOBAL_ACTION_QUICK_SETTINGS
        "power-menu" -> GLOBAL_ACTION_POWER_DIALOG
        "lock-screen" -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
        "screenshot" -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
        "split-screen" -> if (android.os.Build.VERSION.SDK_INT >= 24) GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN else return false
        else -> return false
      }
      return service.performGlobalAction(id)
    }
    fun readScreen(): String {
      val service = instance ?: return ""
      return service.readScreenText()
    }
    fun searchAndOpenInApp(packageName: String, query: String, callback: (Boolean) -> Unit) {
      val service = instance ?: run { callback(false); return }
      service.startSearchAndOpenFlow(packageName, query, callback)
    }

    fun typeIntoFocusedField(text: String): Boolean {
      val service = instance ?: return false
      return service.typeIntoFocusedFieldInternal(text)
    }

    fun clickTextOnScreen(text: String): Boolean {
      val service = instance ?: return false
      return service.clickTextOnScreenInternal(text)
    }

    fun pressImeEnter(): Boolean {
      val service = instance ?: return false
      return service.pressImeEnterInternal()
    }

    fun scrollScreen(direction: String): Boolean {
      val service = instance ?: return false
      return service.scrollScreenInternal(direction)
    }

  }

  private val handler = Handler(Looper.getMainLooper())

  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
    serviceInfo = serviceInfo.apply {
      eventTypes = 32 or
        2048 or
        16
      feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
      flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
        AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
      notificationTimeout = 80
    }
  }

  override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
  override fun onInterrupt() {}

  override fun onDestroy() {
    instance = null
    handler.removeCallbacksAndMessages(null)
    super.onDestroy()
  }

  private fun nodes(root: AccessibilityNodeInfo?): List<AccessibilityNodeInfo> {
    if (root == null) return emptyList()
    val out = mutableListOf<AccessibilityNodeInfo>()
    fun walk(n: AccessibilityNodeInfo) {
      out += n
      for (i in 0 until n.childCount) n.getChild(i)?.let(::walk)
    }
    walk(root)
    return out
  }

  private fun textOf(n: AccessibilityNodeInfo): String =
    listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
      .joinToString(" ").lowercase(Locale.ROOT)

  private fun readScreenText(): String {
    val root = rootInActiveWindow ?: return ""
    val out = mutableListOf<String>()
    fun walk(n: AccessibilityNodeInfo) {
      val text = listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
        .joinToString(" ").trim()
      if (n.isVisibleToUser && text.isNotBlank() && !out.contains(text)) out += text
      for (i in 0 until n.childCount) n.getChild(i)?.let(::walk)
    }
    walk(root)
    return out.take(120).joinToString("\n")
  }


  private fun startSearchAndOpenFlow(packageName: String, query: String, callback: (Boolean) -> Unit) {
    val intent = packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) { callback(false); return }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)

    var step = 0
    var attempts = 0
    val run = object : Runnable {
      override fun run() {
        attempts++
        val root = rootInActiveWindow
        val ok = when (step) {
          0 -> clickSearch(root)
          1 -> setFirstEditText(root, query)
          2 -> pressImeEnterInternal()
          3 -> clickFirstResult(root, query)
          else -> false
        }
        if (ok) { step++; attempts = 0 }
        if (step >= 4) { callback(true); return }
        if (attempts >= 16) { callback(false); return }
        handler.postDelayed(this, when (step) {
          0 -> 1200L
          1 -> 350L
          2 -> 250L
          else -> 1300L
        })
      }
    }
    handler.postDelayed(run, 1200)
  }

  private fun typeIntoFocusedFieldInternal(text: String): Boolean {
    val root = rootInActiveWindow ?: return false
    val node = nodes(root).firstOrNull {
      it.isVisibleToUser &&
        (it.isFocused || it.isAccessibilityFocused) &&
        it.className?.toString()?.contains("EditText", true) == true
    } ?: nodes(root).firstOrNull {
      it.isVisibleToUser &&
        it.className?.toString()?.contains("EditText", true) == true &&
        it.isFocusable
    }
    return setEditText(node, text)
  }

  private fun clickTextOnScreenInternal(text: String): Boolean {
    val target = text.trim().lowercase(Locale.ROOT)
    if (target.isBlank()) return false
    val root = rootInActiveWindow ?: return false
    val n = nodes(root).firstOrNull { it.isVisibleToUser && textOf(it).contains(target) } ?: return false
    var cur: AccessibilityNodeInfo? = n
    repeat(6) {
      if (cur?.isClickable == true && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
      cur = cur?.parent
    }
    return false
  }

  private fun pressImeEnterInternal(): Boolean {
    val root = rootInActiveWindow ?: return false
    val node = nodes(root).firstOrNull {
      it.isVisibleToUser &&
        (it.isFocused || it.isAccessibilityFocused) &&
        it.className?.toString()?.contains("EditText", true) == true
    } ?: nodes(root).firstOrNull {
      it.isVisibleToUser && it.className?.toString()?.contains("EditText", true) == true
    }

    val searchHints = listOf("search", "সার্চ", "খুঁজ", "go", "enter", "done", "অনুসন্ধান")
    val button = nodes(root).firstOrNull {
      it.isVisibleToUser && it.isClickable && searchHints.any { h -> textOf(it).contains(h) }
    }
    return button?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
  }

  private fun scrollScreenInternal(direction: String): Boolean {
    val root = rootInActiveWindow ?: return false
    val scrollable = nodes(root).firstOrNull { it.isVisibleToUser && it.isScrollable } ?: return false
    val action = when (direction.lowercase(Locale.ROOT)) {
      "up" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
      "down" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
      "left" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
      "right" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
      else -> return false
    }
    return scrollable.performAction(action)
  }

  private fun clickFirstResult(root: AccessibilityNodeInfo?, query: String): Boolean {
    val qWords = query.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.length >= 2 }
    val scored = nodes(root).mapNotNull { n ->
      if (!n.isVisibleToUser || !n.isClickable) return@mapNotNull null
      val cls = n.className?.toString().orEmpty()
      if (cls.contains("EditText", true)) return@mapNotNull null
      val t = textOf(n)
      if (t.isBlank()) return@mapNotNull null
      val rect = Rect()
      n.getBoundsInScreen(rect)
      if (rect.width() < 80 || rect.height() < 40) return@mapNotNull null
      val score = qWords.count { t.contains(it) } * 10 + if (n.childCount > 0) 2 else 0
      Triple(n, score, rect.top)
    }.sortedWith(
      compareByDescending<Triple<AccessibilityNodeInfo, Int, Int>> { it.second }.thenBy { it.third }
    )

    for ((node, _, _) in scored.take(12)) {
      var cur: AccessibilityNodeInfo? = node
      repeat(5) {
        if (cur?.isClickable == true && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        cur = cur?.parent
      }
    }
    return false
  }

  private fun startMessageFlow(packageName: String, recipient: String, message: String, callback: (Boolean) -> Unit) {
    val intent = packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) { callback(false); return }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)

    var step = 0
    var attempts = 0
    val run = object : Runnable {
      override fun run() {
        attempts++
        val root = rootInActiveWindow
        val ok = when (step) {
          0 -> clickSearch(root)
          1 -> setFirstEditText(root, recipient)
          2 -> clickRecipient(root, recipient)
          3 -> setMessageEditText(root, message)
          4 -> clickSend(root)
          else -> false
        }
        if (ok) { step++; attempts = 0 }
        if (step >= 5) { callback(true); return }
        if (attempts >= 12) { callback(false); return }
        handler.postDelayed(this, if (step == 0) 1100 else 500)
      }
    }
    handler.postDelayed(run, 1100)
  }

  private fun findPackageForApp(appName: String): String? {
    val target = appName.lowercase(Locale.ROOT)
    val aliases = when (target) {
      "whatsapp" -> listOf("whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ")
      "messenger" -> listOf("messenger", "মেসেঞ্জার")
      "imo" -> listOf("imo", "ইমু")
      else -> listOf(target)
    }
    return packageManager.queryIntentActivities(
      Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
      0
    ).firstOrNull { info ->
      val label = info.activityInfo.applicationInfo.loadLabel(packageManager).toString().lowercase(Locale.ROOT)
      aliases.any { label.contains(it) }
    }?.activityInfo?.packageName
  }

  private fun startCallFlow(appName: String, recipient: String, callback: (Boolean) -> Unit) {
    val packageName = findPackageForApp(appName)
    if (packageName == null) { callback(false); return }
    val intent = packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) { callback(false); return }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)

    var step = 0
    var attempts = 0
    val run = object : Runnable {
      override fun run() {
        attempts++
        val root = rootInActiveWindow
        val ok = when (step) {
          0 -> clickSearch(root)
          1 -> setFirstEditText(root, recipient)
          2 -> clickRecipient(root, recipient)
          3 -> clickVoiceCall(root)
          else -> false
        }
        if (ok) { step++; attempts = 0 }
        if (step >= 4) { callback(true); return }
        if (attempts >= 14) { callback(false); return }
        handler.postDelayed(this, if (step == 0) 1200 else 650)
      }
    }
    handler.postDelayed(run, 1200)
  }

  private fun clickVoiceCall(root: AccessibilityNodeInfo?): Boolean {
    val hints = listOf("call", "voice call", "audio call", "phone", "কল", "ভয়েস কল", "ভয়েস কল", "ফোন")
    val n = nodes(root).firstOrNull {
      it.isVisibleToUser && it.isClickable && hints.any { h -> textOf(it).contains(h) }
    }
    return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
  }

  private fun clickSearch(root: AccessibilityNodeInfo?): Boolean {
    val hints = listOf("search", "সার্চ", "খুঁজ", "find")
    val n = nodes(root).firstOrNull { it.isClickable && hints.any { h -> textOf(it).contains(h) } }
      ?: nodes(root).firstOrNull { it.className?.toString()?.contains("EditText", true) == true && it.isFocusable }
    return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
  }

  private fun setFirstEditText(root: AccessibilityNodeInfo?, value: String): Boolean =
    setEditText(nodes(root).firstOrNull {
      it.className?.toString()?.contains("EditText", true) == true && it.isFocusable && it.isVisibleToUser
    }, value)

  private fun setMessageEditText(root: AccessibilityNodeInfo?, value: String): Boolean {
    val edits = nodes(root).filter {
      it.className?.toString()?.contains("EditText", true) == true && it.isFocusable && it.isVisibleToUser
    }
    return setEditText(edits.lastOrNull(), value)
  }

  private fun setEditText(node: AccessibilityNodeInfo?, value: String): Boolean {
    node ?: return false
    val args = Bundle()
    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
    return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
  }

  private fun clickRecipient(root: AccessibilityNodeInfo?, recipient: String): Boolean {
    val target = recipient.lowercase(Locale.ROOT)
    val n = nodes(root).firstOrNull {
      val text = textOf(it)
      it.isVisibleToUser && (text == target || text.contains(target))
    } ?: return false
    var cur: AccessibilityNodeInfo? = n
    repeat(5) {
      if (cur?.isClickable == true && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
      cur = cur?.parent
    }
    return false
  }

  private fun clickSend(root: AccessibilityNodeInfo?): Boolean {
    val hints = listOf("send", "পাঠান", "পাঠাও", "প্রেরণ")
    val n = nodes(root).firstOrNull {
      it.isVisibleToUser && it.isClickable && hints.any { h -> textOf(it).contains(h) }
    }
    return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
  }
}
