# Abir AI 2.9.0 — Final Build Notes

Included:
- Bengali/English offline assistant
- Gemini online assistant with SecureStore API-key override
- Email/password local account setup/login
- Android App Lock with device biometric/PIN/password fallback
- Wake word and voice input/output
- Camera scene/object analysis through Gemini; no person identity matching
- Installed-app launching
- Contact/direct-number calling
- Messenger/IMO accessibility automation
- Security activity log
- Keyboard + voice chat
- AccessibilityEvent Kotlin build fix

Important:
- Email/password in this build is a device-local login. It is not a cloud account.
- A true remote block/kill-switch from another phone requires a deployed backend/control service. This build does not pretend that a local-only app has remote control.
- The Gemini API key can be supplied at build time through GEMINI_API_KEY and can be overridden by the key saved in SecureStore.
