# Tony / Abir AI — Voice + Background Upgrade (5.4.24)

This additive upgrade keeps the existing feature set and the 200-item memory limit unchanged.

## Fixed / strengthened

- Android microphone foreground service for background wake-word listening.
- Single-recognizer ownership in the background service; no parallel background recognizers.
- Foreground JS voice still stops the background service before taking the microphone.
- Wake-word language rotation: Bengali (Bangladesh), Bengali (India), English (US).
- Offline on-device recognition when Android exposes an on-device recognizer.
- Network recognition fallback when on-device recognition is unavailable.
- Automatic recognizer recovery with backoff after busy/error states.
- Persistent foreground-service notification with live voice status.
- Optional bottom-center floating voice status pill when "Display over other apps" is allowed.
- Expanded floating status when Tony is listening/working.
- Background wake now returns to the app through a PendingIntent/deep-link path instead of relying only on a direct background activity launch.
- Background wake acknowledgement through native TTS when available.
- Command capture after wake-word acknowledgement.
- TTS/microphone sequencing so the service does not immediately reopen the microphone while acknowledgement audio is still playing.
- Service restart handling when the task is removed, subject to Android/OEM restrictions.
- Android 13+ notification permission request when enabling background voice.
- Online assistant request routing now uses lower-temperature generation for more stable intent/fact responses, keeps recent conversation context, and uses stronger research settings for live-search requests.

## Android limitations that remain intentional

Android and individual phone manufacturers can stop microphone services, restrict background activity launches, or remove speech-language models. The app cannot safely bypass those platform protections. The upgrade therefore uses the supported foreground-service, notification, overlay, battery-optimization, and PendingIntent mechanisms.

## Existing systems preserved

- Existing Android actions and Accessibility automation.
- Existing Bengali/English voice paths.
- Existing speaker verification and sensitive-action authentication.
- Existing offline/online assistant routing.
- Existing UI and feature registries.
- Existing 200-item memory limit.
- Existing app/build configuration.
