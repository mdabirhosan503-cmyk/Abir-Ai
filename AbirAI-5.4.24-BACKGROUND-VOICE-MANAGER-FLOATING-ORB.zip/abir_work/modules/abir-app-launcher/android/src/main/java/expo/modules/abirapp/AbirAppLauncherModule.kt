package expo.modules.abirapp

import android.Manifest
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.os.Handler
import android.app.AlarmManager
import android.app.PendingIntent
import android.os.BatteryManager
import android.os.StatFs
import android.os.Looper
import android.os.Environment
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt
import org.json.JSONObject
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import java.util.Locale

class AbirAppLauncherModule : Module() {
  private var textToSpeech: TextToSpeech? = null
  private var textToSpeechReady = false
  private val ttsHandler = Handler(Looper.getMainLooper())
  private val ttsWaiters = mutableListOf<() -> Unit>()
  @Volatile private var cancelActiveSpeechRecognition: (() -> Unit)? = null
  private var miniOverlay: View? = null
  private var miniOverlayWindowManager: WindowManager? = null

  private suspend fun speakAndroidText(text: String, languageTag: String, gender: String): Boolean =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
      val context = appContext.reactContext
        ?: run {
          continuation.resume(false) {}
          return@suspendCancellableCoroutine
        }

      ttsHandler.post {
        fun speakNow() {
          if (!continuation.isActive) return
          val tts = textToSpeech
          if (!textToSpeechReady || tts == null) {
            continuation.resume(false) {}
            return
          }
          val requested = Locale.forLanguageTag(languageTag)
          var localeResult = tts.setLanguage(requested)
          if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            localeResult = tts.setLanguage(Locale.US)
          }
          if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            continuation.resume(false) {}
            return
          }
          tts.setPitch(if (gender.equals("male", true)) 0.92f else 1.02f)
          tts.setSpeechRate(if (languageTag.startsWith("bn")) 0.9f else 0.94f)
          val utteranceId = "abir-${System.nanoTime()}"

          // Do not resolve the JS promise immediately after QUEUE_FLUSH.
          // The previous implementation did that, so the continuous voice
          // loop could reopen SpeechRecognizer while TTS was still speaking.
          // That created the audible stop/start behavior and microphone races.
          tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}

            override fun onDone(id: String?) {
              if (id == utteranceId && continuation.isActive) {
                continuation.resume(true) {}
              }
            }

            override fun onError(id: String?) {
              if (id == utteranceId && continuation.isActive) {
                continuation.resume(false) {}
              }
            }
          })

          val result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, android.os.Bundle(), utteranceId)
          if (result != TextToSpeech.SUCCESS && continuation.isActive) {
            continuation.resume(false) {}
          }
        }

        if (textToSpeechReady && textToSpeech != null) {
          speakNow()
          return@post
        }

        ttsWaiters.add { speakNow() }
        if (textToSpeech == null) {
          textToSpeech = TextToSpeech(context.applicationContext) { status ->
            ttsHandler.post {
              textToSpeechReady = status == TextToSpeech.SUCCESS
              val waiters = ttsWaiters.toList()
              ttsWaiters.clear()
              waiters.forEach { waiter -> waiter() }
            }
          }
        }
      }

      // If the JS caller cancels, the waiter remains harmless because speakNow
      // checks continuation.isActive before speaking/resuming.
    }

  private fun hideMiniInfoInternal(): Boolean {
    val view = miniOverlay ?: return true
    return try { miniOverlayWindowManager?.removeView(view); true } catch (_: Exception) { false } finally { miniOverlay = null; miniOverlayWindowManager = null }
  }

  private fun showMiniInfoInternal(title: String, content: String, durationMs: Long): Boolean {
    val context = appContext.reactContext ?: return false
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) return false
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return false
    val density = context.resources.displayMetrics.density
    val pad = (14 * density).toInt()
    val root = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); setBackgroundColor(Color.rgb(15, 22, 40)); elevation = 18f * density }
    val titleView = TextView(context).apply { text = title.take(80); setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, (6 * density).toInt()) }
    val bodyView = TextView(context).apply { text = content.take(1800); setTextColor(Color.rgb(220, 230, 245)); textSize = 13f }
    val close = TextView(context).apply { text = "✕  Close"; setTextColor(Color.rgb(150, 190, 255)); textSize = 12f; gravity = Gravity.END; setPadding(0, (8 * density).toInt(), 0, 0); setOnClickListener { hideMiniInfoInternal() } }
    root.addView(titleView); root.addView(bodyView); root.addView(close)
    hideMiniInfoInternal()
    @Suppress("DEPRECATION")
    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    val params = WindowManager.LayoutParams((330 * density).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, android.graphics.PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = (8 * density).toInt(); y = (48 * density).toInt() }
    return try {
      wm.addView(root, params); miniOverlay = root; miniOverlayWindowManager = wm
      Handler(Looper.getMainLooper()).postDelayed({ if (miniOverlay === root) hideMiniInfoInternal() }, durationMs.coerceIn(3000L, 60000L))
      true
    } catch (_: Exception) { false }
  }

  private fun listPublicFilesJson(category: String, limit: Int): String {
    val context = appContext.reactContext ?: return "[]"
    val base = when (category.lowercase(Locale.ROOT)) {
      "downloads" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
      "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
      "pictures", "photos" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
      "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
      "movies", "videos" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
      "app" -> context.filesDir
      else -> Environment.getExternalStorageDirectory()
    }
    val out = org.json.JSONArray()
    val files = try { base.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList() } catch (_: Exception) { emptyList() }
    files.take(limit.coerceIn(1, 100)).forEach { file -> out.put(JSONObject().put("name", file.name).put("path", file.absolutePath).put("directory", file.isDirectory).put("sizeBytes", if (file.isFile) file.length() else 0L).put("modifiedAt", file.lastModified())) }
    return out.toString()
  }

  private fun deviceDiagnosticsJson(): String {
    val context = appContext.reactContext ?: return "{}"
    val battery = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
    val batteryPct = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    val stat = StatFs(context.filesDir.absolutePath)
    val freeStorage = stat.availableBytes
    val totalStorage = stat.totalBytes
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val network = cm?.activeNetwork
    val caps = if (network != null) cm.getNetworkCapabilities(network) else null
    val online = caps != null
    val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    return JSONObject()
      .put("batteryPercent", batteryPct)
      .put("freeStorageBytes", freeStorage)
      .put("totalStorageBytes", totalStorage)
      .put("online", online)
      .put("wifi", wifi)
      .put("cellular", cellular)
      .put("sdk", Build.VERSION.SDK_INT)
      .toString()
  }

  private fun scheduleReminderInternal(text: String, delayMs: Long): Boolean {
    val context = appContext.reactContext ?: return false
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
    val intent = Intent(context, AbirReminderReceiver::class.java).putExtra("text", text)
    val requestCode = (System.currentTimeMillis() and 0x7fffffff).toInt()
    val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val trigger = System.currentTimeMillis() + delayMs
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
      else alarm.set(AlarmManager.RTC_WAKEUP, trigger, pending)
      true
    } catch (_: Exception) { false }
  }

  private fun stopAndroidText() {
    ttsHandler.post {
      try { textToSpeech?.stop() } catch (_: Exception) {}
    }
  }

  private suspend fun getCurrentLocationJson(): String =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
      val context = appContext.reactContext
        ?: run {
          continuation.resume("") {}
          return@suspendCancellableCoroutine
        }

      if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
      ) {
        continuation.resume("") {}
        return@suspendCancellableCoroutine
      }

      val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        ?: run {
          continuation.resume("") {}
          return@suspendCancellableCoroutine
        }

      val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        .filter { provider ->
          try { manager.isProviderEnabled(provider) } catch (_: Exception) { false }
        }

      if (providers.isEmpty()) {
        continuation.resume("") {}
        return@suspendCancellableCoroutine
      }

      var finished = false
      val handler = Handler(Looper.getMainLooper())
      lateinit var listener: LocationListener

      fun finish(location: Location?) {
        if (finished || !continuation.isActive) return
        finished = true
        try { manager.removeUpdates(listener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)

        if (location == null) {
          continuation.resume("") {}
          return
        }

        var addressText = ""
        try {
          @Suppress("DEPRECATION")
          val addresses: List<Address>? = Geocoder(context, Locale.getDefault()).getFromLocation(
            location.latitude,
            location.longitude,
            1,
          )
          val address = addresses?.firstOrNull()
          if (address != null) {
            val parts = listOfNotNull(
              address.getAddressLine(0)?.takeIf { it.isNotBlank() },
              address.locality?.takeIf { it.isNotBlank() },
              address.subAdminArea?.takeIf { it.isNotBlank() },
              address.adminArea?.takeIf { it.isNotBlank() },
              address.countryName?.takeIf { it.isNotBlank() },
            ).distinct()
            addressText = parts.joinToString(", ")
          }
        } catch (_: Exception) {
          addressText = ""
        }

        val result = JSONObject()
          .put("latitude", location.latitude)
          .put("longitude", location.longitude)
          .put("accuracy", location.accuracy.toDouble())
          .put("provider", location.provider ?: "")
          .put("address", addressText)
          .toString()
        continuation.resume(result) {}
      }

      listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
          finish(location)
        }
        override fun onProviderDisabled(provider: String) {}
        override fun onProviderEnabled(provider: String) {}
      }

      // Prefer a recent cached location for a fast answer, but request a fresh fix
      // when the cache is unavailable or clearly stale.
      var bestCached: Location? = null
      for (provider in providers) {
        try {
          val cached = manager.getLastKnownLocation(provider)
          if (cached != null && (bestCached == null || cached.time > bestCached!!.time)) bestCached = cached
        } catch (_: SecurityException) {}
      }
      if (bestCached != null && System.currentTimeMillis() - bestCached!!.time < 120_000L) {
        finish(bestCached)
        return@suspendCancellableCoroutine
      }

      try {
        for (provider in providers) {
          manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        }
      } catch (_: SecurityException) {
        finish(null)
        return@suspendCancellableCoroutine
      }

      handler.postDelayed({
        if (!finished) finish(bestCached)
      }, 12_000L)

      continuation.invokeOnCancellation {
        try { manager.removeUpdates(listener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
      }
    }

  private fun launcherActivities(): List<ResolveInfo> {
    val context = appContext.reactContext
      ?: throw IllegalStateException("Android context is unavailable")
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val packageManager = context.packageManager

    @Suppress("DEPRECATION")
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      packageManager.queryIntentActivities(
        intent,
        PackageManager.ResolveInfoFlags.of(0L)
      )
    } else {
      packageManager.queryIntentActivities(intent, 0)
    }
  }

  /**
   * Captures a short 16 kHz mono sample and returns a compact acoustic speaker
   * vector. This is intentionally local-only: raw audio is not persisted.
   *
   * The vector is an integration-safe fallback for the future ECAPA-TDNN
   * provider. It is NOT a cryptographic biometric and should never replace
   * Android device authentication for sensitive actions.
   */
  private fun captureSpeakerVector(durationMs: Long = 2600L): List<Double> {
    val sampleRate = 16000
    val minBuffer = AudioRecord.getMinBufferSize(
      sampleRate,
      AudioFormat.CHANNEL_IN_MONO,
      AudioFormat.ENCODING_PCM_16BIT
    )
    if (minBuffer <= 0) return emptyList()

    val bufferSize = maxOf(minBuffer, sampleRate / 2)
    val recorder = AudioRecord(
      MediaRecorder.AudioSource.VOICE_RECOGNITION,
      sampleRate,
      AudioFormat.CHANNEL_IN_MONO,
      AudioFormat.ENCODING_PCM_16BIT,
      bufferSize
    )

    val pcm = ShortArray(sampleRate * 3)
    var total = 0
    try {
      recorder.startRecording()
      val deadline = System.currentTimeMillis() + durationMs
      while (System.currentTimeMillis() < deadline && total < pcm.size) {
        val read = recorder.read(pcm, total, pcm.size - total)
        if (read > 0) total += read else Thread.sleep(10)
      }
    } finally {
      try { recorder.stop() } catch (_: Exception) {}
      recorder.release()
    }

    if (total < sampleRate) return emptyList()

    val frame = 400 // 25 ms at 16 kHz
    val hop = 200   // 12.5 ms
    val frequencies = intArrayOf(250, 375, 500, 625, 750, 875, 1000, 1250, 1500, 1750, 2000, 2250, 2500, 2750, 3000, 3250, 3500)
    val frameFeatures = ArrayList<DoubleArray>()
    var start = 0

    while (start + frame <= total) {
      val features = DoubleArray(frequencies.size + 3)
      var energy = 0.0
      var zcr = 0.0
      var previous = pcm[start].toDouble()

      for (i in 0 until frame) {
        val x = pcm[start + i].toDouble() / 32768.0
        energy += x * x
        if ((x >= 0.0 && previous < 0.0) || (x < 0.0 && previous >= 0.0)) zcr += 1.0
        previous = x
      }

      val rms = sqrt(energy / frame + 1e-9)
      val zcrRate = zcr / frame
      features[0] = Math.log(rms + 1e-6)
      features[1] = zcrRate

      var weightedFreq = 0.0
      var totalBand = 0.0
      for (k in frequencies.indices) {
        val freq = frequencies[k]
        val omega = 2.0 * Math.PI * freq / sampleRate
        val coeff = 2.0 * cos(omega)
        var s1 = 0.0
        var s2 = 0.0
        for (i in 0 until frame) {
          val x = pcm[start + i].toDouble() / 32768.0
          val s0 = x + coeff * s1 - s2
          s2 = s1
          s1 = s0
        }
        val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
        val safePower = Math.log(abs(power) + 1e-9)
        features[k + 3] = safePower
        val linear = abs(power) + 1e-9
        weightedFreq += freq * linear
        totalBand += linear
      }
      features[2] = if (totalBand > 0.0) weightedFreq / totalBand / sampleRate else 0.0
      frameFeatures.add(features)
      start += hop
    }

    if (frameFeatures.size < 10) return emptyList()
    val dims = frameFeatures[0].size
    val vector = DoubleArray(dims * 2)
    for (d in 0 until dims) {
      var mean = 0.0
      for (row in frameFeatures) mean += row[d]
      mean /= frameFeatures.size
      var variance = 0.0
      for (row in frameFeatures) {
        val delta = row[d] - mean
        variance += delta * delta
      }
      variance /= frameFeatures.size
      vector[d] = mean
      vector[dims + d] = sqrt(variance + 1e-9)
    }

    var norm = 0.0
    for (value in vector) norm += value * value
    norm = sqrt(norm)
    if (norm <= 1e-9) return emptyList()
    return vector.map { it / norm }
  }

  override fun definition() = ModuleDefinition {
    Name("AbirAppLauncher")


    AsyncFunction("isCallAssistantEnabled") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      CallAssistantPrefs.enabled(context)
    }

    AsyncFunction("setCallAssistantEnabled") { enabled: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      CallAssistantPrefs.setEnabled(context, enabled)
      if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? android.app.role.RoleManager
        if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER) &&
          !roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)) {
          val roleIntent = roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER)
          roleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(roleIntent)
          return@AsyncFunction "role-requested"
        }
      }
      if (enabled && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
        val intent = Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
      }
      if (!enabled) {
        CallAssistantService.disconnectCurrentCall()
      }
      "enabled"
    }

    AsyncFunction("isDefaultDialer") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return@AsyncFunction false
      val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? android.app.role.RoleManager
        ?: return@AsyncFunction false
      roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)
    }

    AsyncFunction("requestDefaultDialerRole") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return@AsyncFunction false
      val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? android.app.role.RoleManager
        ?: return@AsyncFunction false
      if (!roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) return@AsyncFunction false
      if (roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)) return@AsyncFunction true
      val roleIntent = roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER)
      roleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(roleIntent)
      true
    }

    AsyncFunction("answerCurrentCall") {
      CallAssistantService.answerCurrentCall()
    }

    AsyncFunction("endCurrentCall") {
      CallAssistantService.disconnectCurrentCall()
    }

    AsyncFunction("startWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Microphone permission has not been granted")
      }
      // Android 13+ hides foreground-service notifications unless POST_NOTIFICATIONS
      // is granted. The service can still run, but asking in JS keeps the user
      // aware that microphone access is active.
      val intent = Intent(context, WakeWordService::class.java).apply {
        action = WakeWordService.ACTION_START
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
      true
    }

    AsyncFunction("pauseWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startService(Intent(context, WakeWordService::class.java).setAction(WakeWordService.ACTION_PAUSE))
      true
    }

    AsyncFunction("resumeWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startService(Intent(context, WakeWordService::class.java).setAction(WakeWordService.ACTION_RESUME))
      true
    }

    AsyncFunction("setWakeWordOverlayVisible") { visible: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startService(Intent(context, WakeWordService::class.java).setAction(if (visible) WakeWordService.ACTION_OVERLAY_SHOW else WakeWordService.ACTION_OVERLAY_HIDE))
      true
    }

    AsyncFunction("stopWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.stopService(Intent(context, WakeWordService::class.java))
      true
    }

    AsyncFunction("isIgnoringBatteryOptimizations") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return@AsyncFunction true
      val power = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
      power.isIgnoringBatteryOptimizations(context.packageName)
    }

    AsyncFunction("requestBatteryOptimizationExemption") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return@AsyncFunction true
      try {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
          data = Uri.parse("package:${context.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
      } catch (_: Exception) {
        try {
          val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(fallback)
          true
        } catch (_: Exception) { false }
      }
    }

    AsyncFunction("wakeScreen") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        ?: return@AsyncFunction false
      @Suppress("DEPRECATION")
      val wakeLock = powerManager.newWakeLock(
        android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
        "${context.packageName}:AbirWakeScreen"
      )
      return@AsyncFunction try {
        wakeLock.acquire(3000L)
        true
      } finally {
        try { if (wakeLock.isHeld) wakeLock.release() } catch (_: Exception) {}
      }
    }

    AsyncFunction("speakText") Coroutine { text: String, languageTag: String, gender: String ->
      speakAndroidText(text, languageTag, gender)
    }

    AsyncFunction("stopSpeaking") {
      stopAndroidText()
      true
    }

    AsyncFunction("getDeviceDiagnostics") {
      deviceDiagnosticsJson()
    }

    AsyncFunction("listPublicFiles") { category: String, limit: Double ->
      listPublicFilesJson(category, limit.toInt())
    }

    AsyncFunction("showMiniInfo") { title: String, content: String, durationMs: Double ->
      showMiniInfoInternal(title, content, durationMs.toLong())
    }

    AsyncFunction("hideMiniInfo") {
      hideMiniInfoInternal()
    }

    AsyncFunction("scheduleReminder") { text: String, delayMs: Double ->
      scheduleReminderInternal(text, delayMs.toLong())
    }

    // The explicit Boolean parameter disambiguates Expo's zero-argument and
    // one-argument Coroutine overloads in current Kotlin compiler versions.
    // The JS wrapper passes false; the value is intentionally unused.
    AsyncFunction("getCurrentLocation") Coroutine { _unused: Boolean ->
      getCurrentLocationJson()
    }

    AsyncFunction("canDrawOverlays") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) true
      else Settings.canDrawOverlays(context)
    }

    AsyncFunction("openOverlaySettings") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }
      true
    }

    AsyncFunction("isAccessibilityEnabled") {
      AbirAccessibilityService.isRunning()
    }

    AsyncFunction("performGlobalAction") { action: String ->
      AbirAccessibilityService.performGlobal(action)
    }

    AsyncFunction("readCurrentScreenText") {
      AbirAccessibilityService.readScreen()
    }

    AsyncFunction("getScreenSnapshot") {
      AbirAccessibilityService.screenSnapshot()
    }

    AsyncFunction("getVolumePercent") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction -1.0
      val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
      if (max <= 0) return@AsyncFunction 0.0
      val current = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
      current.toDouble() * 100.0 / max.toDouble()
    }

    AsyncFunction("setVolumePercent") { percent: Double ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      val clamped = percent.coerceIn(0.0, 100.0)
      val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
      val target = kotlin.math.round(max * clamped / 100.0).toInt().coerceIn(0, max)
      audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, target, 0)
      true
    }

    AsyncFunction("setFlashlight") { enabled: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return@AsyncFunction false
      val camera = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
        ?: return@AsyncFunction false
      val cameraId = camera.cameraIdList.firstOrNull { id ->
        camera.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
      } ?: return@AsyncFunction false
      try {
        camera.setTorchMode(cameraId, enabled)
        true
      } catch (_: Exception) {
        false
      }
    }

    AsyncFunction("controlMedia") { action: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      val key = when (action.lowercase(Locale.ROOT)) {
        "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
        "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
        "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
        "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
        else -> return@AsyncFunction false
      }
      val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key)
      val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key)
      audio.dispatchMediaKeyEvent(down)
      audio.dispatchMediaKeyEvent(up)
      true
    }

    AsyncFunction("setRingerMode") { mode: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      when (mode.lowercase(Locale.ROOT)) {
        "normal" -> audio.ringerMode = android.media.AudioManager.RINGER_MODE_NORMAL
        "vibrate" -> audio.ringerMode = android.media.AudioManager.RINGER_MODE_VIBRATE
        else -> return@AsyncFunction false
      }
      true
    }

    AsyncFunction("adjustVolume") { direction: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      when (direction.lowercase(Locale.ROOT)) {
        "up" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_RAISE, 0)
        "down" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_LOWER, 0)
        "mute" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_MUTE, 0)
        else -> return@AsyncFunction false
      }
      true
    }

    AsyncFunction("openSystemSettings") { kind: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      // Deliberately do not expose the general Android Settings screen.
      // Wi-Fi/Bluetooth/mobile-data commands only open the OS-provided control
      // panel. Android normally blocks ordinary apps from silently toggling
      // these protected radios on behalf of the user.
      val normalized = kind.lowercase(Locale.ROOT)
      val intent = when (normalized) {
        "wifi-settings" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          Intent(Settings.Panel.ACTION_WIFI)
        } else {
          Intent(Settings.ACTION_WIFI_SETTINGS)
        }
        "bluetooth-settings" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "mobile-data-panel" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
          Intent(Settings.ACTION_WIRELESS_SETTINGS)
        }
        "settings" -> Intent(Settings.ACTION_SETTINGS)
        else -> return@AsyncFunction false
      }
      context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      true
    }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
      true
    }

    AsyncFunction("sendMessageViaAccessibility") {
      packageName: String, recipient: String, message: String ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.sendMessage(packageName, recipient, message) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(12, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("searchAndOpenInApp") Coroutine { packageName: String, query: String ->
      kotlinx.coroutines.suspendCancellableCoroutine<Boolean> { continuation ->
        AbirAccessibilityService.searchAndOpenInApp(packageName, query) { ok ->
          if (continuation.isActive) continuation.resume(ok) {}
        }
      }
    }

    AsyncFunction("typeIntoFocusedField") { text: String ->
      AbirAccessibilityService.typeIntoFocusedField(text)
    }

    AsyncFunction("clickTextOnScreen") { text: String ->
      AbirAccessibilityService.clickTextOnScreen(text)
    }

    AsyncFunction("pressImeEnter") {
      AbirAccessibilityService.pressImeEnter()
    }

    AsyncFunction("scrollScreen") { direction: String ->
      AbirAccessibilityService.scrollScreen(direction)
    }

    AsyncFunction("callViaApp") { appName: String, recipient: String ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.callContact(appName, recipient) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(15, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("sendVoiceMessageViaAccessibility") { packageName: String, recipient: String, durationMs: Double ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.sendVoiceMessage(packageName, recipient, durationMs.toLong().coerceIn(3000L, 30000L)) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(45, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("isOnline") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val manager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
          ?: return@AsyncFunction false
      val activeNetwork = manager.activeNetwork ?: return@AsyncFunction false
      val capabilities = manager.getNetworkCapabilities(activeNetwork)
        ?: return@AsyncFunction false
      capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    AsyncFunction("recordSpeakerSample") Coroutine { durationMs: Double ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
        return@Coroutine emptyList<Double>()
      }
      captureSpeakerVector(durationMs.toLong().coerceIn(1800L, 4000L))
    }

    AsyncFunction("isOfflineSpeechRecognitionAvailable") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        false
      } else {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
      }
    }

    // Standard Android speech recognition fallback. It can use the installed
    // speech service when true on-device recognition is unavailable.
    AsyncFunction("recognizeSpeech") Coroutine { localeTag: String, preferOffline: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")

      kotlinx.coroutines.suspendCancellableCoroutine<List<String>> { continuation ->
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var recognizer: SpeechRecognizer? = null
        var bestPartial: List<String> = emptyList()
        val cleanup = {
          try { recognizer?.destroy() } catch (_: Exception) {}
          recognizer = null
        }
        val cancelOperation = {
          if (continuation.isActive) continuation.resume(bestPartial) {}
          cleanup()
        }
        cancelActiveSpeechRecognition = cancelOperation

        mainHandler.post {
          try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
              override fun onReadyForSpeech(params: android.os.Bundle?) {}
              override fun onBeginningOfSpeech() {}
              override fun onRmsChanged(rmsdB: Float) {}
              override fun onBufferReceived(buffer: ByteArray?) {}
              override fun onEndOfSpeech() {}
              override fun onPartialResults(partialResults: android.os.Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() } ?: emptyList()
                if (partial.isNotEmpty()) bestPartial = partial.take(5)
              }
              override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
              override fun onError(error: Int) {
                if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
                if (continuation.isActive) continuation.resume(bestPartial) {}
                cleanup()
              }
              override fun onResults(results: android.os.Bundle?) {
                val matches = results
                  ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                  ?.filter { it.isNotBlank() }
                  ?.take(5)
                  ?: emptyList()
                if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
                if (continuation.isActive) continuation.resume(matches) {}
                cleanup()
              }
            })

            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
              putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1900L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 650L)
            }
            recognizer?.startListening(intent)
          } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(emptyList()) {}
            cleanup()
          }
        }

        mainHandler.postDelayed({
          if (continuation.isActive) {
            continuation.resume(bestPartial) {}
            cleanup()
          }
        }, 12000L)

        continuation.invokeOnCancellation {
          mainHandler.post {
            if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
            cleanup()
          }
        }
      }
    }

    AsyncFunction("cancelSpeechRecognition") {
      val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
      mainHandler.post { cancelActiveSpeechRecognition?.invoke(); cancelActiveSpeechRecognition = null }
      true
    }

    // True on-device speech recognition. This path never asks the network for speech data.
    // Android 12+ is required for the on-device recognizer API.
    AsyncFunction("recognizeOffline") Coroutine { localeTag: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
        return@Coroutine emptyList<String>()
      }

      kotlinx.coroutines.suspendCancellableCoroutine<List<String>> { continuation ->
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var recognizer: SpeechRecognizer? = null
        var bestPartial: List<String> = emptyList()
        val cleanup = {
          try { recognizer?.destroy() } catch (_: Exception) {}
          recognizer = null
        }
        val cancelOperation = {
          if (continuation.isActive) continuation.resume(bestPartial) {}
          cleanup()
        }
        cancelActiveSpeechRecognition = cancelOperation

        mainHandler.post {
          try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
              override fun onReadyForSpeech(params: android.os.Bundle?) {}
              override fun onBeginningOfSpeech() {}
              override fun onRmsChanged(rmsdB: Float) {}
              override fun onBufferReceived(buffer: ByteArray?) {}
              override fun onEndOfSpeech() {}
              override fun onPartialResults(partialResults: android.os.Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() } ?: emptyList()
                if (partial.isNotEmpty()) bestPartial = partial.take(5)
              }
              override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
              override fun onError(error: Int) {
                if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
                if (continuation.isActive) continuation.resume(bestPartial) {}
                cleanup()
              }
              override fun onResults(results: android.os.Bundle?) {
                val matches = results
                  ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                  ?.filter { it.isNotBlank() }
                  ?.take(5)
                  ?: emptyList()
                if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
                if (continuation.isActive) continuation.resume(matches) {}
                cleanup()
              }
            })

            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
              putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1900L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            }
            recognizer?.startListening(intent)
          } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(emptyList()) {}
            cleanup()
          }
        }

        mainHandler.postDelayed({
          if (continuation.isActive) {
            continuation.resume(bestPartial) {}
            cleanup()
          }
        }, 12000L)

        continuation.invokeOnCancellation {
          mainHandler.post {
            if (cancelActiveSpeechRecognition === cancelOperation) cancelActiveSpeechRecognition = null
            cleanup()
          }
        }
      }
    }

    AsyncFunction("getContacts") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Contacts permission has not been granted")
      }

      val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.TYPE,
        ContactsContract.CommonDataKinds.Phone.LABEL
      )
      val contacts = linkedMapOf<String, Map<String, String>>()
      context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection,
        null,
        null,
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
      )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        val nameColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val typeColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
        val labelColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)

        while (cursor.moveToNext()) {
          val id = cursor.getString(idColumn) ?: continue
          val name = cursor.getString(nameColumn)?.trim().orEmpty()
          val number = cursor.getString(numberColumn)?.trim().orEmpty()
          if (name.isBlank() || number.isBlank()) continue

          val type = cursor.getInt(typeColumn)
          val customLabel = cursor.getString(labelColumn)
          val phoneLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
            context.resources,
            type,
            customLabel
          ).toString()
          val key = "$id:$number"
          contacts.putIfAbsent(
            key,
            mapOf(
              "contactId" to id,
              "displayName" to name,
              "phoneNumber" to number,
              "phoneLabel" to phoneLabel
            )
          )
        }
      }
      contacts.values.toList()
    }

    AsyncFunction("getLaunchableApps") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val packageManager = context.packageManager

      launcherActivities()
        .groupBy { it.activityInfo.packageName }
        .mapNotNull { (packageName, activities) ->
          val defaultActivityName =
            packageManager.getLaunchIntentForPackage(packageName)?.component?.className
          val activity = activities.firstOrNull {
            it.activityInfo.name == defaultActivityName
          } ?: activities.firstOrNull() ?: return@mapNotNull null
          val label = activity.activityInfo.applicationInfo
            .loadLabel(packageManager)
            .toString()
            .trim()

          if (label.isBlank()) return@mapNotNull null

          mapOf(
            "label" to label,
            "packageName" to packageName,
            "activityName" to activity.activityInfo.name
          )
        }
        .sortedBy { it["label"]?.lowercase(Locale.ROOT) }
    }

    AsyncFunction("launchApp") { packageName: String, activityName: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val isStillLaunchable = launcherActivities().any {
        it.activityInfo.packageName == packageName &&
          it.activityInfo.name == activityName
      }
      if (!isStillLaunchable) {
        throw IllegalStateException("That app is no longer available")
      }

      val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(packageName, activityName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("openDialer") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_DIAL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      if (intent.resolveActivity(context.packageManager) == null) {
        throw IllegalStateException("No dialer app is available")
      }
      context.startActivity(intent)
      true
    }

    AsyncFunction("placeDirectCall") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Phone-call permission has not been granted")
      }
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_CALL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }
  }
}
