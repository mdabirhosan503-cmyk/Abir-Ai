import AsyncStorage from '@react-native-async-storage/async-storage';

const PREFERENCES_KEY = 'abir-ai-preferences-v1';

export type VoiceGenderPreference = 'male' | 'female';

export type AssistantPreferences = {
  voiceGender: VoiceGenderPreference;
  trustedDirectCall: boolean;
  assistantName: string;
};

export const DEFAULT_PREFERENCES: AssistantPreferences = {
  voiceGender: 'female',
  trustedDirectCall: false,
  assistantName: 'Abir AI',
};

export async function loadAssistantPreferences(): Promise<AssistantPreferences> {
  const stored = await AsyncStorage.getItem(PREFERENCES_KEY);
  if (!stored) return DEFAULT_PREFERENCES;

  try {
    const parsed: unknown = JSON.parse(stored);
    if (!parsed || typeof parsed !== 'object') return DEFAULT_PREFERENCES;
    const preferences = parsed as Partial<AssistantPreferences>;
    return {
      voiceGender:
        preferences.voiceGender === 'male' ? 'male' : 'female',
      trustedDirectCall: preferences.trustedDirectCall === true,
      assistantName: typeof preferences.assistantName === 'string' && preferences.assistantName.trim()
        ? preferences.assistantName.trim().slice(0, 32)
        : DEFAULT_PREFERENCES.assistantName,
    };
  } catch {
    return DEFAULT_PREFERENCES;
  }
}

export async function saveAssistantPreferences(
  preferences: AssistantPreferences,
) {
  await AsyncStorage.setItem(PREFERENCES_KEY, JSON.stringify(preferences));
}
