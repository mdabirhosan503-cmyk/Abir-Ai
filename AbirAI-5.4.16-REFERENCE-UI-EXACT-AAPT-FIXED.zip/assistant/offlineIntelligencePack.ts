/** Additive offline intelligence pack for Abir AI v4.16.0.
 * Uses local heuristics and existing device capabilities; does not pretend a model/OCR engine
 * is installed when it is not. Existing offline extensions remain in the chain.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';
import { repairCommonSpeech } from './localIntelligence';
import { planOfflineTasks, searchLocalNotes, loadLocalNotes, saveLocalDocument, loadLocalDocuments, searchLocalDocuments, saveLocalRoutine, loadLocalRoutines, translateOfflinePhrase } from './offlinePlus';
import { buildGoalPlan, diagnoseLocalFailure, previewRisk, rankLocalCandidates } from './offlineCognition';
import { getOfflineSpeechRecognitionAvailability } from './androidActions';
import { MAX_MEMORY_ITEMS } from './localMemory';
import { getOfflineFeatureReport, FINAL_OFFLINE_FEATURES } from './offlineFinalFeatureSet';

const STATS_KEY = 'abir-ai-offline-pack-stats-v1';
type PackStats = { commands: number; failures: number; lastFeature?: string; lastAt?: number };
const bn = (s: string) => /[\u0980-\u09FF]/u.test(s);
const reply = (r: AssistantRequest, b: string, e: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: r.language === 'bn' || bn(r.text) ? b : e, intent });
const norm = (s: string) => repairCommonSpeech(s).normalize('NFKC').toLocaleLowerCase().replace(/[!?।]+/g, ' ').replace(/\s+/g, ' ').trim();
async function record(feature: string) {
  try {
    const old = JSON.parse((await AsyncStorage.getItem(STATS_KEY)) || '{}') as PackStats;
    await AsyncStorage.setItem(STATS_KEY, JSON.stringify({ ...old, commands: Math.min(1000000, (old.commands || 0) + 1), lastFeature: feature, lastAt: Date.now() }));
  } catch { /* stats are optional */ }
}

function grammar(text: string, r: AssistantRequest): AssistantReply | null {
  if (!/(?:বানান ঠিক|ব্যাকরণ ঠিক|বাক্য ঠিক|grammar check|fix grammar|correct spelling|লেখা ঠিক করো)\s*[:：]?/iu.test(text)) return null;
  const input = text.replace(/^(?:.*?)(?:বানান ঠিক|ব্যাকরণ ঠিক|বাক্য ঠিক|grammar check|fix grammar|correct spelling|লেখা ঠিক করো)\s*[:：]?\s*/iu, '').trim();
  if (!input) return reply(r, 'যে বাক্যটি ঠিক করতে চাও, লিখো: “ব্যাকরণ ঠিক: আমি স্কুলে যায়”। আমি পরিচিত বানান ও বাক্যগঠন যাচাই করতে পারি, তবে এটি পূর্ণাঙ্গ AI grammar model নয়।', 'Send text like “fix grammar: She go to school”. I can check common patterns, not replace a full grammar model.');
  let output = repairCommonSpeech(input).replace(/\s+([,.;!?।])/g, '$1').replace(/([,.;!?।])(?=\S)/g, '$1 ');
  output = output.replace(/\bi am\b/gi, 'I am').replace(/\bi\b/g, 'I').replace(/\byou was\b/gi, 'you were').replace(/\bthey was\b/gi, 'they were').replace(/\bhe go\b/gi, 'he goes').replace(/\bshe go\b/gi, 'she goes').replace(/\bit go\b/gi, 'it goes');
  return reply(r, `স্থানীয় লেখা-সহায়তা (প্রাথমিক পরীক্ষা):\n${output}\n\nনোট: এটি নিয়মভিত্তিক সংশোধন; প্রতিটি ভুল ধরতে নাও পারে।`, `Local writing check (basic):\n${output}\n\nNote: this is rule-based and may miss some errors.`, 'text-analysis');
}

function conversationSummary(r: AssistantRequest): AssistantReply | null {
  if (!/(?:কথোপকথনের সারাংশ|আগের কথার সারাংশ|conversation summary|summarize conversation|আমরা কী কথা বলেছি)/iu.test(r.text)) return null;
  const items = (r.conversationContext || []).slice(-12).filter(x => x.text.trim());
  if (!items.length) return reply(r, 'এই অনুরোধে আগের কথোপকথনের তথ্য পাওয়া যায়নি। কথাগুলো পাঠালে সারাংশ করে দেব।', 'No prior conversation context was provided to summarize. Paste the conversation and I can summarize it.', 'text-analysis');
  const lines = items.slice(-8).map(x => `${x.role === 'user' ? 'তুমি' : 'আবির'}: ${x.text.replace(/\s+/g, ' ').slice(0, 180)}`);
  return reply(r, `স্থানীয় সারাংশ (সাম্প্রতিক ${items.length}টি বার্তার ভিত্তিতে):\n${lines.join('\n')}`, `Local summary from ${items.length} recent messages:\n${items.slice(-8).map(x => `${x.role}: ${x.text.replace(/\s+/g, ' ').slice(0, 180)}`).join('\n')}`, 'text-analysis');
}

function taskChain(r: AssistantRequest): AssistantReply | null {
  if (!/(?:ধাপ সাজাও|কাজের ধাপ|কাজগুলো সাজাও|plan steps|task chain|ধাপে ভাগ করো|একাধিক কাজের পরিকল্পনা)/iu.test(r.text)) return null;
  const source = r.text.replace(/^(?:.*?)(?:ধাপ সাজাও|কাজের ধাপ|কাজগুলো সাজাও|plan steps|task chain|ধাপে ভাগ করো|একাধিক কাজের পরিকল্পনা)\s*[:：-]?\s*/iu, '').trim();
  if (!source) return reply(r, 'উদাহরণ: “ধাপ সাজাও: সেটিংস খোলো তারপর Wi-Fi দেখাও”।', 'Example: “plan steps: open settings then show Wi-Fi”.');
  const tasks = planOfflineTasks(source);
  return reply(r, `কাজের পরিকল্পনা (${tasks.length} ধাপ):\n${tasks.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nএটি পরিকল্পনা মাত্র—সব ধাপ স্বয়ংক্রিয়ভাবে চালানো হয়েছে এমন নয়।`, `Task plan (${tasks.length} steps):\n${tasks.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nThis is a plan; the steps have not automatically been executed.`, 'task-plan');
}

async function notesKnowledge(r: AssistantRequest): Promise<AssistantReply | null> {
  if (!/(?:আমার নোটে খোঁজ|নোট থেকে খোঁজ|লোকাল জ্ঞান|personal knowledge brain|search my notes|find in my notes)/iu.test(r.text)) return null;
  const q = r.text.replace(/^(?:.*?)(?:আমার নোটে খোঁজ|নোট থেকে খোঁজ|লোকাল জ্ঞান|personal knowledge brain|search my notes|find in my notes)\s*[:：-]?\s*/iu, '').trim();
  const allNotes = await loadLocalNotes();
  const ranked = rankLocalCandidates(q, allNotes, n => n.text, 5);
  const results = ranked.length ? ranked : await searchLocalNotes(q);
  if (!results.length) return reply(r, 'লোকাল নোটে মেলেনি। আগে “নোটে রাখো: ...” দিয়ে তথ্য সংরক্ষণ করো, তারপর একই শব্দ বা কাছাকাছি অর্থের শব্দ দিয়ে খোঁজো।', 'No matching local note. Save it with “note: ...” first, then search using the same or related keywords.', 'notes');
  return reply(r, `লোকাল নোট থেকে প্রাসঙ্গিক ${results.length}টি ফল:\n${results.map((n, i) => `${i + 1}. ${n.text.slice(0, 350)}`).join('\n')}\n\nঅনুসন্ধানটি লোকাল শব্দ-সাদৃশ্যভিত্তিক; পূর্ণ embedding model নয়।`, `${results.length} relevant local note result(s):\n${results.map((n, i) => `${i + 1}. ${n.text.slice(0, 350)}`).join('\n')}\n\nThis uses local lexical similarity, not an embedding model.`, 'notes');
}

function pronunciation(r: AssistantRequest): AssistantReply | null {
  if (!/(?:উচ্চারণ অনুশীলন|pronunciation coach|উচ্চারণ শেখাও|শব্দের উচ্চারণ)/iu.test(r.text)) return null;
  const word = r.text.replace(/^(?:.*?)(?:উচ্চারণ অনুশীলন|pronunciation coach|উচ্চারণ শেখাও|শব্দের উচ্চারণ)\s*[:：-]?\s*/iu, '').trim();
  return reply(r, word ? `উচ্চারণ অনুশীলন: “${word}” ধীরে ধীরে বলো, তারপর স্বাভাবিক গতিতে আবার বলো। ডিভাইসে বাংলা TTS/ভয়েস থাকলে সেটি দিয়ে শুনে মিলিয়ে নাও। এই ফিচার নিজে থেকে উচ্চারণের নির্ভুলতা মাপছে না।` : 'যে শব্দটি অনুশীলন করতে চাও লিখো: “উচ্চারণ শেখাও: hello”।', word ? `Pronunciation practice: say “${word}” slowly, then at a natural pace. Compare it with your device’s installed TTS voice; this does not automatically score accuracy.` : 'Type a word, e.g. “pronunciation coach: hello”.', 'text-analysis');
}

function codeReview(r: AssistantRequest): AssistantReply | null {
  if (!/(?:কোড পরীক্ষা|কোডে ভুল খোঁজ|static code check|lint code|কোড lint)/iu.test(r.text)) return null;
  const code = r.text.replace(/^(?:.*?)(?:কোড পরীক্ষা|কোডে ভুল খোঁজ|static code check|lint code|কোড lint)\s*[:：-]?\s*/iu, '');
  const issues: string[] = [];
  if (!code.trim()) return reply(r, 'কোডটি “কোড পরীক্ষা: ...” লিখে পাঠাও।', 'Paste code using “static code check: ...”.');
  if ((code.match(/\{/g) || []).length !== (code.match(/\}/g) || []).length) issues.push('curly braces-এর সংখ্যা মেলেনি');
  if ((code.match(/\(/g) || []).length !== (code.match(/\)/g) || []).length) issues.push('parentheses-এর সংখ্যা মেলেনি');
  if (/\beval\s*\(/.test(code)) issues.push('eval() পাওয়া গেছে; untrusted input-এর জন্য ঝুঁকিপূর্ণ');
  if (/\b(?:password|api[_-]?key|secret)\s*[:=]\s*['"][^'"]{6,}/i.test(code)) issues.push('সম্ভাব্য secret/key hard-code করা আছে');
  if (/TODO|FIXME/.test(code)) issues.push('TODO/FIXME marker আছে');
  return reply(r, `স্থানীয় static check:\n${issues.length ? issues.map((x, i) => `${i + 1}. ${x}`).join('\n') : 'এই সহজ পরীক্ষায় পরিচিত সমস্যা ধরা পড়েনি।'}\n\nএটি কোড চালায় না এবং পূর্ণ compiler/typecheck নয়।`, `Local static check:\n${issues.length ? issues.map((x, i) => `${i + 1}. ${x}`).join('\n') : 'No issue detected by these basic checks.'}\n\nThis does not execute code or replace a compiler/typechecker.`, 'coding');
}

function firstAid(r: AssistantRequest): AssistantReply | null {
  if (!/(?:প্রাথমিক চিকিৎসা|first aid|জরুরি চিকিৎসা|কেউ অজ্ঞান|পোড়া গেলে|পুড়ে গেলে)/iu.test(r.text)) return null;
  return reply(r, 'প্রাথমিক চিকিৎসা গাইড (সাধারণ):\n• গুরুতর বিপদে বাংলাদেশে ৯৯৯-এ কল করো এবং কাছের বিশ্বস্ত প্রাপ্তবয়স্ককে জানাও।\n• অজ্ঞান কিন্তু স্বাভাবিকভাবে শ্বাস নিলে, আঘাতের সন্দেহ না থাকলে পাশ ফিরিয়ে রাখো; মুখে পানি/খাবার দিও না।\n• পোড়া স্থানে ২০ মিনিট ঠান্ডা প্রবাহমান পানি দাও; বরফ, তেল বা টুথপেস্ট দিও না।\n• শ্বাস না নিলে জরুরি সাহায্য ডাকো এবং প্রশিক্ষণ থাকলে CPR শুরু করো।\nএটি চিকিৎসকের বিকল্প নয়।', 'General first-aid guide:\n• For a serious emergency, call the local emergency number (Bangladesh: 999) and alert a trusted adult.\n• If unconscious but breathing normally, place them on their side if safe; give no food or drink.\n• Cool a burn under cool running water for 20 minutes; avoid ice, oil, or toothpaste.\n• If not breathing normally, call emergency services and start CPR if trained.\nThis is not a substitute for professional care.', 'help');
}

function privacy(r: AssistantRequest): AssistantReply | null {
  if (!/(?:permission monitor|privacy monitor|অনুমতি পরীক্ষা|প্রাইভেসি পরীক্ষা|কোন কোন permission|কোন অনুমতি আছে)/iu.test(r.text)) return null;
  return reply(r, 'Privacy Monitor: এই সংস্করণে আমি সরাসরি সব Android permission-এর live তালিকা পড়ছি না। Settings → Apps → Abir AI → Permissions-এ গিয়ে Microphone, Contacts, Notifications ইত্যাদি পরীক্ষা করো; দরকার নেই এমন অনুমতি বন্ধ রাখতে পারো।', 'Privacy Monitor: this build does not read every Android permission live. Open Settings → Apps → Abir AI → Permissions and review Microphone, Contacts, Notifications, etc.; disable permissions you do not need.', 'diagnostics');
}

async function smartContext(r: AssistantRequest): Promise<AssistantReply | null> {
  if (!/(?:প্রাসঙ্গিক তথ্য খোঁজ|আগের প্রসঙ্গ খোঁজ|context memory|smart context|আগের কথায়|আগের কথায়|কথোপকথনে খোঁজ|search conversation)/iu.test(r.text)) return null;
  const q = r.text.replace(/^(?:.*?)(?:প্রাসঙ্গিক তথ্য খোঁজ|আগের প্রসঙ্গ খোঁজ|context memory|smart context|আগের কথায়|আগের কথায়|কথোপকথনে খোঁজ|search conversation)\s*[:：-]?\s*/iu, '').trim();
  const context = r.conversationContext || [];
  const ranked = rankLocalCandidates(q, context, x => x.text, 4);
  const notes = await loadLocalNotes();
  const rankedNotes = rankLocalCandidates(q, notes, x => x.text, 4);
  const lines = [
    ...ranked.map(x => `কথোপকথন: ${x.text.replace(/\s+/g, ' ').slice(0, 220)}`),
    ...rankedNotes.map(x => `লোকাল নোট: ${x.text.replace(/\s+/g, ' ').slice(0, 220)}`),
  ];
  return reply(r, lines.length ? `প্রাসঙ্গিক লোকাল তথ্য (মিলের ভিত্তিতে):\n${lines.join('\n')}\n\nএটি শব্দ-সাদৃশ্যভিত্তিক অনুসন্ধান, পূর্ণ AI semantic understanding নয়।` : 'প্রাসঙ্গিক তথ্য মেলেনি। প্রশ্নের মূল শব্দ যোগ করো বা আগে নোটে তথ্য রাখো।', lines.length ? `Relevant local context:\n${lines.join('\n')}\n\nThis uses lexical similarity, not a full embedding model.` : 'No relevant local context found. Add keywords or save a local note first.', 'memory');
}

function advancedGoalPlan(r: AssistantRequest): AssistantReply | null {
  if (!/(?:goal plan|লক্ষ্যের পরিকল্পনা|স্মার্ট পরিকল্পনা|কাজের নিরাপদ পরিকল্পনা|plan my goal)/iu.test(r.text)) return null;
  const source = r.text.replace(/^(?:.*?)(?:goal plan|লক্ষ্যের পরিকল্পনা|স্মার্ট পরিকল্পনা|কাজের নিরাপদ পরিকল্পনা|plan my goal)\s*[:：-]?\s*/iu, '').trim();
  if (!source) return reply(r, 'উদাহরণ: “লক্ষ্যের পরিকল্পনা: সেটিংস খোলো তারপর Wi-Fi দেখো”।', 'Example: “plan my goal: open settings then check Wi-Fi”.', 'task-plan');
  const steps = buildGoalPlan(source);
  return reply(r, `লক্ষ্য পরিকল্পনা ও ঝুঁকি পরীক্ষা:\n${steps.map((x, i) => `${i + 1}. ${x.task}${x.dependency ? ` (আগের ধাপের পরে: ${x.dependency})` : ''}\n   ঝুঁকি: ${x.risk === 'high' ? 'উচ্চ—আগে নিশ্চিতকরণ' : x.risk === 'medium' ? 'মাঝারি—অনুমতি/সেটিংস যাচাই' : 'কম'}; ফেরানো সম্ভব: ${x.reversible ? 'সম্ভব হতে পারে' : 'নিশ্চিত নয়'}`).join('\n')}\n\nএটি পরিকল্পনা; কোনো কাজ নিজে থেকে চালানো হয়নি।`, `Goal plan and risk review:\n${steps.map((x, i) => `${i + 1}. ${x.task}${x.dependency ? ` (after: ${x.dependency})` : ''}\n   Risk: ${x.risk}; reversible: ${x.reversible ? 'possibly' : 'not guaranteed'}`).join('\n')}\n\nPlanning only; nothing was executed.`, 'task-plan');
}

function recoveryAdvice(r: AssistantRequest): AssistantReply | null {
  if (!/(?:কেন কাজ হয়নি|কেন কাজ হয়নি|কমান্ড ব্যর্থ|নিজে ঠিক করো|সমস্যা সমাধান|self recovery|recover failed|troubleshoot|কাজ করছে না|error ঠিক করো)/iu.test(r.text)) return null;
  const tips = diagnoseLocalFailure(r.text, r.conversationContext || []);
  return reply(r, `Self-Check / Recovery সহায়তা:\n${tips.length ? tips.map((x, i) => `${i + 1}. ${x}`).join('\n') : '১. সঠিক অ্যাপ/কমান্ড নিশ্চিত করো।\n২. অনুমতি ও প্রয়োজনীয় পরিষেবা পরীক্ষা করো।\n৩. ছোট ধাপে পুনরায় চেষ্টা করো।'}\n\nআমি নিজে থেকে ফোনের সব ব্যর্থতা শনাক্ত করতে বা গোপনে পরিবর্তন করতে পারি না; ফল যাচাই করা জরুরি।`, `Self-check / recovery advice:\n${tips.length ? tips.map((x, i) => `${i + 1}. ${x}`).join('\n') : '1. Confirm the target app/command.\n2. Check permissions and required services.\n3. Retry in smaller steps.'}\n\nThis is diagnostic guidance, not automatic repair of every device failure.`, 'diagnostics');
}

function actionPreview(r: AssistantRequest): AssistantReply | null {
  if (!/(?:কমান্ড চালানোর আগে|আগে ঝুঁকি দেখাও|action preview|preview command|ঝুঁকি যাচাই|কাজটা নিরাপদ কি)/iu.test(r.text)) return null;
  const source = r.text.replace(/^(?:.*?)(?:কমান্ড চালানোর আগে|আগে ঝুঁকি দেখাও|action preview|preview command|ঝুঁকি যাচাই|কাজটা নিরাপদ কি)\s*[:：-]?\s*/iu, '').trim();
  const risk = previewRisk(source);
  const level = risk.level === 'high' ? 'উচ্চ' : risk.level === 'medium' ? 'মাঝারি' : 'কম';
  return reply(r, `কমান্ড প্রিভিউ:\nকমান্ড: ${source || '(কমান্ড দেওয়া হয়নি)'}\nঝুঁকি: ${level}\n${risk.reasons.map((x, i) => `${i + 1}. ${x}`).join('\n')}\n\nএটি heuristic preview; Android-এর প্রকৃত action execution বা নিশ্চয়তা নয়।`, `Command preview:\nCommand: ${source || '(no command provided)'}\nRisk: ${risk.level}\n${risk.reasons.map((x, i) => `${i + 1}. ${x}`).join('\n')}\n\nThis is a heuristic preview, not a guarantee about actual Android execution.`, 'help');
}

async function offlineVoiceStatus(r: AssistantRequest): Promise<AssistantReply | null> {
  if (!/(?:অফলাইন ভয়েস স্ট্যাটাস|অফলাইন ভয়েস স্ট্যাটাস|offline voice status|লোকাল voice status|ইন্টারনেট ছাড়া কথা শুনবে)/iu.test(r.text)) return null;
  const available = await getOfflineSpeechRecognitionAvailability();
  return reply(r, available ? 'এই ডিভাইসের Native Android bridge অনুযায়ী offline speech recognition সুবিধা পাওয়া যাচ্ছে। তবে বাংলা ভাষার offline pack ইনস্টল আছে কি না আলাদাভাবে যাচাই করতে হবে।' : 'এই মুহূর্তে অ্যাপের Native Android bridge থেকে offline speech recognition উপলভ্য বলে নিশ্চিত হওয়া যায়নি। Android Speech Services ও বাংলা offline language pack পরীক্ষা করো।', available ? 'The native Android bridge reports offline speech recognition availability. The Bengali offline language pack still needs separate verification.' : 'Offline speech recognition is not confirmed available through the app’s native Android bridge. Check Android Speech Services and the Bengali offline language pack.', 'diagnostics');
}

function modelStatus(r: AssistantRequest): AssistantReply | null {
  if (!/(?:লোকাল ai brain|offline ai model|অফলাইন ai মডেল|লোকাল মডেল আছে কি|offline model status)/iu.test(r.text)) return null;
  return reply(r, 'লোকাল AI মডেল স্ট্যাটাস: এই প্রজেক্টে নিয়মভিত্তিক offline brain আছে। আলাদা Small Language Model ফাইল ও inference runtime যুক্ত না থাকলে এটি পূর্ণ LLM-এর মতো জটিল যুক্তি বা যেকোনো প্রশ্নের উত্তর দিতে পারবে না।', 'Local AI model status: this project has a rule-based offline brain. Without a bundled small language model and inference runtime, it cannot provide full LLM-level reasoning.', 'help');
}

function unavailableCapability(r: AssistantRequest): AssistantReply | null {
  if (!/(?:offline ocr|স্ক্রিনশট বিশ্লেষণ|screenshot analyzer|ফাইলের ভেতর খোঁজ|search file contents|notification organizer|নোটিফিকেশন সাজাও|ব্লুটুথ ডিভাইস history|offline translation pack|অফলাইন অনুবাদ প্যাক)/iu.test(r.text)) return null;
  return reply(r, 'এই কাজটির জন্য আলাদা Android API, OCR/translation model বা ফাইল অ্যাক্সেস সংযোগ লাগবে। বর্তমান কোডে সেটি নিশ্চিতভাবে যুক্ত নেই, তাই কাজ হয়েছে বলে ভুল দাবি করছি না।', 'This needs a dedicated Android API, OCR/translation model, or file-access integration. It is not confirmed as implemented in this build, so I will not claim it worked.', 'help');
}




async function localDocumentVault(r: AssistantRequest): Promise<AssistantReply | null> {
  const t = r.text.trim();
  const saveMatch = t.match(/^(?:ডকুমেন্ট সেভ করো|নথি সেভ করো|save local document|save document offline)\s*[:：]\s*([^|\n]{1,100})\s*[|｜]\s*([\s\S]+)$/iu);
  if (saveMatch) {
    try {
      const doc = await saveLocalDocument(saveMatch[1], saveMatch[2]);
      return reply(r, `ডকুমেন্ট লোকালি সেভ হয়েছে: ${doc.title}\nঅক্ষর: ${doc.text.length}\nসর্বোচ্চ ৪০টি লোকাল ডকুমেন্ট রাখা হবে। এগুলো এই ফোনের অ্যাপ স্টোরেজে থাকে।`, `Saved locally: ${doc.title}\nCharacters: ${doc.text.length}\nUp to 40 local documents are retained in this app's storage.`, 'notes');
    } catch { return reply(r, 'ডকুমেন্ট সেভ করা যায়নি। ফরম্যাট ব্যবহার করো: ডকুমেন্ট সেভ করো: শিরোনাম | সম্পূর্ণ লেখা', 'Could not save. Use: save local document: title | full text', 'diagnostics'); }
  }
  if (/^(?:লোকাল ডকুমেন্ট দেখাও|আমার ডকুমেন্ট দেখাও|list local documents|show saved documents)$/iu.test(t)) {
    const docs = await loadLocalDocuments();
    return reply(r, docs.length ? `লোকাল ডকুমেন্ট (${docs.length}):\n${docs.map((d,i)=>`${i+1}. ${d.title} — ${d.text.length} অক্ষর`).join('\n')}` : 'এখনো কোনো লোকাল ডকুমেন্ট সেভ করা নেই। “ডকুমেন্ট সেভ করো: শিরোনাম | লেখা” ব্যবহার করো।', docs.length ? `Local documents (${docs.length}):\n${docs.map((d,i)=>`${i+1}. ${d.title} — ${d.text.length} characters`).join('\n')}` : 'No local documents saved. Use “save local document: title | text”.', 'notes');
  }
  const searchMatch = t.match(/^(?:ডকুমেন্টে খোঁজ|ডকুমেন্ট থেকে খোঁজ|search local documents|find in saved documents)\s*[:：]?\s*(.+)$/iu);
  const qaMatch = t.match(/^(?:ডকুমেন্ট প্রশ্ন|ডকুমেন্ট থেকে উত্তর|ask saved documents|document q&a)\s*[:：]?\s*(.+)$/iu);
  if (searchMatch || qaMatch) {
    const query = (searchMatch || qaMatch)![1].trim();
    const hits = await searchLocalDocuments(query);
    return reply(r, hits.length ? `লোকাল ডকুমেন্ট থেকে ${hits.length}টি মিল:\n${hits.map((h,i)=>`${i+1}. ${h.document.title}\n${h.excerpt.trim().slice(0,450)}`).join('\n\n')}\n\nএটি সংরক্ষিত লেখার keyword search; কোনো মিল না থাকা তথ্য বানিয়ে বলা হয়নি।` : 'সংরক্ষিত ডকুমেন্টে মেলেনি। ডকুমেন্ট সেভ করো অথবা প্রশ্নের শব্দগুলো বদলে চেষ্টা করো।', hits.length ? `${hits.length} local document match(es):\n${hits.map((h,i)=>`${i+1}. ${h.document.title}\n${h.excerpt.trim().slice(0,450)}`).join('\n\n')}\n\nKeyword search over saved text; no unsupported answer was invented.` : 'No match in saved documents. Save text first or try different keywords.', 'notes');
  }
  return null;
}

async function localRoutineManager(r: AssistantRequest): Promise<AssistantReply | null> {
  const t = r.text.trim();
  const m = t.match(/^(?:রুটিন সেভ করো|নতুন রুটিন|save routine)\s*[:：]\s*([^|\n]{1,80})\s*[|｜]\s*(.+)$/iu);
  if (m) {
    const item = await saveLocalRoutine(m[1], m[2]);
    return reply(r, `রুটিন লোকালি সেভ হয়েছে: ${item.name}\nকমান্ড: ${item.command}\nচালানোর আগে কমান্ডটি দেখে নিশ্চিত হও। এই ফিচার নিজে থেকে কোনো কাজ চালায়নি।`, `Saved routine: ${item.name}\nCommand: ${item.command}\nReview the command before running it. Nothing was executed automatically.`, 'routine');
  }
  if (/^(?:রুটিন দেখাও|আমার রুটিন|list routines|show routines)$/iu.test(t)) {
    const items = await loadLocalRoutines();
    return reply(r, items.length ? `সেভ করা রুটিন:\n${items.map((x,i)=>`${i+1}. ${x.name}: ${x.command}`).join('\n')}` : 'কোনো রুটিন সেভ করা নেই। “রুটিন সেভ করো: নাম | কমান্ড” ব্যবহার করো।', items.length ? `Saved routines:\n${items.map((x,i)=>`${i+1}. ${x.name}: ${x.command}`).join('\n')}` : 'No saved routines. Use “save routine: name | command”.', 'routine');
  }
  return null;
}

function localPhraseTranslator(r: AssistantRequest): AssistantReply | null {
  const m = r.text.trim().match(/^(?:অফলাইন অনুবাদ|অনুবাদ অফলাইনে|offline translate|translate offline)\s*[:：]?\s*(.+)$/iu);
  if (!m) return null;
  const input = m[1].trim();
  const target = /[\u0980-\u09FF]/u.test(input) ? 'en' : 'bn';
  const result = translateOfflinePhrase(input, target);
  return reply(r, result ? `অফলাইন phrasebook:\n${input} → ${result}\n\nএটি সীমিত লোকাল phrasebook; পূর্ণ অনুবাদ মডেল নয়।` : `এই বাক্যটি লোকাল phrasebook-এ নেই: “${input}”\nঅজানা বাক্যের অনুবাদ বানিয়ে বলা হচ্ছে না। সম্পূর্ণ অফলাইন অনুবাদের জন্য আলাদা অনুবাদ মডেল ইনস্টল করতে হবে।`, result ? `Offline phrasebook:\n${input} → ${result}\n\nLimited phrasebook, not a full translation model.` : `Not in the local phrasebook: “${input}”. No translation was fabricated. A separate offline translation model is needed for general translation.`, 'text-analysis');
}

function offlineOcrStatus(r: AssistantRequest): AssistantReply | null {
  if (!/(?:ছবি থেকে লেখা পড়ো|ছবি থেকে লেখা পড়ো|অফলাইন ocr|offline ocr|ocr চালাও|ছবির লেখা বের করো)/iu.test(r.text)) return null;
  return reply(r, 'অফলাইন OCR: এই ZIP-এ OCR ইঞ্জিন/মডেল যুক্ত নেই, তাই এখনই ছবির লেখা শনাক্ত করার দাবি করা ঠিক হবে না। এই সংস্করণে ছবি নির্বাচন করা সম্ভব হলেও সত্যিকারের অফলাইন OCR-এর জন্য Tesseract/ML Kit-এর উপযুক্ত native integration ও বাংলা language data যোগ করতে হবে।', 'Offline OCR: this ZIP does not include an OCR engine/model, so it cannot honestly claim to extract text from an image yet. A compatible native OCR integration and Bengali language data are still required.', 'help');
}

function confidenceEstimator(r: AssistantRequest): AssistantReply | null {
  if (!/(?:উত্তরের confidence|confidence check|কতটা নিশ্চিত|উত্তর যাচাই|hallucination guard|তথ্যটা নিশ্চিত কি)/iu.test(r.text)) return null;
  const t = r.text.toLocaleLowerCase();
  const live = /(?:আজকের|এখনকার|লাইভ|বর্তমান দাম|আজ আবহাওয়া|আজ আবহাওয়া|latest|live|current price|weather today|news today)/iu.test(t);
  const specific = /(?:নাম কী|কত টাকা|কোন তারিখ|কত জন|সঠিক সংখ্যা|exactly|who is|what year)/iu.test(t);
  const level = live ? 'কম' : specific ? 'মাঝারি' : 'মাঝারি';
  return reply(r, `লোকাল Confidence Check: ${level}\nকারণ: ${live ? 'এই প্রশ্নে live/current তথ্য দরকার, অফলাইনে তা যাচাই করা যাচ্ছে না।' : 'নিয়মভিত্তিক বিশ্লেষণ করা হয়েছে; বাহ্যিক উৎস বা পূর্ণ LLM দিয়ে যাচাই করা হয়নি।'}\n\nএটি ক্যালিব্রেটেড probability নয়। অনিশ্চিত তথ্যকে নিশ্চিত তথ্য হিসেবে ধরে নিও না।`, `Local confidence check: ${live ? 'Low' : 'Moderate'}\nReason: ${live ? 'This requires live/current information that cannot be verified offline.' : 'This is rule-based analysis, not verified by external sources or a full LLM.'}\n\nThis is not a calibrated probability. Treat uncertain information cautiously.`, 'help');
}

function studyCoach(r: AssistantRequest): AssistantReply | null {
  if (!/(?:পড়া শেখাও|পড়াশোনার সাহায্য|study coach|শিখতে সাহায্য|এই বিষয় বুঝাও|এই বিষয় বুঝাও|প্র্যাকটিস করাও)/iu.test(r.text)) return null;
  const topic = r.text.replace(/^(?:.*?)(?:পড়া শেখাও|পড়াশোনার সাহায্য|study coach|শিখতে সাহায্য|এই বিষয় বুঝাও|এই বিষয় বুঝাও|প্র্যাকটিস করাও)\s*[:：-]?\s*/iu, '').trim();
  if (!topic) return reply(r, 'যে বিষয়টি শিখতে চাও লিখো। যেমন: “পড়া শেখাও: ভগ্নাংশ”।', 'Name a topic, e.g. “study coach: fractions”.', 'help');
  return reply(r, `অফলাইন Study Coach — ${topic}\n১. আগে বিষয়টির মূল ধারণা নিজের ভাষায় বলার চেষ্টা করো।\n২. এটিকে ৩টি ছোট অংশে ভাগ করো।\n৩. প্রতিটি অংশের পর একটি উদাহরণ নিজে সমাধান করো।\n৪. বই/নোটের তথ্যের সঙ্গে উত্তর মিলিয়ে দেখো।\n৫. শেষে না দেখে ৩টি প্রশ্নের উত্তর দাও।\n\nনোট: বিষয়ের নির্দিষ্ট তথ্য না থাকায় এটি শেখার পদ্ধতি; পূর্ণ AI-তৈরি পাঠ নয়।`, `Offline Study Coach — ${topic}\n1. Explain the core idea in your own words.\n2. Split it into three small parts.\n3. Solve one example after each part.\n4. Check against your book/notes.\n5. Recall three questions without looking.\n\nThis is a study method, not a topic-specific AI lesson.`, 'help');
}

function batteryOptimizer(r: AssistantRequest): AssistantReply | null {
  if (!/(?:ব্যাটারি বাঁচাও|battery optimizer|ব্যাটারি অপ্টিমাইজ|RAM কমাও|ফোন স্লো|ফোন ধীর|ফোন গরম)/iu.test(r.text)) return null;
  return reply(r, 'অফলাইন Battery/RAM Optimizer পরামর্শ:\n• অপ্রয়োজনীয় ব্যাকগ্রাউন্ড অ্যাপ বন্ধ করো।\n• বড় লোকাল AI মডেল ব্যবহারের সময় অন্য ভারী অ্যাপ বন্ধ রাখো।\n• অ্যাপের cache পরিষ্কার করার আগে গুরুত্বপূর্ণ ডেটা মুছবে না—cache ও app data আলাদা।\n• ফোন গরম হলে AI inference থামিয়ে ঠান্ডা হতে দাও।\n• Settings → Battery-তে কোন অ্যাপ বেশি শক্তি নিচ্ছে দেখো।\n\nএই সংস্করণে সরাসরি battery/RAM telemetry নিয়ে স্বয়ংক্রিয় সেটিং বদলানো হচ্ছে না।', 'Offline Battery/RAM advice:\n• Close unnecessary background apps.\n• Avoid running a large local model alongside heavy apps.\n• Do not clear app data when you only intend to clear cache.\n• Pause inference if the phone overheats.\n• Check Settings → Battery for heavy consumers.\n\nThis build does not automatically change settings based on live battery/RAM telemetry.', 'diagnostics');
}

function appCompatibility(r: AssistantRequest): AssistantReply | null {
  if (!/(?:অ্যাপ compatibility|অ্যাপ খুলছে না|অ্যাপ চলে না|app compatibility|app not working|অ্যাপ কাজ করছে না)/iu.test(r.text)) return null;
  return reply(r, 'লোকাল App Compatibility Check:\n১. অ্যাপটি ইনস্টল আছে এবং আপডেটেড কি না দেখো।\n২. Settings → Apps → সংশ্লিষ্ট অ্যাপ → Permissions পরীক্ষা করো।\n৩. Android সংস্করণ ও অ্যাপের ন্যূনতম সংস্করণ মিলিয়ে দেখো।\n৪. Force stop-এর পর আবার খোলো; ডেটা মুছবে না যদি ব্যাকআপ না থাকে।\n৫. ত্রুটি বার্তা থাকলে হুবহু পাঠাও।\n\nআমি সব ইনস্টল করা অ্যাপের সামঞ্জস্য স্বয়ংক্রিয়ভাবে স্ক্যান করছি না।', 'Local App Compatibility Check:\n1. Confirm the app is installed and updated.\n2. Review its permissions in Android Settings.\n3. Compare Android version with the app requirements.\n4. Try Force stop, then reopen; do not clear data without a backup.\n5. Share the exact error message.\n\nThis does not automatically scan every installed app.', 'diagnostics');
}

function knowledgePackStatus(r: AssistantRequest): AssistantReply | null {
  if (!/(?:offline knowledge pack|লোকাল জ্ঞান প্যাক|অফলাইন জ্ঞানভান্ডার|অনুবাদ প্যাকের অবস্থা|translation pack status|লোকাল ম্যাপস স্ট্যাটাস)/iu.test(r.text)) return null;
  return reply(r, 'Offline Knowledge Pack Status:\n• বর্তমান উৎস: অ্যাপের নিয়মভিত্তিক তথ্য, সংরক্ষিত লোকাল নোট ও বিদ্যমান কোড।\n• আলাদা বাংলা encyclopedia, translation model, offline map dataset বা LLM model এই কোড থেকে ইনস্টল আছে বলে নিশ্চিত করা যায় না।\n• এগুলো যোগ করতে আলাদা ডেটাসেট/মডেল, লাইসেন্স ও storage পরিকল্পনা দরকার।', 'Offline Knowledge Pack Status:\n• Current sources: rule-based content, saved local notes, and existing code.\n• This code cannot confirm a bundled Bengali encyclopedia, translation model, offline map dataset, or LLM model.\n• Those require separate datasets/models, licensing, and storage planning.', 'help');
}

function undoPlanner(r: AssistantRequest): AssistantReply | null {
  if (!/(?:undo planner|আগের অবস্থায় ফেরাও|আগের অবস্থায় ফেরাও|কাজ undo|undo কীভাবে|undo plan)/iu.test(r.text)) return null;
  return reply(r, 'Undo Planner:\n• কাজটি কী পরিবর্তন করেছে তা আগে শনাক্ত করো।\n• অ্যাপে Undo/Restore থাকলে সেটি ব্যবহার করো।\n• ফাইল বদলালে backup/version history দেখো।\n• কল, পাঠানো মেসেজ, পেমেন্ট বা স্থায়ী ডিলিট সবসময় ফেরানো যায় না।\n\nএই সহকারী বাস্তব পরিবর্তনের snapshot না রাখলে নিজে থেকে সব কাজ undo করতে পারবে না।', 'Undo Planner:\n• Identify what the action changed.\n• Use the app’s Undo/Restore if available.\n• Check backup/version history for files.\n• Calls, sent messages, payments, and permanent deletion may not be reversible.\n\nWithout snapshots of real changes, the assistant cannot undo every action automatically.', 'undo');
}

function offlineBenchmark(r: AssistantRequest): AssistantReply | null {
  if (!/(?:offline benchmark|অফলাইন benchmark|অফলাইন পরীক্ষা চালাও|নিজের ক্ষমতা পরীক্ষা|কতটা স্মার্ট)/iu.test(r.text)) return null;
  const checks = [
    'লোকাল token similarity: উপলভ্য',
    'কাজের ধাপ ও ঝুঁকি পরিকল্পনা: উপলভ্য',
    'লোকাল নোট ও সংরক্ষিত ডকুমেন্ট keyword search: উপলভ্য',
    'সীমিত বাংলা-ইংরেজি phrasebook অনুবাদ: উপলভ্য',
    'সেভ/লিস্ট রুটিন: উপলভ্য; স্বয়ংক্রিয় execution নয়',
    'প্রাথমিক লেখা/কোড heuristic: উপলভ্য',
    'পূর্ণ LLM inference: আলাদা মডেল/runtime ছাড়া নিশ্চিত নয়',
    'OCR/অনুবাদ/অফলাইন ম্যাপ ডেটা: আলাদা integration ছাড়া নিশ্চিত নয়',
    'Android-এ প্রকৃত action success verification: সংশ্লিষ্ট native signal লাগবে',
  ];
  return reply(r, `Offline Capability Benchmark (feature-level; performance benchmark নয়):\n${checks.map((x, i) => `${i + 1}. ${x}`).join('\n')}\n\nএই রিপোর্ট CPU/RAM speed বা model accuracy মাপেনি।`, `Offline Capability Benchmark (feature-level, not a performance benchmark):\n${checks.map((x, i) => `${i + 1}. ${x}`).join('\n')}\n\nThis report does not measure CPU/RAM speed or model accuracy.`, 'diagnostics');
}

async function localVoiceProfile(r: AssistantRequest): Promise<AssistantReply | null> {
  if (!/(?:voice profile|ভয়েস প্রোফাইল|ভয়েস প্রোফাইল|আমার উত্তর ছোট রাখো|আমার উত্তর বিস্তারিত রাখো|উত্তর বাংলা রাখো)/iu.test(r.text)) return null;
  const key = 'abir-ai-local-voice-profile-v1';
  const text = norm(r.text);
  let preference = 'default';
  if (/(?:উত্তর ছোট রাখো|short answers)/iu.test(text)) preference = 'concise';
  else if (/(?:উত্তর বিস্তারিত রাখো|detailed answers)/iu.test(text)) preference = 'detailed';
  else if (/(?:উত্তর বাংলা রাখো|বাংলায় উত্তর|বাংলায় উত্তর)/iu.test(text)) preference = 'bengali';
  try {
    await AsyncStorage.setItem(key, JSON.stringify({ preference, updatedAt: Date.now() }));
    return reply(r, `লোকাল উত্তর-প্রোফাইল সংরক্ষিত: ${preference}\nএটি ডিভাইসে রাখা হয়েছে। সব voice/TTS সেটিং এই পছন্দ অনুসারে বদলায়—এমন নয়।`, `Local response preference saved: ${preference}. Stored on this device; this does not automatically reconfigure every voice/TTS setting.`, 'memory');
  } catch {
    return reply(r, 'লোকাল প্রোফাইল সংরক্ষণ করা যায়নি। পরে আবার চেষ্টা করো।', 'Could not save the local profile. Try again later.', 'diagnostics');
  }
}

function completeOfflineFeatureList(r: AssistantRequest): AssistantReply | null {
  if (!/(?:সব অফলাইন ফিচারের লিস্ট|অফলাইন ফিচার লিস্ট|show offline features|list offline features|final offline list)/iu.test(r.text)) return null;
  const language = r.language === 'en' && !bn(r.text) ? 'en' : 'bn';
  const lines = getOfflineFeatureReport(language);
  return reply(r, `চূড়ান্ত Offline Feature Set: ${FINAL_OFFLINE_FEATURES.length}টি
${lines.join('\n')}\n\nস্ট্যাটাস: “লোকাল” মানে বর্তমান কোড/স্টোরেজে করা যায়; “Android/API” মানে native capability দরকার; “মডেল দরকার” মানে আলাদা offline model; “ইন্টিগ্রেশন দরকার” মানে dataset/runtime/native integration এখনো প্রয়োজন।`, `Final Offline Feature Set: ${FINAL_OFFLINE_FEATURES.length} features\n${lines.join('\n')}\n\nStatus: local means local code/storage; Android/API means native capability; model required means an offline model is needed; integration required means dataset/runtime/native integration is still needed.`, 'diagnostics');
}

function finalUpgradeStatus(r: AssistantRequest): AssistantReply | null {
  if (!/(?:শেষ অফলাইন আপগ্রেড|offline final upgrade|সব অফলাইন ফিচার|offline feature status|অফলাইন ফিচারের অবস্থা)/iu.test(r.text)) return null;
  return reply(r, 'Abir AI Offline Upgrade Status:\n• যুক্ত: লোকাল lexical context ranking, goal planning, risk preview, recovery advice, local notes search, ৪০টি পর্যন্ত pasted-text document vault ও keyword Q&A, সীমিত বাংলা-ইংরেজি phrasebook, routine save/list, summary, basic writing/code checks, study guidance, privacy/battery guidance।\n• বিদ্যমান সিস্টেম অক্ষত রাখার জন্য additive extension ব্যবহার করা হয়েছে।\n• মেমোরি সীমা: ২০০; document vault আলাদা স্টোরেজে।\n• আলাদা model/runtime বা native integration দরকার: পূর্ণ Local AI Brain, উন্নত বাংলা ASR/TTS, সত্যিকারের image OCR, সাধারণ অনুবাদ মডেল, semantic embeddings, sandboxed code execution, live Android telemetry ও offline maps।\n• Reminder scheduling, basic calculator ও supported device commands আগের সিস্টেম থেকেই আছে।\n\nফিচারের নাম/পরামর্শকে বাস্তব integration-এর সমান ধরা যাবে না।', 'Abir AI Offline Upgrade Status:\n• Added: local lexical context ranking, goal planning, risk preview, recovery advice, local notes search, a 40-document pasted-text vault with keyword Q&A, a limited Bengali-English phrasebook, routine save/list, summaries, basic writing/code checks, study guidance, and privacy/battery guidance.\n• Implemented as additive extensions to preserve existing systems.\n• Memory cap: 200; document vault uses separate storage.\n• Existing reminder scheduling, basic calculator, and supported device commands remain.\n• Separate model/runtime or native integration still needed: full local AI brain, advanced Bengali ASR/TTS, actual image OCR, general translation, semantic embeddings, sandboxed code execution, live Android telemetry, and offline maps.\n\nFeature labels/advice are not the same as a working integration.', 'diagnostics');
}


export const offlineIntelligencePackExtension: AssistantExtension = {
  id: 'offline-intelligence-pack-v4-18',
  async handle(request) {
    const text = norm(request.text);
    const handlers: Array<() => AssistantReply | null | Promise<AssistantReply | null>> = [
      () => offlineVoiceStatus(request),
      () => localDocumentVault(request),
      () => localRoutineManager(request),
      () => localPhraseTranslator(request),
      () => offlineOcrStatus(request),
      () => confidenceEstimator(request),
      () => studyCoach(request),
      () => batteryOptimizer(request),
      () => appCompatibility(request),
      () => knowledgePackStatus(request),
      () => undoPlanner(request),
      () => offlineBenchmark(request),
      () => localVoiceProfile(request),
      () => completeOfflineFeatureList(request),
      () => finalUpgradeStatus(request),
      () => advancedGoalPlan(request),
      () => recoveryAdvice(request),
      () => actionPreview(request),
      () => smartContext(request),
      () => modelStatus(request),
      () => grammar(request.text, request),
      () => conversationSummary(request),
      () => taskChain(request),
      () => pronunciation(request),
      () => codeReview(request),
      () => firstAid(request),
      () => privacy(request),
      () => unavailableCapability(request),
      () => notesKnowledge(request),
    ];
    for (const handler of handlers) {
      const result = await handler();
      if (result) { await record(result.intent); return result; }
    }
    if (/(?:memory limit|মেমোরি সীমা|কতটি স্মৃতি|কত মেমোরি)/iu.test(text)) {
      await record('memory-limit');
      return reply(request, `মেমোরির সর্বোচ্চ সীমা ${MAX_MEMORY_ITEMS}টি তথ্য। নতুন তথ্য যোগ হলে পুরোনো তথ্য আগে সরবে; এই সীমা বাড়ানো হয়নি।`, `Persistent memory is capped at ${MAX_MEMORY_ITEMS} facts. Older facts are trimmed first; the cap has not been increased.`, 'memory');
    }
    return null;
  },
};
