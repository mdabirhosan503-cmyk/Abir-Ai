/** Abir AI 5.4 bilingual local-first utilities.
 * This module implements useful local workflows without pretending that missing native
 * model assets/connectors are available. Persistent fact memory remains capped at 200.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';

const KEY = 'abir-ai-modern-workflows-v1';
type Task = { id: string; title: string; done: boolean; createdAt: number; doneAt?: number };
type Routine = { name: string; steps: string[]; updatedAt: number };
type State = { tasks: Task[]; routines: Routine[]; audit: Array<{ at: number; action: string; result: string }> };
const empty = (): State => ({ tasks: [], routines: [], audit: [] });
const bn = (s: string) => /[\u0980-\u09ff]/u.test(s);
const norm = (s: string) => s.normalize('NFKC').toLocaleLowerCase().replace(/[!?.,،।:：;]+/gu, ' ').replace(/\s+/gu, ' ').trim();
const reply = (r: AssistantRequest, b: string, e: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: r.language === 'bn' || bn(r.text) ? b : e, intent });
async function read(): Promise<State> {
  try {
    const raw = await AsyncStorage.getItem(KEY); const v = raw ? JSON.parse(raw) : {};
    return {
      tasks: Array.isArray(v.tasks) ? v.tasks.filter((x: any) => x && typeof x.title === 'string').slice(-200) : [],
      routines: Array.isArray(v.routines) ? v.routines.filter((x: any) => x && typeof x.name === 'string' && Array.isArray(x.steps)).slice(-50) : [],
      audit: Array.isArray(v.audit) ? v.audit.slice(-100) : [],
    };
  } catch { return empty(); }
}
async function write(s: State) { await AsyncStorage.setItem(KEY, JSON.stringify({ tasks: s.tasks.slice(-200), routines: s.routines.slice(-50), audit: s.audit.slice(-100) })); }
function log(s: State, action: string, result: string) { s.audit.push({ at: Date.now(), action: action.slice(0,120), result: result.slice(0,120) }); s.audit = s.audit.slice(-100); }

function convert(value: number, from: string, to: string): number | null {
  const units: Record<string, { group: string; factor: number; offset?: number }> = {
    m: { group: 'length', factor: 1 }, meter: { group: 'length', factor: 1 }, meters: { group: 'length', factor: 1 }, km: { group: 'length', factor: 1000 }, kilometer: { group: 'length', factor: 1000 }, kilometers: { group: 'length', factor: 1000 }, cm: { group: 'length', factor: .01 }, mm: { group: 'length', factor: .001 }, mile: { group: 'length', factor: 1609.344 }, miles: { group: 'length', factor: 1609.344 }, mi: { group: 'length', factor: 1609.344 }, ft: { group: 'length', factor: .3048 }, feet: { group: 'length', factor: .3048 }, inch: { group: 'length', factor: .0254 }, inches: { group: 'length', factor: .0254 },
    kg: { group: 'mass', factor: 1 }, kilogram: { group: 'mass', factor: 1 }, g: { group: 'mass', factor: .001 }, gram: { group: 'mass', factor: .001 }, lb: { group: 'mass', factor: .45359237 }, lbs: { group: 'mass', factor: .45359237 }, pound: { group: 'mass', factor: .45359237 },
    s: { group: 'time', factor: 1 }, sec: { group: 'time', factor: 1 }, second: { group: 'time', factor: 1 }, min: { group: 'time', factor: 60 }, minute: { group: 'time', factor: 60 }, h: { group: 'time', factor: 3600 }, hr: { group: 'time', factor: 3600 }, hour: { group: 'time', factor: 3600 },
    c: { group: 'temperature', factor: 1 }, celsius: { group: 'temperature', factor: 1 }, f: { group: 'temperature', factor: 1, offset: 32 }, fahrenheit: { group: 'temperature', factor: 1, offset: 32 },
    l: { group: 'volume', factor: 1 }, liter: { group: 'volume', factor: 1 }, liters: { group: 'volume', factor: 1 }, ml: { group: 'volume', factor: .001 }, gallon: { group: 'volume', factor: 3.785411784 }, gallons: { group: 'volume', factor: 3.785411784 },
  };
  const a = units[norm(from)], b = units[norm(to)]; if (!a || !b || a.group !== b.group) return null;
  if (a.group === 'temperature') { const c = norm(from).startsWith('f') ? (value - 32) * 5 / 9 : value; return norm(to).startsWith('f') ? c * 9 / 5 + 32 : c; }
  return value * a.factor / b.factor;
}

async function searchDocs(query: string): Promise<Array<{ title: string; body: string; score: number }>> {
  try {
    const raw = await AsyncStorage.getItem('abir-ai-offline-expansion-v1');
    const value = raw ? JSON.parse(raw) : {};
    const docs = Array.isArray(value.docs) ? value.docs : [];
    const terms = norm(query).split(' ').filter(x => x.length > 1);
    return docs.map((d: any) => {
      if (!d || typeof d.title !== 'string' || typeof d.body !== 'string') return null;
      const hay = norm(`${d.title} ${d.body}`); const score = terms.reduce((n, t) => n + (hay.includes(t) ? 1 : 0), 0);
      return score ? { title: d.title, body: d.body, score } : null;
    }).filter((x: any) => x).sort((a: any, b: any) => b.score - a.score).slice(0, 5);
  } catch { return []; }
}

async function handle(r: AssistantRequest): Promise<AssistantReply | null> {
  const raw = r.text.trim(); if (!raw) return null; const n = norm(raw); const s = await read();
  let m = raw.match(/^(?:add task|create task|নতুন কাজ|কাজ যোগ করো)\s*[:：]?\s*(.+)$/iu);
  if (m) {
    const title = m[1].trim().slice(0,240); if (!title) return null;
    const prior = s.tasks.find(t => norm(t.title) === norm(title) && !t.done);
    if (prior) return reply(r, `এই কাজটি আগে থেকেই আছে: ${prior.title}`, `That task already exists: ${prior.title}`, 'routine');
    s.tasks.push({ id: `${Date.now()}-${s.tasks.length}`, title, done: false, createdAt: Date.now() }); log(s, 'add task', 'saved'); await write(s);
    return reply(r, `কাজ যোগ হয়েছে: ${title}\nমোট অসম্পূর্ণ কাজ: ${s.tasks.filter(t=>!t.done).length}`, `Task added: ${title}\nOpen tasks: ${s.tasks.filter(t=>!t.done).length}`, 'routine');
  }
  if (/^(?:list tasks|show tasks|my tasks|কাজের তালিকা|আমার কাজ দেখাও)$/iu.test(n)) {
    const items = s.tasks.slice().reverse().slice(0,40);
    return reply(r, items.length ? `কাজের তালিকা:\n${items.map((t,i)=>`${i+1}. [${t.done?'✓':' '}] ${t.title}`).join('\n')}` : 'কোনো কাজ সংরক্ষিত নেই।', items.length ? `Tasks:\n${items.map((t,i)=>`${i+1}. [${t.done?'✓':' '}] ${t.title}`).join('\n')}` : 'No saved tasks.', 'routine');
  }
  m = raw.match(/^(?:complete task|finish task|কাজ শেষ|কাজ সম্পন্ন)\s+(\d+)$/iu);
  if (m) { const idx = Number(m[1]) - 1; const view = s.tasks.slice().reverse(); const task = view[idx]; if (!task) return reply(r, 'এই নম্বরের কাজ পাওয়া যায়নি। “কাজের তালিকা” দেখো।', 'Task number not found. List tasks first.', 'routine'); task.done = true; task.doneAt = Date.now(); log(s, 'complete task', task.title); await write(s); return reply(r, `কাজ সম্পন্ন হিসেবে চিহ্নিত: ${task.title}`, `Marked complete: ${task.title}`, 'routine'); }
  m = raw.match(/^(?:save routine|create routine|রুটিন সেভ|রুটিন তৈরি)\s+([^:：]+)\s*[:：]\s*([\s\S]+)$/iu);
  if (m) { const name = m[1].trim().slice(0,100); const steps = m[2].split(/\n|\s*(?:;|\|)\s*/u).map(x=>x.trim()).filter(Boolean).slice(0,30); if (!name || !steps.length) return reply(r, 'রুটিনের নাম ও অন্তত একটি ধাপ দাও।', 'Provide a routine name and at least one step.'); s.routines = s.routines.filter(x=>norm(x.name)!==norm(name)); s.routines.push({ name, steps, updatedAt: Date.now() }); log(s, 'save routine', name); await write(s); return reply(r, `রুটিন সেভ হয়েছে: ${name}\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nএটি সংরক্ষিত পরিকল্পনা; স্বয়ংক্রিয়ভাবে কোনো কাজ চালানো হয়নি।`, `Routine saved: ${name}\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nSaved plan only; no actions were executed.`, 'routine'); }
  if (/^(?:list routines|show routines|রুটিন দেখাও|রুটিনের তালিকা)$/iu.test(n)) return reply(r, s.routines.length ? `সংরক্ষিত রুটিন:\n${s.routines.map((x,i)=>`${i+1}. ${x.name} — ${x.steps.length} ধাপ`).join('\n')}` : 'কোনো রুটিন সেভ নেই।', s.routines.length ? `Saved routines:\n${s.routines.map((x,i)=>`${i+1}. ${x.name} — ${x.steps.length} steps`).join('\n')}` : 'No routines saved.', 'routine');
  m = raw.match(/^(?:preview routine|show routine|রুটিন দেখাও)\s+(.+)$/iu);
  if (m) { const item = s.routines.find(x=>norm(x.name)===norm(m![1])); if (!item) return reply(r, 'এই নামে কোনো রুটিন নেই।', 'No routine with that name.'); return reply(r, `রুটিন: ${item.name}\n${item.steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nপ্রিভিউ মাত্র—কোনো কাজ চালানো হয়নি।`, `Routine: ${item.name}\n${item.steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nPreview only; no action executed.`, 'routine'); }
  m = raw.match(/^(?:ask documents|document question|নথিকে জিজ্ঞেস করো|ডকুমেন্ট থেকে উত্তর)\s*[:：]?\s*(.+)$/iu);
  if (m) { const hits = await searchDocs(m[1]); if (!hits.length) return reply(r, 'সংরক্ষিত নথিতে মিল পাওয়া যায়নি। আগে “নথি সেভ [নাম]: [লেখা” ব্যবহার করো।', 'No matching saved document content found. Save a document first.', 'fallback'); return reply(r, `নথিভিত্তিক ফল (কীওয়ার্ড মিল; এটি জেনারেটিভ AI উত্তর নয়):\n${hits.map(x=>`• ${x.title} (মিল ${x.score}): ${x.body.slice(0,700)}`).join('\n\n')}`, `Document-grounded results (keyword matches; not a generative AI answer):\n${hits.map(x=>`• ${x.title} (score ${x.score}): ${x.body.slice(0,700)}`).join('\n\n')}`, 'notes'); }
  m = raw.match(/^(?:convert|unit convert|একক রূপান্তর|একক বদলাও)\s+(-?\d+(?:\.\d+)?)\s+([a-zA-Z]+)\s+(?:to|into|থেকে|হতে)\s+([a-zA-Z]+)$/iu);
  if (m) { const value = convert(Number(m[1]), m[2], m[3]); if (value === null) return reply(r, 'এই এককগুলো সমর্থিত নয় বা একই ধরনের নয়। দৈর্ঘ্য, ভর, সময়, তাপমাত্রা ও আয়তনের একক ব্যবহার করো।', 'Unsupported or incompatible units. Supported groups: length, mass, time, temperature and volume.', 'unit-converter'); return reply(r, `${m[1]} ${m[2]} = ${Number(value.toPrecision(8))} ${m[3]}`, `${m[1]} ${m[2]} = ${Number(value.toPrecision(8))} ${m[3]}`, 'unit-converter'); }
  if (/^(?:local ai status|offline ai status|অফলাইন এআই স্ট্যাটাস|লোকাল এআই স্ট্যাটাস)$/iu.test(n)) {
    return reply(r, `লোকাল AI অবস্থা\n• অফলাইন কমান্ড ও লোকাল ওয়ার্কফ্লো: সক্রিয়\n• সংরক্ষিত কাজ: ${s.tasks.length} (অসম্পূর্ণ ${s.tasks.filter(x=>!x.done).length})\n• রুটিন: ${s.routines.length}\n• লোকাল অডিট: ${s.audit.length}\n• স্থায়ী মেমোরি সীমা: ২০০\n• পূর্ণ LLM/স্থানীয় speech/OCR: মডেল ও নেটিভ ইন্টিগ্রেশন থাকলেই উপলব্ধ।`, `Local AI status\n• Offline commands and local workflows: active\n• Saved tasks: ${s.tasks.length} (${s.tasks.filter(x=>!x.done).length} open)\n• Routines: ${s.routines.length}\n• Local audit entries: ${s.audit.length}\n• Persistent memory limit: 200\n• Full LLM/local speech/OCR require model assets and native integrations.`, 'diagnostics');
  }
  if (/^(?:modern upgrade status|abir ai 5\.4 status|আধুনিক আপগ্রেড স্ট্যাটাস)$/iu.test(n)) return reply(r, `Abir AI bilingual local workflows\n• Tasks: ${s.tasks.length}/200\n• Routines: ${s.routines.length}/50\n• Audit log: ${s.audit.length}/100\n• Document keyword Q&A: available for locally saved documents\n• Unit conversion: available\n• Memory cap: 200 (unchanged)`, `Abir AI bilingual local workflows\n• Tasks: ${s.tasks.length}/200\n• Routines: ${s.routines.length}/50\n• Audit log: ${s.audit.length}/100\n• Document keyword Q&A: available for locally saved documents\n• Unit conversion: available\n• Memory cap: 200 (unchanged)`, 'diagnostics');
  return null;
}
export const offlineModernUpgradeExtension: AssistantExtension = { id: 'offline-modern-upgrade-5.4', handle };
