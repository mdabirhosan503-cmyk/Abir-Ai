/** Abir AI 5.3 Offline Expansion Pack.
 * Practical, network-free bilingual utilities. Platform/model-dependent features are
 * explicitly not simulated here. Does not modify the persistent memory limit (200).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';

const KEY = 'abir-ai-offline-expansion-v1';
type Doc = { id: string; title: string; body: string; updatedAt: number };
type Quiz = { question: string; answer: string };
type State = { docs: Doc[]; glossary: Array<{ term: string; bn: string; en: string }> };
const EMPTY: State = { docs: [], glossary: [] };
const hasBn = (s: string) => /[\u0980-\u09ff]/u.test(s);
const norm = (s: string) => s.normalize('NFKC').toLocaleLowerCase().replace(/[!?.,،।:：;]+/gu, ' ').replace(/\s+/gu, ' ').trim();
const reply = (r: AssistantRequest, bn: string, en: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: (r.language === 'bn' || hasBn(r.text)) ? bn : en, intent });
async function load(): Promise<State> {
  try { const raw = await AsyncStorage.getItem(KEY); const x = raw ? JSON.parse(raw) : {}; return { docs: Array.isArray(x.docs) ? x.docs.filter((d: any) => d && typeof d.title === 'string' && typeof d.body === 'string').slice(-100) : [], glossary: Array.isArray(x.glossary) ? x.glossary.slice(-300) : [] }; }
  catch { return { ...EMPTY }; }
}
async function save(s: State) { await AsyncStorage.setItem(KEY, JSON.stringify({ docs: s.docs.slice(-100), glossary: s.glossary.slice(-300) })); }
const localPhrases: Record<string, { bn: string; en: string }> = {
  'hello': { bn: 'হ্যালো', en: 'Hello' }, 'good morning': { bn: 'সুপ্রভাত', en: 'Good morning' }, 'good night': { bn: 'শুভ রাত্রি', en: 'Good night' },
  'thank you': { bn: 'ধন্যবাদ', en: 'Thank you' }, 'please': { bn: 'দয়া করে', en: 'Please' }, 'how are you': { bn: 'তুমি কেমন আছ?', en: 'How are you?' },
  'i am fine': { bn: 'আমি ভালো আছি', en: 'I am fine' }, 'what is your name': { bn: 'তোমার নাম কী?', en: 'What is your name?' },
  'আমি ভালো আছি': { bn: 'আমি ভালো আছি', en: 'I am fine' }, 'ধন্যবাদ': { bn: 'ধন্যবাদ', en: 'Thank you' }, 'সুপ্রভাত': { bn: 'সুপ্রভাত', en: 'Good morning' },
  'offline': { bn: 'ইন্টারনেট সংযোগ ছাড়া', en: 'Without an internet connection' }, 'memory': { bn: 'স্মৃতি বা সংরক্ষিত তথ্য', en: 'Stored information or recall' },
  'privacy': { bn: 'গোপনীয়তা', en: 'Control over personal information' }, 'assistant': { bn: 'সহকারী', en: 'A system that helps with tasks' },
  'routine': { bn: 'নিয়মিত কাজের ধারা', en: 'A sequence of tasks performed regularly' }, 'intelligence': { bn: 'বুদ্ধিমত্তা', en: 'Ability to reason and solve problems' },
};
function summarize(text: string, limit = 3): string {
  const sentences = text.replace(/\s+/gu, ' ').split(/(?<=[.!?।])\s+/u).map(s => s.trim()).filter(Boolean);
  if (sentences.length <= limit) return text.trim();
  // Lightweight extractive summary: keep first sentence and sentences with most repeated meaningful words.
  const stop = new Set(['this','that','with','from','have','will','your','about','then','they','them','there','their','যে','এবং','করে','হয়','হবে','কিন্তু','এটা','এটি','তার','একটি']);
  const freq: Record<string, number> = {};
  for (const w of norm(text).split(' ')) if (w.length > 2 && !stop.has(w)) freq[w] = (freq[w] || 0) + 1;
  const ranked = sentences.map((s, i) => ({ s, i, score: norm(s).split(' ').reduce((n, w) => n + (freq[w] || 0), 0) / Math.max(1, norm(s).split(' ').length) + (i === 0 ? 0.5 : 0) }));
  return ranked.sort((a,b) => b.score-a.score).slice(0, limit).sort((a,b) => a.i-b.i).map(x=>x.s).join(' ');
}
function makeQuiz(text: string): Quiz[] {
  const sentences = text.split(/(?<=[.!?।])\s+/u).map(s => s.trim()).filter(s => s.length >= 18);
  return sentences.slice(0, 5).map((s, i) => ({ question: `${i+1}. ${hasBn(s) ? 'এই বাক্যটির মূল বক্তব্য কী?' : 'What is the main point of this sentence?'}`, answer: s }));
}
function planSteps(goal: string): string[] {
  const pieces = goal.split(/\s*(?:;|\||->|=>| then | এরপর | তারপর | এবং তারপর )\s*/iu).map(x=>x.trim()).filter(Boolean);
  return pieces.length > 1 ? pieces.slice(0, 12) : [
    `1. Define the goal / লক্ষ্য পরিষ্কার করো: ${goal}`,
    '2. Gather required information / দরকারি তথ্য জোগাড় করো',
    '3. Break the work into small steps / ছোট ধাপে ভাগ করো',
    '4. Complete one step at a time / এক ধাপ করে কাজ করো',
    '5. Verify the result / ফলাফল যাচাই করো',
  ];
}
async function handle(r: AssistantRequest): Promise<AssistantReply | null> {
  const raw = r.text.trim(); if (!raw) return null;
  const n = norm(raw); const s = await load();

  let m = raw.match(/^(?:save document|add document|document save|নথি সেভ|ডকুমেন্ট যোগ)\s+([^:：]+)\s*[:：]\s*([\s\S]+)$/iu);
  if (m) {
    const title = m[1].trim().slice(0,100), body = m[2].trim().slice(0,30000);
    if (!title || !body) return reply(r, 'নথির নাম ও লেখা দুটোই দিতে হবে।', 'Provide both a document title and its text.');
    s.docs = s.docs.filter(d => norm(d.title) !== norm(title)); s.docs.push({ id: `${Date.now()}`, title, body, updatedAt: Date.now() }); await save(s);
    return reply(r, `নথি লোকালি সেভ হয়েছে: ${title}\nলেখার দৈর্ঘ্য: ${body.length} অক্ষর।`, `Document saved locally: ${title}\nText length: ${body.length} characters.`, 'notes');
  }
  if (/^(?:show documents|list documents|my documents|নথির তালিকা|ডকুমেন্ট দেখাও)$/iu.test(n)) {
    return reply(r, s.docs.length ? `লোকাল নথি:\n${s.docs.slice().reverse().map((d,i)=>`${i+1}. ${d.title} (${d.body.length} অক্ষর)`).join('\n')}` : 'এখনো কোনো নথি সেভ করা নেই।', s.docs.length ? `Local documents:\n${s.docs.slice().reverse().map((d,i)=>`${i+1}. ${d.title} (${d.body.length} characters)`).join('\n')}` : 'No local documents saved yet.', 'notes');
  }
  m = raw.match(/^(?:search documents|find in documents|document search|নথি খোঁজো|ডকুমেন্ট সার্চ)\s+(.+)$/iu);
  if (m) {
    const q = norm(m[1]); const hits = s.docs.filter(d=>norm(d.title).includes(q)||norm(d.body).includes(q)).slice(-10).reverse();
    return reply(r, hits.length ? `নথিতে মিল:\n${hits.map(d=>`• ${d.title}: ${d.body.slice(0,500)}`).join('\n')}` : 'কোনো নথিতে মিল পাওয়া যায়নি।', hits.length ? `Document matches:\n${hits.map(d=>`• ${d.title}: ${d.body.slice(0,500)}`).join('\n')}` : 'No matching documents found.', 'notes');
  }
  m = raw.match(/^(?:summarize|summary|সারাংশ|সারাংশ করো)\s*[:：]?\s*([\s\S]{20,})$/iu);
  if (m) { const out = summarize(m[1]); return reply(r, `সংক্ষিপ্ত সারাংশ (স্থানীয় extractive):\n${out}\n\nনোট: এটি বাক্য বেছে সংক্ষিপ্ত করে; গভীর অর্থবোধক AI সারাংশ নয়।`, `Short summary (local extractive):\n${out}\n\nNote: this selects sentences; it is not a full generative AI summary.`, 'text-analysis'); }
  m = raw.match(/^(?:text stats|analyze text|word count|লেখার পরিসংখ্যান|লেখা বিশ্লেষণ)\s*[:：]?\s*([\s\S]+)$/iu);
  if (m) {
    const t=m[1].trim(), words=t.split(/\s+/u).filter(Boolean), sentences=t.split(/[.!?।]+/u).filter(x=>x.trim()).length, paragraphs=t.split(/\n\s*\n/u).filter(x=>x.trim()).length;
    const stats=`Characters: ${t.length}\nWords: ${words.length}\nSentences: ${sentences}\nParagraphs: ${paragraphs}\nReading time: about ${Math.max(1,Math.ceil(words.length/200))} min`;
    return reply(r, `লেখার পরিসংখ্যান:\nঅক্ষর: ${t.length}\nশব্দ: ${words.length}\nবাক্য: ${sentences}\nঅনুচ্ছেদ: ${paragraphs}\nপড়ার আনুমানিক সময়: ${Math.max(1,Math.ceil(words.length/200))} মিনিট`, stats, 'text-analysis');
  }
  m = raw.match(/^(?:offline translate|translate phrase|অনুবাদ করো|অফলাইন অনুবাদ)\s*[:：]?\s*(.+)$/iu);
  if (m) {
    const q=norm(m[1]); const match=Object.entries(localPhrases).find(([k])=>norm(k)===q) ?? s.glossary.map(x=>[x.term,{bn:x.bn,en:x.en}] as const).find(([k])=>norm(k)===q);
    if (match) { const value=match[1] as {bn:string;en:string}; return reply(r, `বাংলা: ${value.bn}\nEnglish: ${value.en}\n\nএটি স্থানীয় phrasebook/glossary থেকে এসেছে।`, `Bangla: ${value.bn}\nEnglish: ${value.en}\n\nFrom the local phrasebook/glossary.`, 'help'); }
    return reply(r, 'এই বাক্যটি স্থানীয় phrasebook-এ নেই। পূর্ণ বাক্য অনুবাদের জন্য অফলাইন অনুবাদ মডেল যোগ করতে হবে।', 'That phrase is not in the local phrasebook. Full sentence translation requires an offline translation model.', 'fallback');
  }
  m = raw.match(/^(?:teach translation|add glossary|শব্দ শেখাও|গ্লসারি যোগ)\s+(.+?)\s*(?:=>|->|মানে)\s*(.+)$/iu);
  if (m) { const term=m[1].trim().slice(0,100), value=m[2].trim().slice(0,300); s.glossary=s.glossary.filter(x=>norm(x.term)!==norm(term)); s.glossary.push({term,bn:hasBn(term)?term:value,en:hasBn(term)?value:term}); await save(s); return reply(r, `শব্দ জোড়া লোকালি সেভ হয়েছে: ${term} ↔ ${value}`, `Glossary pair saved locally: ${term} ↔ ${value}`); }
  m = raw.match(/^(?:study quiz|make quiz|quiz from|কুইজ বানাও|প্রশ্ন বানাও)\s*[:：]?\s*([\s\S]{20,})$/iu);
  if (m) { const qs=makeQuiz(m[1]); return reply(r, qs.length ? `অনুশীলনের প্রশ্ন (উত্তরসহ):\n${qs.map(q=>`${q.question}\nউত্তর: ${q.answer}`).join('\n\n')}` : 'আরও কিছু বিস্তারিত লেখা দাও, তাহলে অনুশীলনের প্রশ্ন তৈরি করতে পারব।', qs.length ? `Practice quiz (with answers):\n${qs.map(q=>`${q.question}\nAnswer: ${q.answer}`).join('\n\n')}` : 'Provide a longer text to generate practice questions.', 'task-plan'); }
  m = raw.match(/^(?:plan steps|break down|goal plan|লক্ষ্য ভাগ করো|ধাপে ভাগ করো)\s*[:：]?\s*(.+)$/iu);
  if (m) { const steps=planSteps(m[1]); return reply(r, `পরিকল্পনা:\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nএটি পরিকল্পনা মাত্র; কোনো ফোন অ্যাকশন চালানো হয়নি।`, `Plan:\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nPlan only; no device action was executed.`, 'task-plan'); }
  if (/^(?:offline expansion status|offline feature status|অফলাইন ফিচার স্ট্যাটাস|অফলাইন স্ট্যাটাস)$/iu.test(n)) {
    return reply(r, `Abir AI অফলাইন এক্সপ্যানশন\n• লোকাল নথি: ${s.docs.length}/100\n• কাস্টম গ্লসারি: ${s.glossary.length}/300\n• Local phrasebook: সক্রিয়\n• Text statistics / extractive summary / quiz: সক্রিয়\n• নেটওয়ার্ক অনুরোধ: নেই\n• স্থায়ী মেমোরির সীমা: ২০০ (অপরিবর্তিত)\n• পূর্ণ LLM, OCR, speech recognition, background automation: আলাদা মডেল/প্ল্যাটফর্ম ইন্টিগ্রেশন প্রয়োজন।`, `Abir AI Offline Expansion\n• Local documents: ${s.docs.length}/100\n• Custom glossary: ${s.glossary.length}/300\n• Local phrasebook: active\n• Text statistics / extractive summary / quiz: active\n• Network requests: none\n• Persistent memory limit: 200 (unchanged)\n• Full LLM, OCR, speech recognition and background automation require separate model/platform integrations.`, 'diagnostics');
  }
  if (/^(?:help offline|offline help|অফলাইন সাহায্য|অফলাইন কমান্ড)$/iu.test(n)) {
    return reply(r, 'অফলাইন কমান্ড:\n• নথি সেভ [নাম]: [লেখা]\n• নথির তালিকা\n• নথি খোঁজো [শব্দ]\n• সারাংশ: [লেখা]\n• লেখার পরিসংখ্যান: [লেখা]\n• অনুবাদ করো [phrase]\n• শব্দ শেখাও [শব্দ] => [অর্থ]\n• কুইজ বানাও: [লেখা]\n• লক্ষ্য ভাগ করো: [লক্ষ্য]\n• অফলাইন ফিচার স্ট্যাটাস', 'Offline commands:\n• save document [title]: [text]\n• show documents\n• search documents [term]\n• summarize: [text]\n• text stats: [text]\n• offline translate [phrase]\n• teach translation [term] => [meaning]\n• study quiz: [text]\n• break down: [goal]\n• offline feature status');
  }
  return null;
}
export const offlineExpansionExtension: AssistantExtension = { id: 'offline-expansion-5.3', handle };
