import * as Speech from 'expo-speech';
import type { AssistantLanguage } from './offlineBrain';
import { chooseSpeechVoice, type SpeechVoice } from './voiceSelection';
import type { VoiceGenderPreference } from './voicePreferences';

export type SpeechStartOptions = {
  text: string;
  language: AssistantLanguage;
  voiceGender: VoiceGenderPreference;
  voices: SpeechVoice[];
  onDone?: () => void;
  onError?: () => void;
};

export async function speakAssistantText({
  text,
  language,
  voiceGender,
  voices,
  onDone,
  onError,
}: SpeechStartOptions) {
  const selection = chooseSpeechVoice(voices, voiceGender, language);
  await Speech.stop();

  const requestedLanguage = language === 'bn' ? 'bn-BD' : 'en-US';
  const languageMatchedVoice = selection.voice && selection.languageMatched
    ? selection.voice
    : null;

  let fallbackUsed = false;
  const fallback = () => {
    if (fallbackUsed) {
      onError?.();
      return;
    }
    fallbackUsed = true;
    try {
      // Never force a mismatched voice (for example an English voice for Bengali).
      // Let Android's TTS engine choose the best installed voice for the language.
      Speech.speak(text, {
        language: requestedLanguage,
        pitch: voiceGender === 'male' ? 0.92 : 1.02,
        rate: language === 'bn' ? 0.9 : 0.94,
        onDone,
        onStopped: onDone,
        onError,
      });
    } catch {
      onError?.();
    }
  };

  try {
    Speech.speak(text, {
      language: requestedLanguage,
      ...(languageMatchedVoice ? { voice: languageMatchedVoice.identifier } : {}),
      pitch: voiceGender === 'male' ? 0.92 : 1.02,
      rate: language === 'bn' ? 0.9 : 0.94,
      onDone,
      onStopped: onDone,
      onError: fallback,
    });
  } catch {
    fallback();
  }

  return selection;
}
