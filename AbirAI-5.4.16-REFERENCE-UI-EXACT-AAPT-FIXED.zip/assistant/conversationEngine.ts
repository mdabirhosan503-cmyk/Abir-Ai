import type { AssistantLanguage, AssistantReply, AssistantRequest } from './offlineBrain';
import { detectAssistantLanguage } from './localIntelligence';

/**
 * Natural offline conversation layer.
 *
 * This is intentionally deterministic: it does not pretend to be a local LLM
 * and it never invents live facts. Its job is to make everyday conversation,
 * follow-ups, repair questions and small talk feel less robotic when Gemini
 * is unavailable.
 */

type Turn = { role: 'user' | 'assistant'; text: string };


function clean(text: string) {
  return text.normalize('NFKC').replace(/\s+/g, ' ').trim();
}

function reply(language: AssistantLanguage, bnText: string, enText: string, intent: AssistantReply['intent'] = 'casual'): AssistantReply {
  const useBn = language === 'bn';
  return {
    text: useBn ? (bnText.startsWith('বস') ? bnText : `বস, ${bnText}`) : (enText.startsWith('Boss') ? enText : `Boss, ${enText}`),
    intent,
  };
}

function lastTurn(context: Turn[] | undefined, role: Turn['role']) {
  return [...(context ?? [])].reverse().find((item) => item.role === role && clean(item.text));
}

function topicFrom(text: string) {
  const value = clean(text).replace(/^(?:আচ্ছা|ঠিক আছে|ওকে|okay|ok|so|then|তাহলে|মানে|আসলে|well)\s+/iu, '');
  return value.slice(0, 90);
}

export function getOfflineConversationReply(request: AssistantRequest): AssistantReply | null {
  const text = clean(request.text);
  if (!text) return null;

  const language = detectAssistantLanguage(text, request.language);
  const context = request.conversationContext ?? [];
  const previousUser = lastTurn(context, 'user');
  const previousAssistant = lastTurn(context, 'assistant');
  const normalized = text.toLocaleLowerCase();

  // Conversational acknowledgements become context-aware instead of generic
  // "tell me what to do" responses.
  if (/^(?:হ্যাঁ|হ্যা|জি|জী|yes|yeah|yep|ঠিক আছে|আচ্ছা|ওকে|ওকে বস|okay|ok|sure)$/iu.test(normalized)) {
    const previous = previousAssistant?.text ? topicFrom(previousAssistant.text) : '';
    if (previous) {
      return reply(language,
        `ঠিক আছে। আগের কথাটাই ধরে এগোচ্ছি—${previous}${previous.length >= 85 ? '…' : ''}`,
        `Got it. I’ll continue from what I just said: ${previous}${previous.length >= 85 ? '…' : ''}`,
      );
    }
    return reply(language, 'ঠিক আছে। আমি আছি—কথা বলো বা যেটা দরকার সেটা বলো।', 'Got it. I’m here—talk to me or tell me what you need.');
  }

  if (/^(?:না|নাহ|no|nope|not really)$/iu.test(normalized)) {
    return reply(language, 'ঠিক আছে, সমস্যা নেই। অন্যভাবে চেষ্টা করি।', 'Okay, no problem. We can try another way.');
  }

  // "What did you say?" / repeat last answer.
  if (/(?:কি বললে|কী বললে|আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat (?:that|it)|say that again|what did you say)/iu.test(normalized)) {
    if (previousAssistant) {
      return reply(language, `অবশ্যই। আমার আগের কথাটা ছিল: “${previousAssistant.text.slice(0, 420)}”`, `Sure. My previous reply was: “${previousAssistant.text.slice(0, 420)}”`);
    }
    return reply(language, 'এই কথোপকথনে আগের কোনো উত্তর নেই যেটা আবার বলব।', 'There is no earlier reply in this conversation for me to repeat.');
  }

  // Follow-up questions that depend on the immediately previous turn.
  if (/(?:এটা কী|এটা কি|ওটা কী|ওটা কি|মানে কী|মানে কি|কেন|কীভাবে|কিভাবে|আরও বল|আরেকটু বল|বিস্তারিত বল|explain|why|how|what do you mean|tell me more)/iu.test(normalized) && previousAssistant) {
    const subject = topicFrom(previousAssistant.text);
    if (/(?:কেন|why)/iu.test(normalized)) {
      return reply(language,
        `বস, তুমি “কেন” জানতে চাচ্ছো—কিন্তু আগের কথার কোন অংশটা বোঝাচ্ছো সেটা নিশ্চিত না। অংশটা বললে আমি কারণটা পরিষ্কার করে বলব।`,
        `Boss, you’re asking why, but I’m not sure which part of my last reply you mean. Point to that part and I’ll explain the reason.`,
      );
    }
    return reply(language,
      `অবশ্যই। তুমি আগের কথাটা নিয়ে আরও জানতে চাচ্ছো। আমি যেটা বলেছিলাম: “${subject}${subject.length >= 85 ? '…' : ''}”। কোন অংশটা খুলে বলব সেটা বললে আরও নির্দিষ্টভাবে বুঝিয়ে দেব।`,
      `Sure. You’re asking for more detail about my last reply: “${subject}${subject.length >= 85 ? '…' : ''}”. Tell me which part you want expanded and I’ll explain it clearly.`,
    );
  }

  if (/(?:বুঝছ|বুঝতে পারছ|বুঝেছ|বোঝো|understand|do you get it|do you understand)/iu.test(normalized)) {
    return reply(language,
      previousUser ? `হ্যাঁ বস, তোমার কথার মূল বিষয়টা ধরতে পেরেছি: “${topicFrom(previousUser.text)}”।` : 'হ্যাঁ বস, বুঝতে চেষ্টা করছি।',
      previousUser ? `Yes, Boss. I understand the main point: “${topicFrom(previousUser.text)}”.` : 'Yes, Boss. I’m following you.',
    );
  }

  // Natural small talk.
  if (/(?:কেমন আছ|কেমন আছো|কেমন আছেন|কী অবস্থা|কি অবস্থা|how are you|how are you doing|how's it going|hows it going)/iu.test(normalized)) {
    return reply(language,
      'আমি ভালো আছি বস 😄 তোমার সঙ্গে কথা বলার জন্য প্রস্তুত। তুমি চাইলে আড্ডা দিতে পারো, আবার কোনো কাজও দিতে পারো।',
      'I’m doing well, Boss 😄 and I’m ready to chat. We can just talk, or you can give me a task.',
    );
  }

  if (/(?:কি করছ|কী করছ|কি করতেছ|কী করতেছ|what are you doing|what are you up to)/iu.test(normalized)) {
    return reply(language,
      'এই তো বস, তোমার কথার অপেক্ষায় আছি। তুমি যা বলবে সেটা বুঝে উত্তর দেওয়ার চেষ্টা করছি।',
      'I’m right here, Boss, listening to you and figuring out the best response to what you say.',
    );
  }

  if (/(?:আড্ডা দাও|আড্ডা দিবা|আড্ডা দিতে চাই|চলো আড্ডা|let's chat|chat with me|talk with me|just chat)/iu.test(normalized)) {
    return reply(language,
      'চলো বস, আড্ডা দিই 😄 আজকের বিষয় তুমি ঠিক করো—টেক, গেম, ফোন, গল্প, মজার কথা, বা যেকোনো random topic।',
      'Sure, Boss 😄 Let’s chat. Pick the topic—tech, games, phones, stories, random stuff, or anything else.',
    );
  }

  // Simple social/emotional conversational replies without pretending to have
  // human feelings.
  if (/(?:মন খারাপ|খারাপ লাগছে|ভালো লাগছে না|tired|sad|feeling bad|not feeling good)/iu.test(normalized)) {
    return reply(language,
      'বস, খারাপ লাগছে শুনে দুঃখিত। চাইলে কী হয়েছে সেটা বলতে পারো—আমি মন দিয়ে শুনব এবং যতটা পারি সাহায্য করব।',
      'I’m sorry you’re feeling that way, Boss. If you want, tell me what happened—I’ll listen and try to help.',
    );
  }

  if (/(?:ধন্যবাদ|অনেক ধন্যবাদ|thanks|thank you|thx)/iu.test(normalized)) {
    return reply(language, 'স্বাগতম বস 😄', 'You’re welcome, Boss 😄');
  }

  // If the user asks a broad conversational question that is not obviously a
  // device command, give a useful clarification rather than a hard failure.
  const questionLike = /(?:\?|কী|কি|কেন|কীভাবে|কিভাবে|কত|where|what|why|how|when|who|which)\b/iu.test(normalized);
  const actionLike = /(?:খোলো|চালু|বন্ধ|কল|পাঠাও|লিখে|স্ক্রিন|ভলিউম|ফ্ল্যাশ|ওপেন|open|launch|call|send|type|click|tap|volume|flashlight|lock|screenshot)/iu.test(normalized);
  if (questionLike && !actionLike && context.length >= 2) {
    const recent = previousUser ? topicFrom(previousUser.text) : '';
    return reply(language,
      recent
        ? `বস, প্রশ্নটা ধরতে পেরেছি। তুমি “${recent}” বিষয়টার ওপর জানতে চাইছো মনে হচ্ছে। আমি নির্ভুলভাবে উত্তর দিতে পারি যদি তুমি প্রশ্নটা একটু নির্দিষ্ট করে বলো।`
        : 'বস, প্রশ্নটা ধরতে পারছি, কিন্তু ঠিক কোন তথ্যটা জানতে চাইছো সেটা পরিষ্কার না। এক লাইনে একটু নির্দিষ্ট করে বলো।',
      recent
        ? `Boss, I get the question. It sounds like you’re asking about “${recent}”. Make the exact question a little more specific and I’ll answer it clearly.`
        : 'Boss, I get that you have a question, but I can’t tell exactly what information you want yet. Make it a little more specific.',
    );
  }

  return null;
}
