/**
 * Abir AI — Offline 100 Feature Pack
 *
 * This registry keeps the 100 requested offline capabilities in one stable,
 * machine-readable list. It is additive: existing engines and features stay.
 * Some capabilities depend on Android APIs, accessibility, installed apps,
 * or an offline model/runtime; those dependencies are explicitly declared.
 */

export type Offline100Status = 'local' | 'android' | 'app-integration' | 'model-required' | 'planned-integration';

export type Offline100Feature = {
  id: string;
  number: number;
  name: string;
  bengali: string;
  status: Offline100Status;
  note: string;
};

const raw: Array<[string, string, Offline100Status, string]> = [
  ['Context Memory', 'Context Memory', 'local', 'Uses the existing local conversation/memory layer.'],
  ['Follow-up Understanding', 'Follow-up Understanding', 'local', 'Resolves short follow-up commands from recent conversation context.'],
  ['Bangla Natural Language Engine', 'বাংলা Natural Language Engine', 'local', 'Uses the existing Bengali intent and normalization rules.'],
  ['Banglish mixed command', 'Banglish mixed command', 'local', 'Handles Bengali-English mixed command vocabulary.'],
  ['Intent Prediction', 'Intent Prediction', 'local', 'Local intent scoring chooses the most likely action.'],
  ['Smart Clarification', 'Smart Clarification', 'local', 'Ambiguous local commands can request clarification instead of guessing.'],
  ['Conversation Summarizer', 'Conversation Summarizer', 'local', 'Local extractive/context summarization.'],
  ['Local Knowledge Base', 'Local Knowledge Base', 'local', 'Uses locally stored notes, facts and knowledge packs.'],
  ['Personal Command Learning', 'Personal Command Learning', 'local', 'Learns user-defined command aliases locally.'],
  ['Correction Learning', 'Correction Learning', 'local', 'Stores corrections/aliases locally for future commands.'],

  ['Always Listening Mode', 'Always Listening Mode', 'android', 'Continuous voice loop with foreground/background service support.'],
  ['Wake-word detection', 'Wake-word detection', 'android', 'Uses the existing wake-word/background voice service.'],
  ['Offline speech recognition', 'Offline speech recognition', 'model-required', 'Requires an offline speech-recognition engine/model supported by the device.'],
  ['Bangla/Banglish pronunciation handling', 'বাংলা/Banglish pronunciation handling', 'local', 'Speech normalization and common pronunciation repair.'],
  ['Voice activity detection', 'Voice activity detection', 'model-required', 'Depends on the installed speech recognizer/audio engine.'],
  ['Noise filtering', 'Noise filtering', 'model-required', 'Best handled by the speech/audio engine on-device.'],
  ['Repeated-command protection', 'Repeated-command protection', 'local', 'Prevents rapid duplicate command execution in the command loop.'],
  ['Voice session recovery', 'Voice session recovery', 'android', 'Retries/restarts listening after recoverable recognition failures.'],
  ['Speaking interruption', 'Speaking interruption', 'android', 'Stops native speech when a new voice interaction starts.'],
  ['Offline male/female TTS selection', 'Offline male/female TTS selection', 'android', 'Uses installed Android speech voices where available.'],
  ['Short-answer voice mode', 'Short-answer voice mode', 'local', 'Keeps spoken replies concise when quick mode is selected.'],
  ['Detailed-answer voice mode', 'Detailed-answer voice mode', 'local', 'Allows longer local responses when detailed mode is selected.'],

  ['Installed-app intelligence', 'Installed-app intelligence', 'android', 'Discovers launchable installed apps through Android.'],
  ['App search by Bangla name', 'বাংলা নামে App search', 'local', 'Matches Bengali/English aliases against installed app labels.'],
  ['App switching', 'App switching', 'android', 'Uses Android app intents where the OS permits.'],
  ['Recent-app awareness', 'Recent-app awareness', 'android', 'Uses supported Android recent/app state APIs where available.'],
  ['Wi-Fi settings shortcut', 'Wi-Fi settings shortcut', 'android', 'Opens the supported Android Wi-Fi settings screen.'],
  ['Bluetooth settings shortcut', 'Bluetooth settings shortcut', 'android', 'Opens the supported Android Bluetooth settings screen.'],
  ['Airplane-mode settings shortcut', 'Airplane-mode settings shortcut', 'android', 'Opens the supported Android network settings screen.'],
  ['Brightness control', 'Brightness control', 'android', 'Uses supported device/system controls.'],
  ['Volume control', 'Volume control', 'android', 'Controls supported Android audio streams.'],
  ['Media play/pause', 'Media play/pause', 'android', 'Uses supported media control actions.'],
  ['Screenshot command', 'Screenshot command', 'android', 'Uses the existing Android screenshot action where permitted.'],
  ['Notification panel/settings shortcuts', 'Notification panel/settings shortcuts', 'android', 'Uses supported accessibility/system navigation actions.'],
  ['Battery status', 'Battery status', 'android', 'Reads device battery information.'],
  ['Storage status', 'Storage status', 'android', 'Reads available storage information.'],
  ['Network status', 'Network status', 'android', 'Reports local network/connectivity state.'],
  ['Device health dashboard', 'Device health dashboard', 'android', 'Combines available battery, storage, memory and diagnostic telemetry.'],

  ['Contact-name understanding', 'Contact-name understanding', 'android', 'Matches spoken contact names against local contacts.'],
  ['Phone call by voice', 'Phone call by voice', 'android', 'Starts a phone call through supported Android intents.'],
  ['WhatsApp call command', 'WhatsApp call command', 'app-integration', 'Requires WhatsApp plus supported accessibility/app integration.'],
  ['Messenger call command', 'Messenger call command', 'app-integration', 'Requires Messenger plus supported accessibility/app integration.'],
  ['IMO call command', 'IMO call command', 'app-integration', 'Requires IMO plus supported accessibility/app integration.'],
  ['Natural message composition', 'Natural message composition', 'local', 'Builds message text from natural Bengali/English requests.'],
  ['Bangla → polished message conversion', 'বাংলা → polished message conversion', 'local', 'Locally cleans and formats Bengali messages.'],
  ['WhatsApp message automation', 'WhatsApp message automation', 'app-integration', 'Requires WhatsApp and supported accessibility integration.'],
  ['Messenger message automation', 'Messenger message automation', 'app-integration', 'Requires Messenger and supported accessibility integration.'],
  ['IMO message automation', 'IMO message automation', 'app-integration', 'Requires IMO and supported accessibility integration.'],
  ['Voice-message command', 'Voice-message command', 'app-integration', 'Requires supported app accessibility controls for recording/sending.'],
  ['“ওকে এটা পাঠাও” contextual messaging', '“ওকে এটা পাঠাও” contextual messaging', 'local', 'Resolves the most recent message/contact context before dispatch.'],
  ['Message confirmation for ambiguous contacts', 'Ambiguous contact message confirmation', 'local', 'Asks the user to choose when multiple contacts match.'],

  ['Offline Notes', 'Offline Notes', 'local', 'Stores notes locally on the device.'],
  ['Voice-to-note', 'Voice-to-note', 'local', 'Turns recognized voice text into local notes.'],
  ['To-do list', 'To-do list', 'local', 'Local task/checklist storage.'],
  ['Shopping list', 'Shopping list', 'local', 'Local shopping list storage.'],
  ['Local reminders', 'Local reminders', 'android', 'Uses local Android reminder scheduling where supported.'],
  ['Alarm creation shortcut', 'Alarm creation shortcut', 'android', 'Opens/uses supported Android alarm controls.'],
  ['Daily planner', 'Daily planner', 'local', 'Local day planning and task organization.'],
  ['Habit tracker', 'Habit tracker', 'local', 'Local habit entries and progress.'],
  ['Offline calculator', 'Offline calculator', 'local', 'Local arithmetic engine.'],
  ['Unit converter', 'Unit converter', 'local', 'Local unit conversion engine.'],
  ['Age calculator', 'Age calculator', 'local', 'Calculates age from dates locally.'],
  ['Date difference calculator', 'Date difference calculator', 'local', 'Calculates date/time differences locally.'],
  ['Percentage/discount calculator', 'Percentage/discount calculator', 'local', 'Calculates percentage, discount and final values locally.'],

  ['Local file search', 'Local file search', 'android', 'Searches locally accessible device files where Android permissions allow.'],
  ['Voice-based file search', 'Voice-based file search', 'local', 'Converts a spoken file request into a local search query.'],
  ['PDF/text document search', 'PDF/text document search', 'local', 'Searches indexed local text/document content when available.'],
  ['Local document search', 'Local document search', 'local', 'Searches local indexed document metadata/content.'],
  ['Recent-file finder', 'Recent-file finder', 'android', 'Uses local file metadata to find recently used files.'],
  ['Duplicate-file detection', 'Duplicate-file detection', 'android', 'Uses local file size/hash comparisons where access is available.'],
  ['File organization suggestions', 'File organization suggestions', 'local', 'Suggests local organization without silently deleting/moving files.'],
  ['“আমার ওই PDF-টা খুঁজে দাও” command', '“আমার ওই PDF-টা খুঁজে দাও” command', 'local', 'Maps natural Bengali PDF requests to the local file search engine.'],

  ['Local-only mode', 'Local-only mode', 'local', 'Disables online fallback and keeps processing local.'],
  ['Sensitive-command voice verification', 'Sensitive-command voice verification', 'android', 'Uses the existing owner/speaker verification gate for sensitive actions.'],
  ['Private conversation lock', 'Private conversation lock', 'android', 'Uses local device/app authentication where supported.'],
  ['App-action confirmation', 'App-action confirmation', 'local', 'Confirms higher-impact actions before dispatch when configured.'],
  ['Local encrypted memory', 'Local encrypted memory', 'android', 'Uses secure local storage for sensitive saved data where available.'],
  ['Memory delete command', 'Memory delete command', 'local', 'Deletes selected local memories.'],
  ['“আজকের সব memory মুছে দাও” command', 'আজকের সব memory delete command', 'local', 'Supports date-scoped local memory deletion.'],
  ['Per-command permission system', 'Per-command permission system', 'local', 'Separates ordinary actions from higher-risk actions.'],

  ['Context-aware response style', 'Context-aware response style', 'local', 'Adapts response length/tone without making sensitive personal inferences.'],
  ['Conversation mode', 'Conversation mode', 'local', 'Keeps a natural local chat flow.'],
  ['Quick-answer mode', 'Quick-answer mode', 'local', 'Prioritizes short responses.'],
  ['Teacher mode', 'Teacher mode', 'local', 'Uses structured explanations for study requests.'],
  ['Translator mode', 'Translator mode', 'local', 'Uses available local translation/phrase resources.'],
  ['Calculator mode', 'Calculator mode', 'local', 'Routes calculation requests to the local calculator.'],
  ['Phone-control mode', 'Phone-control mode', 'android', 'Routes device-control requests to Android actions.'],
  ['Study assistant mode', 'Study assistant mode', 'local', 'Uses local study helpers and structured practice.'],
  ['Coding helper mode', 'Coding helper mode', 'local', 'Provides local coding explanations/templates; large generation may need online AI.'],
  ['Offline troubleshooting assistant', 'Offline troubleshooting assistant', 'local', 'Uses local diagnostic rules and device capability checks.'],

  ['Command Chain', 'Command Chain', 'local', 'Breaks multi-step requests into ordered local actions.'],
  ['Task Queue', 'Task Queue', 'local', 'Queues independent local tasks and tracks progress.'],
  ['Action Planner', 'Action Planner', 'local', 'Builds an ordered action plan before execution.'],
  ['Failure Recovery', 'Failure Recovery', 'local', 'Retries safe failed steps and chooses available alternatives.'],
  ['Undo Last Action', 'Undo Last Action', 'local', 'Reverses supported reversible local actions.'],
  ['Offline Automation Rules', 'Offline Automation Rules', 'local', 'Stores local rules/routines without requiring cloud execution.'],
  ['Smart Quick Actions', 'Smart Quick Actions', 'local', 'Ranks frequently used local actions for quick access.'],
  ['Custom Skills System', 'Custom Skills System', 'local', 'Stores user-defined local command/skill mappings.'],
  ['Feature Capability Report', 'Feature Capability Report', 'local', 'Reports which of the 100 features are local, Android, app-dependent or model-dependent.'],
  ['Offline Model/Dependency Manager', 'Offline Model/Dependency Manager', 'local', 'Tracks optional on-device models and dependencies without pretending they exist.'],
];

export const OFFLINE_100_FEATURES: Offline100Feature[] = raw.map(([name, bengali, status, note], index) => ({
  id: `abir-offline-${String(index + 1).padStart(3, '0')}`,
  number: index + 1,
  name,
  bengali,
  status,
  note,
}));

if (OFFLINE_100_FEATURES.length !== 100) {
  throw new Error(`Abir AI offline feature pack must contain exactly 100 features; found ${OFFLINE_100_FEATURES.length}.`);
}

export const OFFLINE_100_FEATURE_COUNT = OFFLINE_100_FEATURES.length;

export function getOffline100FeatureReport(language: 'bn' | 'en' = 'bn') {
  const labels: Record<Offline100Status, string> = language === 'bn'
    ? {
        local: 'লোকাল',
        android: 'Android',
        'app-integration': 'App integration',
        'model-required': 'Offline model দরকার',
        'planned-integration': 'Integration দরকার',
      }
    : {
        local: 'local',
        android: 'Android',
        'app-integration': 'app integration',
        'model-required': 'offline model required',
        'planned-integration': 'integration required',
      };

  return OFFLINE_100_FEATURES.map((feature) =>
    `${feature.number}. ${language === 'bn' ? feature.bengali : feature.name} — ${labels[feature.status]}`,
  );
}

export function getOffline100Feature(nameOrNumber: string | number) {
  if (typeof nameOrNumber === 'number') {
    return OFFLINE_100_FEATURES.find((feature) => feature.number === nameOrNumber) ?? null;
  }
  const query = nameOrNumber.trim().toLowerCase();
  return OFFLINE_100_FEATURES.find((feature) =>
    feature.name.toLowerCase() === query || feature.bengali.toLowerCase() === query,
  ) ?? null;
}
