import type { AssistantLanguage } from './offlineBrain';

export type LocalIntentScore = {
  normalized: string;
  language: AssistantLanguage;
  confidence: number;
  ambiguous: boolean;
  destructive: boolean;
  actionSignals: number;
};

const COMMON_SPEECH_FIXES: Array<[RegExp, string]> = [
  [/whatapp|watsapp|whats app/gi, 'whatsapp'],
  [/you ?tube/gi, 'youtube'],
  [/messanger/gi, 'messenger'],
  [/insta gram/gi, 'instagram'],
  [/face book/gi, 'facebook'],
  [/blue tooth/gi, 'bluetooth'],
  [/quick panal/gi, 'quick panel'],
  [/notificaton/gi, 'notification'],
  [/seting|settingg/gi, 'settings'],
  [/volum/gi, 'volume'],
  [/scren/gi, 'screen'],
  [/opn/gi, 'open'],
  [/helo|helllo/gi, 'hello'],
  [/abir ai ai/gi, 'abir ai'],
  [/হোয়াটসাপ|হোয়াটসাপ|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ/gu, 'whatsapp'],
  [/ইউ টিউব/gu, 'youtube'],
  [/মেসেঞ্জার/gu, 'messenger'],
  [/ফেসবুক/gu, 'facebook'],
  [/ব্লুটুথ/gu, 'bluetooth'],
  [/ভলুম/gu, 'ভলিউম'],
  [/স্ক্রিন/gu, 'স্ক্রিন'],
];

export function detectAssistantLanguage(text: string, fallback: AssistantLanguage = 'bn'): AssistantLanguage {
  const bn = (text.match(/[\u0980-\u09FF]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  if (bn > 0 && bn >= Math.max(1, Math.floor(latin * 0.18))) return 'bn';
  if (latin > 0) return 'en';
  return fallback;
}

export function repairCommonSpeech(text: string): string {
  let value = text.normalize('NFKC').trim();
  for (const [pattern, replacement] of COMMON_SPEECH_FIXES) value = value.replace(pattern, replacement);
  return value.replace(/\s+/g, ' ').trim();
}



// Offline ASR often returns near-matches for Bengali/Banglish command words.
// Repair only a small, high-confidence command vocabulary so contact/app names
// and normal conversation are not aggressively rewritten.
const SPEECH_CANONICAL: Array<{ canonical: string; variants: string[] }> = [
  { canonical: 'whatsapp', variants: ['হোয়াটসাপ','হোয়াটসাপ','হোয়াটসঅাপ','হোয়াটসঅাপ','হোয়াটসঅ্যাপ','হোয়াটসঅ্যাপ','হোয়াটস আপ','হোয়াটস আপ','what app','watsap','watsapp','whats app'] },
  { canonical: 'youtube', variants: ['ইউটিউব','ইউ টিউব','ইউটুব','ইউটিউবটা','you tube','you-tube','youtub'] },
  { canonical: 'messenger', variants: ['মেসেঞ্জার','মেসেঞ্জারটা','মেসেন্জার','messanger','messenger'] },
  { canonical: 'imo', variants: ['ইমো','ইমু','ইমোটা','imo'] },
  { canonical: 'facebook', variants: ['ফেসবুক','ফেইসবুক','ফেসবুকটা','face book','facebook'] },
  { canonical: 'instagram', variants: ['ইনস্টাগ্রাম','ইন্সটাগ্রাম','ইনস্টা গ্রাম','insta gram','instagram'] },
  { canonical: 'chrome', variants: ['ক্রোম','গুগল ক্রোম','গুগলক্রোম','chrome'] },
  { canonical: 'খোলো', variants: ['খুলে','খুলুন','খুলে দাও','খুলে দেন','খুইলা','খোল','খুল','ওপেন','open','opn','khulo','khul'] },
  { canonical: 'চালু করো', variants: ['চালু','চালাও','চালিয়ে','চালিয়ে','চালু করে','চালু কর','start','launch','chalu koro'] },
  { canonical: 'কল', variants: ['কল','ফোন','ডায়াল','ডায়াল','ডায়াল কর','ডায়াল কর','call','phone','dial','ring'] },
  { canonical: 'মেসেজ', variants: ['মেসেজ','মেসেজটা','বার্তা','টেক্সট','message','massage','msg','text'] },
  { canonical: 'পাঠাও', variants: ['পাঠাও','পাঠিয়ে দাও','পাঠিয়ে দাও','দিয়ে দাও','দিয়ে দাও','পাঠান','send','sent','pathao'] },
  { canonical: 'ভয়েস মেসেজ', variants: ['ভয়েস মেসেজ','ভয়েস মেসেজ','ভয়েস বার্তা','ভয়েস বার্তা','voice message','voice msg'] },
  { canonical: 'স্ক্রিন', variants: ['স্ক্রিন','স্কিন','screen','scren'] },
  { canonical: 'ভলিউম', variants: ['ভলিউম','ভলুম','ভলিয়ুম','volume','volum'] },
  { canonical: 'বাড়াও', variants: ['বাড়াও','বাড়াও','বাড়াতে','বাড়াতে','বাড়িয়ে','বাড়িয়ে','barhao','barao'] },
  { canonical: 'কমাও', variants: ['কমাও','কমাতে','কমিয়ে','কমিয়ে','komao','komiye'] },
  { canonical: 'সেটিংস', variants: ['সেটিংস','সেটিং','সেটিংসটা','setting','settings','seting'] },
  { canonical: 'ব্যাটারি', variants: ['ব্যাটারি','ব্যাটারি','battery','battry'] },
  { canonical: 'ফ্ল্যাশলাইট', variants: ['ফ্ল্যাশলাইট','ফ্ল্যাশ লাইট','টর্চ','flashlight','torch'] },
];

function editDistance(a: string, b: string): number {
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    let left = i;
    for (let j = 1; j <= b.length; j += 1) {
      const old = prev[j];
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      prev[j] = Math.min(prev[j] + 1, left + 1, prev[j - 1] + cost);
      left = prev[j];
    }
  }
  return prev[b.length];
}

function replaceNearToken(token: string): string {
  const lower = token.toLowerCase();
  for (const item of SPEECH_CANONICAL) {
    for (const variant of item.variants) {
      const v = variant.toLowerCase();
      if (lower === v) return item.canonical;
    }
  }

  // Fuzzy repair is intentionally conservative: only short command tokens
  // with a strong edit-distance match are changed.
  if (token.length < 4) return token;
  let best: { canonical: string; distance: number; length: number } | null = null;
  for (const item of SPEECH_CANONICAL) {
    for (const variant of item.variants) {
      const v = variant.toLowerCase();
      if (v.length < 4 || Math.abs(v.length - lower.length) > 2) continue;
      const distance = editDistance(lower, v);
      const threshold = Math.max(1, Math.floor(Math.max(v.length, lower.length) * 0.24));
      if (distance <= threshold && (!best || distance < best.distance)) {
        best = { canonical: item.canonical, distance, length: v.length };
      }
    }
  }
  return best ? best.canonical : token;
}

export function repairSpeechTranscript(text: string): string {
  let value = repairCommonSpeech(text).normalize('NFKC');
  for (const item of SPEECH_CANONICAL) {
    for (const variant of item.variants) {
      const escaped = variant.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      value = value.replace(new RegExp(`(^|\\s)${escaped}(?=\\s|$)`, 'giu'), `$1${item.canonical}`);
    }
  }
  return value
    .split(/(\s+)/)
    .map(part => /^\s+$/.test(part) ? part : replaceNearToken(part))
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function scoreSpeechCandidate(text: string): number {
  const repaired = repairSpeechTranscript(text);
  const commandPatterns = [
    /\b(?:open|launch|start|খোলো|চালু করো)\b/iu,
    /\b(?:call|phone|dial|কল)\b/iu,
    /\b(?:message|msg|text|মেসেজ|বার্তা|পাঠাও)\b/iu,
    /\b(?:whatsapp|messenger|imo|youtube|facebook|instagram|chrome)\b/iu,
    /\b(?:screen|স্ক্রিন|volume|ভলিউম|settings|সেটিংস|battery|ব্যাটারি)\b/iu,
    /\b(?:voice message|ভয়েস মেসেজ|ভয়েস মেসেজ)\b/iu,
  ];
  const signals = commandPatterns.reduce((n, re) => n + (re.test(repaired) ? 1 : 0), 0);
  const bn = (repaired.match(/[\u0980-\u09FF]/g) || []).length;
  const latin = (repaired.match(/[A-Za-z]/g) || []).length;
  const mixed = bn > 0 && latin > 0 ? 5 : 0;
  const penalty = repaired.length < 2 ? 20 : 0;
  return signals * 35 + Math.min(bn, 20) + mixed - penalty;
}

export function splitOfflineTasks(text: string): string[] {
  return repairCommonSpeech(text)
    .split(/\s+(?:এবং|তারপর|পরে|and then|then|after that|also)\s+/iu)
    .map(item => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

export function scoreLocalIntent(text: string): LocalIntentScore {
  const normalized = repairCommonSpeech(text).toLowerCase();
  const language = detectAssistantLanguage(text);
  const destructive = /(?:delete|remove|erase|wipe|reset|uninstall|ডিলিট|মুছে|মুছ|রিসেট|আনইনস্টল)/iu.test(normalized);
  const ambiguous = /^(?:এটা|ওটা|ওইটা|সেটা|this|that|it|do it|করো|ওটা করো)$/iu.test(normalized);
  const actionSignals = [
    /(?:open|launch|start|খোলো|খুলে|ওপেন|চালু)/iu,
    /(?:call|phone|dial|কল|ফোন|নাম্বার)/iu,
    /(?:volume|ভলিউম|sound|শব্দ|flashlight|torch|ফ্ল্যাশ)/iu,
    /(?:click|tap|চাপ|scroll|স্ক্রল|type|লিখ)/iu,
    /(?:screen|স্ক্রিন|accessibility|অ্যাক্সেসিবিলিটি)/iu,
  ].reduce((n, re) => n + (re.test(normalized) ? 1 : 0), 0);
  const confidence = Math.min(1, 0.42 + actionSignals * 0.12 + (normalized.length > 8 ? 0.08 : 0));
  return { normalized, language, confidence, ambiguous, destructive, actionSignals };
}

export function isCompoundCommand(text: string): boolean {
  return splitOfflineTasks(text).length > 1;
}
