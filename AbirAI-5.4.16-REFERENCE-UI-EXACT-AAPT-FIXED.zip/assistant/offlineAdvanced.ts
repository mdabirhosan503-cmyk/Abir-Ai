import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantReply, AssistantRequest, AssistantIntent } from './offlineBrain';
import { detectAssistantLanguage, repairCommonSpeech } from './localIntelligence';
import { analyzeOfflineText, planOfflineTasks } from './offlinePlus';

const CACHE_KEY = 'abir-ai-offline-knowledge-cache-v1';
const MAX_CACHE = 40;

const KNOWLEDGE: Record<string, string> = {
  'what is cpu': 'CPU হলো ফোন/কম্পিউটারের প্রধান প্রসেসর, যা নির্দেশনা ও হিসাবের কাজ চালায়।',
  'what is ram': 'RAM হলো অস্থায়ী দ্রুত মেমোরি, যেখানে চলমান অ্যাপের ডেটা রাখা হয়।',
  'cpu কী': 'CPU হলো প্রসেসর; এটি নির্দেশনা ও হিসাবের কাজ চালায়।',
  'র‍্যাম কী': 'RAM হলো অস্থায়ী দ্রুত মেমোরি, যেখানে চলমান কাজের ডেটা থাকে।',
  'ইন্টারনেট কী': 'ইন্টারনেট হলো বিশ্বজুড়ে সংযুক্ত নেটওয়ার্কগুলোর সমষ্টি।',
  'what is wifi': 'Wi‑Fi হলো বেতার নেটওয়ার্ক প্রযুক্তি, যা কাছাকাছি ডিভাইসকে নেটওয়ার্কে যুক্ত করে।',
  'ওয়াইফাই কী': 'Wi‑Fi হলো বেতার নেটওয়ার্ক প্রযুক্তি।',
};

function bn(text: string) { return /[\u0980-\u09FF]/u.test(text); }
function reply(text: string, intent: AssistantIntent = 'casual'): AssistantReply { return { text, intent }; }

async function cacheKnowledge(key: string, value: string) {
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    const old = raw ? JSON.parse(raw) : {};
    const next = { ...(old && typeof old === 'object' ? old : {}), [key]: value } as Record<string,string>;
    const entries = Object.entries(next).slice(-MAX_CACHE);
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(Object.fromEntries(entries)));
  } catch {}
}

async function readCachedKnowledge(key: string): Promise<string | null> {
  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Record<string,string>;
    return typeof data?.[key] === 'string' ? data[key] : null;
  } catch { return null; }
}

function normalize(text: string) {
  return repairCommonSpeech(text).toLocaleLowerCase().replace(/[!?.,।]+$/g, '').trim();
}

function taskRecovery(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = normalize(text);
  if (!/(?:কাজটা|command|কমান্ড).*(?:কাজ হয়নি|হয়নি|failed|fail|didn't work|কাজ করছে না)/iu.test(n)) return null;
  return reply(language === 'bn'
    ? 'কাজটা ব্যর্থ হলে আমি আগে একই উদ্দেশ্যের সহজ উপায়, তারপর বিকল্প কমান্ড, শেষে প্রয়োজনীয় permission/Accessibility যাচাই করব।'
    : 'If a task fails, I will retry the same intent with a simpler action, then check the required permission or Accessibility access.', 'casual');
}

function intentPrediction(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = normalize(text);
  if (/^(?:কিছু একটা করো|do something|help me|কিছু করো)$/iu.test(n)) {
    return reply(language === 'bn' ? 'তুমি কী করতে চাও—অ্যাপ খোলা, স্ক্রিন কন্ট্রোল, ফোন কন্ট্রোল, হিসাব, নোট, নাকি অন্য কিছু?' : 'What do you want to do—open an app, control the screen/phone, calculate, save a note, or something else?', 'help');
  }
  return null;
}

function commandSuggestions(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = normalize(text);
  if (!/(?:আর কী পারো|আর কি পারো|what else can you do|suggest commands|কমান্ড সাজেস্ট)/iu.test(n)) return null;
  return reply(language === 'bn'
    ? 'অফলাইনে বলতে পারো: “YouTube খোলো”, “ভলিউম ৫০%”, “স্ক্রিন পড়ো”, “এটা নোট করো”, “আগের কাজটা undo করো”, “৩ কিমি মিটারে কত?”, “এই লেখাটা বিশ্লেষণ করো”।'
    : 'Try: “open YouTube”, “set volume to 50%”, “read screen”, “save this note”, “undo”, “convert 3 km to meters”, or “analyze this text”.', 'help');
}

function localKnowledge(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = normalize(text);
  if (n.includes('offline knowledge') || n.includes('লোকাল জ্ঞান') || n.includes('অফলাইনে কী জানো')) {
    return reply(language === 'bn'
      ? 'আমার লোকাল knowledge engine সাধারণ device/technology, command এবং সংরক্ষিত local knowledge ইন্টারনেট ছাড়াই ব্যবহার করতে পারে।'
      : 'My local knowledge engine can answer supported device, technology, command, and cached-knowledge questions without internet.', 'casual');
  }
  const direct = KNOWLEDGE[n];
  if (direct) return reply(language === 'bn' ? direct : direct, 'casual');
  return null;
}

function localTextTools(text: string, language: 'bn'|'en'): AssistantReply | null {
  const m = text.match(/(?:analyze|বিশ্লেষণ|analyser)\s*(?:this|এটা|এই লেখাটা)?\s*[:：-]?\s*(.+)$/iu);
  if (!m?.[1]) return null;
  const a = analyzeOfflineText(m[1]);
  return reply(language === 'bn' ? `অফলাইন বিশ্লেষণ: ${a.words} শব্দ, ${a.sentences} বাক্য, ${a.characters} অক্ষর।` : `Offline analysis: ${a.words} words, ${a.sentences} sentences, ${a.characters} characters.`, 'text-analysis');
}

function powerAware(language: 'bn'|'en'): AssistantReply | null {
  // Purely local policy signal; actual battery level is read by the existing native diagnostics action.
  return reply(language === 'bn'
    ? 'Power-aware mode চালু আছে: battery কম থাকলে ভারী local কাজ কমিয়ে lightweight processing বেছে নেব।'
    : 'Power-aware mode is enabled: when battery is low, I will prefer lightweight local processing.', 'casual');
}

export async function getAdvancedOfflineReply(request: AssistantRequest): Promise<AssistantReply | null> {
  const language = detectAssistantLanguage(request.text, request.language);
  const text = request.text.trim();
  const n = normalize(text);

  const recovered = taskRecovery(text, language); if (recovered) return recovered;
  const predicted = intentPrediction(text, language); if (predicted) return predicted;
  const suggestions = commandSuggestions(text, language); if (suggestions) return suggestions;

  if (/(?:power aware|power mode|battery saver intelligence|পাওয়ার aware|পাওয়ার মোড|ব্যাটারি কম হলে)/iu.test(n)) return powerAware(language);

  const knowledge = localKnowledge(text, language); if (knowledge) return knowledge;
  const textTools = localTextTools(text, language); if (textTools) return textTools;

  const learn = text.match(/^(?:learn command|শিখো|কমান্ড শিখো)\s+(.+?)\s+(?:means|মানে|হবে)\s+(.+)$/iu);
  if (learn?.[1] && learn?.[2]) {
    await cacheKnowledge(normalize(learn[1]), learn[2].trim());
    return reply(language === 'bn' ? `ঠিক আছে, “${learn[1]}” কমান্ডটির অর্থ লোকালভাবে শিখলাম।` : `Okay, I learned “${learn[1]}” locally.`, 'memory');
  }

  const cached = await readCachedKnowledge(n);
  if (cached) return reply(cached, 'casual');


  return null;
}
