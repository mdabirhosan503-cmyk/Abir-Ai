import AsyncStorage from '@react-native-async-storage/async-storage';

const ACTION_HISTORY_KEY = 'abir-ai-action-history-v1';
const MAX_ACTION_HISTORY = 30;

export type LocalActionRecord = {
  action: string;
  value?: number;
  time: number;
};

export async function loadActionHistory(): Promise<LocalActionRecord[]> {
  try {
    const raw = await AsyncStorage.getItem(ACTION_HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(-MAX_ACTION_HISTORY) : [];
  } catch { return []; }
}

export async function recordLocalAction(record: LocalActionRecord) {
  const history = await loadActionHistory();
  await AsyncStorage.setItem(ACTION_HISTORY_KEY, JSON.stringify([...history, record].slice(-MAX_ACTION_HISTORY)));
}

export async function getLastLocalAction() {
  const history = await loadActionHistory();
  return history.at(-1) ?? null;
}

export async function clearActionHistory() {
  await AsyncStorage.removeItem(ACTION_HISTORY_KEY);
}
