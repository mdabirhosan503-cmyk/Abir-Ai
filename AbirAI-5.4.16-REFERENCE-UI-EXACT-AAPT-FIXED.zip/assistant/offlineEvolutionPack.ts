/** Abir AI 5.0 Offline Evolution Pack. Local-only practical tools; no network calls. */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';
const KEY = 'abir-ai-offline-evolution-v1';
type Task = { id: string; text: string; done: boolean; createdAt: number; completedAt?: number };
type Note = { id: string; body: string; updatedAt: number };
type State = { tasks: Task[]; notes: Note[]; aliases: Array<{ phrase: string; command: string }> };
const empty: State = { tasks: [], notes: [], aliases: [] };
const isBn = (s: string) => /[\u0980-\u09ff]/u.test(s);
const norm = (s: string) => s.toLocaleLowerCase().replace(/[!?.,।]+/gu, ' ').replace(/\s+/gu, ' ').trim();
async function load(): Promise<State> { try { const raw=await AsyncStorage.getItem(KEY); const v=raw?JSON.parse(raw):{}; return { tasks:Array.isArray(v.tasks)?v.tasks.slice(-200):[], notes:Array.isArray(v.notes)?v.notes.slice(-200):[], aliases:Array.isArray(v.aliases)?v.aliases.slice(-100):[] }; } catch { return { ...empty }; } }
async function save(s: State) { try { await AsyncStorage.setItem(KEY, JSON.stringify({tasks:s.tasks.slice(-200),notes:s.notes.slice(-200),aliases:s.aliases.slice(-100)})); } catch {} }
function reply(lang:'bn'|'en', bn:string, en:string, intent:AssistantReply['intent']='help'):AssistantReply { return {text:lang==='bn'?bn:en,intent}; }
function safeMath(s:string):number|null {
 const src=s.replace(/×/g,'*').replace(/÷/g,'/').replace(/,/g,'').trim(); if(!/^[\d\s()+\-*/%.]+$/.test(src)||!/[\d]/.test(src)) return null;
 const t=src.match(/\d+(?:\.\d+)?|[()+\-*/%]/g); if(!t||t.join('')!==src.replace(/\s/g,'')) return null; let i=0;
 const expr=():number=>{let v=term();while(t[i]==='+'||t[i]==='-'){const op=t[i++];const r=term();v=op==='+'?v+r:v-r;}return v;};
 const term=():number=>{let v=factor();while(['*','/','%'].includes(t[i]||'')){const op=t[i++];const r=factor();if((op==='/'||op==='%')&&r===0)throw Error();v=op==='*'?v*r:op==='/'?v/r:v%r;}return v;};
 const factor=():number=>{if(t[i]==='+'){i++;return factor();}if(t[i]==='-'){i++;return -factor();}if(t[i]==='('){i++;const v=expr();if(t[i++]!==')')throw Error();return v;}const x=t[i++];if(!x||!/^\d/.test(x))throw Error();return Number(x);};
 try{const v=expr();return i===t.length&&Number.isFinite(v)?v:null;}catch{return null;}
}
const glossary:Record<string,{bn:string;en:string}>={offline:{bn:'ইন্টারনেট সংযোগ ছাড়া কাজ করা',en:'Working without an internet connection.'},memory:{bn:'স্মৃতি বা সংরক্ষিত তথ্য',en:'Stored information or recall.'},intelligence:{bn:'বুদ্ধিমত্তা',en:'Ability to reason, learn and solve problems.'},routine:{bn:'নিয়মিত কাজের ধারা',en:'A sequence of actions performed regularly.'},privacy:{bn:'গোপনীয়তা',en:'Control over personal information and its use.'},assistant:{bn:'সহকারী',en:'A system that helps with tasks.'},বাংলা:{bn:'বাংলা ভাষা বা লিপি',en:'Bangla/Bengali language or script.'},অফলাইন:{bn:'ইন্টারনেট ছাড়া',en:'Without an internet connection.'},স্মৃতি:{bn:'মনে রাখা তথ্য বা স্মরণশক্তি',en:'Remembered information or recall.'}};
export const EVOLUTION_FEATURES=['Safe arithmetic parser','Local notes','Task completion/deletion/search','Offline glossary','Text statistics','Local workspace status','Bounded local storage','No-network handlers'] as const;
async function handle(req:AssistantRequest):Promise<AssistantReply|null>{
 const raw=req.text.trim();if(!raw)return null;const n=norm(raw);const lang=req.language||(isBn(raw)?'bn':'en');
 const calc=raw.match(/^(?:calculate|calc|গণনা|হিসাব|ক্যালকুলেটর|কত হবে)\s*[:：]?\s*(.+)$/iu);
 if(calc){const v=safeMath(calc[1]);return v===null?reply(lang,'অঙ্কটি বুঝতে পারিনি। সংখ্যা, + − × ÷ %, বন্ধনী ব্যবহার করে বলো।','I could not parse that calculation. Use numbers, + - * / %, and parentheses.','calculator'):reply(lang,`উত্তর: ${new Intl.NumberFormat('bn-BD',{maximumFractionDigits:8}).format(v)}`,`Result: ${v}`,'calculator');}
 const add=raw.match(/^(?:task|todo|কাজ যোগ|কাজ|করতে হবে)\s*[:：]?\s+(.+)$/iu);
 if(add){const s=await load();s.tasks.push({id:String(Date.now()),text:add[1].trim(),done:false,createdAt:Date.now()});await save(s);return reply(lang,`কাজ যোগ হয়েছে: ${add[1].trim()}`,`Task added: ${add[1].trim()}`,'task-plan');}
 if(/^(?:show tasks|list tasks|todo list|কাজের তালিকা|আমার কাজগুলো|pending tasks)$/iu.test(n)){const s=await load();const a=s.tasks.filter(x=>!x.done).slice(-20);return reply(lang,a.length?`অসমাপ্ত কাজ:\n${a.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'এখন কোনো অসমাপ্ত কাজ নেই।',a.length?`Pending tasks:\n${a.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'No pending tasks.','task-plan');}
 const done=n.match(/^(?:complete task|finish task|কাজ শেষ|কাজ সম্পন্ন)\s*(\d+)$/iu);
 if(done){const s=await load();const a=s.tasks.filter(x=>!x.done);const ix=Number(done[1])-1;if(ix<0||ix>=a.length)return reply(lang,'ওই নম্বরের অসমাপ্ত কাজ পাওয়া যায়নি।','No pending task with that number.','task-plan');a[ix].done=true;a[ix].completedAt=Date.now();await save(s);return reply(lang,`কাজ সম্পন্ন: ${a[ix].text}`,`Completed: ${a[ix].text}`,'task-plan');}
 const del=n.match(/^(?:delete task|remove task|কাজ মুছো|কাজ বাদ)\s*(\d+)$/iu);
 if(del){const s=await load();const a=s.tasks.filter(x=>!x.done);const ix=Number(del[1])-1;if(ix<0||ix>=a.length)return reply(lang,'ওই নম্বরের অসমাপ্ত কাজ পাওয়া যায়নি।','No pending task with that number.','task-plan');const id=a[ix].id,label=a[ix].text;s.tasks=s.tasks.filter(x=>x.id!==id);await save(s);return reply(lang,`কাজ মুছে ফেলা হয়েছে: ${label}`,`Deleted task: ${label}`,'task-plan');}
 const note=raw.match(/^(?:note|save note|নোট|নোট রাখো|নোট লেখো)\s*[:：]?\s*(.+)$/iu);
 if(note){const s=await load();s.notes.push({id:String(Date.now()),body:note[1].trim(),updatedAt:Date.now()});await save(s);return reply(lang,`লোকাল নোটে সংরক্ষণ করেছি: ${note[1].trim()}`,`Saved locally: ${note[1].trim()}`,'notes');}
 if(/^(?:show notes|list notes|নোট দেখাও|আমার নোট|নোটের তালিকা)$/iu.test(n)){const s=await load();const a=s.notes.slice(-15).reverse();return reply(lang,a.length?`সাম্প্রতিক লোকাল নোট:\n${a.map((x,i)=>`${i+1}. ${x.body}`).join('\n')}`:'এখনো কোনো নোট নেই।',a.length?`Recent local notes:\n${a.map((x,i)=>`${i+1}. ${x.body}`).join('\n')}`:'No local notes yet.','notes');}
 const search=raw.match(/^(?:search notes|find note|নোট খোঁজো|নোটে খুঁজো)\s+(.+)$/iu);
 if(search){const s=await load();const q=norm(search[1]);const a=s.notes.filter(x=>norm(x.body).includes(q)).slice(-10).reverse();return reply(lang,a.length?`মিল পাওয়া নোট:\n${a.map((x,i)=>`${i+1}. ${x.body}`).join('\n')}`:'মিল পাওয়া যায়নি।',a.length?`Matching notes:\n${a.map((x,i)=>`${i+1}. ${x.body}`).join('\n')}`:'No matching notes.','notes');}
 const meaning=raw.match(/^(?:meaning|define|অর্থ|মানে|শব্দের অর্থ)\s+(.+)$/iu);
 if(meaning){const e=glossary[norm(meaning[1])];return e?reply(lang,`${meaning[1]}: ${e.bn}`,`${meaning[1]}: ${e.en}`):reply(lang,`“${meaning[1]}” শব্দটি built-in offline glossary-তে নেই।`,`“${meaning[1]}” is not in the built-in offline glossary yet.`);}
 const stats=raw.match(/^(?:text stats|text statistics|টেক্সট স্ট্যাটস|লেখার পরিসংখ্যান)\s*[:：]\s*(.+)$/iu);
 if(stats){const t=stats[1],words=t.trim()?t.trim().split(/\s+/u).length:0,sent=(t.match(/[.!?।]+/gu)||[]).length;return reply(lang,`অক্ষর: ${Array.from(t).length}\nশব্দ: ${words}\nবাক্যচিহ্ন: ${sent}`,`Characters: ${Array.from(t).length}\nWords: ${words}\nSentence marks: ${sent}`,'text-analysis');}
 if(/^(?:workspace status|local data status|লোকাল ডাটা স্ট্যাটাস|ওয়ার্কস্পেস স্ট্যাটাস)$/iu.test(n)){const s=await load();return reply(lang,`Abir Local Workspace\n• অসমাপ্ত কাজ: ${s.tasks.filter(x=>!x.done).length}\n• সম্পন্ন কাজ: ${s.tasks.filter(x=>x.done).length}\n• নোট: ${s.notes.length}\n• Storage: local AsyncStorage\n• Memory limit: 200 remembered items\n• এই module network request করে না।`,`Abir Local Workspace\n• Pending tasks: ${s.tasks.filter(x=>!x.done).length}\n• Completed tasks: ${s.tasks.filter(x=>x.done).length}\n• Notes: ${s.notes.length}\n• Storage: local AsyncStorage\n• Memory limit: 200 remembered items\n• This module makes no network requests.`);}
 return null;
}
export const offlineEvolutionExtension:AssistantExtension={id:'offline-evolution-pack-5.0',async handle(request){return handle(request);}};
