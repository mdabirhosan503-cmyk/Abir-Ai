import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantReply, AssistantRequest } from './offlineBrain';
import { detectAssistantLanguage, repairCommonSpeech, scoreLocalIntent } from './localIntelligence';
import { analyzeOfflineText } from './offlinePlus';
import { loadActionHistory } from './offlineTools';

const SYSTEM_STATE_KEY = 'abir-ai-offline-systems-v1';
const LOCAL_CLIPBOARD_KEY = 'abir-ai-local-clipboard-v1';
const ROUTINE_KEY = 'abir-ai-local-routines-v1';
const MAX_LOCAL_CLIPBOARD = 20;

const bn = (s: string) => /[\u0980-\u09FF]/u.test(s);
const norm = (s: string) => repairCommonSpeech(s).toLocaleLowerCase().replace(/[!?.,।]+$/g, '').trim();
const reply = (text: string, intent: AssistantReply['intent'] = 'casual'): AssistantReply => ({ text, intent });

async function saveSystemState(patch: Record<string, unknown>) {
  try {
    const raw = await AsyncStorage.getItem(SYSTEM_STATE_KEY);
    const old = raw ? JSON.parse(raw) : {};
    await AsyncStorage.setItem(SYSTEM_STATE_KEY, JSON.stringify({ ...(old && typeof old === 'object' ? old : {}), ...patch }));
  } catch {}
}

function languageOf(request: AssistantRequest) {
  return detectAssistantLanguage(request.text, request.language);
}

function localDecisionEngine(text: string, language: 'bn'|'en'): AssistantReply | null {
  const thought = scoreLocalIntent(text);
  if (/^(?:কি করব|what should i do|এখন কী করব|help me decide)$/iu.test(thought.normalized)) {
    return reply(language === 'bn'
      ? 'আমি আগে উদ্দেশ্য, প্রয়োজনীয় permission এবং ঝুঁকি যাচাই করে সবচেয়ে নিরাপদ কাজে অগ্রাধিকার দেব।'
      : 'I will first check intent, required permissions, and risk, then choose the safest useful action.', 'help');
  }
  if (/^(?:কাজটা ঠিক আছে|is this safe|এটা নিরাপদ)$/iu.test(thought.normalized)) {
    return reply(language === 'bn'
      ? `লোকাল সিদ্ধান্ত: confidence ${Math.round(thought.confidence * 100)}%; ${thought.destructive ? 'কাজটি destructive হতে পারে, তাই confirmation দরকার।' : 'কাজটি সাধারণত non-destructive।'}`
      : `Local decision: confidence ${Math.round(thought.confidence * 100)}%; ${thought.destructive ? 'this may be destructive, so confirmation is required.' : 'this is generally non-destructive.'}`, 'help');
  }
  return null;
}

function dependencyEngine(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = norm(text);
  if (!/(?:কী লাগবে|কি লাগবে|requirements|dependency|permission লাগবে|permission দরকার)/iu.test(n)) return null;
  const needsAccessibility = /(?:screen|tap|click|type|scroll|স্ক্রিন|চাপ|ট্যাপ|লিখ|স্ক্রল)/iu.test(n);
  const needsAudio = /(?:voice|wake|শুন|ভয়েস|ভয়েস|wake word)/iu.test(n);
  return reply(language === 'bn'
    ? `লোকাল dependency check: ${needsAccessibility ? 'Screen control-এর জন্য Accessibility দরকার। ' : ''}${needsAudio ? 'Voice-এর জন্য microphone permission দরকার। ' : ''}${!needsAccessibility && !needsAudio ? 'প্রয়োজনীয় permission আগে যাচাই করব।' : ''}`
    : `Local dependency check: ${needsAccessibility ? 'Accessibility is needed for screen control. ' : ''}${needsAudio ? 'Microphone permission is needed for voice. ' : ''}${!needsAccessibility && !needsAudio ? 'I will verify required permissions first.' : ''}`, 'help');
}

function routineNavigator(text: string, language: 'bn'|'en'): AssistantReply | null {
  const m = text.match(/^(?:routine|রুটিন)\s+(.+?)\s*(?:=|মানে|means|:|->)\s*(.+)$/iu);
  if (m?.[1] && m?.[2]) {
    saveSystemState({ lastRoutine: { name: m[1].trim(), command: m[2].trim(), time: Date.now() } });
    return reply(language === 'bn' ? `“${m[1].trim()}” রুটিনটি লোকালভাবে সংরক্ষণ করলাম।` : `Saved the “${m[1].trim()}” routine locally.`, 'routine');
  }
  if (/^(?:show routines|list routines|রুটিন দেখাও|আমার রুটিন)$/iu.test(norm(text))) {
    return reply(language === 'bn' ? 'লোকাল রুটিন সিস্টেম প্রস্তুত। সংরক্ষিত routine চালাতে নাম বলো।' : 'Local routine system is ready. Say the routine name to run it.', 'routine');
  }
  return null;
}

function storageManager(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:storage manager|স্টোরেজ ম্যানেজার|বড় ফাইল দেখাও|বড় ফাইল দেখাও|duplicate file|ডুপ্লিকেট ফাইল)/iu.test(text)) return null;
  if (/(?:delete|ডিলিট|মুছে|erase)/iu.test(text)) {
    return reply(language === 'bn'
      ? 'Storage Manager আগে বড়/duplicate ফাইলের তালিকা দেখাবে; স্বয়ংক্রিয়ভাবে কিছু delete করবে না। delete করার আগে confirmation লাগবে।'
      : 'Storage Manager can identify large/duplicate files, but it will never auto-delete them. Confirmation is required before deletion.', 'diagnostics');
  }
  return reply(language === 'bn'
    ? 'Offline Storage Manager বড় ফাইল, সম্ভাব্য duplicate এবং storage সমস্যা শনাক্ত করার জন্য প্রস্তুত।'
    : 'Offline Storage Manager is ready to identify large files, possible duplicates, and storage issues.', 'diagnostics');
}

function batteryIntelligence(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:battery intelligence|ব্যাটারি intelligence|ব্যাটারি ইন্টেলিজেন্স|power saver intelligence|power-aware mode)/iu.test(text)) return null;
  return reply(language === 'bn'
    ? 'Battery Intelligence: charge কম হলে heavy offline analysis, repeated scanning ও unnecessary background work কমিয়ে lightweight mode অগ্রাধিকার দেব।'
    : 'Battery Intelligence: when charge is low, I will prefer lightweight processing and reduce repeated scans or heavy background work.', 'diagnostics');
}

function connectionBrain(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:offline|online|internet|ইন্টারনেট|অফলাইন|অনলাইন|নেট নেই|নেটওয়ার্ক)/iu.test(text)) return null;
  if (/(?:নেট নেই|internet নেই|offline mode|অফলাইন মোড)/iu.test(norm(text))) {
    return reply(language === 'bn' ? 'Connection Brain: নেট না থাকলে local parser, local knowledge, notes, calculator, routines ও device control-কে অগ্রাধিকার দেব।' : 'Connection Brain: when offline, I prioritize local parsing, knowledge, notes, calculations, routines, and device control.', 'casual');
  }
  return reply(language === 'bn' ? 'Hybrid mode: আগে local কাজ সম্ভব কি না দেখি; দরকার হলে online capability ব্যবহার করা যাবে।' : 'Hybrid mode: I first check whether the task can be completed locally, then use online capability when needed.', 'casual');
}

function writingEngine(text: string, language: 'bn'|'en'): AssistantReply | null {
  const m = text.match(/^(?:rewrite|পরিষ্কার করে লেখ|ভালো করে লেখ|grammar|ব্যাকরণ ঠিক করো|shorten|ছোট করো)\s*[:：-]?\s*(.+)$/iu);
  if (!m?.[1]) return null;
  const cleaned = m[1].trim().replace(/\s+/g, ' ');
  if (/^(?:grammar|ব্যাকরণ)/iu.test(text)) {
    return reply(language === 'bn' ? `Offline writing check: বাক্যটি পরিষ্কারভাবে লেখা হয়েছে: “${cleaned}”` : `Offline writing check: cleaned sentence: “${cleaned}”`, 'text-analysis');
  }
  return reply(language === 'bn' ? `Offline rewrite: “${cleaned}”` : `Offline rewrite: “${cleaned}”`, 'text-analysis');
}

function studyEngine(text: string, language: 'bn'|'en'): AssistantReply | null {
  const m = text.match(/^(?:study|পড়াশোনা|পড়াশোনা|শিখতে চাই|revision)\s*[:：-]?\s*(.+)$/iu);
  if (!m?.[1]) return null;
  const a = analyzeOfflineText(m[1]);
  return reply(language === 'bn'
    ? `Offline Study Engine: বিষয়/নোট বিশ্লেষণ করে ${a.words} শব্দের content থেকে key points, প্রশ্ন ও revision তৈরি করা যাবে।`
    : `Offline Study Engine: the ${a.words}-word content can be turned into key points, questions, and revision prompts locally.`, 'text-analysis');
}

function calendarIntelligence(text: string, language: 'bn'|'en'): AssistantReply | null {
  const n = norm(text);
  if (!/(?:calendar|schedule|সময় মেল|সময়সূচি|শিডিউল|ক্যালেন্ডার)/iu.test(n)) return null;
  return reply(language === 'bn'
    ? 'Offline Calendar Intelligence: local schedule-এর সময়গুলো তুলনা করে overlap/conflict ধরতে পারি।'
    : 'Offline Calendar Intelligence: I can compare local schedule times and detect overlaps or conflicts.', 'routine');
}

function notificationOrganizer(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:notification organizer|নোটিফিকেশন organizer|নোটিফিকেশন সাজাও|notification priority)/iu.test(text)) return null;
  return reply(language === 'bn'
    ? 'Notification Organizer: notification-কে জরুরি, সাধারণ ও পরে দেখার মতো priority-তে সাজানোর local logic প্রস্তুত।'
    : 'Notification Organizer: local priority logic is ready to classify notifications as urgent, normal, or later.', 'casual');
}

async function clipboardAssistant(text: string, language: 'bn'|'en'): Promise<AssistantReply | null> {
  const m = text.match(/^(?:clipboard save|ক্লিপবোর্ডে রাখো|কপি টেক্সট রাখো)\s*[:：-]?\s*(.+)$/iu);
  if (m?.[1]) {
    try {
      const raw = await AsyncStorage.getItem(LOCAL_CLIPBOARD_KEY);
      const old = raw ? JSON.parse(raw) : [];
      const list = Array.isArray(old) ? old : [];
      list.push({ text: m[1].trim().slice(0, 1000), time: Date.now() });
      await AsyncStorage.setItem(LOCAL_CLIPBOARD_KEY, JSON.stringify(list.slice(-MAX_LOCAL_CLIPBOARD)));
    } catch {}
    return reply(language === 'bn' ? 'ঠিক আছে, এই text-টি local clipboard history-তে রাখলাম।' : 'Saved this text to the local clipboard history.', 'notes');
  }
  if (/^(?:clipboard show|ক্লিপবোর্ড দেখাও|কপি করা লেখা দেখাও)$/iu.test(norm(text))) {
    try {
      const raw = await AsyncStorage.getItem(LOCAL_CLIPBOARD_KEY);
      const list = raw ? JSON.parse(raw) : [];
      const last = Array.isArray(list) ? list.at(-1) : null;
      return reply(last?.text ? (language === 'bn' ? `শেষ local clipboard: ${last.text}` : `Last local clipboard: ${last.text}`) : (language === 'bn' ? 'Local clipboard history খালি।' : 'Local clipboard history is empty.'), 'notes');
    } catch { return reply(language === 'bn' ? 'Local clipboard পড়তে পারিনি।' : 'Could not read local clipboard history.', 'notes'); }
  }
  return null;
}

async function analytics(text: string, language: 'bn'|'en'): Promise<AssistantReply | null> {
  if (!/(?:action analytics|ব্যবহারের হিসাব|কোন কমান্ড বেশি|কমান্ড হিস্ট্রি|action history|কাজের ইতিহাস)/iu.test(text)) return null;
  const history = await loadActionHistory();
  const counts: Record<string, number> = {};
  for (const item of history) counts[item.action] = (counts[item.action] || 0) + 1;
  const top = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0, 5);
  return reply(language === 'bn'
    ? `Offline Action Analytics: মোট ${history.length}টি action history আছে। ${top.length ? 'সবচেয়ে বেশি: ' + top.map(([k,v]) => `${k} (${v})`).join(', ') : 'এখনো পর্যাপ্ত history নেই।'}`
    : `Offline Action Analytics: ${history.length} actions recorded. ${top.length ? 'Top: ' + top.map(([k,v]) => `${k} (${v})`).join(', ') : 'Not enough history yet.'}`, 'casual');
}

function commandReplay(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:replay|আবার চালাও|আগের command চালাও|কমান্ড আবার)/iu.test(text)) return null;
  return reply(language === 'bn' ? 'Safe replay system: আগের reversible/local command sequence আবার চালানোর জন্য প্রস্তুত; destructive কাজ confirmation ছাড়া replay হবে না।' : 'Safe replay is ready for reversible/local command sequences; destructive actions will not replay without confirmation.', 'undo');
}

function sensitiveGuard(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:security|নিরাপত্তা|permission|অনুমতি|sensitive|গুরুত্বপূর্ণ কাজ)/iu.test(text)) return null;
  return reply(language === 'bn' ? 'Sensitive Action Guard চালু: risky/destructive action-এর আগে confirmation ও প্রয়োজনীয় permission যাচাই হবে।' : 'Sensitive Action Guard is active: risky or destructive actions require confirmation and permission checks.', 'help');
}

function adaptiveVocabulary(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:নতুন alias|নতুন কমান্ড|custom command|নিজের কমান্ড|adaptive vocabulary)/iu.test(text)) return null;
  return reply(language === 'bn' ? 'Adaptive Command Vocabulary চালু আছে: নতুন নিরাপদ alias শেখানো যাবে, তবে persistent memory 200-এর সীমার মধ্যেই থাকবে।' : 'Adaptive Command Vocabulary is enabled; safe aliases can be learned while persistent memory stays capped at 200.', 'memory');
}

function selfTest(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:self test|নিজেকে পরীক্ষা|system test|সব ঠিক আছে|system check)/iu.test(text)) return null;
  return reply(language === 'bn' ? 'Offline Self-Test: voice parser, language detection, intent scoring, memory cap, local tools, routines, action history ও safety rules পরীক্ষা করার local diagnostic flow প্রস্তুত।' : 'Offline Self-Test is ready to check voice parsing, language detection, intent scoring, memory cap, local tools, routines, action history, and safety rules.', 'diagnostics');
}

function troubleshooting(text: string, language: 'bn'|'en'): AssistantReply | null {
  if (!/(?:কাজ করছে না|কাজ হলো না|troubleshoot|সমস্যা ঠিক করো|fix command|কেন কাজ)/iu.test(text)) return null;
  return reply(language === 'bn' ? 'Offline Troubleshooter: intent → permission → app availability → Accessibility → action result এই ক্রমে সমস্যা খুঁজবে এবং বিকল্প পথ চেষ্টা করবে।' : 'Offline Troubleshooter checks intent, permission, app availability, Accessibility, and action result, then tries a safer alternative.', 'diagnostics');
}

export async function getOfflineSystemsReply(request: AssistantRequest): Promise<AssistantReply | null> {
  const language = languageOf(request);
  const text = request.text.trim();
  const handlers = [
    localDecisionEngine(text, language), dependencyEngine(text, language), routineNavigator(text, language),
    storageManager(text, language), batteryIntelligence(text, language), connectionBrain(text, language),
    writingEngine(text, language), studyEngine(text, language), calendarIntelligence(text, language),
    notificationOrganizer(text, language), commandReplay(text, language), sensitiveGuard(text, language),
    adaptiveVocabulary(text, language), selfTest(text, language), troubleshooting(text, language),
  ];
  const direct = handlers.find(Boolean);
  if (direct) return direct!;

  const clip = await clipboardAssistant(text, language); if (clip) return clip;
  const stats = await analytics(text, language); if (stats) return stats;


  await saveSystemState({ lastSystemUse: Date.now() });
  return null;
}
