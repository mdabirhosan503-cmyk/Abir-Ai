export type MessageApp = 'whatsapp' | 'messenger' | 'imo';

export type MessageRequest = {
  app: MessageApp;
  recipient: string;
  message: string;
};

export type VoiceMessageRequest = {
  app: MessageApp;
  recipient: string;
  durationMs: number;
};

function clean(value: string) {
  return value.trim().replace(/^['"“”‘’]|['"“”‘’]$/g, '').replace(/\s+/g, ' ');
}

function appFromText(value: string): MessageApp {
  return /imo|ইমু/i.test(value) ? 'imo' : /messenger|মেসেঞ্জার/i.test(value) ? 'messenger' : 'whatsapp';
}

function appLabel(app: MessageApp) {
  return app === 'whatsapp' ? 'WhatsApp' : app === 'messenger' ? 'Messenger' : 'IMO';
}

export function extractMessageRequest(text: string): MessageRequest | null {
  const t = text.trim();
  const appPattern = '(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)';
  const bn = t.match(new RegExp(`^(${appPattern})\s*(?:এ|তে|-এ|-তে)?\s+(.+?)\s*কে?\s+(?:মেসেজ|বার্তা|টেক্সট)\s+(?:দাও|দিয়ে দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|পাঠিয়ে দাও|করো)\s*[:：-]?\s*(.+)$`, 'iu'))
    || t.match(new RegExp(`^(.+?)(?:\s*কে)?\s+${appPattern}\s+(?:এ|তে|-এ|-তে)?\s*(?:মেসেজ|বার্তা|টেক্সট)\s+(?:দাও|দিয়ে দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|পাঠিয়ে দাও|করো)\s*[:：-]?\s*(.+)$`, 'iu'));
  if (bn) {
    const firstIsApp = new RegExp(`^${appPattern}$`, 'iu').test(bn[1]);
    const app = firstIsApp ? appFromText(bn[1]) : appFromText(bn[2]);
    const recipient = clean((firstIsApp ? bn[2] : bn[1]).replace(/\s+কে$/u, ''));
    const message = clean(bn[3] ?? '');
    if (recipient && message) return { app, recipient, message };
  }

  const en = t.match(/^(?:send|message|text)\s+(?:a\s+)?message\s+to\s+(.+?)\s+(?:on|via|in)\s+(whatsapp|messenger|imo)\s*[:,-]?\s+(.+)$/i)
    || t.match(/^(?:send|message|text)\s+(.+?)\s+(?:on|via|in)\s+(whatsapp|messenger|imo)\s*[:,-]?\s+(.+)$/i)
    || t.match(/^(whatsapp|messenger|imo)\s+(.+?)\s+(?:message|text)\s*[:,-]?\s+(.+)$/i);
  if (en) {
    const app = en[1].toLowerCase() in { whatsapp:1, messenger:1, imo:1 } ? appFromText(en[1]) : appFromText(en[2]);
    const recipient = clean(en[1].toLowerCase() in { whatsapp:1, messenger:1, imo:1 } ? en[2] : en[1]);
    const message = clean(en[3]);
    if (recipient && message) return { app, recipient, message };
  }
  return null;
}

export function extractVoiceMessageRequest(text: string): VoiceMessageRequest | null {
  const t = text.trim();
  const appPattern = '(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)';
  const durationMatch = t.match(/(?:([0-9]{1,2})|([০-৯]{1,2}))\s*(?:সেকেন্ড|second|seconds|sec)/iu);
  const digits = durationMatch?.[1] ?? durationMatch?.[2]?.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  const durationMs = Math.min(30, Math.max(3, Number(digits || 8))) * 1000;

  const bn = t.match(new RegExp(`^${appPattern}\s*(?:এ|তে|-এ|-তে)?\s+(.+?)(?:\s*কে)?\s+(?:ভয়েস|ভয়েস|voice)\s*(?:মেসেজ|বার্তা|message|note)\s+(?:দাও|দিয়ে দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|পাঠিয়ে দাও|করো)`, 'iu'))
    || t.match(new RegExp(`^(.+?)(?:\s*কে)?\s+${appPattern}\s+(?:এ|তে|-এ|-তে)?\s+(?:ভয়েস|ভয়েস|voice)\s*(?:মেসেজ|বার্তা|message|note)\s+(?:দাও|দিয়ে দাও|দিয়ে দাও|পাঠাও|পাঠিয়ে দাও|পাঠিয়ে দাও|করো)`, 'iu'));
  if (bn) {
    const firstIsApp = new RegExp(`^${appPattern}$`, 'iu').test(bn[1]);
    const app = firstIsApp ? appFromText(bn[1]) : appFromText(bn[2]);
    const recipient = clean((firstIsApp ? bn[2] : bn[1]).replace(/\s+কে$/u, ''));
    if (recipient) return { app, recipient, durationMs };
  }

  const en = t.match(/^(?:send|record)\s+(?:a\s+)?voice\s+(?:message|note)\s+to\s+(.+?)\s+(?:on|via|in)\s+(whatsapp|messenger|imo)/i)
    || t.match(/^(?:send|record)\s+(.+?)\s+(?:a\s+)?voice\s+(?:message|note)\s+(?:on|via|in)\s+(whatsapp|messenger|imo)/i);
  if (en) {
    return { app: appFromText(en[2]), recipient: clean(en[1]), durationMs };
  }
  return null;
}

export function messageAutomationReply(request: MessageRequest, language: 'bn' | 'en', result: 'sent' | 'not-enabled' | 'failed') {
  const label = appLabel(request.app);
  if (result === 'sent') return language === 'bn'
    ? `${label}-এ ${request.recipient}-কে মেসেজ পাঠিয়ে দিয়েছি।`
    : `I sent the message to ${request.recipient} on ${label}.`;
  if (result === 'not-enabled') return language === 'bn'
    ? 'মেসেজ পাঠাতে Android Accessibility Service চালু করতে হবে। Settings খুলে Abir AI-কে অনুমতি দাও।'
    : 'Android Accessibility Service must be enabled. Open Settings and allow Abir AI.';
  return language === 'bn'
    ? `${label}-এ ${request.recipient}-কে মেসেজ পাঠানো যায়নি।`
    : `I could not send the message to ${request.recipient} on ${label}.`;
}
