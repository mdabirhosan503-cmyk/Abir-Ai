import AsyncStorage from '@react-native-async-storage/async-storage';

// Extra offline features are intentionally stored separately from remembered facts.
// The assistant memory limit remains MAX_MEMORY_ITEMS = 200 in localMemory.ts.
const NOTES_KEY = 'abir-ai-local-notes-v1';
const ROUTINES_KEY = 'abir-ai-local-routines-v1';
const ALIASES_KEY = 'abir-ai-local-aliases-v1';
const MAX_NOTES = 100;
const MAX_ROUTINES = 20;
const MAX_ALIASES = 50;

export type LocalNote = { id: string; text: string; createdAt: number };
export type LocalRoutine = { id: string; name: string; command: string; createdAt: number };
export type LocalAlias = { phrase: string; command: string; uses: number; updatedAt: number };

async function readJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as T;
    return parsed ?? fallback;
  } catch { return fallback; }
}

async function writeJson<T>(key: string, value: T) {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export async function loadLocalNotes(): Promise<LocalNote[]> {
  const notes = await readJson<LocalNote[]>(NOTES_KEY, []);
  return Array.isArray(notes) ? notes.slice(-MAX_NOTES) : [];
}

export async function addLocalNote(text: string): Promise<LocalNote> {
  const note: LocalNote = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, text: text.trim().slice(0, 5000), createdAt: Date.now() };
  const notes = await loadLocalNotes();
  await writeJson(NOTES_KEY, [...notes, note].slice(-MAX_NOTES));
  return note;
}

export async function searchLocalNotes(query: string): Promise<LocalNote[]> {
  const q = query.trim().toLocaleLowerCase();
  const notes = await loadLocalNotes();
  if (!q) return notes.slice(-10).reverse();
  return notes.filter(n => n.text.toLocaleLowerCase().includes(q)).slice(-10).reverse();
}

export async function clearLocalNotes() { await AsyncStorage.removeItem(NOTES_KEY); }

export async function loadLocalRoutines(): Promise<LocalRoutine[]> {
  const items = await readJson<LocalRoutine[]>(ROUTINES_KEY, []);
  return Array.isArray(items) ? items.slice(-MAX_ROUTINES) : [];
}

export async function saveLocalRoutine(name: string, command: string): Promise<LocalRoutine> {
  const item = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name: name.trim().slice(0, 80), command: command.trim().slice(0, 500), createdAt: Date.now() };
  const routines = await loadLocalRoutines();
  await writeJson(ROUTINES_KEY, [...routines.filter(r => r.name.toLowerCase() !== item.name.toLowerCase()), item].slice(-MAX_ROUTINES));
  return item;
}

export async function findLocalRoutine(name: string): Promise<LocalRoutine | null> {
  const q = name.trim().toLocaleLowerCase();
  return (await loadLocalRoutines()).find(r => r.name.toLocaleLowerCase() === q || r.name.toLocaleLowerCase().includes(q)) ?? null;
}

export async function loadLocalAliases(): Promise<LocalAlias[]> {
  const items = await readJson<LocalAlias[]>(ALIASES_KEY, []);
  return Array.isArray(items) ? items.slice(-MAX_ALIASES) : [];
}

export async function learnLocalAlias(phrase: string, command: string): Promise<void> {
  const p = phrase.trim().toLocaleLowerCase().slice(0, 80);
  const c = command.trim().slice(0, 300);
  if (!p || !c) return;
  const aliases = await loadLocalAliases();
  const old = aliases.find(a => a.phrase === p);
  const item: LocalAlias = { phrase: p, command: c, uses: (old?.uses ?? 0) + 1, updatedAt: Date.now() };
  await writeJson(ALIASES_KEY, [...aliases.filter(a => a.phrase !== p), item].slice(-MAX_ALIASES));
}

export async function resolveLocalAlias(text: string): Promise<string | null> {
  const n = text.trim().toLocaleLowerCase();
  const aliases = await loadLocalAliases();
  const hit = aliases.find(a => n === a.phrase || n.includes(a.phrase));
  if (!hit) return null;
  hit.uses += 1;
  hit.updatedAt = Date.now();
  await writeJson(ALIASES_KEY, aliases.slice(-MAX_ALIASES));
  return hit.command;
}

export function planOfflineTasks(text: string): string[] {
  return text
    .normalize('NFKC')
    .split(/\s*(?:এবং তারপর|তারপর|পরে|এবং|and then|then|after that|also|, then)\s*/iu)
    .map(s => s.trim().replace(/^\s*(?:please|প্লিজ|দয়া করে|দয়া করে)\s+/iu, ''))
    .filter(Boolean)
    .slice(0, 6);
}

export function summarizeLocalContext(context: Array<{ role: 'user' | 'assistant'; text: string }> = []) {
  const lastUser = [...context].reverse().find(x => x.role === 'user')?.text ?? '';
  const lastAssistant = [...context].reverse().find(x => x.role === 'assistant')?.text ?? '';
  return { lastUser, lastAssistant, turns: context.length };
}

export function convertOfflineUnit(value: number, from: string, to: string): number | null {
  const f = from.toLowerCase(); const t = to.toLowerCase();
  const aliases: Record<string, string> = {
    km: 'km', kilometer: 'km', kilometers: 'km', কিলোমিটার: 'km',
    m: 'm', meter: 'm', meters: 'm', মিটার: 'm',
    cm: 'cm', centimeter: 'cm', centimeters: 'cm', সেন্টিমিটার: 'cm',
    mile: 'mile', miles: 'mile', মাইল: 'mile',
    kg: 'kg', kilogram: 'kg', kilograms: 'kg', কেজি: 'kg', কিলোগ্রাম: 'kg',
    g: 'g', gram: 'g', grams: 'g', গ্রাম: 'g',
    lb: 'lb', pound: 'lb', pounds: 'lb', পাউন্ড: 'lb',
    c: 'c', '°c': 'c', celsius: 'c', সেলসিয়াস: 'c', সেলসিয়াস: 'c',
    f: 'f', '°f': 'f', fahrenheit: 'f', ফারেনহাইট: 'f',
    l: 'l', liter: 'l', litre: 'l', liters: 'l', literss: 'l', লিটার: 'l',
    ml: 'ml', milliliter: 'ml', milliliters: 'ml', মিলিলিটার: 'ml',
  };
  const a = aliases[f]; const b = aliases[t]; if (!a || !b) return null;
  if (a === b) return value;
  const length: Record<string, number> = { km: 1000, m: 1, cm: 0.01, mile: 1609.344 };
  if (length[a] && length[b]) return value * length[a] / length[b];
  const mass: Record<string, number> = { kg: 1, g: 0.001, lb: 0.45359237 };
  if (mass[a] && mass[b]) return value * mass[a] / mass[b];
  const volume: Record<string, number> = { l: 1, ml: 0.001 };
  if (volume[a] && volume[b]) return value * volume[a] / volume[b];
  if (a === 'c' && b === 'f') return value * 9 / 5 + 32;
  if (a === 'f' && b === 'c') return (value - 32) * 5 / 9;
  return null;
}

export function analyzeOfflineText(text: string) {
  const clean = text.replace(/\s+/g, ' ').trim();
  const sentences = clean ? clean.split(/[.!?।]+/).map(s => s.trim()).filter(Boolean) : [];
  const words = clean ? clean.split(/\s+/).filter(Boolean) : [];
  return { characters: clean.length, words: words.length, sentences: sentences.length, preview: clean.slice(0, 1000) };
}

// Additive local document vault for pasted/imported text. It is deliberately separate
// from remembered facts, so the 200-item personal-memory limit is unchanged.
const DOCUMENTS_KEY = 'abir-ai-local-documents-v1';
const MAX_DOCUMENTS = 40;
export type LocalDocument = { id: string; title: string; text: string; createdAt: number };
export async function loadLocalDocuments(): Promise<LocalDocument[]> {
  const items = await readJson<LocalDocument[]>(DOCUMENTS_KEY, []);
  return Array.isArray(items) ? items.slice(-MAX_DOCUMENTS) : [];
}
export async function saveLocalDocument(title: string, text: string): Promise<LocalDocument> {
  const item: LocalDocument = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title: title.trim().slice(0, 100) || 'Untitled document', text: text.trim().slice(0, 30000), createdAt: Date.now() };
  if (!item.text) throw new Error('Document text is empty');
  const all = await loadLocalDocuments();
  await writeJson(DOCUMENTS_KEY, [...all.filter(d => d.title.toLocaleLowerCase() !== item.title.toLocaleLowerCase()), item].slice(-MAX_DOCUMENTS));
  return item;
}
export async function searchLocalDocuments(query: string): Promise<Array<{ document: LocalDocument; excerpt: string; score: number }>> {
  const terms = query.toLocaleLowerCase().split(/\s+/u).filter(t => t.length > 1);
  const docs = await loadLocalDocuments();
  return docs.map(document => {
    const haystack = `${document.title} ${document.text}`.toLocaleLowerCase();
    const score = terms.reduce((n, term) => n + (haystack.includes(term) ? 1 : 0), 0);
    const at = terms.map(term => haystack.indexOf(term)).filter(i => i >= 0).sort((a,b) => a-b)[0] ?? 0;
    const excerpt = document.text.slice(Math.max(0, at - 120), Math.min(document.text.length, at + 420));
    return { document, excerpt, score };
  }).filter(x => x.score > 0).sort((a,b) => b.score - a.score || b.document.createdAt - a.document.createdAt).slice(0, 5);
}

/** Small, transparent offline phrasebook; unknown phrases are never fabricated. */
export function translateOfflinePhrase(input: string, target: 'bn' | 'en'): string | null {
  const clean = input.trim().toLocaleLowerCase().replace(/[.!?।]+$/u, '');
  const pairs: Array<[string, string]> = [
    ['hello','হ্যালো'], ['হ্যালো','hello'], ['হ্যালো কেমন আছ','Hello, how are you?'], ['how are you','তুমি কেমন আছ'], ['তুমি কেমন আছ','How are you?'],
    ['good morning','সুপ্রভাত'], ['সুপ্রভাত','Good morning'], ['good night','শুভ রাত্রি'], ['শুভ রাত্রি','Good night'],
    ['thank you','ধন্যবাদ'], ['ধন্যবাদ','Thank you'], ['please','অনুগ্রহ করে'], ['অনুগ্রহ করে','Please'], ['sorry','দুঃখিত'], ['দুঃখিত','Sorry'],
    ['yes','হ্যাঁ'], ['হ্যাঁ','Yes'], ['no','না'], ['না','No'], ['help me','আমাকে সাহায্য করো'], ['আমাকে সাহায্য করো','Help me'],
    ['what is your name','তোমার নাম কী'], ['তোমার নাম কী','What is your name?'], ['i do not understand','আমি বুঝতে পারছি না'], ['আমি বুঝতে পারছি না','I do not understand'],
    ['where is the hospital','হাসপাতাল কোথায়'], ['হাসপাতাল কোথায়','Where is the hospital?'], ['how much does it cost','এটার দাম কত'], ['এটার দাম কত','How much does it cost?'],
    ['আমি ভালো আছি','I am fine'], ['i am fine','আমি ভালো আছি'], ['আমি তোমাকে সাহায্য করতে পারি','I can help you'], ['i can help you','আমি তোমাকে সাহায্য করতে পারি']
  ];
  const found = pairs.find(([a]) => a === clean);
  if (!found) return null;
  // Entries are written source -> translation; target chooses the opposite side when source is known.
  const sourceBn = /[\u0980-\u09FF]/u.test(input);
  if (target === 'en') return sourceBn ? (pairs.find(([a]) => a === clean)?.[1] ?? null) : null;
  return sourceBn ? null : (found[1] || null);
}
