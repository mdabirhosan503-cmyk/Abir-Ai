/** Abir AI 5.2 Next-Generation local-first features.
 * These are real local command handlers; platform integrations are reported separately.
 * Does not import or change localMemory.ts (the 200 remembered-facts limit stays intact).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';

const STORE = 'abir-ai-nextgen-local-v1';
type Audit = { at: number; action: string; result: string };
type LocalState = { aliases: Array<{ phrase: string; command: string }>; audit: Audit[]; failures: Array<{ at: number; command: string; reason: string }> };
const empty = (): LocalState => ({ aliases: [], audit: [], failures: [] });
const norm = (s: string) => s.toLocaleLowerCase().normalize('NFKC').replace(/[!?.,،।:：]+/gu, ' ').replace(/\s+/gu, ' ').trim();
const isBn = (s: string) => /[\u0980-\u09ff]/u.test(s);
const reply = (r: AssistantRequest, bn: string, en: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: r.language === 'bn' || isBn(r.text) ? bn : en, intent });
async function read(): Promise<LocalState> {
  try { const raw = await AsyncStorage.getItem(STORE); const x = raw ? JSON.parse(raw) : {}; return { aliases: Array.isArray(x.aliases) ? x.aliases.slice(-100) : [], audit: Array.isArray(x.audit) ? x.audit.slice(-100) : [], failures: Array.isArray(x.failures) ? x.failures.slice(-50) : [] }; } catch { return empty(); }
}
async function write(s: LocalState) { await AsyncStorage.setItem(STORE, JSON.stringify({ aliases: s.aliases.slice(-100), audit: s.audit.slice(-100), failures: s.failures.slice(-50) })); }
function addAudit(s: LocalState, action: string, result: string) { s.audit.push({ at: Date.now(), action: action.slice(0,160), result: result.slice(0,160) }); s.audit = s.audit.slice(-100); }
const words = (s: string) => new Set(norm(s).split(' ').filter(x => x.length > 1));
function similarity(a: string, b: string) { const aa = words(a), bb = words(b); if (!aa.size || !bb.size) return 0; let n = 0; for (const w of aa) if (bb.has(w)) n++; return n / (aa.size + bb.size - n); }
function goalSteps(goal: string): string[] {
  const g = goal.trim();
  const parts = g.split(/\s*(?:, তারপর | তারপর | এবং তারপর | এরপর | -> |=>|;|\|)\s*/u).map(x => x.trim()).filter(Boolean);
  if (parts.length > 1) return parts.slice(0, 10);
  return [`লক্ষ্যটি স্পষ্ট করো: ${g}`, 'প্রয়োজনীয় তথ্য/উপকরণ প্রস্তুত করো', 'প্রথম ছোট ধাপটি সম্পন্ন করো', 'ফলাফল যাচাই করো', 'অসম্পূর্ণ অংশ থাকলে পরবর্তী ধাপ ঠিক করো'];
}
async function handle(request: AssistantRequest): Promise<AssistantReply | null> {
  const text = request.text.trim(); if (!text) return null;
  const n = norm(text); const s = await read();
  const aliasAdd = text.match(/^(?:learn phrase|learn command|শেখাও|কমান্ড শেখাও)\s+(.+?)\s*(?:=>|->|মানে|বললে)\s*(.+)$/iu);
  if (aliasAdd) {
    const phrase = norm(aliasAdd[1]), command = aliasAdd[2].trim();
    if (!phrase || !command || phrase === norm(command)) return reply(request, 'একটি আলাদা বাক্য ও তার সরাসরি কমান্ড দাও।', 'Provide a distinct phrase and a direct command.');
    s.aliases = s.aliases.filter(x => norm(x.phrase) !== phrase); s.aliases.push({ phrase, command }); addAudit(s, 'phrase learning', 'saved'); await write(s);
    return reply(request, `বাক্য শেখা হয়েছে: “${phrase}” → “${command}”। এটি লোকালেই রাখা হয়েছে।`, `Learned locally: “${phrase}” → “${command}”.`, 'help');
  }
  const exact = s.aliases.find(x => norm(x.phrase) === n);
  if (exact) { addAudit(s, 'learned phrase', 'matched'); await write(s); return reply(request, `এই বাক্যটির শেখানো কমান্ড: ${exact.command}\nনিরাপত্তার জন্য এটি শুধু দেখালাম; কমান্ডটি চালাতে আলাদা করে বলো।`, `Learned command: ${exact.command}\nFor safety, this is a preview only. Ask separately to run it.`); }
  if (/^(?:show learned phrases|শেখানো কমান্ড দেখাও|আমার শেখানো বাক্য)$/iu.test(n)) return reply(request, s.aliases.length ? `শেখানো বাক্য:\n${s.aliases.map((x,i)=>`${i+1}. ${x.phrase} → ${x.command}`).join('\n')}` : 'এখনো কোনো বাক্য শেখানো হয়নি। “শেখাও [বাক্য] => [কমান্ড]” ব্যবহার করো।', s.aliases.length ? `Learned phrases:\n${s.aliases.map((x,i)=>`${i+1}. ${x.phrase} → ${x.command}`).join('\n')}` : 'No learned phrases yet. Use “learn phrase [phrase] => [command]”.');

  const goal = text.match(/^(?:goal plan|plan goal|লক্ষ্য পরিকল্পনা|লক্ষ্য ভাগ করো|প্ল্যান করো)\s*[:：]?\s*(.+)$/iu);
  if (goal) { const steps = goalSteps(goal[1]); addAudit(s, 'goal plan', 'preview generated'); await write(s); return reply(request, `লক্ষ্য: ${goal[1]}\nপরিকল্পিত ধাপ:\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nএটি পরিকল্পনা মাত্র; কোনো ডিভাইস অ্যাকশন চালানো হয়নি।`, `Goal: ${goal[1]}\nPlan:\n${steps.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nPlan only; no device action was executed.`, 'task-plan'); }

  const conflict = text.match(/^(?:memory conflict check|check memory conflict|মেমোরি দ্বন্দ্ব পরীক্ষা|তথ্য মিলিয়ে দেখো)\s+(.+?)\s+(?:vs|versus|নাকি|বনাম|=>)\s+(.+)$/iu);
  if (conflict) { const score = similarity(conflict[1], conflict[2]); const verdict = score >= .5 ? 'তথ্য দুটির মধ্যে উল্লেখযোগ্য মিল আছে; একই তথ্যের ভিন্ন রূপ হতে পারে।' : 'তথ্য দুটির মধ্যে স্পষ্ট শব্দগত মিল কম; পরস্পরবিরোধী কি না নিশ্চিত হতে প্রসঙ্গ দরকার।'; return reply(request, `তথ্য ১: ${conflict[1]}\nতথ্য ২: ${conflict[2]}\n${verdict}\nকোনো মেমোরি পরিবর্তন করা হয়নি।`, `Fact A: ${conflict[1]}\nFact B: ${conflict[2]}\n${score >= .5 ? 'The facts overlap substantially and may be variants of the same fact.' : 'Low lexical overlap; more context is needed to determine whether they conflict.'}\nNo memory was changed.`); }

  const qa = text.match(/^(?:local knowledge|জ্ঞানভান্ডার|লোকাল জ্ঞান)\s+(.+)$/iu);
  if (qa) return reply(request, 'লোকাল জ্ঞানভান্ডারে এখনো স্বতন্ত্র নথি-ইনডেক্স সংযুক্ত নেই। বিদ্যমান “নোট খোঁজো [শব্দ]” বা “লোকাল সার্চ [শব্দ]” কমান্ড দিয়ে সংরক্ষিত নোট ও টাস্ক খুঁজে দেখতে পারো।', 'A dedicated document index is not connected yet. Use “search notes [term]” or “global search [term]” to search saved local notes and tasks.');

  if (/^(?:device capability map|device capability|ডিভাইস সক্ষমতা|ফোনের সক্ষমতা দেখাও)$/iu.test(n)) return reply(request, 'ডিভাইস সক্ষমতা: এই কমান্ডে নিরাপদে যাচাইযোগ্য অ্যাপ-স্তরের তথ্যই দেখানো যায়। ক্যামেরা/OCR, নোটিফিকেশন, অ্যাক্সেসিবিলিটি, ব্যাকগ্রাউন্ড কাজ ও মডেল চালানোর ক্ষমতা জানতে সংশ্লিষ্ট Android API/অনুমতি পরীক্ষা করতে হবে। অনুমতি না থাকলে ফিচারটি উপলব্ধ বলে ধরা হবে না।', 'Capability map: this command can only report app-level facts safely. Camera/OCR, notifications, accessibility, background work and local model support require their Android APIs and permissions to be checked; unavailable permissions are not treated as available.', 'diagnostics');

  if (/^(?:automation simulate|simulate automation|অটোমেশন সিমুলেট|রুটিন সিমুলেট)\s+.+$/iu.test(text)) { const action = text.replace(/^(?:automation simulate|simulate automation|অটোমেশন সিমুলেট|রুটিন সিমুলেট)\s+/iu, '').trim(); const unsafe = /(?:delete|remove|send|pay|purchase|call|কল|পাঠাও|মুছে|ডিলিট|পেমেন্ট|কিনে নাও)/iu.test(action); return reply(request, `সিমুলেশন প্রিভিউ: ${action}\n• বাস্তব অ্যাকশন চালানো হয়নি।\n• ${unsafe ? 'এই ধাপে গুরুত্বপূর্ণ পরিবর্তন/বাহ্যিক কাজ থাকতে পারে—স্পষ্ট নিশ্চিতকরণ ও উপযুক্ত অ্যাকশন হ্যান্ডলার দরকার।' : 'পরবর্তী ধাপে সংশ্লিষ্ট অ্যাপ/অনুমতি উপলব্ধ কি না যাচাই করতে হবে।'}`, `Simulation preview: ${action}\n• No real action was executed.\n• ${unsafe ? 'This may involve a consequential/external action and requires explicit confirmation plus a supported handler.' : 'The next step must verify the required app and permission.'}`); }

  const failure = text.match(/^(?:log failure|record failure|ব্যর্থতা নোট করো|কমান্ড ব্যর্থতা)\s+(.+?)\s+(?:because|কারণ|:|—)\s*(.+)$/iu);
  if (failure) { s.failures.push({ at: Date.now(), command: failure[1].slice(0,160), reason: failure[2].slice(0,200) }); s.failures = s.failures.slice(-50); addAudit(s, failure[1], 'failure recorded'); await write(s); return reply(request, 'ব্যর্থতার কারণ লোকালি নথিভুক্ত হয়েছে।', 'Failure recorded locally.'); }
  if (/^(?:show failure patterns|ব্যর্থতার রিপোর্ট|ফেইলিউর রিপোর্ট)$/iu.test(n)) return reply(request, s.failures.length ? `সাম্প্রতিক ব্যর্থতা:\n${s.failures.slice(-15).reverse().map((x,i)=>`${i+1}. ${x.command} — ${x.reason}`).join('\n')}` : 'এখনো কোনো ব্যর্থতা নথিভুক্ত নেই।', s.failures.length ? `Recent failures:\n${s.failures.slice(-15).reverse().map((x,i)=>`${i+1}. ${x.command} — ${x.reason}`).join('\n')}` : 'No failures recorded.');
  if (/^(?:action audit|show action audit|অ্যাকশন লগ|কাজের লগ দেখাও)$/iu.test(n)) return reply(request, s.audit.length ? `সাম্প্রতিক লোকাল লগ:\n${s.audit.slice(-20).reverse().map((x,i)=>`${i+1}. ${new Date(x.at).toLocaleString()} — ${x.action}: ${x.result}`).join('\n')}` : 'এখনো কোনো লোকাল লগ নেই।', s.audit.length ? `Recent local audit:\n${s.audit.slice(-20).reverse().map((x,i)=>`${i+1}. ${new Date(x.at).toLocaleString()} — ${x.action}: ${x.result}`).join('\n')}` : 'No local audit entries yet.');

  if (/^(?:nextgen feature status|নেক্সটজেন ফিচার স্ট্যাটাস)$/iu.test(n)) return reply(request, `Next-Gen লোকাল মডিউল\n• শেখানো বাক্য: ${s.aliases.length}\n• ব্যর্থতার নথি: ${s.failures.length}\n• লোকাল অডিট এন্ট্রি: ${s.audit.length}\n• মেমোরি সীমা: ২০০ (অপরিবর্তিত)\n• এই মডিউলের নেটওয়ার্ক অনুরোধ: নেই`, `Next-Gen local module\n• Learned phrases: ${s.aliases.length}\n• Failure records: ${s.failures.length}\n• Local audit entries: ${s.audit.length}\n• Memory limit: 200 (unchanged)\n• Network requests in this module: none`, 'diagnostics');
  return null;
}

export const offlineNextGenExtension: AssistantExtension = { id: 'offline-nextgen-5.2', handle };
