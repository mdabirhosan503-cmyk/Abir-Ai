/** Abir AI 5.1 Modern Features Pack.
 * Local-first commands only. Existing extensions and localMemory.ts are intentionally untouched.
 * Android-only actions still require the relevant native module and user permission.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAssistantReply, type AssistantExtension, type AssistantReply, type AssistantRequest } from './offlineBrain';

const KEY = 'abir-ai-modern-features-v1';
type Entry = { id: string; text: string; at: number; done?: boolean };
type Shortcut = { phrase: string; command: string };
type Routine = { name: string; commands: string[] };
type State = { notes: Entry[]; tasks: Entry[]; shortcuts: Shortcut[]; routines: Routine[]; undo: Array<{ kind: 'note'|'task'; entry: Entry }> ; favorites: string[] };
const empty = (): State => ({ notes: [], tasks: [], shortcuts: [], routines: [], undo: [], favorites: [] });
const bn = (s: string) => /[\u0980-\u09ff]/u.test(s);
const norm = (s: string) => s.toLocaleLowerCase().replace(/[!?.,।:：]+/gu, ' ').replace(/\s+/gu, ' ').trim();
const answer = (request: AssistantRequest, bnText: string, enText: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: request.language === 'bn' || bn(request.text) ? bnText : enText, intent });
async function load(): Promise<State> {
  try {
    const raw = await AsyncStorage.getItem(KEY); const x = raw ? JSON.parse(raw) : {};
    return { notes: Array.isArray(x.notes) ? x.notes.slice(-200) : [], tasks: Array.isArray(x.tasks) ? x.tasks.slice(-200) : [], shortcuts: Array.isArray(x.shortcuts) ? x.shortcuts.slice(-100) : [], routines: Array.isArray(x.routines) ? x.routines.slice(-50) : [], undo: Array.isArray(x.undo) ? x.undo.slice(-20) : [], favorites: Array.isArray(x.favorites) ? x.favorites.slice(-30) : [] };
  } catch { return empty(); }
}
async function save(s: State) { await AsyncStorage.setItem(KEY, JSON.stringify({ ...s, notes:s.notes.slice(-200), tasks:s.tasks.slice(-200), shortcuts:s.shortcuts.slice(-100), routines:s.routines.slice(-50), undo:s.undo.slice(-20), favorites:s.favorites.slice(-30) })); }
async function loadLegacyLocalData(): Promise<{notes: Array<{text:string}>; tasks: Array<{text:string;done?:boolean}>}> {
  try { const raw=await AsyncStorage.getItem('abir-ai-offline-evolution-v1'); const x=raw?JSON.parse(raw):{}; return { notes:Array.isArray(x.notes)?x.notes.map((v:any)=>({text:String(v.body??'')})):[], tasks:Array.isArray(x.tasks)?x.tasks.map((v:any)=>({text:String(v.text??''),done:!!v.done})):[] }; } catch { return {notes:[],tasks:[]}; }
}
const entry = (text: string): Entry => ({ id: `${Date.now()}-${Math.random().toString(36).slice(2,7)}`, text: text.trim(), at: Date.now() });
const featureNames = [
  'Adaptive Smart Brain','Smart Local Memory (existing 200-item limit preserved)','Natural Voice Command','Multi-Step Action Planner','Personal Knowledge Vault','Context-Aware Replies','Smart Follow-up','Offline Mini AI Tools','Bangla Intent Engine','Command Confidence Check','Smart App Discovery','Routine Launcher','Clipboard Assistant (platform permission required)','Screenshot Explainer (image input required)','Smart Notification Summary (notification access required)','Local Reminder Engine','Focus Mode','Voice Notes to Tasks','Smart Duplicate Cleaner','Memory Importance Score (existing memory cap unchanged)','Explain My Answer','Offline Troubleshooter','Privacy Dashboard','Private Vault Lock (device authentication support)','Undo Last Action','Action Preview','Smart Search Everywhere','Personal Command Builder','Adaptive Interface','Offline Health Check'
] as const;

async function handle(request: AssistantRequest): Promise<AssistantReply | null> {
  const original = request.text.trim(); if (!original) return null;
  let raw = original, n = norm(raw); const s = await load();
  // User-defined local aliases: “shortcut add phrase => command”. Resolve only exact phrases.
  const aliasAdd = raw.match(/^(?:shortcut add|add shortcut|শর্টকাট যোগ|কমান্ড যোগ)\s+(.+?)\s*(?:=>|->|মানে|হবে)\s*(.+)$/iu);
  if (aliasAdd) {
    const phrase = norm(aliasAdd[1]), command = aliasAdd[2].trim();
    if (!phrase || !command) return answer(request, 'শর্টকাটের নাম ও কমান্ড দুটোই দিতে হবে।', 'Provide both a shortcut phrase and a command.');
    s.shortcuts = s.shortcuts.filter(x => norm(x.phrase) !== phrase); s.shortcuts.push({ phrase, command }); await save(s);
    return answer(request, `শর্টকাট সংরক্ষিত: “${phrase}” → “${command}”।`, `Shortcut saved: “${phrase}” → “${command}”.`);
  }
  const matched = s.shortcuts.find(x => norm(x.phrase) === n);
  if (matched) {
    const target = norm(matched.command);
    if (target === n || s.shortcuts.some(x => norm(x.phrase) === target)) return answer(request, 'শর্টকাটের মধ্যে লুপ/চেইন পাওয়া গেছে। অন্য একটি কমান্ড দিয়ে শর্টকাটটি আবার তৈরি করো।', 'This shortcut would create a loop/chain. Recreate it with a direct command.');
    return getAssistantReply({ ...request, text: matched.command });
  }

  const previewAction = raw.match(/^(?:preview action|action preview|কাজের প্রিভিউ|অ্যাকশন প্রিভিউ)\s+(.+)$/iu);
  if (previewAction) return answer(request, `কাজের প্রিভিউ (এখনো চালানো হয়নি):\n${previewAction[1].trim()}\n\nএই প্রিভিউ কোনো অ্যাপ খোলে না বা ডিভাইসে পরিবর্তন করে না।`, `Action preview (not executed):\n${previewAction[1].trim()}\n\nThis preview does not launch apps or change device settings.`, 'help');

  const routineSave = raw.match(/^(?:routine save|save routine|রুটিন সেভ|রুটিন বানাও)\s+([^:：]+)\s*[:：]\s*(.+)$/iu);
  if (routineSave) {
    const name = routineSave[1].trim(); const commands = routineSave[2].split(/\s*(?:\||;|, তারপর | তারপর )\s*/u).map(x=>x.trim()).filter(Boolean).slice(0,10);
    s.routines = s.routines.filter(x=>norm(x.name)!==norm(name)); s.routines.push({name,commands}); await save(s);
    return answer(request, `“${name}” রুটিনে ${commands.length}টি ধাপ সেভ হয়েছে। এখন “রুটিন দেখাও” বললে দেখতে পাবে।`, `Saved routine “${name}” with ${commands.length} steps. Say “show routines” to review it.`, 'routine');
  }
  if (/^(?:show routines|list routines|রুটিন দেখাও|আমার রুটিন)$/iu.test(n)) return answer(request, s.routines.length ? `সেভ করা রুটিন:\n${s.routines.map(r=>`• ${r.name}: ${r.commands.join(' → ')}`).join('\n')}` : 'এখনো কোনো রুটিন সেভ করা নেই।', s.routines.length ? `Saved routines:\n${s.routines.map(r=>`• ${r.name}: ${r.commands.join(' → ')}`).join('\n')}` : 'No saved routines yet.', 'routine');
  const routineRun = raw.match(/^(?:preview routine|run routine|রুটিন চালাও|রুটিন প্রিভিউ)\s+(.+)$/iu);
  if (routineRun) { const r=s.routines.find(x=>norm(x.name)===norm(routineRun[1])); return r ? answer(request, `রুটিন “${r.name}” চালানোর আগে ধাপগুলো দেখে নাও:\n${r.commands.map((c,i)=>`${i+1}. ${c}`).join('\n')}\n\nএই প্রিভিউ নিজে থেকে অ্যাপ/সিস্টেম অ্যাকশন চালায়নি।`, `Routine “${r.name}” preview:\n${r.commands.map((c,i)=>`${i+1}. ${c}`).join('\n')}\n\nPreview only; no app/system actions were executed.`, 'routine') : answer(request,'ওই নামে রুটিন পাওয়া যায়নি।','No routine found with that name.','routine'); }

  const note = raw.match(/^(?:note|save note|নোট|নোট রাখো|নোট লেখো)\s*[:：]?\s*(.+)$/iu);
  if (note) { const e=entry(note[1]); s.notes.push(e); s.undo.push({kind:'note',entry:e}); await save(s); return answer(request,`লোকাল নোটে সংরক্ষণ করেছি: ${e.text}`,`Saved locally: ${e.text}`,'notes'); }
  if (/^(?:show notes|list notes|নোট দেখাও|আমার নোট|নোটের তালিকা)$/iu.test(n)) return answer(request,s.notes.length?`লোকাল নোট (সর্বশেষ 20):\n${s.notes.slice(-20).reverse().map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'এখনো কোনো নোট নেই।',s.notes.length?`Local notes (latest 20):\n${s.notes.slice(-20).reverse().map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'No local notes yet.','notes');
  const noteSearch = raw.match(/^(?:search notes|find note|নোট খোঁজো|নোটে খুঁজো)\s+(.+)$/iu);
  if (noteSearch) { const q=norm(noteSearch[1]); const hits=s.notes.filter(x=>norm(x.text).includes(q)).slice(-10).reverse(); return answer(request,hits.length?`মিল পাওয়া নোট:\n${hits.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'মিল পাওয়া যায়নি।',hits.length?`Matching notes:\n${hits.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'No matching notes.','notes'); }
  const taskAdd = raw.match(/^(?:task|todo|কাজ যোগ|কাজ|করতে হবে)\s*[:：]?\s+(.+)$/iu);
  if (taskAdd) { const e=entry(taskAdd[1]); s.tasks.push(e); s.undo.push({kind:'task',entry:e}); await save(s); return answer(request,`কাজ যোগ হয়েছে: ${e.text}`,`Task added: ${e.text}`,'task-plan'); }
  if (/^(?:show tasks|list tasks|todo list|কাজের তালিকা|আমার কাজগুলো|pending tasks)$/iu.test(n)) { const a=s.tasks.filter(x=>!x.done).slice(-25); return answer(request,a.length?`অসমাপ্ত কাজ:\n${a.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'এখন কোনো অসমাপ্ত কাজ নেই।',a.length?`Pending tasks:\n${a.map((x,i)=>`${i+1}. ${x.text}`).join('\n')}`:'No pending tasks.','task-plan'); }
  const taskDone=raw.match(/^(?:complete task|finish task|কাজ শেষ|কাজ সম্পন্ন)\s*(\d+)$/iu);
  if(taskDone){const a=s.tasks.filter(x=>!x.done);const i=Number(taskDone[1])-1;if(!a[i])return answer(request,'ওই নম্বরের অসমাপ্ত কাজ পাওয়া যায়নি।','No pending task with that number.','task-plan');a[i].done=true;await save(s);return answer(request,`কাজ সম্পন্ন: ${a[i].text}`,`Completed: ${a[i].text}`,'task-plan');}
  const searchAll=raw.match(/^(?:search everything|global search|সব খোঁজো|সব জায়গায় খোঁজো|লোকাল সার্চ)\s+(.+)$/iu);
  if(searchAll){const q=norm(searchAll[1]);const legacy=await loadLegacyLocalData();const results=[...s.notes.filter(x=>norm(x.text).includes(q)).map(x=>`নোট: ${x.text}`),...legacy.notes.filter(x=>norm(x.text).includes(q)).map(x=>`নোট: ${x.text}`),...s.tasks.filter(x=>norm(x.text).includes(q)).map(x=>`কাজ${x.done?' (সম্পন্ন)':''}: ${x.text}`),...legacy.tasks.filter(x=>norm(x.text).includes(q)).map(x=>`কাজ${x.done?' (সম্পন্ন)':''}: ${x.text}`),...s.shortcuts.filter(x=>norm(x.phrase).includes(q)||norm(x.command).includes(q)).map(x=>`শর্টকাট: ${x.phrase} → ${x.command}`)];return answer(request,results.length?`লোকাল সার্চ ফলাফল:\n${results.slice(0,20).join('\n')}`:'লোকাল ডেটায় কিছু পাওয়া যায়নি।',results.length?`Local search results:\n${results.slice(0,20).join('\n')}`:'Nothing found in local data.','notes');}
  if (/^(?:clean duplicate notes|remove duplicate notes|ডুপ্লিকেট নোট খোঁজো|নোটের ডুপ্লিকেট দেখাও)$/iu.test(n)) { const seen=new Set<string>(), dup:string[]=[]; for(const x of s.notes){const k=norm(x.text);if(seen.has(k))dup.push(x.text);else seen.add(k);} return answer(request,dup.length?`একই ধরনের ${dup.length}টি ডুপ্লিকেট নোট পাওয়া গেছে (কিছুই মুছে ফেলা হয়নি):\n${dup.slice(0,15).join('\n')}`:'ডুপ্লিকেট নোট পাওয়া যায়নি।',dup.length?`Found ${dup.length} duplicate notes (nothing deleted):\n${dup.slice(0,15).join('\n')}`:'No duplicate notes found.','notes'); }
  if (/^(?:undo|undo last action|শেষ কাজ ফিরিয়ে দাও|আগের কাজ ফিরিয়ে দাও|আনডু)$/iu.test(n)) { const last=s.undo.pop(); if(!last)return answer(request,'ফিরিয়ে আনার মতো কোনো সাম্প্রতিক নোট/কাজ নেই।','There is no recent note/task creation to undo.','undo'); if(last.kind==='note')s.notes=s.notes.filter(x=>x.id!==last.entry.id);else s.tasks=s.tasks.filter(x=>x.id!==last.entry.id); await save(s); return answer(request,`শেষ ${last.kind==='note'?'নোট':'কাজ'} তৈরির কাজটি ফিরিয়ে নেওয়া হয়েছে।`,`Undid the last ${last.kind} creation.`,'undo'); }
  const stats=raw.match(/^(?:text stats|text statistics|টেক্সট স্ট্যাটস|লেখার পরিসংখ্যান)\s*[:：]\s*(.+)$/iu);
  if(stats){const t=stats[1],words=t.trim()?t.trim().split(/\s+/u).length:0,sent=(t.match(/[.!?।]+/gu)||[]).length;return answer(request,`অক্ষর: ${Array.from(t).length}\nশব্দ: ${words}\nবাক্যচিহ্ন: ${sent}`,`Characters: ${Array.from(t).length}\nWords: ${words}\nSentence marks: ${sent}`,'text-analysis');}
  const focus=raw.match(/^(?:focus plan|ফোকাস প্ল্যান|পড়াশোনা মোড|পড়াশোনা মোড)\s*(\d+)?$/iu);
  if(focus){const minutes=Math.max(1,Math.min(180,Number(focus[1]||25)));return answer(request,`ফোকাস সেশন প্রস্তুত: ${minutes} মিনিট।\n১. একটি কাজ বেছে নাও\n২. নোট/কাজের তালিকা খোলো\n৩. ডিভাইসের Clock অ্যাপে ${minutes} মিনিটের টাইমার সেট করো\n\nএই কমান্ড নিজে থেকে ব্যাকগ্রাউন্ড টাইমার চালু করেনি।`,`Focus session prepared: ${minutes} minutes.\n1. Choose one task\n2. Open your notes/task list\n3. Set a ${minutes}-minute timer in the Clock app\n\nThis command does not start a background timer itself.`,'task-plan');}
  if(/^(?:privacy dashboard|privacy status|গোপনীয়তা ড্যাশবোর্ড|প্রাইভেসি স্ট্যাটাস)$/iu.test(n)) return answer(request,`লোকাল প্রাইভেসি স্ট্যাটাস\n• এই Modern Features মডিউলের ডেটা AsyncStorage-এ লোকালি থাকে।\n• নোট/কাজ/শর্টকাট/রুটিন: আলাদা লোকাল স্টোরেজ।\n• এই মডিউল নিজে কোনো নেটওয়ার্ক রিকোয়েস্ট করে না।\n• Android permission আলাদা Settings থেকে যাচাই করতে হবে।`,`Local privacy status\n• This Modern Features module stores data in local AsyncStorage.\n• Notes/tasks/shortcuts/routines use separate local storage.\n• This module itself makes no network requests.\n• Android permissions must be reviewed separately in Settings.`,'diagnostics');
  if(/^(?:offline health check|self test|অফলাইন হেলথ চেক|সেলফ টেস্ট|নিজেকে পরীক্ষা করো)$/iu.test(n)) return answer(request,`Abir AI লোকাল হেলথ চেক\n• Modern feature storage: ${s.notes.length} নোট, ${s.tasks.length} কাজ, ${s.shortcuts.length} শর্টকাট, ${s.routines.length} রুটিন\n• Undo history: ${s.undo.length}\n• Storage read: সফল\n• নেটওয়ার্ক কল: এই মডিউলে নেই\n• Android-only সুবিধা: সংশ্লিষ্ট অনুমতি/নেটিভ মডিউল থাকলে তবেই কাজ করবে।`,`Abir AI local health check\n• Modern feature storage: ${s.notes.length} notes, ${s.tasks.length} tasks, ${s.shortcuts.length} shortcuts, ${s.routines.length} routines\n• Undo history: ${s.undo.length}\n• Storage read: successful\n• Network calls: none in this module\n• Android-only features require the corresponding permission/native module.`,'diagnostics');
  if(/^(?:explain answer|why this answer|উত্তর ব্যাখ্যা|কেন এই উত্তর)$/iu.test(n)) return answer(request,'এই উত্তরের ভিত্তি যাচাই করতে নির্দিষ্ট প্রশ্ন/উত্তরটি পাঠাও। Abir তখন উপলব্ধ লোকাল তথ্য ও সীমাবদ্ধতা আলাদা করে ব্যাখ্যা করতে পারবে।','Send the specific question/answer to explain its basis. Abir can then separate available local evidence from limitations.');
  if(/^(?:feature status|show modern features|ফিচার স্ট্যাটাস|মডার্ন ফিচার দেখাও)$/iu.test(n)) return answer(request,`Abir AI Modern Pack\n${featureNames.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nনোট: তালিকার কিছু ফিচার কমান্ড/লোকাল লজিক হিসেবে আছে; ক্লিপবোর্ড, স্ক্রিনশট/OCR, নোটিফিকেশন, বায়োমেট্রিক ও ব্যাকগ্রাউন্ড অটোমেশনের মতো সুবিধা ডিভাইস-অনুমতি বা আলাদা নেটিভ ইন্টিগ্রেশন চাইতে পারে।`,`Abir AI Modern Pack\n${featureNames.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nNote: Some capabilities are command/local-logic support; clipboard, screenshot/OCR, notifications, biometrics, and background automation may require device permissions or separate native integration.`,'help');
  if (/^(?:local data status|workspace status|লোকাল ডাটা স্ট্যাটাস|ওয়ার্কস্পেস স্ট্যাটাস)$/iu.test(n)) return answer(request,`Abir Modern Workspace\n• নোট: ${s.notes.length}\n• অসমাপ্ত কাজ: ${s.tasks.filter(x=>!x.done).length}\n• সম্পন্ন কাজ: ${s.tasks.filter(x=>x.done).length}\n• শর্টকাট: ${s.shortcuts.length}\n• রুটিন: ${s.routines.length}\n• Existing remembered-facts limit: 200 (unchanged)`,`Abir Modern Workspace\n• Notes: ${s.notes.length}\n• Pending tasks: ${s.tasks.filter(x=>!x.done).length}\n• Completed tasks: ${s.tasks.filter(x=>x.done).length}\n• Shortcuts: ${s.shortcuts.length}\n• Routines: ${s.routines.length}\n• Existing remembered-facts limit: 200 (unchanged)`,'diagnostics');
  return null;
}

export const MODERN_FEATURES = featureNames;
export const offlineModernFeaturesExtension: AssistantExtension = { id: 'offline-modern-features-5.1', handle };
