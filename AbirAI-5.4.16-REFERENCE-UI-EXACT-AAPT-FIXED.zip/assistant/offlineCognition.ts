/** Lightweight, fully local reasoning helpers. These are deterministic heuristics, not an LLM. */
const STOP = new Set(['এবং','তারপর','করে','করো','করতে','আমার','তুমি','আমি','একটা','একটি','এই','ওই','যে','কি','কী','হবে','হলো','হয়','হয়','দাও','দিয়ে','দিয়ে','the','and','then','please','can','you','my','me','for','to','a','an','is','are','of','in','on','with','it','this','that','do','make','help']);
export function localTokens(text: string): string[] {
  return text.normalize('NFKC').toLocaleLowerCase().match(/[\p{L}\p{N}]+/gu)?.filter(t => t.length > 1 && !STOP.has(t)) ?? [];
}
export function localSimilarity(query: string, candidate: string): number {
  const q = new Set(localTokens(query));
  const c = new Set(localTokens(candidate));
  if (!q.size || !c.size) return 0;
  let common = 0;
  for (const token of q) if (c.has(token)) common++;
  // Dice coefficient rewards useful overlap without requiring exact wording.
  return (2 * common) / (q.size + c.size);
}
export function rankLocalCandidates<T>(query: string, items: T[], getText: (item: T) => string, limit = 5): T[] {
  return items.map((item, index) => ({ item, index, score: localSimilarity(query, getText(item)) }))
    .filter(x => x.score >= 0.12).sort((a, b) => b.score - a.score || b.index - a.index).slice(0, limit).map(x => x.item);
}
export type PlannedStep = { task: string; dependency: string | null; risk: 'low' | 'medium' | 'high'; reversible: boolean };
export function buildGoalPlan(text: string): PlannedStep[] {
  const pieces = text.normalize('NFKC').split(/\s*(?:এবং তারপর|তারপর|এরপর|পরে|এবং|and then|then|after that|next|, then|;|\n)\s*/iu)
    .map(s => s.trim().replace(/^(?:দয়া করে|দয়া করে|please)\s+/iu, '').replace(/[।.!]+$/u, '').trim()).filter(Boolean).slice(0, 8);
  return pieces.map((task, i) => {
    const t = task.toLocaleLowerCase();
    const high = /(?:delete|মুছে|ডিলিট|factory reset|রিসেট|send|পাঠিয়ে|পাঠিয়ে|pay|পেমেন্ট|কল করো|call |purchase|কিনে)/iu.test(t);
    const medium = /(?:setting|সেটিংস|permission|অনুমতি|wifi|bluetooth|install|ইনস্টল|uninstall|আনইনস্টল|share|শেয়ার|শেয়ার)/iu.test(t);
    return { task, dependency: i ? pieces[i - 1] : null, risk: high ? 'high' : medium ? 'medium' : 'low', reversible: !high && !/(?:delete|মুছে|factory reset|payment|পেমেন্ট|send|পাঠিয়ে|পাঠিয়ে)/iu.test(t) };
  });
}
export function diagnoseLocalFailure(text: string, context: Array<{ role: 'user' | 'assistant'; text: string }> = []): string[] {
  const t = text.toLocaleLowerCase();
  const tips: string[] = [];
  if (/(?:খুলছে না|খুলতে পারছি না|open failed|couldn.t open|app not found|পাওয়া যাচ্ছে না|পাওয়া যাচ্ছে না)/iu.test(t)) {
    tips.push('অ্যাপটি ইনস্টল আছে কি না এবং Android-এ launchable activity আছে কি না দেখো।');
    tips.push('একই নামের একাধিক অ্যাপ থাকলে নির্দিষ্ট অ্যাপের নাম বলো।');
  }
  if (/(?:ভয়েস|ভয়েস|মাইক্রোফোন|voice|speech|recognition)/iu.test(t)) {
    tips.push('Microphone permission, Android Speech Services এবং প্রয়োজনীয় ভাষার offline speech pack পরীক্ষা করো।');
  }
  if (/(?:ইন্টারনেট|network|offline|নেটওয়ার্ক|নেটওয়ার্ক)/iu.test(t)) {
    tips.push('Offline কাজের জন্য লোকাল ব্যবস্থা বেছে নাও; online কাজের জন্য নেটওয়ার্ক ও API configuration যাচাই করো।');
  }
  if (/(?:কাজ করে না|ব্যর্থ|failed|error|হয়নি|হয়নি)/iu.test(t)) {
    tips.push('একবারে একটি ছোট কমান্ড দিয়ে পুনরায় পরীক্ষা করো এবং ফলাফল নিশ্চিত না হওয়া পর্যন্ত সফল ধরে নিও না।');
  }
  const latestAssistant = [...context].reverse().find(x => x.role === 'assistant')?.text;
  if (latestAssistant && tips.length) tips.push(`সাম্প্রতিক উত্তরের অংশ: “${latestAssistant.replace(/\s+/g, ' ').slice(0, 100)}”`);
  return [...new Set(tips)].slice(0, 5);
}
export function previewRisk(text: string): { level: 'low' | 'medium' | 'high'; reasons: string[] } {
  const t = text.toLocaleLowerCase();
  const reasons: string[] = [];
  if (/(?:delete|মুছে|ডিলিট|factory reset|ফ্যাক্টরি রিসেট|send|পাঠিয়ে|পাঠিয়ে|pay|পেমেন্ট|purchase|কিনে|কল করো|call )/iu.test(t)) reasons.push('ডেটা মুছতে, যোগাযোগ করতে বা অর্থ ব্যয় করতে পারে—আগে নিশ্চিতকরণ দরকার।');
  if (/(?:permission|অনুমতি|accessibility|অ্যাক্সেসিবিলিটি|install|ইনস্টল|uninstall|আনইনস্টল|settings|সেটিংস)/iu.test(t)) reasons.push('সিস্টেম সেটিংস বা অনুমতি বদলাতে পারে; প্রয়োজনীয় অনুমতি ছাড়া চালানো যাবে না।');
  if (reasons.some(x => /ডেটা মুছতে/.test(x))) return { level: 'high', reasons };
  if (reasons.length) return { level: 'medium', reasons };
  return { level: 'low', reasons: ['চিহ্নিত উচ্চ-ঝুঁকির শব্দ পাওয়া যায়নি; তবুও বাস্তব কাজের আগে ফল যাচাই করো।'] };
}
export function summarizeLocalContext(context: Array<{ role: 'user' | 'assistant'; text: string }> = [], limit = 6): string[] {
  return context.filter(x => x.text.trim()).slice(-limit).map(x => `${x.role === 'user' ? 'তুমি' : 'আবির'}: ${x.text.replace(/\s+/g, ' ').slice(0, 160)}`);
}
