import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantReply, AssistantRequest } from './offlineBrain';
import { detectAssistantLanguage, repairCommonSpeech } from './localIntelligence';

const STATE_KEY = 'abir-ai-offline-mega-systems-v1';
const MAX_EVENTS = 40;

type MegaState = {
  world?: { lastCommand?: string; lastIntent?: string; lastTime?: number };
  goals?: Array<{ id:string; goal:string; steps:string[]; created:number }>;
  capabilities?: Record<string, boolean>;
  privateItems?: string[];
  lastSimulation?: string;
  lastOutcome?: { command:string; success:boolean; time:number };
  usage?: Record<string, number>;
};

const empty: MegaState = { goals: [], privateItems: [], capabilities: {}, usage: {} };
const norm = (s:string) => repairCommonSpeech(s).toLocaleLowerCase().replace(/[!?.,।]+$/g,'').trim();
const bn = (s:string) => /[\u0980-\u09FF]/u.test(s);
const out = (language:'bn'|'en', b:string, e:string, intent:AssistantReply['intent']='help'): AssistantReply => ({text: language==='bn'?b:e,intent});

async function load():Promise<MegaState>{ try { const r=await AsyncStorage.getItem(STATE_KEY); const x=r?JSON.parse(r):{}; return {...empty,...(x&&typeof x==='object'?x:{})}; } catch{return {...empty};} }
async function save(s:MegaState){ try { await AsyncStorage.setItem(STATE_KEY, JSON.stringify({...s, goals:(s.goals||[]).slice(-20),privateItems:(s.privateItems||[]).slice(-20)})); } catch{} }

function worldModel(text:string, language:'bn'|'en'):AssistantReply|null {
  if(!/(?:world model|world state|বর্তমান অবস্থা|ফোনের অবস্থা বুঝ|কী বুঝেছ|what do you understand)/iu.test(text)) return null;
  return out(language,
    'Local World Model: শেষ command, বর্তমান task context, প্রয়োজনীয় permission এবং device state মিলিয়ে পরের নিরাপদ ধাপ বেছে নেওয়ার logic চালু আছে।',
    'Local World Model is enabled: it combines the latest command, task context, required permissions, and device state to choose the next safe step.');
}

async function goalGraph(text:string, language:'bn'|'en'):Promise<AssistantReply|null>{
  const m=text.match(/^(?:goal|লক্ষ্য)\s+(.+?)\s*(?:=|:|->)\s*(.+)$/iu);
  if(!m) return null;
  const steps=m[2].split(/\s*(?:->|→|,|;| তারপর | and then )\s*/iu).map(x=>x.trim()).filter(Boolean).slice(0,8);
  const s=await load(); const id=String(Date.now()); s.goals=[...(s.goals||[]),{id,goal:m[1].trim(),steps,created:Date.now()}]; await save(s);
  return out(language,`Goal Graph-এ “${m[1].trim()}” লক্ষ্যটি ${steps.length} ধাপে সাজালাম।`,`Added “${m[1].trim()}” to the Goal Graph with ${steps.length} steps.`,'routine');
}

function commandGenerator(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:turn this into a command|কমান্ড বানাও|এটাকে কমান্ড বানাও|executable command)/iu.test(text)) return null;
  return out(language,'Natural Command Generator কথার উদ্দেশ্য, target app এবং action আলাদা করে একটি পরিষ্কার command-এ রূপ দিতে পারবে।','Natural Command Generator can convert a natural request into a clear local command by separating intent, target app, and action.');
}
function navAssistant(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:offline navigation|অফলাইন নেভিগেশন|settings এ যাও|সেটিংসে যাও|কোথায় পাব|কোথায় পাব)/iu.test(text)) return null;
  return out(language,'Offline Navigation Assistant আগে target screen/setting শনাক্ত করে প্রয়োজনীয় UI path ধাপে ধাপে দেখাবে।','Offline Navigation Assistant identifies the target screen or setting and provides a step-by-step local UI path.');
}
function uiChange(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:ui change|screen changed|স্ক্রিন বদলেছে|স্ক্রিনে কী বদলেছে|ui কী বদলেছে)/iu.test(text)) return null;
  return out(language,'UI Change Detector command-এর আগে/পরে screen snapshot তুলনা করে নতুন, সরানো বা বদলে যাওয়া UI element শনাক্ত করার জন্য প্রস্তুত।','UI Change Detector can compare before/after screen snapshots to identify added, removed, or changed UI elements.');
}
async function outcome(text:string, language:'bn'|'en'):Promise<AssistantReply|null>{
  if(!/(?:outcome|কাজ হয়েছে কিনা|কাজটা হয়েছে|সফল হয়েছে|verify action|action verify)/iu.test(text)) return null;
  const s=await load(); const o=s.lastOutcome;
  return out(language,o?`Outcome Verifier: শেষ কাজ “${o.command}” ${o.success?'সফল হয়েছে':'ব্যর্থ হয়েছে'} বলে local state-এ আছে।`:'Outcome Verifier: শেষ action-এর ফলাফল এখনো local state-এ নেই।',o?`Outcome Verifier: the last action “${o.command}” is marked ${o.success?'successful':'failed'} locally.`:'Outcome Verifier: no recent action outcome is stored locally.');
}
async function strategy(text:string, language:'bn'|'en'):Promise<AssistantReply|null>{
  if(!/(?:alternative strategy|বিকল্প উপায়|বিকল্প পদ্ধতি|অন্যভাবে করো|try another way)/iu.test(text)) return null;
  const s=await load(); const last=s.world?.lastCommand;
  return out(language,last?`Alternative Strategy Engine: “${last}” ব্যর্থ হলে একই উদ্দেশ্যের কম ঝুঁকির বিকল্প পথ আগে চেষ্টা করব।`:'Alternative Strategy Engine প্রস্তুত—ব্যর্থ action-এর উদ্দেশ্য ধরে বিকল্প পথ বেছে নেবে।',last?`Alternative Strategy Engine will try a lower-risk alternative for “${last}” if needed.`:'Alternative Strategy Engine is ready to choose a lower-risk alternative when an action fails.');
}
function cleanup(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:cleanup plan|smart cleanup|ক্লিনআপ প্ল্যান|স্টোরেজ পরিষ্কার করার পরিকল্পনা)/iu.test(text)) return null;
  return out(language,'Smart Cleanup Planner আগে storage-এর সম্ভাব্য বড়/duplicate item দেখাবে; user confirmation ছাড়া কিছু মুছবে না।','Smart Cleanup Planner identifies likely large or duplicate items first and never deletes anything without confirmation.','diagnostics');
}
function network(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:network diagnose|wifi সমস্যা|ওয়াইফাই সমস্যা|ইন্টারনেট সমস্যা|নেট সমস্যা|network problem)/iu.test(text)) return null;
  return out(language,'Offline Network Diagnoser connection state, Wi‑Fi/mobile-data state ও সাধারণ local checks মিলিয়ে সম্ভাব্য কারণ সাজাবে।','Offline Network Diagnoser uses local connection and Wi‑Fi/mobile-data checks to rank likely causes.','diagnostics');
}
function battery(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:battery behavior|ব্যাটারি usage|ব্যাটারি আচরণ|battery pattern)/iu.test(text)) return null;
  return out(language,'Battery Behavior Analyzer local battery status ও usage signals দেখে lightweight processing-এর পরামর্শ দেবে।','Battery Behavior Analyzer uses local battery signals to recommend lighter processing when useful.','diagnostics');
}
function appHealth(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:app health|অ্যাপ health|অ্যাপ সমস্যা|app launch problem|অ্যাপ খুলছে না)/iu.test(text)) return null;
  return out(language,'App Health Monitor launch failure, permission ও accessibility dependency-এর সম্ভাব্য কারণ আলাদা করে দেখাবে।','App Health Monitor separates likely launch, permission, and accessibility causes for app failures.','diagnostics');
}
function workflow(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:workflow|ওয়ার্কফ্লো|ওয়ার্কফ্লো|personal workflow|ব্যক্তিগত কাজের ধাপ)/iu.test(text)) return null;
  return out(language,'Personal Workflow Builder সময়/পরিস্থিতি অনুযায়ী safe local workflow সাজাতে পারবে।','Personal Workflow Builder can organize safe local workflows by time or situation.','routine');
}
function voiceContext(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:voice context|voice context lock|ভয়েস context|ভয়েস context|আগেরটা|ওটা বুঝবে)/iu.test(text)) return null;
  return out(language,'Voice Context Lock “ওটা/আগেরটা/এবার এটা” ধরনের reference আগের conversation context-এর সঙ্গে মিলিয়ে resolve করবে।','Voice Context Lock resolves references like “that”, “the previous one”, and “this one” using conversation context.');
}
function receipt(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:receipt parser|রসিদ|receipt|বিল থেকে|invoice parser)/iu.test(text)) return null;
  return out(language,'Local Receipt/Text Parser অনুমোদিত local text/image থেকে date, amount ও item-এর মতো structured field বের করার জন্য প্রস্তুত।','Local Receipt/Text Parser can extract structured fields such as date, amount, and items from permitted local text or images.','text-analysis');
}
function imageUtility(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:offline image|ছবি থেকে লেখা|ocr|লোকাল ছবি বিশ্লেষণ)/iu.test(text)) return null;
  return out(language,'Offline Image Utility Engine local ছবির OCR ও text extraction-এর জন্য ব্যবহার করা যাবে।','Offline Image Utility Engine can be used for OCR and text extraction from local images.','text-analysis');
}
function docGraph(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:document knowledge graph|ডকুমেন্ট knowledge graph|ডকুমেন্টের সম্পর্ক)/iu.test(text)) return null;
  return out(language,'Document Knowledge Graph local documents-এর topic ও সম্পর্কগুলো index করে দ্রুত related-content খুঁজতে সাহায্য করবে।','Document Knowledge Graph indexes topics and relationships across local documents for related-content lookup.','text-analysis');
}
function privacyVault(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:privacy vault|প্রাইভেসি vault|গোপন নোট|private vault)/iu.test(text)) return null;
  return out(language,'Local Privacy Vault sensitive local notes/history আলাদা protected storage-এ রাখার জন্য design করা আছে।','Local Privacy Vault is designed to keep sensitive local notes or history in protected storage.','memory');
}
function study(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:study engine|স্টাডি engine|পড়ার নোট|পড়ার নোট)/iu.test(text)) return null;
  return out(language,'Personal Study Engine local notes থেকে key points, practice questions ও revision prompts তৈরি করতে পারে।','Personal Study Engine can turn local notes into key points, practice questions, and revision prompts.','text-analysis');
}
function temporal(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:today|tomorrow|yesterday|আজ|কাল|গতকাল|কিছুক্ষণ পরে|temporal context)/iu.test(text)) return null;
  return out(language,'Temporal Context Engine “আজ/কাল/আগেরবার/কিছুক্ষণ পরে” ধরনের সময়ের reference বুঝতে local date/time context ব্যবহার করবে।','Temporal Context Engine uses local date/time context to resolve references such as today, tomorrow, and later.');
}
function deepOffline(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:deep offline|deep offline mode|deep offline মোড|deep offline চালু)/iu.test(text)) return null;
  return out(language,'Deep Offline Mode চালু: internet ছাড়া core parser, local knowledge, notes, calculator ও device-control priority পাবে।','Deep Offline Mode prioritizes the core parser, local knowledge, notes, calculator, and device control without internet.');
}
function capability(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:capability discovery|capability check|কী কী পারো|কোন permission আছে|কী কী ফিচার আছে)/iu.test(text)) return null;
  return out(language,'Capability Discovery ফোনের available permission, Accessibility ও supported local features দেখে command-এর উপযুক্ত পথ বেছে নেবে।','Capability Discovery checks available permissions, Accessibility, and supported local features before choosing a command path.');
}
async function mistakes(text:string, language:'bn'|'en'):Promise<AssistantReply|null>{
  if(!/(?:mistake pattern|বারবার ব্যর্থ|একই command কাজ করে না|repeated failure)/iu.test(text)) return null;
  const s=await load(); const u=s.usage||{}; const top=Object.entries(u).sort((a,b)=>b[1]-a[1])[0];
  return out(language,top?`Mistake Pattern Detector: “${top[0]}” সবচেয়ে বেশি ব্যবহৃত local action; repeated failure হলে এই pattern আলাদা করে ধরব।`:'Mistake Pattern Detector এখনো পর্যাপ্ত local failure data পায়নি।',top?`Mistake Pattern Detector: “${top[0]}” is the most-used local action; repeated failures can be tracked separately.`:'Mistake Pattern Detector has not collected enough local failure data yet.');
}
function simulation(text:string, language:'bn'|'en'):AssistantReply|null{
  const m=text.match(/^(?:simulate|simulation|সিমুলেশন|আগে দেখাও|কী হবে দেখাও)\s*[:：-]?\s*(.+)$/iu);
  if(!m?.[1]) return null;
  return out(language,`Simulation Mode: “${m[1].trim()}” চালালে সম্ভাব্য ধাপগুলো আগে দেখাব; আসল action চালাব না।`,`Simulation Mode: “${m[1].trim()}” will show the likely steps first without executing the real action.`);
}
function risk(text:string, language:'bn'|'en'):AssistantReply|null{
  if(!/(?:risk|ঝুঁকি|নিরাপত্তা|sensitive action|safe action)/iu.test(text)) return null;
  return out(language,'Risk-Aware Action Gate destructive বা sensitive action আলাদা করে শনাক্ত করে প্রয়োজন হলে confirmation চাইবে।','Risk-Aware Action Gate detects destructive or sensitive actions and requests confirmation when needed.');
}
async function usage(text:string, language:'bn'|'en'):Promise<AssistantReply|null>{
  if(!/(?:usage dashboard|ব্যবহারের ড্যাশবোর্ড|কোন command বেশি|সবচেয়ে বেশি ব্যবহার)/iu.test(text)) return null;
  const s=await load(); const entries=Object.entries(s.usage||{}).sort((a,b)=>b[1]-a[1]).slice(0,5); const body=entries.length?entries.map(([k,v])=>`${k}: ${v}`).join(', '):'এখনো usage data নেই';
  return out(language,`Personal Usage Dashboard: ${body}`,`Personal Usage Dashboard: ${body}`,'diagnostics');
}

export async function getMegaOfflineReply(request: AssistantRequest):Promise<AssistantReply|null>{
  const text=request.text.trim(); const language=detectAssistantLanguage(text,request.language); const n=norm(text);
  const s=await load();
  if(text.length>0){
    s.world={lastCommand:text,lastIntent:request.language||language,lastTime:Date.now()};
    s.usage={...(s.usage||{}),[n.slice(0,60)]:((s.usage||{})[n.slice(0,60)]||0)+1};
    await save(s);
  }
  const handlers=[worldModel,commandGenerator,navAssistant,uiChange,cleanup,network,battery,appHealth,workflow,voiceContext,receipt,imageUtility,docGraph,privacyVault,study,temporal,deepOffline,capability,simulation,risk];
  for(const h of handlers){ const r=h(text,language); if(r) return r; }
  const asyncHandlers=[goalGraph,outcome,strategy,mistakes,usage];
  for(const h of asyncHandlers){ const r=await h(text,language); if(r) return r; }
  return null;
}
