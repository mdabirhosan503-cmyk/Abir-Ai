/**
 * Abir AI 4.19 Offline Ultimate Pack
 *
 * Additive, offline-first control layer. Features that require an Android API or
 * a local ML model are exposed as capability-aware states instead of pretending
 * they are available. No network calls are made here.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AssistantExtension, AssistantReply, AssistantRequest } from './offlineBrain';
import { planOfflineTasks, analyzeOfflineText } from './offlinePlus';

const STATE_KEY = 'abir-ai-offline-ultimate-v1';
const MAX_AUDIT = 100;

type Mode = 'fast' | 'deep' | 'safe' | 'offline' | 'learning' | 'silent' | 'normal';
type UltimateState = {
  mode: Mode;
  privateMode: boolean;
  habits: Array<{ name: string; count: number; updatedAt: number }>;
  tasks: Array<{ id: string; text: string; done: boolean; createdAt: number }>;
  macros: Array<{ phrase: string; command: string; uses: number }>;
  audit: Array<{ command: string; time: number; result: string }>;
  customData: Record<string, string>;
};

const DEFAULT_STATE: UltimateState = { mode: 'normal', privateMode: false, habits: [], tasks: [], macros: [], audit: [], customData: {} };

async function loadState(): Promise<UltimateState> {
  try {
    const raw = await AsyncStorage.getItem(STATE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return { ...DEFAULT_STATE, ...(parsed && typeof parsed === 'object' ? parsed : {}) };
  } catch { return { ...DEFAULT_STATE }; }
}
async function saveState(state: UltimateState) {
  try { await AsyncStorage.setItem(STATE_KEY, JSON.stringify({ ...state, audit: state.audit.slice(-MAX_AUDIT), tasks: state.tasks.slice(-100), habits: state.habits.slice(-50), macros: state.macros.slice(-50) })); } catch {}
}
const isBn = (s: string) => /[\u0980-\u09FF]/u.test(s);
const reply = (language: 'bn'|'en', bn: string, en: string, intent: AssistantReply['intent'] = 'help'): AssistantReply => ({ text: language === 'bn' ? bn : en, intent });
const norm = (s: string) => s.toLocaleLowerCase().replace(/[!?.,।]+/gu, ' ').replace(/\s+/gu, ' ').trim();

export const OFFLINE_ULTIMATE_FEATURES = [
  'Local Brain','Bangla Reasoning','Banglish Understanding','Context Memory','Conversation Summarizer','Semantic Local Memory','Preference Learning','Intent Confidence','Follow-up Resolution','Typo/Speech Repair',
  'Offline Voice Layer','Offline Bengali ASR','Offline English ASR','Bangla-English Mixed ASR','Wake Word','Voice Activity Detection','Noise Filtering','Voice Interruption','Offline TTS','Voice Profiles',
  'Phone Control','App Launcher','App Search','Settings Navigation','Wi-Fi/Bluetooth Controls','Flashlight','Volume','Brightness','Media','Notifications','Screenshot','Back/Home/Recents','Accessibility Action Planner','Multi-step Action Queue',
  'Automation Engine','Scheduled Routines','Conditional Routines','Battery Triggers','Charging Triggers','Network Triggers','App Triggers','Notification Triggers','Routine Templates','Retry/Recovery','Undo Planner','Action Preview',
  'Knowledge Vault','Local TXT/PDF Search','Local Notes Search','Document Index','Document Q&A','Grounded Summaries','Keyword Extraction','Duplicate Detection','Local Knowledge Graph','Personal Knowledge Graph',
  'Bengali Dictionary','English Dictionary','Synonyms','Antonyms','Spelling Helper','Grammar Helper','Transliteration','Offline Phrasebook',
  'Reminders','Recurring Reminders','Tasks','Checklists','Habits','Deadlines','Priority Ranking','Morning Routine','Night Routine','Study Planner',
  'Memory Search','Memory Importance','Memory Forget/Update','Private Mode','Memory Export','Local Data Audit','No-cloud Mode','Sensitive Data Filter','Encrypted Storage Adapter',
  'Math Engine','Equation Solver','Formula Helper','Unit Converter','Calculator','Static Code Analyzer','Code Security Checks','Quiz Generator','Flashcards','Revision Planner',
  'Diagnostics','Self Test','Capability Inspector','Permission Guidance','Battery Monitor','RAM/Storage Guidance','Network Diagnoser','App Health Monitor','Feature Dependency Inspector','Offline Benchmark Lab',
  'Safe Mode','Fast Mode','Deep Mode','Silent Mode','Learning Mode','Custom Commands','Command Macros','Frequently Used Commands','Adaptive Responses','Decision Assistant','Troubleshooter','Workflow Builder',
  'OCR Capability Adapter','Image Analysis Capability Adapter','Document Scanner Capability Adapter','Offline Navigation Capability Adapter','Local Places Database Adapter','Model Manager Adapter','Sandbox Adapter',
] as const;

function featureStatus(name: string): 'READY'|'ANDROID'|'MODEL_REQUIRED'|'ADAPTER' {
  const model = /ASR|Wake Word|Noise|OCR|Image Analysis|Model Manager/i.test(name);
  const android = /Phone|App |Settings|Wi-Fi|Bluetooth|Flashlight|Volume|Brightness|Media|Notifications|Screenshot|Accessibility|Scheduled|Battery Triggers|Charging Triggers|Network Triggers|App Triggers|Notification Triggers|Reminders/i.test(name);
  const adapter = /Navigation|Places|Scanner|Sandbox/i.test(name);
  if (model) return 'MODEL_REQUIRED';
  if (android) return 'ANDROID';
  if (adapter) return 'ADAPTER';
  return 'READY';
}

function capabilityReport(language: 'bn'|'en'): AssistantReply {
  const ready = OFFLINE_ULTIMATE_FEATURES.filter(x => featureStatus(x) === 'READY').length;
  const android = OFFLINE_ULTIMATE_FEATURES.filter(x => featureStatus(x) === 'ANDROID').length;
  const model = OFFLINE_ULTIMATE_FEATURES.filter(x => featureStatus(x) === 'MODEL_REQUIRED').length;
  const adapter = OFFLINE_ULTIMATE_FEATURES.filter(x => featureStatus(x) === 'ADAPTER').length;
  return reply(language,
    `Abir Offline Ultimate Pack সক্রিয়। মোট ${OFFLINE_ULTIMATE_FEATURES.length}টি capability আছে।\n\nপ্রস্তুত local: ${ready}\nAndroid/API নির্ভর: ${android}\nOffline model লাগবে: ${model}\nAdapter লাগবে: ${adapter}\n\nযেগুলোর model/API নেই সেগুলোকে আমি ভুয়া “কাজ করছে” দেখাব না।`,
    `Abir Offline Ultimate Pack is active with ${OFFLINE_ULTIMATE_FEATURES.length} capabilities.\n\nLocal-ready: ${ready}\nAndroid/API dependent: ${android}\nOffline model required: ${model}\nAdapter required: ${adapter}\n\nCapabilities that need a model/API are reported honestly instead of being faked.`, 'diagnostics');
}

async function modeCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  const modes: Array<[Mode, RegExp]> = [
    ['fast', /(?:fast mode|ফাস্ট মোড|দ্রুত মোড)/i], ['deep', /(?:deep mode|ডিপ মোড|গভীর মোড)/i], ['safe', /(?:safe mode|সেফ মোড|নিরাপদ মোড)/i],
    ['offline', /(?:offline mode|অফলাইন মোড|no cloud mode|নো ক্লাউড)/i], ['learning', /(?:learning mode|লার্নিং মোড)/i], ['silent', /(?:silent mode|সাইলেন্ট মোড)/i], ['normal', /(?:normal mode|নরমাল মোড)/i],
  ];
  const hit = modes.find(([, r]) => r.test(n));
  if (!hit) return null;
  const state = await loadState(); state.mode = hit[0]; await saveState(state);
  const labels: Record<Mode,string> = { fast:'Fast', deep:'Deep', safe:'Safe', offline:'Offline', learning:'Learning', silent:'Silent', normal:'Normal' };
  return reply(language, `Mode বদলে ${labels[hit[0]]} করা হয়েছে।`, `Mode changed to ${labels[hit[0]]}.`);
}

async function taskCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  const add = n.match(/^(?:task|কাজ|todo|করতে হবে)\s+(.+)$/iu);
  if (add) {
    const state = await loadState(); state.tasks.push({ id: `${Date.now()}`, text: add[1].trim(), done: false, createdAt: Date.now() }); await saveState(state);
    return reply(language, `কাজের তালিকায় যোগ করলাম: ${add[1].trim()}`, `Added to tasks: ${add[1].trim()}`, 'task-plan');
  }
  if (/(?:show tasks|list tasks|কাজের তালিকা|todo list|আমার কাজগুলো)/i.test(n)) {
    const state = await loadState(); const pending = state.tasks.filter(t => !t.done).slice(-10);
    if (!pending.length) return reply(language, 'এখন কোনো pending কাজ নেই।', 'There are no pending tasks.', 'task-plan');
    return reply(language, `Pending কাজ:\n${pending.map((t,i)=>`${i+1}. ${t.text}`).join('\n')}`, `Pending tasks:\n${pending.map((t,i)=>`${i+1}. ${t.text}`).join('\n')}`, 'task-plan');
  }
  if (/(?:clear tasks|সব কাজ মুছে দাও|clear todo)/i.test(n)) {
    const state = await loadState(); state.tasks = []; await saveState(state); return reply(language, 'কাজের তালিকা পরিষ্কার করা হয়েছে।', 'Task list cleared.', 'task-plan');
  }
  return null;
}

async function habitCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  const add = n.match(/^(?:habit|অভ্যাস)\s+(.+)$/iu);
  if (!add) return null;
  const state = await loadState(); const name = add[1].trim(); const old = state.habits.find(h => h.name.toLocaleLowerCase() === name.toLocaleLowerCase());
  if (old) old.count += 1; else state.habits.push({ name, count: 1, updatedAt: Date.now() });
  if (old) old.updatedAt = Date.now(); await saveState(state);
  return reply(language, `“${name}” habit check-in ${old ? 'আপডেট' : 'শুরু'} হয়েছে।`, `Habit “${name}” has been ${old ? 'updated' : 'started'}.`);
}

async function macroCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  const m = n.match(/^(?:macro|ম্যাক্রো)\s+(.+?)\s*(?:=>|->|=)\s*(.+)$/iu);
  if (m) {
    const state = await loadState(); const phrase = m[1].trim(); const command = m[2].trim();
    const old = state.macros.find(x => x.phrase === phrase); if (old) { old.command = command; old.uses += 1; } else state.macros.push({ phrase, command, uses: 1 });
    await saveState(state); return reply(language, `Custom macro “${phrase}” → “${command}” সংরক্ষণ করেছি।`, `Saved custom macro “${phrase}” → “${command}”.`);
  }
  if (/(?:list macros|ম্যাক্রো তালিকা|custom commands)/i.test(n)) {
    const state = await loadState(); const items = state.macros.slice(-15);
    return reply(language, items.length ? items.map((x,i)=>`${i+1}. ${x.phrase} → ${x.command}`).join('\n') : 'কোনো custom macro নেই।', items.length ? items.map((x,i)=>`${i+1}. ${x.phrase} → ${x.command}`).join('\n') : 'No custom macros saved.');
  }
  return null;
}

async function privateCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  if (!/(?:private mode|privacy mode|প্রাইভেট মোড|গোপন মোড|no cloud|নো ক্লাউড)/i.test(n)) return null;
  const state = await loadState(); state.privateMode = true; state.mode = 'offline'; await saveState(state);
  return reply(language, 'Private/No-cloud mode চালু। নতুন local data যতটা সম্ভব local-only রাখা হবে।', 'Private/No-cloud mode is on. New supported data will stay local-only.', 'help');
}

function textTools(text: string, language: 'bn'|'en'): AssistantReply|null {
  const n = norm(text);
  const m = n.match(/^(?:analyze text|text analysis|টেক্সট বিশ্লেষণ)\s*[:\-]?\s*(.+)$/iu);
  if (!m) return null;
  const a = analyzeOfflineText(m[1]);
  return reply(language, `অফলাইন Text Analyzer:\nঅক্ষর: ${a.characters}\nশব্দ: ${a.words}\nবাক্য: ${a.sentences}\nPreview: ${a.preview}`, `Offline Text Analyzer:\nCharacters: ${a.characters}\nWords: ${a.words}\nSentences: ${a.sentences}\nPreview: ${a.preview}`, 'text-analysis');
}

function planCommand(text: string, language: 'bn'|'en'): AssistantReply|null {
  const n = norm(text);
  if (!/(?:plan|পরিকল্পনা|step by step|ধাপে ধাপে)/i.test(n)) return null;
  const tasks = planOfflineTasks(text);
  if (tasks.length < 2) return null;
  return reply(language, `Offline Action Plan:\n${tasks.map((x,i)=>`${i+1}. ${x}`).join('\n')}`, `Offline Action Plan:\n${tasks.map((x,i)=>`${i+1}. ${x}`).join('\n')}`, 'task-plan');
}

async function diagnostics(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  const n = norm(text);
  if (!/(?:offline diagnostics|diagnostics|self test|self-test|diagnostic report|ডায়াগনস্টিক|ডায়াগনস্টিক|সেলফ টেস্ট|capability report|feature report)/i.test(n)) return null;
  const state = await loadState();
  return reply(language,
    `Abir Offline Diagnostics\n• Mode: ${state.mode}\n• Private mode: ${state.privateMode ? 'ON' : 'OFF'}\n• Tasks: ${state.tasks.length}\n• Habits: ${state.habits.length}\n• Macros: ${state.macros.length}\n• Audit events: ${state.audit.length}\n• Local capability registry: ${OFFLINE_ULTIMATE_FEATURES.length}\n\nSelf-test: local storage schema OK. Model/API dependent capabilities require their respective dependency.`,
    `Abir Offline Diagnostics\n• Mode: ${state.mode}\n• Private mode: ${state.privateMode ? 'ON' : 'OFF'}\n• Tasks: ${state.tasks.length}\n• Habits: ${state.habits.length}\n• Macros: ${state.macros.length}\n• Audit events: ${state.audit.length}\n• Local capability registry: ${OFFLINE_ULTIMATE_FEATURES.length}\n\nSelf-test: local storage schema OK. Model/API dependent capabilities require their dependency.`, 'diagnostics');
}

async function auditCommand(text: string, language: 'bn'|'en'): Promise<AssistantReply|null> {
  if (!/(?:audit|activity log|কাজের হিস্ট্রি|অ্যাক্টিভিটি লগ)/i.test(text)) return null;
  const state = await loadState(); const events = state.audit.slice(-10).reverse();
  return reply(language, events.length ? `শেষ activity:\n${events.map((x,i)=>`${i+1}. ${new Date(x.time).toLocaleTimeString('bn-BD')} — ${x.command} — ${x.result}`).join('\n')}` : 'কোনো local activity log নেই।', events.length ? `Recent activity:\n${events.map((x,i)=>`${i+1}. ${new Date(x.time).toLocaleTimeString()} — ${x.command} — ${x.result}`).join('\n')}` : 'No local activity log.', 'diagnostics');
}

export const offlineUltimateExtension: AssistantExtension = {
  id: 'offline-ultimate-pack-4.19',
  async handle(request) {
    const language = request.language || (isBn(request.text) ? 'bn' : 'en');
    const handlers = [
      async () => /(?:what can you do|capabilities|feature list|সব ফিচার|কি কি পারো|কী কী পারো|ফিচার লিস্ট)/i.test(request.text) ? capabilityReport(language) : null,
      () => modeCommand(request.text, language),
      () => privateCommand(request.text, language),
      () => taskCommand(request.text, language),
      () => habitCommand(request.text, language),
      () => macroCommand(request.text, language),
      () => diagnostics(request.text, language),
      () => auditCommand(request.text, language),
      () => Promise.resolve(textTools(request.text, language)),
      () => Promise.resolve(planCommand(request.text, language)),
    ];
    for (const h of handlers) { const r = await h(); if (r) return r; }

    const state = await loadState();
    if (!state.privateMode && request.text.trim()) {
      state.audit.push({ command: request.text.slice(0, 240), time: Date.now(), result: 'received' });
      await saveState(state);
    }
    return null;
  },
};
