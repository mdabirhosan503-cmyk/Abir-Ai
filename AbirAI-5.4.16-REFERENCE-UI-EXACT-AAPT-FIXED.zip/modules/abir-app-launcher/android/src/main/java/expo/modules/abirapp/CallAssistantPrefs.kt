package expo.modules.abirapp

import android.content.Context

object CallAssistantPrefs {
  private const val PREFS = "abir_call_assistant"
  private const val KEY_ENABLED = "enabled"

  fun enabled(context: Context): Boolean =
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      .getBoolean(KEY_ENABLED, false)

  fun setEnabled(context: Context, enabled: Boolean) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
      .edit()
      .putBoolean(KEY_ENABLED, enabled)
      .apply()
  }
}
