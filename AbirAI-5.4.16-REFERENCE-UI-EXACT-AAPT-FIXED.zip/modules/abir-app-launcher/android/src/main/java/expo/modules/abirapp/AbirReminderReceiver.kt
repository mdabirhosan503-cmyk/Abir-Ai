package expo.modules.abirapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AbirReminderReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val text = intent.getStringExtra("text") ?: return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channelId = "abir-reminders"
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      manager.createNotificationChannel(NotificationChannel(channelId, "Abir reminders", NotificationManager.IMPORTANCE_HIGH))
    }
    val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      android.app.Notification.Builder(context, channelId)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Abir AI")
        .setContentText(text)
        .setAutoCancel(true)
        .build()
    } else {
      @Suppress("DEPRECATION")
      android.app.Notification.Builder(context)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Abir AI")
        .setContentText(text)
        .setAutoCancel(true)
        .build()
    }
    manager.notify((System.currentTimeMillis() and 0x7fffffff).toInt(), notification)
  }
}
