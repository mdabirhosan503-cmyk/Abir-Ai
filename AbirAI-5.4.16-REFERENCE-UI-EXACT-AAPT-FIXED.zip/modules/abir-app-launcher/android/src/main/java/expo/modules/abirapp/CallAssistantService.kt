package expo.modules.abirapp

import android.telecom.Call
import android.telecom.InCallService
import android.os.Build

/**
 * Handles the system/SIM call side of Abir's Call Assistant.
 *
 * Android only binds this service when the app has the required phone role.
 * It can answer/control the call, but ordinary third-party apps are not
 * granted unrestricted access to the two-way cellular call audio.
 */
class CallAssistantService : InCallService() {
  companion object {
    @Volatile private var currentCall: Call? = null

    fun answerCurrentCall(): Boolean {
      val call = currentCall ?: return false
      return try {
        call.answer(0)
        true
      } catch (_: Exception) { false }
    }

    fun disconnectCurrentCall(): Boolean {
      val call = currentCall ?: return false
      return try {
        call.disconnect()
        true
      } catch (_: Exception) { false }
    }

    fun hasCall(): Boolean = currentCall != null
  }

  override fun onCallAdded(call: Call) {
    super.onCallAdded(call)
    currentCall = call

    // Only auto-answer when the user explicitly enabled Call Assistant.
    if (CallAssistantPrefs.enabled(this) && isIncoming(call)) {
      try {
        call.answer(0)
      } catch (_: Exception) {}
    }

    call.registerCallback(object : Call.Callback() {
      override fun onStateChanged(call: Call, state: Int) {
        if (state == Call.STATE_DISCONNECTED) {
          if (currentCall === call) currentCall = null
        }
      }
    })
  }

  override fun onCallRemoved(call: Call) {
    if (currentCall === call) currentCall = null
    super.onCallRemoved(call)
  }

  private fun isIncoming(call: Call): Boolean =
    call.details?.state == Call.STATE_RINGING
}
