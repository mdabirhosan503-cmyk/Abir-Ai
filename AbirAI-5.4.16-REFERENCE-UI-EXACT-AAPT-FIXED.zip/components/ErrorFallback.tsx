import React, { useState } from 'react';
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';
import { reloadAppAsync } from 'expo';

export type ErrorFallbackProps = {
  error: Error;
  resetError: () => void;
};

export function ErrorFallback({ error, resetError }: ErrorFallbackProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleRestart = async () => {
    try {
      await reloadAppAsync('Abir AI runtime error recovery');
    } catch (restartError) {
      console.error('Failed to restart app:', restartError);
      resetError();
    }
  };

  const formatErrorDetails = (): string => {
    let details = `Error: ${error?.message || 'Unknown error'}\n\n`;
    if (error?.stack) details += `Stack Trace:\n${error.stack}`;
    return details;
  };

  const monoFont = Platform.select({
    ios: 'Menlo',
    android: 'monospace',
    default: 'monospace',
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}> 
      <Pressable
        onPress={() => setIsModalVisible(true)}
        accessibilityLabel="View error details"
        accessibilityRole="button"
        style={({ pressed }) => [
          styles.topButton,
          {
            top: insets.top + 16,
            backgroundColor: colors.card,
            opacity: pressed ? 0.75 : 1,
          },
        ]}
      >
        <Feather name="alert-circle" size={20} color={colors.foreground} />
      </Pressable>

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.foreground }]}>Something went wrong</Text>
        <Text style={[styles.message, { color: colors.mutedForeground }]}>Please reload Abir AI to continue.</Text>

        <Pressable
          onPress={handleRestart}
          style={({ pressed }) => [
            styles.button,
            {
              backgroundColor: colors.primary,
              opacity: pressed ? 0.9 : 1,
              transform: [{ scale: pressed ? 0.98 : 1 }],
            },
          ]}
        >
          <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>Try Again</Text>
        </Pressable>

        <Pressable
          onPress={() => setIsModalVisible(true)}
          style={[styles.detailsButton, { borderColor: colors.border }]}
        >
          <Text style={[styles.detailsButtonText, { color: colors.foreground }]}>Show error details</Text>
        </Pressable>
      </View>

      <Modal
        visible={isModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Abir AI Error</Text>
              <Pressable
                onPress={() => setIsModalVisible(false)}
                accessibilityRole="button"
                style={styles.closeButton}
              >
                <Feather name="x" size={24} color={colors.foreground} />
              </Pressable>
            </View>

            <ScrollView
              style={styles.modalScrollView}
              contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 20 }}
            >
              <View style={[styles.errorContainer, { backgroundColor: colors.card }]}> 
                <Text style={[styles.errorText, { color: colors.foreground, fontFamily: monoFont }]}> 
                  {formatErrorDetails()}
                </Text>
              </View>
              <Text style={[styles.hint, { color: colors.mutedForeground }]}> 
                If you send this error text, the exact runtime problem can be fixed instead of guessing.
              </Text>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { width: '88%', maxWidth: 440, alignItems: 'center' },
  title: { fontSize: 30, fontWeight: '800', textAlign: 'center' },
  message: { fontSize: 17, marginTop: 14, textAlign: 'center', lineHeight: 25 },
  button: { width: '100%', marginTop: 28, paddingVertical: 16, borderRadius: 16, alignItems: 'center' },
  buttonText: { fontSize: 17, fontWeight: '800' },
  detailsButton: { width: '100%', marginTop: 12, paddingVertical: 14, borderRadius: 16, borderWidth: 1, alignItems: 'center' },
  detailsButtonText: { fontSize: 15, fontWeight: '700' },
  topButton: { position: 'absolute', right: 16, width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'flex-end' },
  modalContainer: { width: '100%', height: '88%', borderTopLeftRadius: 22, borderTopRightRadius: 22 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1 },
  modalTitle: { fontSize: 20, fontWeight: '800' },
  closeButton: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  modalScrollView: { flex: 1 },
  errorContainer: { borderRadius: 12, padding: 14 },
  errorText: { fontSize: 12, lineHeight: 18 },
  hint: { marginTop: 12, fontSize: 12, lineHeight: 18 },
});
