# Abir AI 5.4.16 — Time Response Fix

Fixed the offline time-query response in `assistant/offlineBrain.ts`.

Before:
- Bengali time replies added an unrelated “চাপ নিও না” sentence.
- English time replies added an unrelated “no rush” sentence.

Now:
- Bengali: only the current time is returned.
- English: only the current time is returned.

No other files or features were intentionally changed.
