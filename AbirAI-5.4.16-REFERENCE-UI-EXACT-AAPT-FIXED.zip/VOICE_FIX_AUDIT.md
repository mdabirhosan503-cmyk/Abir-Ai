# Abir AI 4.6.1 — Voice + Control Fix Audit

## Problems found in the uploaded 4.6.1 source

1. Standard Android speech fallback still forced `EXTRA_PREFER_OFFLINE=true`.
   - If the phone reported an on-device recognizer but did not have the needed Bengali/English language model, voice input could return nothing.
2. Background Wake Word used the standard recognizer with offline-only preference when the on-device recognizer was unavailable.
   - This made background listening fail on phones without the required offline language pack.
3. Bengali TTS could be paired with a mismatched English voice identifier.
   - Some Android TTS engines silently produce no speech in that situation.
4. Background Wake Word state was not persisted.
   - Permission denial or disabling Wake Word could cause it to become enabled again after reopening the app.
5. Overlay permission was prompted repeatedly whenever the app became active.
   - The voice service can still listen without overlay permission; only the floating UI needs that permission.
6. Native Android TTS was missing as a direct fallback.
   - The fixed build now has a native Android TextToSpeech path before Expo Speech on Android.

## Changes made

- Android speech fallback now supports `preferOffline=false` for the normal speech service.
- Voice input tries on-device recognition first, then normal Android speech recognition with network allowed.
- Wake Word uses on-device recognition when available; otherwise it allows the standard speech service to use the network.
- Bengali TTS no longer forces an English voice identifier onto Bengali text.
- Added native Android TextToSpeech functions: `speakText` and `stopSpeaking`.
- Android TTS is now the primary Android reply-voice path, with Expo Speech as fallback.
- Wake Word preference is persisted.
- Wake Word initialization waits for the saved preference before starting, preventing startup races.
- Floating overlay permission is requested at most once per app session and is no longer required for voice recognition itself.
- App/module version metadata is aligned to 4.6.1 / versionCode 25.

## Validation

- TypeScript transpile checks passed for the modified TS/TSX files.
- ZIP/source structure was preserved; no old assistant features were intentionally removed.
- A full Gradle release build was not run in this offline environment because the Gradle wrapper may need to download Gradle 9.3.1.
