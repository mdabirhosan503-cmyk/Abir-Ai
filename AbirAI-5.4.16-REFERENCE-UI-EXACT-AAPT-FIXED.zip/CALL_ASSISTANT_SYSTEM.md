# Abir AI Universal Call Assistant

This version adds a native Android Call Assistant foundation without removing the existing offline/online voice systems.

## Included
- Native `InCallService` for Android/SIM calls.
- Explicit voice/text command: `কল রিসিভ করে কথা বলো` / `answer the call and talk`.
- Call Assistant enable/disable state stored locally.
- Default Phone App role request on Android 10+.
- Incoming SIM calls can be auto-answered when Call Assistant is enabled and Abir AI is the active default phone app.
- `কল শেষ করো` / `hang up` control.
- Existing Wake Word, Accessibility, offline speech, online assistant, memory and English support remain in place.

## Important Android limitation
A normal third-party Android app is not granted unrestricted access to the two-way audio stream of every cellular/VoIP call. Therefore this release does **not** pretend that Abir can hear and speak through every WhatsApp, Messenger, IMO or other VoIP call.

For SIM calls, `InCallService` can manage the call when Abir is the permitted/default phone app. For third-party VoIP apps, Abir can continue to use its existing Accessibility/app automation where the target app exposes usable UI controls, but direct conversational call-audio access depends on the target app and Android/device privileges.

## Offline/online behavior
The Call Assistant command itself works offline. Existing Abir speech/AI selection remains unchanged: on-device speech/logic can work without internet when the device has the required offline model; online services remain available when connected.
