# Abir AI 5.4.16 — Natural Conversation Upgrade

This cumulative upgrade keeps the existing offline/online architecture and memory limit of 200.

## What changed

- Added a deterministic offline conversational layer for natural Bangla, Banglish and English small talk.
- Added context-aware follow-ups such as “এটা কী?”, “কেন?”, “আরও বল”, “কি বললে?”, and acknowledgements.
- Added more natural handling for greetings, chatting, thanks, simple emotional check-ins and conversational repair.
- Offline fallback wording is less robotic and no longer immediately gives up with “I didn’t understand”.
- Online Gemini is now allowed to enhance natural conversation, greetings, coding and unresolved requests when a key/network is available.
- Device actions remain local-first; online mode does not replace deterministic phone controls.
- Recent conversation context sent to online mode increased from 8 to 12 turns.
- Existing memory cap remains 200.

## Important limitation

Offline mode remains deterministic/heuristic. It is not a local large language model. A true fully offline LLM-quality conversation requires an on-device language model and sufficient device storage/RAM. This upgrade improves naturalness and context handling without pretending that limitation does not exist.
