# Abir AI 4.10.0 — Offline Feature Expansion

All existing 4.8.0 features are preserved.

Added offline capabilities:
- smarter follow-up context and local intent planning
- multi-step task planning/execution (up to 6 deterministic subcommands)
- local notes: save/search offline
- bounded local routines
- offline command aliases/learning storage
- offline unit conversion (length, mass, volume, temperature)
- offline text analysis (characters/words/sentences)
- improved task splitting and command repair hooks
- existing screen snapshot/smart screen action retained
- existing diagnostics, reminders, action history and undo retained
- existing local memory limit is unchanged at 200 remembered facts

Memory policy:
`assistant/localMemory.ts` still exports `MAX_MEMORY_ITEMS = 200`. No increase was made.


## 4.10.0 Offline Advanced Systems
- Task recovery and fallback guidance
- Intent prediction for vague commands
- Local knowledge engine + persistent local knowledge cache
- Offline command suggestions
- Offline text analysis shortcuts
- Power-aware processing policy
- Local command learning remains enabled
- Advanced screen semantic control, app profiles, diagnostics, routines, notes, undo and 200-item memory are preserved
- Memory limit remains exactly 200 remembered facts
