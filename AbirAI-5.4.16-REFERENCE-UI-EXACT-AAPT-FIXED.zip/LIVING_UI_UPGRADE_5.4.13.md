# Abir AI 5.4.13 — Living UI Upgrade

This release keeps the existing Offline 100 Feature Pack and adds a more reactive visual layer.

## Living UI changes
- Animated neural-network background with moving nodes and links
- Slow energy halo and scanning light effect
- Background animation speeds up during listening, processing, speaking, or continuous voice mode
- Dashboard metric cards gently breathe/pulse
- Intelligence/status panels gently animate instead of remaining completely static
- Existing living voice orb, waveform, floating voice orb, and live status rotation are preserved
- No change to the 200-item local memory limit

## Version
- App version: 5.4.13
- Android versionCode: 47
