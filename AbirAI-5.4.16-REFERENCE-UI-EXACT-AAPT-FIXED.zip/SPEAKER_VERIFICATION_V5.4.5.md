# Abir AI 5.4.5 — Offline Voice + Owner Speaker Verification

## What changed

- Bengali offline recognition now tries `bn-BD`, `bn-IN`, then `en-US`.
- Android on-device recognition is preferred before the normal recognizer's offline-preference path.
- Added local Owner Voice enrollment with up to 5 samples.
- Raw voice recordings are not persisted. The native layer converts each short sample into a compact local acoustic vector and stores only that vector.
- Screen off, screen on, and power-menu sensitive actions now require a fresh local speaker verification plus Android device authentication.
- Added Owner Voice Record / Reset controls in Settings.
- Persistent memory limit remains unchanged at 200 items.

## Security note

The bundled speaker layer is an offline acoustic-vector fallback designed around a future neural embedding provider. It is **not** a cryptographic biometric and must not be treated as equivalent to a trained ECAPA-TDNN model. Android fingerprint/face/PIN/password remains the final security gate for sensitive device actions.

For a production-grade neural speaker embedding, the `verifyLiveSpeaker()` API can later be backed by an on-device ECAPA-TDNN/LiteRT model without changing the UI or command gate.
