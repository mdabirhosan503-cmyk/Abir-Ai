# Abir AI 5.4.14 — Bengali Offline Speech Accuracy Fix

## What changed
- Added conservative post-ASR Bengali/Banglish transcript repair for common command/app words.
- Added semantic candidate scoring so Android offline recognizer alternatives are ranked by command usefulness, not just Bengali character count.
- Applied transcript repair before offline intent parsing.
- Kept contact/person names untouched unless they exactly match a small command vocabulary.
- Keeps the strict on-device recognizer first; no network speech is used while offline.

## Important limitation
Android offline speech recognition quality depends on the language model installed on the device. If the phone has no Bengali on-device model, code cannot manufacture one. In that case the app must either use an installed offline Bengali model or use online recognition when the user permits it.

## Version
5.4.14 / Android versionCode 48
