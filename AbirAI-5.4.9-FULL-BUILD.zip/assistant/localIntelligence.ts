import type { AssistantLanguage } from './offlineBrain';

export type LocalIntentScore = {
  normalized: string;
  language: AssistantLanguage;
  confidence: number;
  ambiguous: boolean;
  destructive: boolean;
  actionSignals: number;
};

const COMMON_SPEECH_FIXES: Array<[RegExp, string]> = [
  [/whatapp|watsapp|whats app/gi, 'whatsapp'],
  [/you ?tube/gi, 'youtube'],
  [/messanger/gi, 'messenger'],
  [/insta gram/gi, 'instagram'],
  [/face book/gi, 'facebook'],
  [/blue tooth/gi, 'bluetooth'],
  [/quick panal/gi, 'quick panel'],
  [/notificaton/gi, 'notification'],
  [/seting|settingg/gi, 'settings'],
  [/volum/gi, 'volume'],
  [/scren/gi, 'screen'],
  [/opn/gi, 'open'],
  [/helo|helllo/gi, 'hello'],
  [/abir ai ai/gi, 'abir ai'],
  [/হোয়াটসাপ|হোয়াটসাপ|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ/gu, 'whatsapp'],
  [/ইউ টিউব/gu, 'youtube'],
  [/মেসেঞ্জার/gu, 'messenger'],
  [/ফেসবুক/gu, 'facebook'],
  [/ব্লুটুথ/gu, 'bluetooth'],
  [/ভলুম/gu, 'ভলিউম'],
  [/স্ক্রিন/gu, 'স্ক্রিন'],
];

export function detectAssistantLanguage(text: string, fallback: AssistantLanguage = 'bn'): AssistantLanguage {
  const bn = (text.match(/[\u0980-\u09FF]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  if (bn > 0 && bn >= Math.max(1, Math.floor(latin * 0.18))) return 'bn';
  if (latin > 0) return 'en';
  return fallback;
}

export function repairCommonSpeech(text: string): string {
  let value = text.normalize('NFKC').trim();
  for (const [pattern, replacement] of COMMON_SPEECH_FIXES) value = value.replace(pattern, replacement);
  return value.replace(/\s+/g, ' ').trim();
}

export function splitOfflineTasks(text: string): string[] {
  return repairCommonSpeech(text)
    .split(/\s+(?:এবং|তারপর|পরে|and then|then|after that|also)\s+/iu)
    .map(item => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

export function scoreLocalIntent(text: string): LocalIntentScore {
  const normalized = repairCommonSpeech(text).toLowerCase();
  const language = detectAssistantLanguage(text);
  const destructive = /(?:delete|remove|erase|wipe|reset|uninstall|ডিলিট|মুছে|মুছ|রিসেট|আনইনস্টল)/iu.test(normalized);
  const ambiguous = /^(?:এটা|ওটা|ওইটা|সেটা|this|that|it|do it|করো|ওটা করো)$/iu.test(normalized);
  const actionSignals = [
    /(?:open|launch|start|খোলো|খুলে|ওপেন|চালু)/iu,
    /(?:call|phone|dial|কল|ফোন|নাম্বার)/iu,
    /(?:volume|ভলিউম|sound|শব্দ|flashlight|torch|ফ্ল্যাশ)/iu,
    /(?:click|tap|চাপ|scroll|স্ক্রল|type|লিখ)/iu,
    /(?:screen|স্ক্রিন|accessibility|অ্যাক্সেসিবিলিটি)/iu,
  ].reduce((n, re) => n + (re.test(normalized) ? 1 : 0), 0);
  const confidence = Math.min(1, 0.42 + actionSignals * 0.12 + (normalized.length > 8 ? 0.08 : 0));
  return { normalized, language, confidence, ambiguous, destructive, actionSignals };
}

export function isCompoundCommand(text: string): boolean {
  return splitOfflineTasks(text).length > 1;
}
