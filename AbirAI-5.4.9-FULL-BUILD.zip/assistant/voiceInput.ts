import { Platform } from 'react-native';
import { PermissionsAndroid } from 'react-native';
import type { AssistantLanguage } from './offlineBrain';
import { getOfflineSpeechRecognitionAvailability, getOnlineStatus, recognizeAndroidSpeech } from './androidActions';

type BrowserRecognitionResult = {
  results: ArrayLike<ArrayLike<{ transcript: string }>>;
};

type BrowserRecognition = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: BrowserRecognitionResult) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechWindow = Window & {
  SpeechRecognition?: new () => BrowserRecognition;
  webkitSpeechRecognition?: new () => BrowserRecognition;
};

export async function listenForText(
  language: AssistantLanguage,
): Promise<string | null> {
  const preferredLocale = language === 'bn' ? 'bn-BD' : 'en-US';

  if (Platform.OS === 'android') {
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
      throw new Error(
        language === 'bn'
          ? 'ভয়েস ইনপুটের জন্য মাইক্রোফোন অনুমতি প্রয়োজন। সেটিংসে অনুমতি দিয়ে আবার চেষ্টা করো।'
          : 'Microphone permission is needed for voice input. Allow it in settings and try again.',
      );
    }

    const rankCandidates = (values: string[]) => {
      const commandWords = /open|launch|start|call|phone|dial|whatsapp|youtube|messenger|instagram|facebook|volume|sound|increase|decrease|settings|wifi|bluetooth|home|back|recent|notification|screenshot|screen|camera|read|age|খোলো|খুলে|ওপেন|চালু|হোয়াটস|হোয়াটস|ইউটিউব|মেসেঞ্জার|কল|ফোন|নাম্বার|ভলিউম|শব্দ|বাড়াও|বাড়াও|বাড়াইতে|বাড়াতে|কমাও|কমাইতে|সেটিংস|হোম|পিছনে|রিসেন্ট|নোটিফিকেশন|স্ক্রিন|ক্যামেরা|পড়|পড়|বয়স|বয়স/i;
      return values
        .map((value, index) => {
          const text = value.trim();
          const commandScore = commandWords.test(text) ? 30 : 0;
          const bengaliScore = /[\u0980-\u09FF]/.test(text) ? 12 : 0;
          const mixedLanguageScore = /[\u0980-\u09FF]/.test(text) && /[A-Za-z]/.test(text) ? 6 : 0;
          return { text, score: commandScore + bengaliScore + mixedLanguageScore + Math.max(0, 8 - index) };
        })
        .filter(item => item.text)
        .sort((a, b) => b.score - a.score);
    };

    const native = await import('./androidActions');
    const locales = preferredLocale === 'bn-BD' ? ['bn-BD', 'bn-IN', 'en-US'] : ['en-US', 'bn-BD', 'bn-IN'];
    const allOfflineCandidates: string[] = [];

    // Offline path #1: strict Android on-device recognizer first.
    // This avoids accidentally depending on a network recognizer when offline.
    const offlineAvailable = await getOfflineSpeechRecognitionAvailability();
    if (offlineAvailable) {
      for (const candidateLocale of locales) {
        const candidates = await native.recognizeOfflineSpeech(candidateLocale);
        allOfflineCandidates.push(...candidates.filter(Boolean));
        if (allOfflineCandidates.length && rankCandidates(allOfflineCandidates)[0]?.score >= 20) break;
      }
    }

    // Offline path #2: installed Android speech service with offline preference.
    for (const locale of locales) {
      const candidates = await recognizeAndroidSpeech(locale, true);
      allOfflineCandidates.push(...candidates.filter(Boolean));
      if (allOfflineCandidates.length && rankCandidates(allOfflineCandidates)[0]?.score >= 20) break;
    }

    const bestOffline = rankCandidates(allOfflineCandidates)[0]?.text;
    if (bestOffline) return bestOffline;

    // Only use network speech recognition when the device is actually online.
    // This prevents an offline voice tap from hanging through repeated network
    // timeouts when no offline language model is installed.
    const online = await getOnlineStatus();
    if (!online) return null;

    const fallbackLocales = preferredLocale === 'bn-BD'
      ? ['bn-BD', 'bn-IN', 'en-US']
      : ['en-US', 'bn-BD', 'bn-IN'];

    for (let attempt = 0; attempt < 2; attempt += 1) {
      for (const locale of fallbackLocales) {
        const candidates = await recognizeAndroidSpeech(locale, false);
        const ranked = rankCandidates(candidates);
        const best = ranked[0]?.text;
        if (best) return best;
      }
    }
    return null;
  }

  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    const speechWindow = window as SpeechWindow;
    const Recognition =
      speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;
    if (!Recognition) {
      throw new Error('This browser does not support speech recognition.');
    }

    return new Promise<string | null>((resolve, reject) => {
      const recognition = new Recognition();
      recognition.lang = preferredLocale;
      recognition.interimResults = false;
      recognition.maxAlternatives = 5;
      recognition.onresult = (event) => {
        const candidates: string[] = [];
        for (let i = 0; i < event.results.length; i += 1) {
          for (let j = 0; j < event.results[i].length; j += 1) {
            const value = event.results[i][j]?.transcript?.trim();
            if (value) candidates.push(value);
          }
        }
        resolve(candidates[0] || null);
      };
      recognition.onerror = (event) =>
        reject(new Error(`Speech recognition failed: ${event.error}`));
      recognition.onend = () => resolve(null);
      recognition.start();
    });
  }

  throw new Error('Voice input is currently supported on Android and web.');
}

export async function listenForOfflineText(
  language: AssistantLanguage,
): Promise<string | null> {
  if (Platform.OS !== 'android') return null;
  const permission = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
  );
  if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
    throw new Error(
      language === 'bn'
        ? 'ভয়েস নিরাপত্তার জন্য মাইক্রোফোন অনুমতি প্রয়োজন।'
        : 'Microphone permission is required for voice security.',
    );
  }
  const locales = language === 'bn' ? ['bn-BD', 'bn-IN', 'en-US'] : ['en-US', 'bn-BD', 'bn-IN'];
  const results: string[] = [];

  // Prefer the strict Android 12+ on-device recognizer first.
  // Bengali devices often expose bn-IN offline even when bn-BD is unavailable.
  const available = await getOfflineSpeechRecognitionAvailability();
  if (available) {
    const native = await import('./androidActions');
    for (const locale of locales) {
      const candidates = await native.recognizeOfflineSpeech(locale);
      results.push(...candidates.filter(Boolean));
    }
  }

  // Fallback to the installed Android speech service with offline preference.
  for (const locale of locales) {
    const candidates = await recognizeAndroidSpeech(locale, true);
    results.push(...candidates.filter(Boolean));
  }

  return results[0]?.trim() || null;
}
