import { requireOptionalNativeModule } from 'expo';
import { Platform } from 'react-native';
import type { LaunchableApp } from './appNameMatcher';
import type { ContactPhone } from './contactHandler';
export type { LaunchableApp } from './appNameMatcher';

type NativeAssistantModule = {
  getLaunchableApps: () => Promise<LaunchableApp[]>;
  launchApp: (packageName: string, activityName: string) => Promise<boolean>;
  getContacts: () => Promise<ContactPhone[]>;
  openDialer: (phoneNumber: string) => Promise<boolean>;
  placeDirectCall: (phoneNumber: string) => Promise<boolean>;
  isOnline: () => Promise<boolean>;
  isOfflineSpeechRecognitionAvailable: () => Promise<boolean>;
  recognizeOffline: (locale: string) => Promise<string[]>;
  startWakeWord: () => Promise<boolean>;
  stopWakeWord: () => Promise<boolean>;
  isAccessibilityEnabled: () => Promise<boolean>;
  openAccessibilitySettings: () => Promise<boolean>;
  sendMessageViaAccessibility: (packageName: string, recipient: string, message: string) => Promise<boolean>;
  performGlobalAction: (action: string) => Promise<boolean>;
  readCurrentScreenText: () => Promise<string>;
  adjustVolume: (direction: string) => Promise<boolean>;
  openSystemSettings: (kind: string) => Promise<boolean>;
};

export type AppDiscoveryResult =
  | { status: 'available'; apps: LaunchableApp[] }
  | { status: 'unsupported' }
  | { status: 'native-build-required' }
  | { status: 'failed' };

export type AppLaunchResult = 'opened' | 'unsupported' | 'native-build-required' | 'failed';

const nativeAssistant =
  Platform.OS === 'android'
    ? requireOptionalNativeModule<NativeAssistantModule>('AbirAppLauncher')
    : null;

export async function getLaunchableApps(): Promise<AppDiscoveryResult> {
  if (Platform.OS !== 'android') return { status: 'unsupported' };
  if (!nativeAssistant) return { status: 'native-build-required' };

  try {
    const apps = await nativeAssistant.getLaunchableApps();
    return Array.isArray(apps)
      ? { status: 'available', apps }
      : { status: 'failed' };
  } catch {
    return { status: 'failed' };
  }
}

export async function launchInstalledApp(
  app: LaunchableApp,
): Promise<AppLaunchResult> {
  if (Platform.OS !== 'android') return 'unsupported';
  if (!nativeAssistant) return 'native-build-required';

  try {
    const started = await nativeAssistant.launchApp(
      app.packageName,
      app.activityName,
    );
    return started ? 'opened' : 'failed';
  } catch {
    return 'failed';
  }
}

export type DeviceContactResult =
  | { status: 'available'; contacts: ContactPhone[] }
  | { status: 'unsupported' }
  | { status: 'native-build-required' }
  | { status: 'failed' };

export async function getDeviceContacts(): Promise<DeviceContactResult> {
  if (Platform.OS !== 'android') return { status: 'unsupported' };
  if (!nativeAssistant) return { status: 'native-build-required' };
  try {
    const contacts = await nativeAssistant.getContacts();
    return Array.isArray(contacts)
      ? { status: 'available', contacts }
      : { status: 'failed' };
  } catch {
    return { status: 'failed' };
  }
}

export async function openContactDialer(phoneNumber: string) {
  if (Platform.OS !== 'android') return 'unsupported' as const;
  if (!nativeAssistant) return 'native-build-required' as const;
  try {
    return (await nativeAssistant.openDialer(phoneNumber))
      ? 'opened'
      : 'failed';
  } catch {
    return 'failed';
  }
}

export async function placeDirectCall(phoneNumber: string) {
  if (Platform.OS !== 'android') return 'unsupported' as const;
  if (!nativeAssistant) return 'native-build-required' as const;
  try {
    return (await nativeAssistant.placeDirectCall(phoneNumber))
      ? 'placed'
      : 'failed';
  } catch {
    return 'failed';
  }
}

export async function getOfflineSpeechRecognitionAvailability() {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try {
    return await nativeAssistant.isOfflineSpeechRecognitionAvailable();
  } catch {
    return false;
  }
}

export async function recognizeOfflineSpeech(locale: string) {
  if (Platform.OS !== 'android' || !nativeAssistant) return [];
  try {
    const result = await nativeAssistant.recognizeOffline(locale);
    return Array.isArray(result) ? result : [];
  } catch {
    return [];
  }
}

export async function getOnlineStatus() {
  if (Platform.OS === 'web' && typeof navigator !== 'undefined') {
    return navigator.onLine;
  }
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try {
    return await nativeAssistant.isOnline();
  } catch {
    return false;
  }
}

export function appActionReply(
  status: AppLaunchResult,
  app: LaunchableApp,
  language: 'bn' | 'en',
) {
  if (status === 'opened') {
    return language === 'bn'
      ? `${app.label} খুলে দিয়েছি। কাজ শেষ হলে আমি এখানেই আছি!`
      : `Opened ${app.label}. I’ll be here when you get back.`;
  }
  if (status === 'native-build-required') {
    return 'Installed-app actions need an Android build that includes Abir AI’s app-discovery module. Rebuild the Android app, then try again.';
  }
  if (status === 'unsupported') {
    return 'Opening installed apps is available only in the Android app.';
  }
  return language === 'bn'
    ? `${app.label} খোলা গেল না। অ্যাপটি আনইনস্টল হয়েছে কি না দেখে আবার চেষ্টা করো।`
    : `I couldn’t open ${app.label}. Check whether it was uninstalled and try again.`;
}

export function appDiscoveryReply(
  status: Exclude<AppDiscoveryResult['status'], 'available'>,
  language: 'bn' | 'en',
) {
  if (status === 'native-build-required') {
    return 'Installed-app discovery needs an Android build that includes Abir AI’s app-discovery module. Rebuild the Android app, then try again.';
  }
  if (status === 'unsupported') {
    return 'Opening installed apps is available only in the Android app.';
  }
  return language === 'bn'
    ? 'ফোনের ইনস্টল করা অ্যাপগুলোর তালিকা পাওয়া গেল না। আবার চেষ্টা করো।'
    : 'I couldn’t read the installed-app list. Please try again.';
}


export async function startWakeWord() {
  if (Platform.OS !== 'android') return false;
  if (!nativeAssistant) return false;
  try {
    return await nativeAssistant.startWakeWord();
  } catch {
    return false;
  }
}

export async function stopWakeWord() {
  if (Platform.OS !== 'android') return false;
  if (!nativeAssistant) return false;
  try {
    return await nativeAssistant.stopWakeWord();
  } catch {
    return false;
  }
}


export async function isAccessibilityEnabled() {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.isAccessibilityEnabled(); } catch { return false; }
}

export async function openAccessibilitySettings() {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.openAccessibilitySettings(); } catch { return false; }
}

export async function sendMessageViaAccessibility(packageName: string, recipient: string, message: string) {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.sendMessageViaAccessibility(packageName, recipient, message); } catch { return false; }
}


export type GlobalDeviceAction =
  | 'back'
  | 'home'
  | 'recents'
  | 'notifications'
  | 'quick-settings'
  | 'power-menu'
  | 'lock-screen'
  | 'screenshot'
  | 'split-screen'
  | 'volume-up'
  | 'volume-down'
  | 'volume-mute'
  | 'settings'
  | 'wifi-settings'
  | 'bluetooth-settings';

export async function adjustDeviceVolume(direction: 'up' | 'down' | 'mute') {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.adjustVolume(direction); } catch { return false; }
}

export async function openSystemSettings(kind: 'settings' | 'wifi-settings' | 'bluetooth-settings') {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.openSystemSettings(kind); } catch { return false; }
}

export async function performDeviceAction(action: GlobalDeviceAction) {
  if (Platform.OS !== 'android' || !nativeAssistant) return false;
  try { return await nativeAssistant.performGlobalAction(action); } catch { return false; }
}

export async function readCurrentScreenText() {
  if (Platform.OS !== 'android' || !nativeAssistant) return null;
  try {
    const text = await nativeAssistant.readCurrentScreenText();
    return text?.trim() || null;
  } catch { return null; }
}
