import type { AssistantMemory } from './localMemory';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber, normalizeAssistantCommand } from './intentParser';

export type AssistantLanguage = 'bn' | 'en';

export interface AssistantRequest {
  text: string;
  language: AssistantLanguage;
  now?: Date;
  memory?: AssistantMemory;
}

export type AssistantIntent =
  | 'greeting'
  | 'casual'
  | 'help'
  | 'time'
  | 'date'
  | 'joke'
  | 'calculator'
  | 'clear-history'
  | 'open-app'
  | 'device-action'
  | 'screen-read'
  | 'call-contact'
  | 'memory'
  | 'fallback';

export interface AssistantReply {
  text: string;
  intent: AssistantIntent;
  appQuery?: string;
  contactQuery?: string;
  deviceAction?:
    | 'back'
    | 'home'
    | 'recents'
    | 'notifications'
    | 'quick-settings'
    | 'power-menu'
    | 'lock-screen'
    | 'screenshot'
    | 'split-screen'
    | 'volume-up'
    | 'volume-down'
    | 'volume-mute'
    | 'settings'
    | 'wifi-settings'
    | 'bluetooth-settings';
}

export interface AssistantExtension {
  id: string;
  handle(request: AssistantRequest): Promise<AssistantReply | null>;
}

const hasBengali = (text: string) => /[\u0980-\u09FF]/.test(text);
let responseCursor = 0;

function variant<T>(items: T[]) {
  const selected = items[responseCursor % items.length];
  responseCursor += 1;
  return selected;
}

function normalizeNumerals(text: string) {
  return normalizeAssistantCommand(text)
    .replace(/(?:^|\s)(?:hey|hello|hi|abir|abira|adiraabir|adira abir|এবির|আবির|আদিরাবির|আদির আবির)(?=\s|$)/giu, ' ')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

function calculate(text: string): number | null {
  let expression = text
    .replace(/^(?:calculate|solve|what is|কত|গণনা করো|হিসাব করো|যোগ করো|বিয়োগ করো|বিয়োগ করো|গুণ করো|ভাগ করো)\s*/i, '')
    .replace(/×|x/gi, '*')
    .replace(/÷/g, '/')
    .replace(/শতকরা/g, '%')
    .replace(/শতাংশ/g, '%')
    .replace(/যোগ/g, '+')
    .replace(/বিয়োগ|বিয়োগ/g, '-')
    .replace(/গুণ/g, '*')
    .replace(/ভাগ/g, '/')
    .replace(/সমান\s*কত/g, '')
    .trim();

  // Accept common spoken forms such as “১০ যোগ ৫ গুণ ২” and parentheses.
  expression = expression.replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  expression = expression.replace(/[^0-9+\-*/%.()\s]/g, ' ');
  expression = expression.replace(/\s+/g, ' ').trim();
  if (!expression || !/[0-9]/.test(expression)) return null;

  const tokens = expression.match(/\d+(?:\.\d+)?|[()+\-*/%]/g);
  if (!tokens) return null;
  let index = 0;

  const parsePrimary = (): number | null => {
    const token = tokens[index];
    if (token === undefined) return null;
    if (token === '(') {
      index += 1;
      const value = parseAddSub();
      if (tokens[index] !== ')') return null;
      index += 1;
      return value;
    }
    if (/^\d/.test(token)) {
      index += 1;
      return Number(token);
    }
    return null;
  };

  const parseUnary = (): number | null => {
    if (tokens[index] === '+') {
      index += 1;
      return parseUnary();
    }
    if (tokens[index] === '-') {
      index += 1;
      const value = parseUnary();
      return value === null ? null : -value;
    }
    return parsePrimary();
  };

  const parseMulDiv = (): number | null => {
    let value = parseUnary();
    if (value === null) return null;
    while (index < tokens.length && ['*', '/', '%'].includes(tokens[index])) {
      const op = tokens[index++];
      const right = parseUnary();
      if (right === null || (op === '/' && right === 0)) return null;
      if (op === '*') value *= right;
      else if (op === '/') value /= right;
      else value %= right;
    }
    return value;
  };

  const parseAddSub = (): number | null => {
    let value = parseMulDiv();
    if (value === null) return null;
    while (index < tokens.length && ['+', '-'].includes(tokens[index])) {
      const op = tokens[index++];
      const right = parseMulDiv();
      if (right === null) return null;
      value = op === '+' ? value + right : value - right;
    }
    return value;
  };

  const result = parseAddSub();
  if (result === null || index !== tokens.length || !Number.isFinite(result)) return null;
  return result;
}

function convertUnit(text: string): { value: number; unit: string } | null {
  const normalized = text
    .replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)))
    .toLowerCase();
  const match = normalized.match(/(-?\d+(?:\.\d+)?)\s*(km|kilometer|kilometers|কিলোমিটার|m|meter|meters|মিটার|cm|centimeter|centimeters|সেন্টিমিটার|kg|kilogram|kilograms|কেজি|কিলোগ্রাম|g|gram|grams|গ্রাম|mile|miles|মাইল|c|°c|ফারেনহাইট|fahrenheit|f|°f|celsius|সেলসিয়াস|সেলসিয়াস)/i);
  if (!match) return null;
  const value = Number(match[1]);
  const unit = match[2].toLowerCase();
  if (['km','kilometer','kilometers','কিলোমিটার'].includes(unit)) return { value: value * 1000, unit: 'মিটার' };
  if (['m','meter','meters','মিটার'].includes(unit)) return { value, unit: 'মিটার' };
  if (['cm','centimeter','centimeters','সেন্টিমিটার'].includes(unit)) return { value: value / 100, unit: 'মিটার' };
  if (['kg','kilogram','kilograms','কেজি','কিলোগ্রাম'].includes(unit)) return { value, unit: 'কেজি' };
  if (['g','gram','grams','গ্রাম'].includes(unit)) return { value: value / 1000, unit: 'কেজি' };
  if (['mile','miles','মাইল'].includes(unit)) return { value: value * 1.609344, unit: 'কিলোমিটার' };
  if (['c','°c','celsius','সেলসিয়াস','সেলসিয়াস'].includes(unit)) return { value: value * 9 / 5 + 32, unit: '°F' };
  if (['f','°f','fahrenheit','ফারেনহাইট'].includes(unit)) return { value: (value - 32) * 5 / 9, unit: '°C' };
  return null;
}

function rememberedName(memory?: AssistantMemory) {
  const fact = memory?.facts.find((item) =>
    /^(?:my name is|আমার নাম)\s*/i.test(item),
  );
  return fact?.replace(/^(?:my name is|আমার নাম)\s*/i, '').trim() || null;
}

export const offlineCommandExtension: AssistantExtension = {
  id: 'offline-command-and-conversation-brain',
  async handle({ text, language, now = new Date(), memory }) {
    const normalized = normalizeNumerals(text);
    const bengali = hasBengali(text) || language === 'bn';
    const reply = (bn: string, en: string, intent: AssistantIntent) => ({
      text: bengali ? bn : en,
      intent,
    });

    const directPhoneNumber = extractDirectPhoneNumber(text);
    const callQuery = extractCallQuery(text);
    if (directPhoneNumber) {
      return {
        ...reply(
          `${directPhoneNumber}-এ কল দিচ্ছি…`,
          `Calling ${directPhoneNumber}…`,
          'call-contact',
        ),
        contactQuery: directPhoneNumber,
      };
    }

    if (callQuery) {
      return {
        ...reply(
          `${callQuery}-এর নম্বর খুঁজছি…`,
          `Looking for ${callQuery} in your contacts…`,
          'call-contact',
        ),
        contactQuery: callQuery,
      };
    }

    const deviceAction = (() => {
      if (/(?:back|go back|go backwards|পিছনে|পেছনে|আগের পেজ|আগের পাতায়|আগের পৃষ্ঠায়)/i.test(normalized)) return 'back' as const;
      if (/(?:home|go home|home screen|হোমে|হোম স্ক্রিনে|মূল স্ক্রিনে)/i.test(normalized)) return 'home' as const;
      if (/(?:recent apps|recents|recent|সাম্প্রতিক অ্যাপ|রিসেন্ট অ্যাপ|আগের অ্যাপগুলো|আগের অ্যাপ)/i.test(normalized)) return 'recents' as const;
      if (/(?:notifications|notification panel|notification shade|নোটিফিকেশন|বিজ্ঞপ্তি|নোটিফিকেশন প্যানেল)/i.test(normalized)) return 'notifications' as const;
      if (/(?:quick settings|quick panel|control center|কুইক সেটিংস|কুইক প্যানেল|কন্ট্রোল সেন্টার)/i.test(normalized)) return 'quick-settings' as const;
      if (/(?:power menu|power dialog|পাওয়ার মেনু|পাওয়ার মেনু|পাওয়ার অপশন|পাওয়ার অপশন|পাওয়ার বাটন মেনু)/i.test(normalized)) return 'power-menu' as const;
      if (/(?:lock screen|screen lock|lock the phone|ফোনটা লক|স্ক্রিন লক|স্ক্রিন বন্ধ|ফোন লক)/i.test(normalized)) return 'lock-screen' as const;
      if (/(?:screenshot|screen shot|capture screen|স্ক্রিনশট|স্ক্রিন শট|স্ক্রিনের ছবি|স্ক্রিন ক্যাপচার|স্ক্রিনের একটা ছবি)/i.test(normalized)) return 'screenshot' as const;
      if (/(?:split screen|split-screen|দুই অ্যাপ পাশাপাশি|স্প্লিট স্ক্রিন|দুইটা অ্যাপ একসাথে)/i.test(normalized)) return 'split-screen' as const;
      if (/(?:volume up|increase volume|turn.*volume.*up|শব্দ বাড়াও|শব্দ বাড়াও|ভলিউম বাড়াও|ভলিউম বাড়াও|ভলিউমটা.*বাড়|শব্দটা.*বাড়)/i.test(normalized)) return 'volume-up' as const;
      if (/(?:volume down|decrease volume|turn.*volume.*down|শব্দ কমাও|ভলিউম কমাও|ভলিউমটা.*কম|শব্দটা.*কম)/i.test(normalized)) return 'volume-down' as const;
      if (/(?:mute|silent|turn.*sound.*off|শব্দ বন্ধ|মিউট|সাইলেন্ট|নীরব)/i.test(normalized)) return 'volume-mute' as const;
      if (/(?:wifi settings|wi-fi settings|ওয়াইফাই সেটিংস|ওয়াইফাই সেটিংস|wifi-তে যাও)/i.test(normalized)) return 'wifi-settings' as const;
      if (/(?:bluetooth settings|ব্লুটুথ সেটিংস|bluetooth-এ যাও)/i.test(normalized)) return 'bluetooth-settings' as const;
      if (/(?:open settings|settings|সেটিংস খোলো|সেটিংস খুলে দাও|সেটিংস|ফোনের সেটিংসে)/i.test(normalized)) return 'settings' as const;
      return null;
    })();
    if (deviceAction) {
      const labels: Record<typeof deviceAction, [string,string]> = {
        back: ['পিছনে যাচ্ছি।','Going back.'],
        home: ['হোম স্ক্রিনে যাচ্ছি।','Going to the home screen.'],
        recents: ['সাম্প্রতিক অ্যাপ দেখাচ্ছি।','Opening recent apps.'],
        notifications: ['নোটিফিকেশন প্যানেল খুলছি।','Opening notifications.'],
        'quick-settings': ['কুইক সেটিংস খুলছি।','Opening quick settings.'],
        'power-menu': ['পাওয়ার মেনু খুলছি।','Opening the power menu.'],
        'lock-screen': ['ফোন লক করছি।','Locking the screen.'],
        screenshot: ['স্ক্রিনশট নিচ্ছি।','Taking a screenshot.'],
        'split-screen': ['স্প্লিট স্ক্রিন চালু করার চেষ্টা করছি।','Trying to enter split-screen mode.'],
        'volume-up': ['ভলিউম বাড়াচ্ছি।','Increasing volume.'],
        'volume-down': ['ভলিউম কমাচ্ছি।','Decreasing volume.'],
        'volume-mute': ['মিডিয়া ভলিউম মিউট করছি।','Muting media volume.'],
        settings: ['সেটিংস খুলছি।','Opening Settings.'],
        'wifi-settings': ['Wi-Fi সেটিংস খুলছি।','Opening Wi-Fi settings.'],
        'bluetooth-settings': ['Bluetooth সেটিংস খুলছি।','Opening Bluetooth settings.'],
      };
      const [bn,en] = labels[deviceAction];
      return { ...reply(bn,en,'device-action'), deviceAction };
    }

    if (/(?:read (?:the )?screen|what(?:'s| is) on screen|স্ক্রিনে কী আছে|স্ক্রিনটা পড়ে শোনাও|স্ক্রিন পড়ো|স্ক্রিনের লেখা বলো)/i.test(normalized)) {
      return { ...reply('স্ক্রিনের লেখা পড়ছি…','Reading the current screen…','screen-read') };
    }

    // Smart offline intent repair: understand indirect/polite phrasing and
    // common mixed-language wording before falling back to Gemini online.
    const repaired = normalized
      .replace(/(?:তুমি|আপনি|তুই)\s+(?:কি|কী)\s+/u, '')
      .replace(/(?:আমার জন্য|আমাকে)\s+/u, '')
      .replace(/(?:একটু|দয়া করে|দয়া করে|প্লিজ|please|kindly)\s+/giu, '')
      .trim();

    if (/(?:আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat that|say that again|say it again|again please)/i.test(repaired)) {
      return reply(
        'অবশ্যই—শেষ কথাটা আবার বলছি।',
        'Sure — I’ll repeat that.',
        'casual',
      );
    }

    if (/(?:থামো|চুপ|চুপ করো|stop talking|stop speaking|be quiet|শব্দ বন্ধ করো)/i.test(repaired)) {
      return reply('ঠিক আছে। কথা বলা থামালাম।', 'Okay. I stopped speaking.', 'casual');
    }

    const appQuery = extractAppQuery(repaired);
    if (appQuery) {
      return {
        ...reply(
          'ইনস্টল করা অ্যাপটি খুঁজছি…',
          'Looking for that installed app…',
          'open-app',
        ),
        appQuery,
      };
    }

    if (/^(?:clear|clear chat|reset chat|চ্যাট মুছো|সব মুছে দাও)$/.test(normalized)) {
      return reply(
        'ঠিক আছে, পুরোনো কথাগুলো সরিয়ে দিলাম। এবার নতুন করে শুরু করি!',
        'Done. I cleared the old messages. Fresh start!',
        'clear-history',
      );
    }

    if (
      /^(?:hi|hello|hey|good morning|good evening|হাই|হ্যালো|আসসালামু আলাইকুম|সালাম)$/.test(
        normalized,
      )
    ) {
      const name = rememberedName(memory);
      return reply(
        variant([
          `হ্যালো${name ? ` ${name}` : ''}! আজ কী নিয়ে একটু বুদ্ধি খাটাব?`,
          `সালাম${name ? ` ${name}` : ''}! বলো, আজকের অভিযান কোন দিকে?`,
          `হাই${name ? ` ${name}` : ''}! আড্ডা, অঙ্ক, নাকি কোনো কাজ—তুমি বেছে নাও।`,
        ]),
        variant([
          `Hey${name ? ` ${name}` : ''}! What are we figuring out today?`,
          `Hello${name ? ` ${name}` : ''}! Pick a topic and I’ll do my best offline impression of a genius.`,
          `Hi${name ? ` ${name}` : ''}! Need a hand, a joke, or just a chat?`,
        ]),
        'greeting',
      );
    }

    if (
      /(?:what do you remember|তুমি কী মনে রেখেছ|কি মনে রেখেছ|কী মনে রেখেছ)/i.test(
        normalized,
      )
    ) {
      const facts = memory?.facts ?? [];
      return reply(
        facts.length
          ? `এই ডিভাইসে মনে রেখেছি:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'এখনো আলাদা করে কিছু মনে রাখিনি। চাইলে “মনে রাখো, আমি…” বলে কোনো পছন্দ জানাতে পারো।',
        facts.length
          ? `Saved on this device:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'I haven’t saved any facts yet. Say “remember that I…” to save a preference locally.',
        'memory',
      );
    }

    if (/(?:what were we (?:discussing|talking about)|আগে কী বলছিলাম|আমরা কী নিয়ে কথা বলছিলাম|আমরা কি নিয়ে কথা বলছিলাম)/i.test(normalized)) {
      const topics = memory?.recentTopics ?? [];
      return reply(
        topics.length
          ? `সাম্প্রতিক কথা ছিল:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'এই ডিভাইসে এখনো সাম্প্রতিক কথার প্রসঙ্গ জমেনি।',
        topics.length
          ? `Recently, we talked about:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'There isn’t any recent conversation context saved on this device yet.',
        'memory',
      );
    }

    if (/(?:how are you|how'?s it going|কেমন আছো|কেমন আছেন|আজকে কেমন|কি খবর|কী খবর)/i.test(normalized)) {
      return reply(
        variant([
          'আমার মানুষের মতো অনুভূতি নেই, তবে তোমার সঙ্গে আড্ডা দিতে আর কাজে লাগতে প্রস্তুত। তোমার খবর কী?',
          'আমি অনুভূতি পাই না—তবে অফলাইনেও বেশ ফুরফুরে! তোমার দিনটা কেমন যাচ্ছে?',
          'মানুষের মতো ভালো-মন্দ লাগা নেই, কিন্তু সাহায্য করতে একদম রেডি। আজ কী চলছে?',
        ]),
        variant([
          'I don’t have feelings like a person, but I’m ready to chat and help. How are you doing?',
          'No human moods on my side, but I’m here and ready. How’s your day going?',
          'I’m not conscious, but I can still be a pretty good conversation buddy. What’s up?',
        ]),
        'casual',
      );
    }

    if (/(?:আড্ডা|গল্প করি|চলো কথা বলি|chat with me|let'?s chat|talk to me)/i.test(normalized)) {
      return reply(
        variant([
          'চল! আজকের দিনের সবচেয়ে মজার বা অদ্ভুত ঘটনাটা কী?',
          'আড্ডা জমুক। খাবার, সিনেমা, ভ্রমণ—কোন বিষয় দিয়ে শুরু করব?',
          'আমি প্রস্তুত। তুমি একটা বিষয় ছুড়ে দাও, আমি কথার বলটা ধরছি!',
        ]),
        variant([
          'I’m in. What was the most interesting thing about your day?',
          'Let’s chat. Food, movies, travel, or a wonderfully specific question?',
          'Deal. Toss me a topic and I’ll keep the conversation going offline.',
        ]),
        'casual',
      );
    }

    if (
      /^(?:hi|hello|hey|thanks|thank you|ধন্যবাদ|থ্যাংকস|বিদায়|বিদায়|বাই|bye)[!. ]*$/i.test(
        normalized,
      )
    ) {
      return reply(
        variant([
          'স্বাগতম! দরকার হলে আবার ডাক দিও।',
          'ধন্যবাদ তোমাকেও! আড্ডার দরজা খোলা থাকল।',
          'বাই! কাজটা হলে কৃতিত্ব তোমার, না হলে দোষটা নেটওয়ার্কের—যদিও আমি অফলাইন!',
        ]),
        variant([
          'Anytime. I’ll be right here when you need me.',
          'Thanks for chatting. The offline door is always open.',
          'See you! If anything goes wrong, we can blame the math. Mostly.',
        ]),
        'casual',
      );
    }

    if (
      /(?:help|what can you do|commands|সাহায্য|কী করতে পারো|কি করতে পারো|কমান্ড)/.test(
        normalized,
      )
    ) {
      return reply(
        'আমি সময়-তারিখ বলতে, বড় অঙ্কের সহজ হিসাব কষতে, একক রূপান্তর করতে, আড্ডা দিতে, কৌতুক বলতে, এই ডিভাইসে পছন্দ মনে রাখতে, Android অ্যাপ খুলতে এবং অনুমতি দিলে পরিচিতি বা সরাসরি নম্বরে কলের প্রস্তুতি নিতে পারি।',
        'Offline: time/date, multi-step arithmetic, common unit conversion, casual chat, jokes, local memories, Android app launching, and contact/direct-number calls with Android permission and confirmation.',
        'help',
      );
    }

    if (/(?:তোমার নাম কী|তোমার নাম কি|who are you|what is your name|what's your name)/i.test(normalized)) {
      return reply(
        'আমার নাম আবির AI। আমি এই ফোনের Android Assistant। আমি offline ও online—দুইভাবেই কাজ করি; নেট না থাকলেও অনেক সাধারণ কথা, অঙ্ক, সময়-তারিখ, স্মৃতি আর ফোনের অনুমোদিত কমান্ড সামলাতে পারি।',
        'I’m Abir AI, your on-device assistant. I can still handle many everyday conversations, calculations, time/date, memory, and device commands offline.',
        'casual',
      );
    }

    if (/(?:তুমি কি অফলাইনে কাজ করতে পারো|অফলাইনে কাজ করো|can you work offline|do you work offline)/i.test(normalized)) {
      return reply(
        'হ্যাঁ। আমার লোকাল ব্রেইন ইন্টারনেট ছাড়াই সাধারণ কথা, অঙ্ক, সময়-তারিখ, স্মৃতি আর কিছু ডিভাইস কমান্ড বুঝতে পারে। তবে ওয়েবের খবর বা অনলাইন AI দরকার এমন প্রশ্নে ইন্টারনেট লাগবে।',
        'Yes. My local brain can handle everyday chat, math, time/date, memory, and supported device commands without internet. Web information and some advanced AI tasks still need a connection.',
        'help',
      );
    }

    if (/(?:শুভ সকাল|সুপ্রভাত|good morning)/i.test(normalized)) {
      return reply('সুপ্রভাত! আজকের কাজটা বলো, আবির প্রস্তুত।', 'Good morning! Tell me what you want to do.', 'greeting');
    }

    if (/(?:শুভ রাত্রি|শুভ রাত|good night)/i.test(normalized)) {
      return reply('শুভ রাত্রি! ভালো থেকো। দরকার হলে আবার “আবির” বলে ডাকবে।', 'Good night! I’ll be here when you call me.', 'casual');
    }

    if (/(?:ধন্যবাদ|অনেক ধন্যবাদ|thanks|thank you)/i.test(normalized)) {
      return reply('স্বাগতম! 😊', 'You’re welcome!', 'casual');
    }

    if (/(?:বাংলাদেশের রাজধানী|capital of bangladesh|ঢাকার রাজধানী)/i.test(normalized)) {
      return reply('বাংলাদেশের রাজধানী ঢাকা।', 'The capital of Bangladesh is Dhaka.', 'casual');
    }

    if (/(?:বাংলাদেশের মুদ্রা|currency of bangladesh|টাকার নাম কী)/i.test(normalized)) {
      return reply('বাংলাদেশের মুদ্রা হলো টাকা, যার আন্তর্জাতিক কোড BDT।', 'Bangladesh uses the taka, with the international code BDT.', 'casual');
    }

    if (/(?:১\s*কিলোমিটার|1\s*kilometer|এক কিলোমিটার).*(?:কত মিটার|how many meters)/i.test(normalized)) {
      return reply('১ কিলোমিটার = ১,০০০ মিটার।', '1 kilometer equals 1,000 meters.', 'calculator');
    }

    const conversion = convertUnit(normalized);
    if (conversion && /(?:কত|convert|রূপান্তর|সমান|equals|in)/i.test(normalized)) {
      const formatted = Number.isInteger(conversion.value) ? String(conversion.value) : String(Number(conversion.value.toFixed(4)));
      return reply(
        `${formatted} ${conversion.unit}।`,
        `${formatted} ${conversion.unit}.`,
        'calculator',
      );
    }

    if (/(?:time|সময়|সময়|কটা বাজে)/.test(normalized)) {
      const time = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        hour: 'numeric',
        minute: '2-digit',
      }).format(now);
      return reply(
        `এখন ${time}। ঘড়ি বলল, আমি শুধু সময় বলি—চাপ নিও না!`,
        `It’s ${time}. The clock says I should mention: no rush.`,
        'time',
      );
    }

    if (/(?:date|today|আজ|তারিখ|কোন বার)/.test(normalized)) {
      const date = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }).format(now);
      return reply(`আজ ${date}।`, `Today is ${date}.`, 'date');
    }

    if (/(?:joke|কৌতুক|জোক|হাসাও|মজার কথা)/.test(normalized)) {
      return reply(
        variant([
          'কম্পিউটার ডাক্তারকে বলল, “আমার ভাইরাস হয়েছে।” ডাক্তার বললেন, “তাহলে আজ একটু অফলাইনে থাকুন!”',
          'একটা ফোন আরেকটাকে বলল, “তোমার চার্জ কেমন?” সে বলল, “সম্পর্কটা ১% ব্যাটারির মতো—যেকোনো সময় শেষ!”',
          'শিক্ষক: ২ আর ২ কত? ছাত্র: ৪। শিক্ষক: খুব ভালো! ক্যালকুলেটর: এত প্রশংসা আমি কোনোদিন পাইনি।',
        ]),
        variant([
          'Why did the phone go to therapy? Too many unresolved notifications.',
          'I told my calculator a joke. It said the punchline didn’t add up.',
          'My offline mode and I have a lot in common: we both avoid unnecessary connections.',
        ]),
        'joke',
      );
    }

    if (
      /(?:who are you|are you (?:real|conscious|alive)|তুমি কে|তুমি কি মানুষ|তুমি কি বাস্তব)/i.test(
        normalized,
      )
    ) {
      return reply(
        'আমি আবির AI—একটি সফটওয়্যার সহকারী। মানুষের মতো চেতনা বা অনুভূতি নেই; আমি offline ও online—দুইভাবেই সাহায্য করি।',
        'I’m Abir AI, your Android Assistant. I can work both offline and online, and I can handle supported phone tasks without internet when Android allows it.',
        'casual',
      );
    }

    // Smart offline conversation layer: deterministic, friendly, and privacy-first.
    // It intentionally avoids pretending to know live/web facts when offline.
    if (/(?:তুমি কি আমাকে চিনতে পারো|আমাকে চিনতে পারো|do you know me|do you remember me)/i.test(normalized)) {
      const name = rememberedName(memory);
      return reply(
        name
          ? `হ্যাঁ, ${name}—এই ডিভাইসে তুমি যে তথ্য আমাকে মনে রাখতে বলেছো, সেখান থেকে তোমাকে চিনতে পারি। তবে আমি তোমার ব্যক্তিগত তথ্য নিজে থেকে সংগ্রহ করি না।`
          : 'তুমি আমাকে যেসব তথ্য এই ডিভাইসে মনে রাখতে বলবে, সেগুলো থেকেই তোমাকে চিনতে পারব। আমি নিজে থেকে ব্যক্তিগত তথ্য সংগ্রহ করি না।',
        name
          ? `Yes, ${name}. I can use what you chose to save on this device, but I don’t collect personal information on my own.`
          : 'I can remember information you explicitly save on this device. I do not collect personal information on my own.',
        'memory',
      );
    }

    if (/(?:তুমি কত বছরের|তোমার বয়স|তোমার বয়স|how old are you|your age)/i.test(normalized)) {
      return reply(
        'আমার মানুষের মতো বয়স নেই। আমি সফটওয়্যার—তবে তোমার সঙ্গে কাজ করার জন্য সবসময় প্রস্তুত।',
        'I don’t have a human age. I’m software, but I’m always ready to help.',
        'casual',
      );
    }

    if (/(?:কে বানিয়েছে|কে তোমাকে বানিয়েছে|কে তোমাকে তৈরি করেছে|who made you|who created you|who built you)/i.test(normalized)) {
      return reply(
        'আমি Abir AI—তোমার Android Assistant। আমি offline ও online—দুইভাবেই কাজ করতে পারি এবং Android যতটা অনুমতি দেয় ততটা ফোনে সাহায্য করতে পারি।',
        'I’m Abir AI, the assistant inside this app. I’m built from the code and rules of this project.',
        'casual',
      );
    }

    if (/(?:তুমি কি আমাকে ভালোবাসো|তুমি কি আমাকে পছন্দ করো|do you love me|do you like me)/i.test(normalized)) {
      return reply(
        'আমি মানুষের মতো ভালোবাসা অনুভব করি না। তবে তোমার সঙ্গে সম্মানজনকভাবে কথা বলতে এবং কাজে সাহায্য করতে পারি।',
        'I don’t feel love like a person does, but I can always treat you respectfully and help you.',
        'casual',
      );
    }

    if (/(?:তুমি বোকা|তুমি একটা বোকা|you are stupid|you are dumb)/i.test(normalized)) {
      return reply(
        'হাহা, আজ হয়তো আমার উত্তরটা ভালো হয়নি! 😄 তুমি আবার প্রশ্নটা বলো—আমি আরও ভালোভাবে চেষ্টা করি।',
        'Fair enough 😄 I may have missed that one. Ask again and I’ll try a better answer.',
        'casual',
      );
    }

    if (/(?:ভালো করেছ|দারুণ|সাবাশ|great job|good job|well done|nice)/i.test(normalized)) {
      return reply(
        'ধন্যবাদ! 😄 এবার পরের কাজটা বলো।',
        'Thanks! 😄 What should we tackle next?',
        'casual',
      );
    }

    if (/(?:দুঃখিত|সরি|sorry|my bad)/i.test(normalized)) {
      return reply(
        'কোনো সমস্যা নেই। আবার শুরু করি—কী করতে হবে বলো।',
        'No problem. Let’s start again. What do you need?',
        'casual',
      );
    }

    if (/^(?:হ্যাঁ|হ্যা|জি|জী|yes|yeah|yep|ঠিক আছে|আচ্ছা|okay|ok)$/i.test(normalized)) {
      return reply(
        'ঠিক আছে। 👍 এখন কী করতে হবে বলো।',
        'Got it. 👍 Tell me what you want to do next.',
        'casual',
      );
    }

    if (/^(?:না|নাহ|no|nope)$/i.test(normalized)) {
      return reply(
        'ঠিক আছে। কোনো সমস্যা নেই। অন্য কিছু করতে চাইলে বলো।',
        'Okay, no problem. Tell me if you want to do something else.',
        'casual',
      );
    }

    if (/(?:বিরক্ত লাগছে|বোর লাগছে|i am bored|i’m bored|im bored)/i.test(normalized)) {
      return reply(
        'চলো একটা কাজ করি! 😄 চাইলে আমি কৌতুক বলি, অঙ্ক দিই, সাধারণ জ্ঞান প্রশ্ন করি, অথবা তোমার সঙ্গে আড্ডা দিই।',
        'Let’s do something! 😄 I can tell a joke, give you a puzzle, ask a trivia question, or just chat.',
        'casual',
      );
    }

    if (/(?:কি খবর|কী খবর|what’s up|what is up|whats up)/i.test(normalized)) {
      return reply(
        'এই তো, তোমার কমান্ডের অপেক্ষায় আছি। 😄 তুমি যা বলবে, অফলাইনে যতটা পারি বুঝে কাজ করব।',
        'I’m here and ready for your next command. 😄 I’ll do my best offline.',
        'casual',
      );
    }

    if (/(?:আবহাওয়া|আবহাওয়া|weather|বৃষ্টি হবে কি|বৃষ্টি হবে কিনা)/i.test(normalized)) {
      return reply(
        'আমি অফলাইনে লাইভ আবহাওয়া দেখতে পারি না। ইন্টারনেট থাকলে বর্তমান আবহাওয়া দেখে বলতে পারব।',
        'I can’t see live weather while offline. With internet access, I can check the current weather.',
        'help',
      );
    }

    if (/(?:ইন্টারনেট নেই|নেট নেই|offline|অফলাইন)/i.test(normalized)) {
      return reply(
        'সমস্যা নেই। ইন্টারনেট ছাড়াও আমি কথা বলা, স্মৃতি, অঙ্ক এবং Android-এর অনুমোদিত অনেক control চালাতে পারি।',
        'No problem. I can keep working offline too—conversation, memory, calculations, and supported Android controls are available without internet.',
        'help',
      );
    }

    if (/(?:একটা ধাঁধা|ধাঁধা বল|riddle|puzzle)/i.test(normalized)) {
      return reply(
        'ধাঁধা: এমন কী জিনিস, যত কাটবে তত বড় হবে? উত্তর চাইলে বলো “উত্তর বলো”।',
        'Riddle: What gets bigger the more you cut it? Say “tell me the answer” when you want the answer.',
        'casual',
      );
    }

    if (/(?:উত্তর বলো|ধাঁধার উত্তর|tell me the answer|answer please)/i.test(normalized)) {
      return reply(
        'উত্তর: গর্ত। যত কাটবে, গর্ত তত বড় হবে। 😄',
        'Answer: a hole. The more you cut, the bigger it gets. 😄',
        'casual',
      );
    }

    if (/(?:বাংলাদেশের জাতীয় ফুল|বাংলাদেশের জাতীয় ফুল)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় ফুল শাপলা।', 'The national flower of Bangladesh is the water lily.', 'casual');
    }

    if (/(?:বাংলাদেশের জাতীয় পাখি|বাংলাদেশের জাতীয় পাখি)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় পাখি দোয়েল।', 'The national bird of Bangladesh is the Oriental magpie-robin.', 'casual');
    }

    if (/(?:বাংলাদেশের জাতীয় ফল|বাংলাদেশের জাতীয় ফল)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় ফল কাঁঠাল।', 'The national fruit of Bangladesh is jackfruit.', 'casual');
    }

    const answer = calculate(normalized);
    if (answer !== null) {
      const value = Number.isInteger(answer)
        ? String(answer)
        : String(Number(answer.toFixed(4)));
      return reply(
        `উত্তর ${new Intl.NumberFormat('bn-BD').format(answer)}। অঙ্কটা বেশ ভদ্র ছিল!`,
        `That’s ${value}. This sum behaved nicely.`,
        'calculator',
      );
    }

    return reply(
      'এটা অফলাইনে ঠিক বুঝতে পারিনি। আরেকটু অন্যভাবে বলবে? চাইলে আড্ডা, সময়-তারিখ, ছোট অঙ্ক, অ্যাপ খোলা বা পরিচিতিকে কলের কথা বলতে পারো।',
      'I didn’t quite catch the intent. Rephrase it naturally—I can handle Bengali, English, or mixed phrasing.',
      'fallback',
    );
  },
};

const defaultExtensions = [offlineCommandExtension];

export async function getAssistantReply(
  request: AssistantRequest,
  extensions: AssistantExtension[] = defaultExtensions,
): Promise<AssistantReply> {
  for (const extension of extensions) {
    const result = await extension.handle(request);
    if (result) return result;
  }

  return {
    text:
      request.language === 'bn'
        ? 'এই কাজটা এখনো আমার অফলাইন কমান্ডে নেই। চাইলে কথাটা আরেকভাবে বলো—আমি বাংলা, English আর mixed command বুঝে চেষ্টা করব।'
        : 'I don’t have that action in my offline command set yet. Rephrase it in Bengali, English, or mixed language and I’ll try again.',
    intent: 'fallback',
  };
}
