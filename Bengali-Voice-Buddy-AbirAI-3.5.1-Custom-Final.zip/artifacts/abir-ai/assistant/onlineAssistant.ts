import * as SecureStore from 'expo-secure-store';
export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
  imageBase64?: string;
  imageMimeType?: string;
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Gemini Developer API (generateContent).
// The key is supplied only at build time through EXPO_PUBLIC_GEMINI_API_KEY.
// If the key is missing or the request fails, Abir AI falls back to the offline brain.
const buildApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const model = process.env.EXPO_PUBLIC_GEMINI_MODEL?.trim() || 'gemini-2.5-flash';
const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';

function cleanReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const candidates = Array.isArray(record.candidates) ? record.candidates : [];
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = (first as Record<string, unknown>).content;
  if (!content || typeof content !== 'object') return null;
  const parts = Array.isArray((content as Record<string, unknown>).parts)
    ? (content as Record<string, unknown>).parts
    : [];
  const text = parts
    .filter((part): part is Record<string, unknown> => Boolean(part && typeof part === 'object'))
    .map(part => part.text)
    .filter((part): part is string => typeof part === 'string')
    .join(' ')
    .trim();
  return text || null;
}

export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  enabled: Boolean(buildApiKey),
  async respond(request) {
    const apiKey = (await SecureStore.getItemAsync(ACCOUNT_API_KEY))?.trim() || buildApiKey;
    if (!apiKey) return null;

    try {
      const systemInstruction =
        request.language === 'bn'
          ? 'তুমি Abir AI-এর অনলাইন সহকারী। ব্যবহারকারী যেভাবে স্বাভাবিকভাবে কথা বলে—ঘুরিয়ে, ভদ্রভাবে, অসম্পূর্ণভাবে, বাংলা-English mixed বা কথ্য ভাষায়—সেই কথার আসল উদ্দেশ্য বুঝে উত্তর দাও। নির্দিষ্ট কমান্ডের বাক্য আশা করবে না। ব্যবহারকারী বাংলায় লিখলে বাংলায় উত্তর দাও। ফোনের action command লোকাল সিস্টেম চালায়। দরকার হলে সংক্ষিপ্ত clarification চাও, কিন্তু অযথা প্রশ্ন করো না।'
          : 'You are Abir AI, an online assistant. Understand natural, indirect, polite, incomplete, mixed-language, and conversational phrasing instead of requiring exact command wording. Infer the user’s intent when it is clear, and ask a brief clarification only when necessary. Reply in the user’s language and give step-by-step help when useful. Phone actions are handled locally.';

      const response = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
          contents: [
            {
              role: 'user',
              parts: [
                { text: request.text },
                ...(request.imageBase64
                  ? [
                      {
                        inlineData: {
                          mimeType: request.imageMimeType || 'image/jpeg',
                          data: request.imageBase64,
                        },
                      },
                    ]
                  : []),
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 700,
          },
        }),
      });

      if (!response.ok) return null;
      return cleanReply(await response.json());
    } catch {
      return null;
    }
  },
};
