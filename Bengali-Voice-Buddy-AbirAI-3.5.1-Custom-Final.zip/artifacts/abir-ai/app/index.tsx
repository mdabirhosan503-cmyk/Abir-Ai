import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import * as Speech from 'expo-speech';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  AppState,
  Alert,
  Linking,
  FlatList,
  Keyboard,
  Modal,
  Platform,
  PermissionsAndroid,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  Image,
  View,
} from 'react-native';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  type AssistantLanguage,
  type AssistantIntent,
} from '@/assistant/offlineBrain';
import { getAssistantReply } from '@/assistant/offlineBrain';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber } from '@/assistant/intentParser';
import { extractMessageRequest, messageAutomationReply, type MessageRequest } from '@/assistant/messageAutomation';
import {
  appActionReply,
  appDiscoveryReply,
  getDeviceContacts,
  getLaunchableApps,
  getOfflineSpeechRecognitionAvailability,
  getOnlineStatus,
  launchInstalledApp,
  openContactDialer,
  placeDirectCall,
  performDeviceAction,
  adjustDeviceVolume,
  openSystemSettings,
  readCurrentScreenText,
  startWakeWord,
  stopWakeWord,
  isAccessibilityEnabled,
  openAccessibilitySettings,
  sendMessageViaAccessibility,
  type LaunchableApp,
} from '@/assistant/androidActions';
import {
  appChoicePrompt,
  matchInstalledApps,
  noMatchingAppReply,
  selectAppChoice,
} from '@/assistant/appNameMatcher';
import {
  formatCallConfirmation,
  formatContactChoicePrompt,
  matchContacts,
  selectContactChoice,
  type ContactPhone,
} from '@/assistant/contactHandler';
import {
  addRecentTopic,
  clearLocalMemory,
  EMPTY_MEMORY,
  handleMemoryCommand,
  loadLocalMemory,
  saveLocalMemory,
  type AssistantMemory,
} from '@/assistant/localMemory';
import {
  DEFAULT_PREFERENCES,
  loadAssistantPreferences,
  saveAssistantPreferences,
  type AssistantPreferences,
  type VoiceGenderPreference,
} from '@/assistant/voicePreferences';
import {
  chooseSpeechVoice,
  loadSpeechVoices,
  voiceFallbackMessage,
  type SpeechVoice,
} from '@/assistant/voiceSelection';
import { speakAssistantText } from '@/assistant/textToSpeech';
import { optionalOnlineAssistant } from '@/assistant/onlineAssistant';
import { listenForText } from '@/assistant/voiceInput';
import { useColors } from '@/hooks/useColors';


function getDeviceAction(text: string): 'back' | 'home' | 'recents' | 'notifications' | 'quick-settings' | null {
  const n = text.toLowerCase();
  if (/(?:back|go back|পিছনে যাও|পেছনে যাও)/i.test(n)) return 'back';
  if (/(?:home|go home|হোমে যাও|হোমে নিয়ে যাও)/i.test(n)) return 'home';
  if (/(?:recent apps|recents|সাম্প্রতিক অ্যাপ|রিসেন্ট অ্যাপ)/i.test(n)) return 'recents';
  if (/(?:notifications|notification panel|নোটিফিকেশন|বিজ্ঞপ্তি)/i.test(n)) return 'notifications';
  if (/(?:quick settings|quick panel|কুইক সেটিংস|কুইক প্যানেল)/i.test(n)) return 'quick-settings';
  return null;
}
function replyNeedsDeviceAction(text: string) { return getDeviceAction(text) !== null; }

type Message = {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  time: number;
  intent?: AssistantIntent;
};

type SavedChat = {
  messages: Message[];
  language: AssistantLanguage;
  autoSpeak: boolean;
};

type UiIconName =
  | 'sparkles'
  | 'volume-high'
  | 'volume-mute'
  | 'volume-medium'
  | 'trash'
  | 'mic'
  | 'arrow-up'
  | 'settings'
  | 'close'
  | 'camera'
  | 'shield';

function UiIcon({
  name,
  color,
  size = 20,
}: {
  name: UiIconName;
  color: string;
  size?: number;
}) {
  const strokeProps = {
    fill: 'none',
    stroke: color,
    strokeWidth: 1.8,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };

  let drawing: React.ReactNode;
  switch (name) {
    case 'sparkles':
      drawing = (
        <>
          <Path
            d="M12 3 13.9 8.1 19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"
            {...strokeProps}
          />
          <Path d="M19 15v4M17 17h4" {...strokeProps} />
        </>
      );
      break;
    case 'volume-high':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a9 9 0 0 1 0 11" {...strokeProps} />
        </>
      );
      break;
    case 'volume-medium':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6" {...strokeProps} />
        </>
      );
      break;
    case 'volume-mute':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="m17 9 5 6m0-6-5 6" {...strokeProps} />
        </>
      );
      break;
    case 'trash':
      drawing = (
        <>
          <Path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14" {...strokeProps} />
          <Path d="M9 7V4h6v3" {...strokeProps} />
        </>
      );
      break;
    case 'mic':
      drawing = (
        <>
          <Rect x="9" y="3" width="6" height="12" rx="3" {...strokeProps} />
          <Path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" {...strokeProps} />
        </>
      );
      break;
    case 'arrow-up':
      drawing = <Path d="M12 19V5M6 11l6-6 6 6" {...strokeProps} />;
      break;
    case 'settings':
      drawing = (
        <>
          <Path
            d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z"
            {...strokeProps}
          />
          <Path
            d="m19.4 15 .1.1a1.8 1.8 0 1 1-2.5 2.5l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.3a1.8 1.8 0 1 1-3.6 0v-.2a1.7 1.7 0 0 0-2.9-1.2l-.1.1a1.8 1.8 0 1 1-2.5-2.5l.1-.1a1.7 1.7 0 0 0-1.2-2.9h-.3a1.8 1.8 0 1 1 0-3.6h.2a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a1.8 1.8 0 1 1 2.5-2.5l.1.1a1.7 1.7 0 0 0 2.9-1.2v-.3a1.8 1.8 0 1 1 3.6 0v.2a1.7 1.7 0 0 0 2.9 1.2l.1-.1a1.8 1.8 0 1 1 2.5 2.5l-.1.1a1.7 1.7 0 0 0 1.2 2.9h.3a1.8 1.8 0 1 1 0 3.6h-.2a1.7 1.7 0 0 0-1.2 2.9Z"
            {...strokeProps}
          />
        </>
      );
      break;
    case 'close':
      drawing = <Path d="m6 6 12 12M18 6 6 18" {...strokeProps} />;
      break;
    case 'camera':
      drawing = (
        <>
          <Path d="M4 8h3l1.5-2h7L17 8h3v11H4V8Z" {...strokeProps} />
          <Circle cx="12" cy="13.5" r="3.5" {...strokeProps} />
        </>
      );
      break;
    case 'shield':
      drawing = (
        <>
          <Path d="M12 3 19 6v5c0 4.5-2.9 8-7 10-4.1-2-7-5.5-7-10V6l7-3Z" {...strokeProps} />
          <Path d="m9 12 2 2 4-4" {...strokeProps} />
        </>
      );
      break;
    default:
      drawing = <Circle cx="12" cy="12" r="8" {...strokeProps} />;
  }

  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityRole="image">
      {drawing}
    </Svg>
  );
}

const STORAGE_KEY = 'abir-ai-chat-v1';
const MAX_MESSAGES = 160;
const CAMERA_MEMORY_KEY = 'abir-ai-camera-memory-v1';
const MAX_CAMERA_MEMORIES = 5;
const APP_LOCK_KEY = 'abir-ai-app-lock-v2';
const ACCOUNT_KEY = 'abir-ai-account-v2';
const ACCOUNT_EMAIL_KEY = 'abir-ai-account-email-v2';
const ACCOUNT_PASSWORD_KEY = 'abir-ai-account-password-v2';
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';
const SECURITY_LOG_KEY = 'abir-ai-security-log-v1';
const MAX_SECURITY_LOGS = 60;

function messagingPackage(app: MessageRequest['app']) {
  return app === 'imo' ? 'com.imo.android.imoim' : 'com.facebook.orca';
}

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function welcomeMessage(language: AssistantLanguage): Message {
  return {
    id: 'welcome',
    role: 'assistant',
    text:
      language === 'bn'
        ? 'আসসালামু আলাইকুম! আমি Abir—তোমার Android Assistant। আমি অফলাইন ও অনলাইন—দুইভাবেই কাজ করতে পারি। কী করতে হবে বলো?'
        : 'Hi! I’m Abir, your Android Assistant. I can work both offline and online. What would you like me to do?',
    time: Date.now(),
  };
}

function isSavedChat(value: unknown): value is SavedChat {
  if (!value || typeof value !== 'object') return false;
  const saved = value as Partial<SavedChat>;
  return (
    Array.isArray(saved.messages) &&
    (saved.language === 'bn' || saved.language === 'en') &&
    typeof saved.autoSpeak === 'boolean' &&
    saved.messages.every(
      (message) =>
        message &&
        typeof message.id === 'string' &&
        (message.role === 'assistant' || message.role === 'user') &&
        typeof message.text === 'string' &&
        typeof message.time === 'number',
    )
  );
}

function getTimeLabel(timestamp: number, language: AssistantLanguage) {
  return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
  }).format(timestamp);
}

function isCancelAppChoice(text: string) {
  return /^(?:cancel|never mind|nevermind|stop|থাক|বাদ দাও|বাতিল|না)$/i.test(
    text.trim(),
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([welcomeMessage('bn')]);
  const [language, setLanguage] = useState<AssistantLanguage>('bn');
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [voiceGender, setVoiceGender] = useState<VoiceGenderPreference>(DEFAULT_PREFERENCES.voiceGender);
  const [speechVoices, setSpeechVoices] = useState<SpeechVoice[]>([]);
  const [draft, setDraft] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(true);
  const [savedCameraUris, setSavedCameraUris] = useState<string[]>([]);
  const [cameraPreviewUri, setCameraPreviewUri] = useState<string | null>(null);
  const [ownerVerified, setOwnerVerified] = useState(false);
  const [appLockEnabled, setAppLockEnabled] = useState(false);
  const [appUnlocked, setAppUnlocked] = useState(false);
  const [securityLogs, setSecurityLogs] = useState<Array<{id:string;time:number;event:string;detail?:string}>>([]);
  const [memory, setMemory] = useState<AssistantMemory>(EMPTY_MEMORY);
  const [account, setAccount] = useState<{email:string;apiKey:string} | null>(null);
  const [accountLoggedIn, setAccountLoggedIn] = useState(false);
  const [accountReady, setAccountReady] = useState(false);
  const [accountEmail, setAccountEmail] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [accountApiKey, setAccountApiKey] = useState('');
  const [showAccountSetup, setShowAccountSetup] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [pendingAppChoices, setPendingAppChoices] = useState<
    LaunchableApp[] | null
  >(null);
  const [pendingContactChoices, setPendingContactChoices] = useState<
    ContactPhone[] | null
  >(null);
  const inputRef = useRef<TextInput>(null);
  const voicePulse = useRef(new Animated.Value(1)).current;
  const lastAssistantText = useRef<string | null>(null);

  useEffect(() => {
    if (!isListening) {
      voicePulse.stopAnimation();
      voicePulse.setValue(1);
      return;
    }

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(voicePulse, {
          toValue: 1.12,
          duration: 650,
          useNativeDriver: true,
        }),
        Animated.timing(voicePulse, {
          toValue: 1,
          duration: 650,
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => {
      loop.stop();
      voicePulse.setValue(1);
    };
  }, [isListening, voicePulse]);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!mounted || !stored) return;
        const parsed: unknown = JSON.parse(stored);
        if (!isSavedChat(parsed)) return;
        setMessages(parsed.messages);
        setLanguage(parsed.language);
        setAutoSpeak(parsed.autoSpeak);
      })
      .catch(() => {
        // A corrupt or unavailable local cache should not prevent a new chat.
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });

    Promise.all([
      AsyncStorage.getItem(APP_LOCK_KEY),
      SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY),
      SecureStore.getItemAsync(ACCOUNT_API_KEY),
      SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY),
      AsyncStorage.getItem(SECURITY_LOG_KEY),
    ]).then(([lock, email, key, savedPassword, logs]) => {
      setAppLockEnabled(lock === 'enabled');
      setAppUnlocked(lock !== 'enabled');
      if (email) {
        setAccountEmail(email);
        setAccountApiKey(key ?? '');
        setAccount({ email, apiKey: key ?? '' });
        setAccountLoggedIn(false);
      }
      if (logs) {
        try { const v = JSON.parse(logs); if (Array.isArray(v)) setSecurityLogs(v.slice(-MAX_SECURITY_LOGS)); } catch {}
      }
      setAccountReady(true);
    }).catch(() => setAccountReady(true));

    loadLocalMemory().then(setMemory).catch(() => setMemory(EMPTY_MEMORY));
    Promise.all([loadAssistantPreferences(), loadSpeechVoices()])
      .then(([preferences, voices]) => {
        setVoiceGender(preferences.voiceGender);
        setSpeechVoices(voices);
      })
      .catch(() => {});

    AsyncStorage.getItem(CAMERA_MEMORY_KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setSavedCameraUris(
            parsed
              .filter((value): value is string => typeof value === 'string')
              .slice(0, MAX_CAMERA_MEMORIES),
          );
        }
      })
      .catch(() => {});

    // Owner verification uses the phone's built-in biometric system.
    // Abir does not store or compare face/fingerprint templates itself.

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android' || isLoading) return;
    let mounted = true;
    const handleWakeUrl = async (url: string) => {
      if (!url.startsWith('abir-ai://wake')) return;
      const parsed = Linking.parse(url);
      const command = typeof parsed.queryParams?.text === 'string'
        ? parsed.queryParams.text.trim()
        : '';
      if (!mounted) return;
      if (command) {
        await sendText(command, true);
      } else {
        await startVoiceInput();
      }
    };

    const subscription = Linking.addEventListener('url', ({ url }) => {
      void handleWakeUrl(url);
    });
    void Linking.getInitialURL().then((url) => {
      if (url) void handleWakeUrl(url);
    });

    if (wakeWordEnabled) {
      void startWakeWord();
    }

    return () => {
      mounted = false;
      subscription.remove();
    };
  }, [isLoading, wakeWordEnabled]);

  useEffect(() => {
    if (isLoading) return;
    const saved: SavedChat = {
      messages: messages.slice(-MAX_MESSAGES),
      language,
      autoSpeak,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(saved)).catch(() => {
      Alert.alert(
        language === 'bn' ? 'চ্যাট সংরক্ষণ হয়নি' : 'Chat not saved',
        language === 'bn'
          ? 'এই ডিভাইসে চ্যাট সংরক্ষণ করা যায়নি।'
          : 'This chat could not be saved on this device.',
      );
    });
  }, [autoSpeak, isLoading, language, messages]);

  const speakMessage = async (message: Message) => {
    try {
      setSpeakingId(message.id);
      const speechLanguage: AssistantLanguage = /[\u0980-\u09FF]/.test(message.text) ? 'bn' : language;
      const selection = await speakAssistantText({
        text: message.text,
        language: speechLanguage,
        voiceGender,
        voices: speechVoices,
        onDone: () => setSpeakingId(null),
        onError: () => {
          setSpeakingId(null);
          Alert.alert(
            language === 'bn' ? 'ভয়েস পাওয়া যায়নি' : 'Voice unavailable',
            language === 'bn'
              ? 'ফোনের Text-to-Speech-এ বাংলা/পছন্দের ভয়েস ইনস্টল আছে কি না দেখে নাও।'
              : 'Check that the phone has a compatible Text-to-Speech voice installed.',
          );
        },
      });
      if (!selection.languageMatched && speechVoices.length) {
        // No hard failure: the TTS module already retries with the closest voice.
      }
    } catch {
      setSpeakingId(null);
    }
  };

  const repeatLastAssistantReply = async () => {
    const lastAssistant = [...messages].reverse().find(item => item.role === 'assistant');
    if (!lastAssistant) {
      Alert.alert(
        language === 'bn' ? 'এখনো কোনো উত্তর নেই' : 'No reply yet',
        language === 'bn' ? 'Abir-এর কোনো আগের উত্তর পাওয়া যায়নি।' : 'There is no previous Abir reply to repeat.',
      );
      return;
    }
    await speakMessage(lastAssistant);
  };

  const stopVoiceReply = async () => {
    try {
      await Speech.stop();
    } finally {
      setSpeakingId(null);
    }
  };

  const addSecurityLog = async (event: string, detail?: string) => {
    const entry = { id: createId(), time: Date.now(), event, detail };
    setSecurityLogs(current => {
      const next = [...current, entry].slice(-MAX_SECURITY_LOGS);
      AsyncStorage.setItem(SECURITY_LOG_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  const authenticateOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      if (!hasHardware || !enrolled) return false;
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'Abir AI আনলক করো' : 'Unlock Abir AI',
        promptSubtitle: 'Fingerprint/Face/PIN/Password',
        biometricsSecurityLevel: 'strong',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      await addSecurityLog(result.success ? 'unlock-success' : 'unlock-failed');
      return result.success;
    } catch {
      await addSecurityLog('unlock-error');
      return false;
    }
  };

  const configureAppLock = async () => {
    const ok = await authenticateOwner();
    if (!ok) {
      Alert.alert(
        language === 'bn' ? 'ভেরিফিকেশন দরকার' : 'Verification required',
        language === 'bn' ? 'ফোনের fingerprint/face/PIN/password দিয়ে যাচাই করো।' : 'Verify with the phone fingerprint/face/PIN/password.',
      );
      return;
    }
    const next = !appLockEnabled;
    await AsyncStorage.setItem(APP_LOCK_KEY, next ? 'enabled' : 'disabled');
    setAppLockEnabled(next);
    setAppUnlocked(true);
    await addSecurityLog(next ? 'app-lock-enabled' : 'app-lock-disabled');
    Alert.alert(
      next ? (language === 'bn' ? 'App Lock চালু' : 'App Lock enabled') : (language === 'bn' ? 'App Lock বন্ধ' : 'App Lock disabled'),
      next
        ? (language === 'bn' ? 'Abir background-এ গেলে আবার lock হবে।' : 'Abir will lock when it goes to the background.')
        : (language === 'bn' ? 'এখন আর App Lock থাকবে না।' : 'App Lock is now disabled.'),
    );
  };

  const saveAccount = async () => {
    const email = accountEmail.trim();
    const password = accountPassword.trim();
    const key = accountApiKey.trim();
    if (!email || !password) {
      Alert.alert(
        language === 'bn' ? 'তথ্য অসম্পূর্ণ' : 'Missing information',
        language === 'bn' ? 'Email এবং password দাও।' : 'Enter email and password.',
      );
      return;
    }
    await SecureStore.setItemAsync(ACCOUNT_EMAIL_KEY, email);
    await SecureStore.setItemAsync(ACCOUNT_PASSWORD_KEY, password);
    if (key) await SecureStore.setItemAsync(ACCOUNT_API_KEY, key);
    else await SecureStore.deleteItemAsync(ACCOUNT_API_KEY);
    const value = { email, apiKey: key };
    setAccount(value);
    setAccountLoggedIn(true);
    setAccountPassword('');
    setShowAccountSetup(false);
    await addSecurityLog('account-configured', email);
    Alert.alert(
      language === 'bn' ? 'Login সেট হয়েছে' : 'Login configured',
      language === 'bn' ? 'Email, password এবং API key এই ফোনে নিরাপদ storage-এ রাখা হয়েছে।' : 'Email, password and API key are stored in secure device storage.',
    );
  };

  const loginAccount = async () => {
    const email = accountEmail.trim();
    const password = accountPassword;
    const savedEmail = await SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY);
    const savedPassword = await SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY);
    if (email && password && email === savedEmail && password === savedPassword) {
      setAccountLoggedIn(true);
      setAccount({ email, apiKey: accountApiKey.trim() });
      setAccountPassword('');
      setShowAccountSetup(false);
      await addSecurityLog('account-login-success', email);
      return;
    }
    Alert.alert(language === 'bn' ? 'Login ব্যর্থ' : 'Login failed', language === 'bn' ? 'Email বা password ভুল।' : 'Email or password is incorrect.');
    await addSecurityLog('account-login-failed', email || 'unknown');
  };

  useEffect(() => {
    if (isLoading || !appLockEnabled) return;
    const sub = AppState.addEventListener('change', state => {
      if (state === 'background' || state === 'inactive') {
        setAppUnlocked(false);
        void addSecurityLog('app-backgrounded');
      }
      if (state === 'active' && !appUnlocked) {
        void authenticateOwner().then(setAppUnlocked);
      }
    });
    if (!appUnlocked) void authenticateOwner().then(setAppUnlocked);
    return () => sub.remove();
  }, [isLoading, appLockEnabled]);

  const sendText = async (rawText: string, forceSpeak = false) => {
    const text = rawText.trim();
    if (!text || isSending) return;

    Keyboard.dismiss();
    setDraft('');
    setIsSending(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

    const userMessage: Message = {
      id: createId(),
      role: 'user',
      text,
      time: Date.now(),
    };

    const responseLanguage = /[\u0980-\u09FF]/.test(text) ? 'bn' : language;

    // Voice-first convenience: repeat or stop can work immediately without
    // sending the phrase to Gemini or the offline fallback brain.
    if (/^(?:আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat that|say that again|say it again|again)$/i.test(text)) {
      const previous = lastAssistantText.current;
      if (previous) {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: previous, intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      } else {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'এখনো আবার বলার মতো কোনো আগের উত্তর নেই।' : 'There is no previous answer to repeat yet.', intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      }
      setIsSending(false);
      return;
    }
    if (/^(?:থামো|চুপ|চুপ করো|stop talking|stop speaking|be quiet)$/i.test(text)) {
      await Speech.stop();
      const stopMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'ঠিক আছে, কথা বলা থামালাম।' : 'Okay, I stopped speaking.', intent: 'casual', time: Date.now() };
      setMessages(current => [...current, userMessage, stopMessage].slice(-MAX_MESSAGES));
      setIsSending(false);
      return;
    }

    try {
      const memoryResult = handleMemoryCommand(text, memory);
      if (memoryResult) {
        setMemory(memoryResult.memory);
        await saveLocalMemory(memoryResult.memory);
        const assistantMessage: Message = {
          id: createId(), role: 'assistant', text: memoryResult.reply, intent: 'memory', time: Date.now(),
        };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      const messageRequest = extractMessageRequest(text);
      if (messageRequest && Platform.OS === 'android') {
        const enabled = await isAccessibilityEnabled();
        if (!enabled) {
          const responseText = messageAutomationReply(messageRequest, responseLanguage, 'not-enabled');
          const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
          setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
          await addSecurityLog('message-automation-blocked', `${messageRequest.app}:${messageRequest.recipient}`);
          Alert.alert(
            responseLanguage === 'bn' ? 'Accessibility দরকার' : 'Accessibility required',
            responseLanguage === 'bn' ? 'Messenger/IMO চালাতে Abir AI-কে Accessibility permission দিতে হবে। Settings খুলব?' : 'Abir AI needs Accessibility permission to operate Messenger/IMO. Open Settings?',
            [
              { text: responseLanguage === 'bn' ? 'না' : 'Cancel', style: 'cancel' },
              { text: 'Settings', onPress: () => void openAccessibilitySettings() },
            ],
          );
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }
        const sent = await sendMessageViaAccessibility(
          messagingPackage(messageRequest.app),
          messageRequest.recipient,
          messageRequest.message,
        );
        const responseText = messageAutomationReply(messageRequest, responseLanguage, sent ? 'sent' : 'failed');
        const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await addSecurityLog(sent ? 'message-sent' : 'message-failed', `${messageRequest.app}:${messageRequest.recipient}`);
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      if (pendingAppChoices && !extractAppQuery(text)) {
        if (isCancelAppChoice(text)) {
          setPendingAppChoices(null);
          const cancelledMessage: Message = {
            id: createId(),
            role: 'assistant',
            text:
              responseLanguage === 'bn'
                ? 'ঠিক আছে, অ্যাপ খোলা বাতিল করলাম।'
                : 'Okay, I cancelled opening an app.',
            time: Date.now(),
          };
          setMessages((current) =>
            [...current, userMessage, cancelledMessage].slice(-MAX_MESSAGES),
          );
          if (autoSpeak || forceSpeak) void speakMessage(cancelledMessage);
          return;
        }

        const selectedApp = selectAppChoice(text, pendingAppChoices);
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: selectedApp
            ? responseLanguage === 'bn'
              ? `${selectedApp.label} খুলছি…`
              : `Opening ${selectedApp.label}…`
            : appChoicePrompt(pendingAppChoices, responseLanguage),
          intent: 'open-app',
          time: Date.now(),
        };
        setMessages((current) =>
          [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES),
        );

        if (!selectedApp) {
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }

        setPendingAppChoices(null);
        const launchStatus = await launchInstalledApp(selectedApp);
        const responseText = appActionReply(
          launchStatus,
          selectedApp,
          responseLanguage,
        );
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? { ...message, text: responseText }
              : message,
          ),
        );
        if (autoSpeak || forceSpeak) {
          void speakMessage({ ...assistantMessage, text: responseText });
        }
        return;
      }

      if (pendingAppChoices) setPendingAppChoices(null);
      // Run the local command/brain first. This is important: device controls,
      // app opening, calls, memory and other deterministic actions must work
      // even with the internet completely disabled. Only unresolved questions
      // are sent to Gemini when online.
      const offlineReply = await getAssistantReply({
        text,
        language: responseLanguage,
        now: new Date(),
        memory,
      });
      const onlineText = offlineReply.intent === 'fallback' && optionalOnlineAssistant.enabled
        ? await optionalOnlineAssistant.respond({
            text,
            language: responseLanguage === 'bn' ? 'bn' : 'en',
          })
        : null;
      const reply = onlineText
        ? { text: onlineText, intent: 'fallback' as AssistantIntent }
        : offlineReply;
      const assistantMessage: Message = {
        id: createId(),
        role: 'assistant',
        text: reply.text,
        intent: reply.intent,
        time: Date.now(),
      };

      setMessages((current) => {
        const next =
          reply.intent === 'clear-history'
            ? [userMessage, assistantMessage]
            : [...current, userMessage, assistantMessage];
        return next.slice(-MAX_MESSAGES);
      });

      let finalAssistantMessage = assistantMessage;
      lastAssistantText.current = assistantMessage.text;
      if (reply.intent === 'clear-history') setPendingAppChoices(null);

      if (reply.intent === 'device-action' && reply.deviceAction) {
        let ok = false;
        if (reply.deviceAction === 'volume-up') ok = await adjustDeviceVolume('up');
        else if (reply.deviceAction === 'volume-down') ok = await adjustDeviceVolume('down');
        else if (reply.deviceAction === 'volume-mute') ok = await adjustDeviceVolume('mute');
        else if (reply.deviceAction === 'settings' || reply.deviceAction === 'wifi-settings' || reply.deviceAction === 'bluetooth-settings') {
          ok = await openSystemSettings(reply.deviceAction);
        } else {
          ok = await performDeviceAction(reply.deviceAction);
        }
        const responseText = ok
          ? reply.text
          : (responseLanguage === 'bn' ? 'এই ফোনে কাজটি করা গেল না। প্রয়োজনীয় Android permission/Accessibility চালু আছে কি না দেখে আবার চেষ্টা করো।' : 'I could not perform that action on this phone. Check the required Android permission/Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'screen-read') {
        const screenText = await readCurrentScreenText();
        const responseText = screenText
          ? (responseLanguage === 'bn' ? `বর্তমান স্ক্রিনে যা দেখা যাচ্ছে:\n${screenText}` : `Here is the readable text on the current screen:\n${screenText}`)
          : (responseLanguage === 'bn' ? 'বর্তমান স্ক্রিনের লেখা পড়তে পারিনি। Accessibility permission চালু আছে কি না দেখো।' : 'I could not read the current screen. Check Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'open-app' && reply.appQuery) {
        const discovery = await getLaunchableApps();
        let responseText: string;

        if (discovery.status !== 'available') {
          responseText = appDiscoveryReply(discovery.status, responseLanguage);
        } else {
          const matches = matchInstalledApps(reply.appQuery, discovery.apps);
          if (matches.length === 0) {
            responseText = noMatchingAppReply(reply.appQuery);
          } else if (matches.length > 1) {
            const choices = matches.slice(0, 8);
            setPendingAppChoices(choices);
            responseText = appChoicePrompt(choices, responseLanguage);
          } else {
            const launchStatus = await launchInstalledApp(matches[0]);
            responseText = appActionReply(
              launchStatus,
              matches[0],
              responseLanguage,
            );
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      if (reply.intent === 'call-contact' && reply.contactQuery) {
        let responseText = reply.text;
        const directPhoneNumber = extractDirectPhoneNumber(reply.contactQuery);

        if (directPhoneNumber) {
          if (Platform.OS === 'android') {
            const permission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CALL_PHONE,
            );
            if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText =
                responseLanguage === 'bn'
                  ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                  : 'Phone-call permission was not granted. Allow it and try again.';
            } else {
              const callStatus = await placeDirectCall(directPhoneNumber);
              responseText =
                callStatus === 'placed'
                  ? responseLanguage === 'bn'
                    ? `${directPhoneNumber}-এ কল দিচ্ছি।`
                    : `Calling ${directPhoneNumber}.`
                  : responseLanguage === 'bn'
                    ? 'এই নম্বরে কল দেওয়া গেল না।'
                    : 'I could not place the call to this number.';
            }
          } else {
            responseText =
              responseLanguage === 'bn'
                ? 'এই ডিভাইস থেকে সরাসরি ফোন কল সমর্থিত নয়।'
                : 'Direct phone calls are not supported on this device.';
          }
        } else {
          const contactsResult = await getDeviceContacts();

          if (contactsResult.status !== 'available') {
            responseText =
              responseLanguage === 'bn'
                ? 'পরিচিতির নম্বর পড়া গেল না। Contacts অনুমতি চালু আছে কি না দেখে আবার চেষ্টা করো।'
                : 'I could not read your contacts. Check Contacts permission and try again.';
          } else {
            const matches = matchContacts(reply.contactQuery, contactsResult.contacts);
            if (matches.length === 0) {
              responseText =
                responseLanguage === 'bn'
                  ? `${reply.contactQuery} নামে কোনো পরিচিতি খুঁজে পেলাম না।`
                  : `I couldn’t find a contact named ${reply.contactQuery}.`;
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingContactChoices(choices);
              responseText = formatContactChoicePrompt(choices, responseLanguage);
            } else {
              const contact = matches[0];
              if (Platform.OS === 'android') {
                const permission = await PermissionsAndroid.request(
                  PermissionsAndroid.PERMISSIONS.CALL_PHONE,
                );
                if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
                  responseText =
                    responseLanguage === 'bn'
                      ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                      : 'Phone-call permission was not granted. Allow it and try again.';
                } else {
                  const callStatus = await placeDirectCall(contact.phoneNumber);
                  responseText =
                    callStatus === 'placed'
                      ? responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দিচ্ছি।`
                        : `Calling ${contact.displayName}.`
                      : responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দেওয়া গেল না।`
                        : `I couldn’t call ${contact.displayName}.`;
                }
              }
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      const updatedMemory = addRecentTopic(memory, text);
      if (updatedMemory !== memory) {
        setMemory(updatedMemory);
        await saveLocalMemory(updatedMemory);
      }
      if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
    } finally {
      setIsSending(false);
    }
  };

  const captureCameraPhoto = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          language === 'bn' ? 'ক্যামেরা অনুমতি দরকার' : 'Camera permission needed',
          language === 'bn' ? 'ক্যামেরা চালু করার অনুমতি দাও।' : 'Allow camera access to take a photo.',
        );
        return;
      }
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: false,
        base64: true,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const asset = result.assets[0];
      const uri = asset.uri;
      setCameraPreviewUri(uri);

      // The camera is for showing Abir something, not for building a personal
      // photo collection. Keep only the current preview URI locally.
      setSavedCameraUris([uri]);

      if (!asset.base64) {
        const fallback = language === 'bn'
          ? 'ছবিটি পাওয়া গেছে, কিন্তু বিশ্লেষণের জন্য ছবির ডেটা পাওয়া যায়নি। আবার চেষ্টা করো।'
          : 'I got the photo, but could not read its image data for analysis. Please try again.';
        await sendText(fallback, true);
        return;
      }

      setIsSending(true);
      try {
        const onlineText = optionalOnlineAssistant.enabled
          ? await optionalOnlineAssistant.respond({
              text: language === 'bn'
                ? 'এই ছবিটা দেখে বলো এখানে কী আছে। যা নিশ্চিতভাবে দেখা যাচ্ছে শুধু সেটাই বলো। মানুষ থাকলে পরিচয় অনুমান করবে না; শুধু দৃশ্যমান বৈশিষ্ট্য ও পরিস্থিতি বর্ণনা করো।'
                : 'Look at this image and tell me what is in it. Only state what is visibly supported. If a person is present, do not guess their identity; describe only visible features and context.',
              language: language === 'bn' ? 'bn' : 'en',
              imageBase64: asset.base64,
              imageMimeType: asset.mimeType || 'image/jpeg',
            })
          : null;

        const responseText = onlineText || (language === 'bn'
          ? 'ছবিটা দেখেছি, কিন্তু এখন অনলাইন Gemini চালু নেই—তাই ছবিটা কী তা বিশ্লেষণ করতে পারছি না।'
          : 'I received the image, but Gemini is not available online right now, so I cannot analyze what is in it.');

        const userMessage: Message = {
          id: createId(),
          role: 'user',
          text: language === 'bn' ? '📷 এটা কী?' : '📷 What is this?',
          time: Date.now(),
        };
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: responseText,
          intent: 'fallback',
          time: Date.now(),
        };
        setMessages((current) => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await speakMessage(assistantMessage);
      } finally {
        setIsSending(false);
      }
    } catch {
      Alert.alert(
        language === 'bn' ? 'ক্যামেরা খোলা যায়নি' : 'Camera unavailable',
        language === 'bn' ? 'আবার চেষ্টা করো।' : 'Please try again.',
      );
    }
  };

  const verifyOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      if (!hasHardware || !enrolled) {
        Alert.alert(
          language === 'bn' ? 'Owner verification সেট করা নেই' : 'Owner verification unavailable',
          language === 'bn'
            ? 'ফোনের Settings থেকে fingerprint/face unlock সেট করলে Abir সেটা দিয়ে তোমাকে যাচাই করতে পারবে।'
            : 'Set up fingerprint or face unlock in phone Settings so Abir can verify the device owner.',
        );
        return false;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'এটা কি তুমি?' : 'Is this you?',
        promptSubtitle: 'Abir AI owner verification',
        biometricsSecurityLevel: 'strong',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      const verified = result.success;
      setOwnerVerified(verified);
      Alert.alert(
        verified
          ? language === 'bn' ? 'তুমি যাচাই হয়েছ' : 'Owner verified'
          : language === 'bn' ? 'যাচাই হয়নি' : 'Not verified',
        verified
          ? language === 'bn' ? 'এই সেশনে Abir তোমাকে ফোনের মালিক হিসেবে ধরবে।' : 'Abir will treat you as the verified device owner for this session.'
          : language === 'bn' ? 'ভেরিফিকেশন সফল হয়নি।' : 'The verification did not succeed.',
      );
      return verified;
    } catch {
      setOwnerVerified(false);
      return false;
    }
  };

  const startVoiceInput = async () => {
    if (isListening || isSending) return;
    setIsListening(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    try {
      // Voice commands are a conversational mode: always read the action/reply
      // aloud so the user can operate Abir AI without touching the keyboard.
      if (!autoSpeak) setAutoSpeak(true);

      const recognizedText = await listenForText(language);
      if (recognizedText) {
        await sendText(recognizedText, true);
      } else {
        const message: Message = {
          id: createId(),
          role: 'assistant',
          text: language === 'bn'
            ? 'আমি শুনতে পাইনি। আবার বলো—যেমন “Abir YouTube খোলো” বা “আবির ভলিউম কমাও”।'
            : 'I didn’t catch that. Try again, for example: “Abir open YouTube” or “Abir lower the volume.”',
          time: Date.now(),
          intent: 'fallback',
        };
        setMessages(current => [...current, message].slice(-MAX_MESSAGES));
        await speakMessage(message);
      }
    } catch (error) {
      Alert.alert(
        language === 'bn' ? 'ভয়েস ইনপুট কাজ করেনি' : 'Voice input unavailable',
        error instanceof Error
          ? error.message
          : language === 'bn'
            ? 'মাইক্রোফোন বা স্পিচ সার্ভিসটি পরীক্ষা করে আবার চেষ্টা করো।'
            : 'Check microphone or speech-service availability and try again.',
      );
    } finally {
      setIsListening(false);
    }
  };

  const confirmClear = () => {
    Alert.alert(
      language === 'bn' ? 'চ্যাট পরিষ্কার করবে?' : 'Clear this chat?',
      language === 'bn'
        ? 'সংরক্ষিত কথোপকথন মুছে যাবে।'
        : 'Your saved conversation will be deleted.',
      [
        { text: language === 'bn' ? 'থাক' : 'Cancel', style: 'cancel' },
        {
          text: language === 'bn' ? 'মুছে দাও' : 'Clear',
          style: 'destructive',
          onPress: () => {
            setMessages([welcomeMessage(language)]);
            void Speech.stop();
          },
        },
      ],
    );
  };

  const suggestions =
    language === 'bn'
      ? [
          'একটা কৌতুক বলো',
          'এখন সময় কত?',
          '২ + ২',
          'তুমি কী করতে পারো?',
          'WhatsApp ওপেন করো',
          'YouTube ওপেন করো',
        ]
      : [
          'Tell me a joke',
          'What time is it?',
          '2 + 2',
          'What can you do?',
          'Open WhatsApp',
          'Open YouTube',
        ];

  const inputBackground = { backgroundColor: colors.card };
  const bottomInset =
    Platform.OS === 'web' ? 34 : Math.max(insets.bottom, 10);
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <KeyboardAvoidingView
        style={styles.keyboardFrame}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        <View style={[styles.header, { paddingTop: topInset + 10 }]}>
          <View style={styles.brand}>
            <View
              style={[
                styles.brandMark,
                { backgroundColor: colors.accentSoft, borderColor: colors.border },
              ]}
            >
              <UiIcon name="sparkles" size={21} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.title, { color: colors.foreground }]}>
                Abir AI
              </Text>
              <View style={styles.subtitleRow}>
                <View
                  style={[styles.onlineDot, { backgroundColor: colors.primary }]}
                />
                <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'Android Assistant · Offline + Online' : 'Android Assistant · Offline + Online'}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.headerActions}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'Login / Account খুলুন' : 'Open Login / Account'}
              testID="header-account"
              onPress={() => setShowAccountSetup(true)}
              style={({ pressed }) => [
                styles.headerAccountButton,
                {
                  backgroundColor: accountLoggedIn ? colors.accentSoft : colors.card,
                  borderColor: accountLoggedIn ? colors.primary : colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <UiIcon name="person" size={17} color={colors.primary} />
              <Text style={[styles.headerAccountText, { color: colors.foreground }]}>
                {accountLoggedIn ? '✓' : 'ID'}
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                language === 'bn' ? 'ভাষা বদলাও' : 'Change language'
              }
              testID="language-toggle"
              onPress={() =>
                setLanguage((current) => (current === 'bn' ? 'en' : 'bn'))
              }
              style={({ pressed }) => [
                styles.languageButton,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.languageText, { color: colors.foreground }]}>
                {language === 'bn' ? 'EN' : 'বাংলা'}
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                wakeWordEnabled
                  ? language === 'bn' ? 'আবির ওয়েক-ওয়ার্ড বন্ধ' : 'Turn off Abir wake word'
                  : language === 'bn' ? 'আবির ওয়েক-ওয়ার্ড চালু' : 'Turn on Abir wake word'
              }
              testID="wake-word-toggle"
              onPress={() => {
                setWakeWordEnabled((current) => {
                  const next = !current;
                  void (next ? startWakeWord() : stopWakeWord());
                  return next;
                });
              }}
              style={({ pressed }) => [
                styles.iconButton,
                {
                  backgroundColor: wakeWordEnabled ? colors.accent : colors.card,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <UiIcon
                name="mic"
                size={19}
                color={wakeWordEnabled ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                autoSpeak
                  ? language === 'bn'
                    ? 'স্বয়ংক্রিয় ভয়েস বন্ধ'
                    : 'Turn off automatic voice replies'
                  : language === 'bn'
                    ? 'স্বয়ংক্রিয় ভয়েস চালু'
                    : 'Turn on automatic voice replies'
              }
              testID="auto-speech-toggle"
              onPress={() => setAutoSpeak((current) => !current)}
              style={({ pressed }) => [
                styles.iconButton,
                {
                  backgroundColor: autoSpeak ? colors.accent : colors.card,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <UiIcon
                name={autoSpeak ? 'volume-high' : 'volume-mute'}
                size={19}
                color={autoSpeak ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'ভয়েস বদলাও' : 'Change voice'}
              testID="voice-gender-toggle"
              onPress={() => {
                const next: VoiceGenderPreference = voiceGender === 'female' ? 'male' : 'female';
                setVoiceGender(next);
                void loadAssistantPreferences().then(current => saveAssistantPreferences({ ...current, voiceGender: next })).catch(() => {});
              }}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Text style={[styles.languageText, { color: colors.foreground, fontSize: 12 }]}>
                {voiceGender === 'female' ? '♀' : '♂'}
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'চ্যাট পরিষ্কার' : 'Clear chat'}
              testID="clear-chat"
              onPress={confirmClear}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <UiIcon name="trash" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>
        </View>

        <FlatList
          inverted
          data={[...messages].reverse()}
          keyExtractor={(item) => item.id}
          style={styles.messages}
          contentContainerStyle={styles.messageList}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          scrollEnabled={messages.length > 0}
          renderItem={({ item }) => {
            const isUser = item.role === 'user';
            if (isLoading || !accountReady || (appLockEnabled && !appUnlocked)) {
    return (
      <View style={[styles.lockScreen, { backgroundColor: colors.background }]}>
        <StatusBar style="light" />
        <UiIcon name="shield" size={54} color={colors.primary} />
        <Text style={[styles.lockTitle, { color: colors.foreground }]}>
          {accountReady
            ? (!accountLoggedIn ? (language === 'bn' ? 'Abir AI Login করো' : 'Log in to Abir AI') : (language === 'bn' ? 'Abir AI লক করা আছে' : 'Abir AI is locked'))
            : (language === 'bn' ? 'Abir AI প্রস্তুত হচ্ছে…' : 'Preparing Abir AI…')}
        </Text>
        <Text style={[styles.lockText, { color: colors.mutedForeground }]}>
          {!accountLoggedIn ? (language === 'bn' ? 'Email, password এবং API key দিয়ে Login করো।' : 'Log in with email, password and API key.') : (language === 'bn' ? 'Fingerprint/Face/PIN/Password দিয়ে আনলক করো।' : 'Unlock with your phone fingerprint/face/PIN/password.')}
        </Text>
        <Pressable onPress={() => void authenticateOwner().then(setAppUnlocked)} style={[styles.unlockButton, { backgroundColor: colors.primary }]}>
          <Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>{language === 'bn' ? 'আনলক' : 'Unlock'}</Text>
        </Pressable>
        <Pressable onPress={() => setShowAccountSetup(true)} style={[styles.accountLink, { borderColor: colors.border }]}>
          <Text style={{ color: colors.foreground }}>{language === 'bn' ? 'Account / API Key' : 'Account / API Key'}</Text>
        </Pressable>
      </View>
    );
  }

  return (
              <View
                style={[
                  styles.messageRow,
                  isUser ? styles.userRow : styles.assistantRow,
                ]}
              >
                {!isUser && (
                  <View
                    style={[
                      styles.messageAvatar,
                      { backgroundColor: colors.accentSoft },
                    ]}
                  >
                    <UiIcon name="sparkles" size={13} color={colors.primary} />
                  </View>
                )}
                <View style={styles.messageBody}>
                  <View
                    style={[
                      styles.messageBubble,
                      {
                        backgroundColor: isUser
                          ? colors.userBubble
                          : colors.assistantBubble,
                        borderColor: colors.border,
                      },
                      isUser && styles.userBubble,
                    ]}
                  >
                    <Text
                      selectable
                      style={[
                        styles.messageText,
                        { color: colors.foreground },
                        isUser && styles.userMessageText,
                      ]}
                    >
                      {item.text}
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.messageMeta,
                      isUser && styles.userMeta,
                    ]}
                  >
                    <Text
                      style={[
                        styles.timeText,
                        { color: colors.mutedForeground },
                      ]}
                    >
                      {getTimeLabel(item.time, language)}
                    </Text>
                    {!isUser && (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={
                          language === 'bn' ? 'উত্তরটি শোনো' : 'Play voice reply'
                        }
                        testID={`speak-${item.id}`}
                        onPress={() => void speakMessage(item)}
                        hitSlop={8}
                      >
                        <UiIcon
                          name={speakingId === item.id ? 'volume-high' : 'volume-medium'}
                          size={15}
                          color={colors.mutedForeground}
                        />
                      </Pressable>
                    )}
                  </View>
                </View>
              </View>
            );
          }}
          ListHeaderComponent={
            isSending ? (
              <View style={[styles.typingRow, { borderColor: colors.border }]}>
                <ActivityIndicator size="small" color={colors.primary} />
                <Text style={[styles.typingText, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'একটু ভাবছি…' : 'Thinking…'}
                </Text>
              </View>
            ) : null
          }
        />

        <View style={[styles.composerArea, { paddingBottom: bottomInset }]}>
          {messages.length <= 1 && (
            <View style={styles.suggestions}>
              {suggestions.map((suggestion) => (
                <Pressable
                  key={suggestion}
                  accessibilityRole="button"
                  testID={`suggestion-${suggestion}`}
                  onPress={() => void sendText(suggestion)}
                  style={({ pressed }) => [
                    styles.suggestionChip,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.border,
                      opacity: pressed ? 0.65 : 1,
                    },
                  ]}
                >
                  <Text
                    numberOfLines={1}
                    style={[styles.suggestionText, { color: colors.secondaryForeground }]}
                  >
                    {suggestion}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          <View
            style={[
              styles.composer,
              inputBackground,
              { borderColor: colors.input },
            ]}
          >
            <TextInput
              ref={inputRef}
              testID="chat-input"
              value={draft}
              onChangeText={setDraft}
              onSubmitEditing={() => void sendText(draft)}
              placeholder={
                language === 'bn' ? 'আবিরকে কিছু জিজ্ঞেস করো…' : 'Message Abir…'
              }
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.foreground }]}
              multiline
              maxLength={1000}
              returnKeyType="send"
              blurOnSubmit={false}
              accessibilityLabel={
                language === 'bn' ? 'বার্তা লিখুন' : 'Type a message'
              }
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                isListening
                  ? language === 'bn'
                    ? 'শুনছে'
                    : 'Listening'
                  : language === 'bn'
                    ? 'ভয়েস ইনপুট'
                    : 'Voice input'
              }
              testID="voice-input"
              disabled={isListening || isSending}
              onPress={() => void startVoiceInput()}
              style={({ pressed }) => [
                styles.composerIcon,
                {
                  backgroundColor: isListening ? colors.accent : 'transparent',
                  opacity: pressed ? 0.65 : 1,
                },
              ]}
            >
              {isListening ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <UiIcon name="mic" size={21} color={colors.mutedForeground} />
              )}
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'বার্তা পাঠান' : 'Send message'}
              testID="send-message"
              disabled={!draft.trim() || isSending}
              onPress={() => void sendText(draft)}
              style={({ pressed }) => [
                styles.sendButton,
                {
                  backgroundColor: colors.primary,
                  opacity: !draft.trim() || isSending ? 0.45 : pressed ? 0.75 : 1,
                },
              ]}
            >
              <UiIcon name="arrow-up" size={21} color={colors.primaryForeground} />
            </Pressable>
          </View>
          <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
            {language === 'bn'
              ? 'Android Assistant · Offline + Online · দ্রুত কাজ আগে লোকালেই চেষ্টা করি'
              : 'Android Assistant · Offline + Online · local commands first'}
          </Text>
        </View>
      </KeyboardAvoidingView>

      <View style={[styles.floatingTools, { bottom: Math.max(insets.bottom, 12) + 83 }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={language === 'bn' ? 'শেষ উত্তর আবার শোনো' : 'Repeat last reply'}
          onPress={() => void repeatLastAssistantReply()}
          style={({ pressed }) => [styles.smallFloatingButton, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        >
          <UiIcon name="volume-medium" size={19} color={colors.primary} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={language === 'bn' ? 'ভয়েস থামাও' : 'Stop voice'}
          onPress={() => void stopVoiceReply()}
          style={({ pressed }) => [styles.smallFloatingButton, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        >
          <UiIcon name="volume-mute" size={19} color={colors.mutedForeground} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={language === 'bn' ? 'ক্যামেরা' : 'Camera'}
          onPress={() => void captureCameraPhoto()}
          style={({ pressed }) => [styles.smallFloatingButton, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        >
          <UiIcon name="camera" size={20} color={colors.primary} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={language === 'bn' ? 'App Lock' : 'App Lock'}
          onPress={() => void configureAppLock()}
          style={({ pressed }) => [styles.smallFloatingButton, { backgroundColor: ownerVerified ? colors.accent : colors.card, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        >
          <UiIcon name="shield" size={20} color={ownerVerified ? colors.primary : colors.mutedForeground} />
        </Pressable>
      </View>

      <Animated.View
        pointerEvents="box-none"
        style={[
          styles.voiceBubbleWrap,
          {
            bottom: Math.max(insets.bottom, 12) + 76,
            transform: [{ scale: voicePulse }],
          },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={
            isListening
              ? language === 'bn' ? 'আবির শুনছে' : 'Abir is listening'
              : language === 'bn' ? 'কথা বলো' : 'Talk to Abir'
          }
          testID="floating-voice-bubble"
          disabled={isListening || isSending}
          onPress={() => void startVoiceInput()}
          style={({ pressed }) => [
            styles.voiceBubble,
            {
              backgroundColor: isListening ? colors.primary : colors.card,
              borderColor: colors.border,
              opacity: pressed ? 0.75 : isSending ? 0.45 : 1,
            },
          ]}
        >
          {isListening ? (
            <ActivityIndicator size="small" color={colors.primaryForeground} />
          ) : (
            <UiIcon name="mic" size={24} color={colors.primary} />
          )}
        </Pressable>
      </Animated.View>

      <Modal
        visible={Boolean(cameraPreviewUri)}
        transparent
        animationType="fade"
        onRequestClose={() => setCameraPreviewUri(null)}
      >
        <View style={styles.cameraModal}>
          <View style={styles.cameraCard}>
            <Text style={[styles.cameraTitle, { color: colors.foreground }]}>
              {language === 'bn' ? 'তোলা ছবি' : 'Captured photo'}
            </Text>
            {cameraPreviewUri ? (
              <Image source={{ uri: cameraPreviewUri }} style={styles.cameraImage} resizeMode="contain" />
            ) : null}
            <Text style={[styles.cameraHint, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? `${savedCameraUris.length}টি ছবি এই ডিভাইসে রাখা হয়েছে। এগুলো Abir-এর face-recognition database নয়।`
                : `${savedCameraUris.length} photos are kept on this device. They are not used as an Abir face-recognition database.`}
            </Text>
            <Pressable
              onPress={() => setCameraPreviewUri(null)}
              style={[styles.cameraCloseButton, { backgroundColor: colors.primary }]}
            >
              <Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>
                {language === 'bn' ? 'বন্ধ' : 'Close'}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showAccountSetup} transparent animationType="slide" onRequestClose={() => setShowAccountSetup(false)}>
        <View style={styles.accountOverlay}>
          <View style={[styles.accountCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 22 }]}>Abir Account</Text>
            <Text style={[styles.lockText, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? 'নতুন ফোনে একই settings/API key ব্যবহার করার জন্য email ও API key রাখতে পারো। Password এখানে সংরক্ষণ করা হয় না।'
                : 'Save your email and API key for device setup. Your password is not stored in this app.'}
            </Text>
            <TextInput value={accountEmail} onChangeText={setAccountEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountPassword} onChangeText={setAccountPassword} secureTextEntry placeholder={language === 'bn' ? 'Password' : 'Password'} placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountApiKey} onChangeText={setAccountApiKey} autoCapitalize="none" placeholder="Gemini API key" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <Pressable onPress={() => setShowAccountSetup(false)} style={[styles.accountAction, { borderColor: colors.border }]}><Text style={{ color: colors.foreground }}>{language === 'bn' ? 'বন্ধ' : 'Close'}</Text></Pressable>
              <Pressable onPress={() => void (accountLoggedIn ? loginAccount() : saveAccount())} style={[styles.accountAction, { backgroundColor: colors.primary, borderColor: colors.primary }]}><Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>{accountLoggedIn ? (language === 'bn' ? 'Login' : 'Login') : (language === 'bn' ? 'Create/Login' : 'Create/Login')}</Text></Pressable>
            </View>
            <Text style={[styles.footerNote, { color: colors.mutedForeground, marginTop: 12 }]}>
              {account ? `${language === 'bn' ? 'Configured:' : 'Configured:'} ${account.email}` : (language === 'bn' ? 'Account এখনো সেট করা হয়নি।' : 'No account configured yet.')}
            </Text>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  keyboardFrame: { flex: 1 },
  header: {
    minHeight: 78,
    paddingHorizontal: 18,
    paddingBottom: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: {
    width: 42,
    height: 42,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: -0.3 },
  subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  onlineDot: { width: 6, height: 6, borderRadius: 3 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  headerAccountButton: {
    minWidth: 42,
    height: 38,
    paddingHorizontal: 9,
    borderRadius: 13,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  headerAccountText: { fontSize: 11, fontWeight: '800' },
  languageButton: {
    minWidth: 42,
    height: 36,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  languageText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  messages: { flex: 1 },
  messageList: {
    paddingHorizontal: 17,
    paddingTop: 15,
    paddingBottom: 14,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  messageRow: { flexDirection: 'row', marginBottom: 18, gap: 8, maxWidth: '90%' },
  assistantRow: { alignSelf: 'flex-start', alignItems: 'flex-end' },
  userRow: { alignSelf: 'flex-end' },
  messageAvatar: {
    width: 23,
    height: 23,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  messageBody: { flexShrink: 1 },
  messageBubble: {
    borderWidth: 1,
    borderRadius: 18,
    borderBottomLeftRadius: 6,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  userBubble: { borderBottomLeftRadius: 18, borderBottomRightRadius: 6 },
  messageText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 23,
    letterSpacing: 0.05,
  },
  userMessageText: { fontFamily: 'Inter_500Medium' },
  messageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 5,
    marginLeft: 3,
  },
  userMeta: { justifyContent: 'flex-end', marginRight: 2 },
  timeText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  typingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginLeft: 31,
    marginBottom: 14,
  },
  typingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  composerArea: { paddingHorizontal: 14, paddingTop: 8, gap: 9 },
  suggestions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
    paddingBottom: 1,
  },
  suggestionChip: {
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 11,
    paddingVertical: 8,
    maxWidth: '100%',
  },
  suggestionText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  composer: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingLeft: 13,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 4,
  },
  input: {
    flex: 1,
    maxHeight: 112,
    minHeight: 39,
    paddingTop: 9,
    paddingBottom: 7,
    paddingRight: 5,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 21,
  },
  composerIcon: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButton: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  floatingTools: {
    position: 'absolute',
    right: 88,
    zIndex: 20,
    flexDirection: 'row',
    gap: 8,
  },
  smallFloatingButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
    shadowOpacity: 0.18,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  cameraModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 22,
  },
  cameraCard: {
    width: '100%',
    maxWidth: 420,
    borderRadius: 24,
    padding: 18,
    backgroundColor: '#12191A',
  },
  cameraTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  cameraImage: {
    width: '100%',
    height: 320,
    borderRadius: 16,
    backgroundColor: '#050707',
  },
  cameraHint: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 10,
  },
  cameraCloseButton: {
    alignSelf: 'flex-end',
    marginTop: 14,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 14,
  },
  voiceBubbleWrap: {
    position: 'absolute',
    right: 18,
    zIndex: 20,
  },
  voiceBubble: {
    width: 58,
    height: 58,
    borderRadius: 29,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 7,
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  footerNote: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    paddingHorizontal: 4,
    paddingBottom: 2,
  },

  lockScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  lockTitle: { marginTop: 18, fontSize: 24, fontWeight: '800', textAlign: 'center' },
  lockText: { marginTop: 10, fontSize: 15, lineHeight: 22, textAlign: 'center' },
  unlockButton: { marginTop: 22, minWidth: 150, alignItems: 'center', paddingVertical: 13, paddingHorizontal: 24, borderRadius: 18 },
  accountLink: { marginTop: 12, paddingVertical: 10, paddingHorizontal: 18, borderWidth: 1, borderRadius: 14 },
  accountOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.58)' },
  accountCard: { borderTopWidth: 1, borderLeftWidth: 1, borderRightWidth: 1, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 30 },
  accountInput: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginTop: 10 },
  accountAction: { flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 14, borderWidth: 1 },
});
