package expo.modules.abirapp

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.SpeechRecognizer
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.util.Locale

class AbirAppLauncherModule : Module() {
  private fun launcherActivities(): List<ResolveInfo> {
    val context = appContext.reactContext
      ?: throw IllegalStateException("Android context is unavailable")
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val packageManager = context.packageManager

    @Suppress("DEPRECATION")
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      packageManager.queryIntentActivities(
        intent,
        PackageManager.ResolveInfoFlags.of(0L)
      )
    } else {
      packageManager.queryIntentActivities(intent, 0)
    }
  }

  override fun definition() = ModuleDefinition {
    Name("AbirAppLauncher")


    AsyncFunction("startWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Microphone permission has not been granted")
      }
      val intent = Intent(context, WakeWordService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
      true
    }

    AsyncFunction("stopWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.stopService(Intent(context, WakeWordService::class.java))
      true
    }

    AsyncFunction("isAccessibilityEnabled") {
      AbirAccessibilityService.isRunning()
    }

    AsyncFunction("performGlobalAction") { action: String ->
      AbirAccessibilityService.performGlobal(action)
    }

    AsyncFunction("readCurrentScreenText") {
      AbirAccessibilityService.readScreen()
    }

    AsyncFunction("adjustVolume") { direction: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      when (direction.lowercase(Locale.ROOT)) {
        "up" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_RAISE, 0)
        "down" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_LOWER, 0)
        "mute" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_MUTE, 0)
        else -> return@AsyncFunction false
      }
      true
    }

    AsyncFunction("openSystemSettings") { kind: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val action = when (kind.lowercase(Locale.ROOT)) {
        "wifi-settings" -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth-settings" -> Settings.ACTION_BLUETOOTH_SETTINGS
        else -> Settings.ACTION_SETTINGS
      }
      context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      true
    }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
      true
    }

    AsyncFunction("sendMessageViaAccessibility") {
      packageName: String, recipient: String, message: String ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.sendMessage(packageName, recipient, message) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(12, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("isOnline") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val manager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
          ?: return@AsyncFunction false
      val activeNetwork = manager.activeNetwork ?: return@AsyncFunction false
      val capabilities = manager.getNetworkCapabilities(activeNetwork)
        ?: return@AsyncFunction false
      capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    AsyncFunction("isOfflineSpeechRecognitionAvailable") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        false
      } else {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
      }
    }

    // True on-device speech recognition. This path never asks the network for speech data.
    // Android 12+ is required for the on-device recognizer API.
    AsyncFunction("recognizeOffline") Coroutine { localeTag: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
        return@Coroutine emptyList<String>()
      }

      kotlinx.coroutines.suspendCancellableCoroutine<List<String>> { continuation ->
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var recognizer: SpeechRecognizer? = null
        val cleanup = {
          try { recognizer?.destroy() } catch (_: Exception) {}
          recognizer = null
        }

        mainHandler.post {
          try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
              override fun onReadyForSpeech(params: android.os.Bundle?) {}
              override fun onBeginningOfSpeech() {}
              override fun onRmsChanged(rmsdB: Float) {}
              override fun onBufferReceived(buffer: ByteArray?) {}
              override fun onEndOfSpeech() {}
              override fun onPartialResults(partialResults: android.os.Bundle?) {}
              override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
              override fun onError(error: Int) {
                if (continuation.isActive) continuation.resume(emptyList()) {}
                cleanup()
              }
              override fun onResults(results: android.os.Bundle?) {
                val matches = results
                  ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                  ?.filter { it.isNotBlank() }
                  ?.take(5)
                  ?: emptyList()
                if (continuation.isActive) continuation.resume(matches) {}
                cleanup()
              }
            })

            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
              putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            }
            recognizer?.startListening(intent)
          } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(emptyList()) {}
            cleanup()
          }
        }

        continuation.invokeOnCancellation {
          mainHandler.post { cleanup() }
        }
      }
    }

    AsyncFunction("getContacts") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Contacts permission has not been granted")
      }

      val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.TYPE,
        ContactsContract.CommonDataKinds.Phone.LABEL
      )
      val contacts = linkedMapOf<String, Map<String, String>>()
      context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection,
        null,
        null,
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
      )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        val nameColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val typeColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
        val labelColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)

        while (cursor.moveToNext()) {
          val id = cursor.getString(idColumn) ?: continue
          val name = cursor.getString(nameColumn)?.trim().orEmpty()
          val number = cursor.getString(numberColumn)?.trim().orEmpty()
          if (name.isBlank() || number.isBlank()) continue

          val type = cursor.getInt(typeColumn)
          val customLabel = cursor.getString(labelColumn)
          val phoneLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
            context.resources,
            type,
            customLabel
          ).toString()
          val key = "$id:$number"
          contacts.putIfAbsent(
            key,
            mapOf(
              "contactId" to id,
              "displayName" to name,
              "phoneNumber" to number,
              "phoneLabel" to phoneLabel
            )
          )
        }
      }
      contacts.values.toList()
    }

    AsyncFunction("getLaunchableApps") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val packageManager = context.packageManager

      launcherActivities()
        .groupBy { it.activityInfo.packageName }
        .mapNotNull { (packageName, activities) ->
          val defaultActivityName =
            packageManager.getLaunchIntentForPackage(packageName)?.component?.className
          val activity = activities.firstOrNull {
            it.activityInfo.name == defaultActivityName
          } ?: activities.firstOrNull() ?: return@mapNotNull null
          val label = activity.activityInfo.applicationInfo
            .loadLabel(packageManager)
            .toString()
            .trim()

          if (label.isBlank()) return@mapNotNull null

          mapOf(
            "label" to label,
            "packageName" to packageName,
            "activityName" to activity.activityInfo.name
          )
        }
        .sortedBy { it["label"]?.lowercase(Locale.ROOT) }
    }

    AsyncFunction("launchApp") { packageName: String, activityName: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val isStillLaunchable = launcherActivities().any {
        it.activityInfo.packageName == packageName &&
          it.activityInfo.name == activityName
      }
      if (!isStillLaunchable) {
        throw IllegalStateException("That app is no longer available")
      }

      val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(packageName, activityName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("openDialer") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_DIAL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      if (intent.resolveActivity(context.packageManager) == null) {
        throw IllegalStateException("No dialer app is available")
      }
      context.startActivity(intent)
      true
    }

    AsyncFunction("placeDirectCall") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Phone-call permission has not been granted")
      }
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_CALL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }
  }
}
