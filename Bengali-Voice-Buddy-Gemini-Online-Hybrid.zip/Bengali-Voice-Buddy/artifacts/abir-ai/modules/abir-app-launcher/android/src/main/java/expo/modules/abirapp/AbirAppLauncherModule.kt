package expo.modules.abirapp

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.speech.SpeechRecognizer
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.util.Locale

class AbirAppLauncherModule : Module() {
  private fun launcherActivities(): List<ResolveInfo> {
    val context = appContext.reactContext
      ?: throw IllegalStateException("Android context is unavailable")
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val packageManager = context.packageManager

    @Suppress("DEPRECATION")
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      packageManager.queryIntentActivities(
        intent,
        PackageManager.ResolveInfoFlags.of(0L)
      )
    } else {
      packageManager.queryIntentActivities(intent, 0)
    }
  }

  override fun definition() = ModuleDefinition {
    Name("AbirAppLauncher")


    AsyncFunction("startWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Microphone permission has not been granted")
      }
      val intent = Intent(context, WakeWordService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
      true
    }

    AsyncFunction("stopWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.stopService(Intent(context, WakeWordService::class.java))
      true
    }

    AsyncFunction("isOnline") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val manager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
          ?: return@AsyncFunction false
      val activeNetwork = manager.activeNetwork ?: return@AsyncFunction false
      val capabilities = manager.getNetworkCapabilities(activeNetwork)
        ?: return@AsyncFunction false
      capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    AsyncFunction("isOfflineSpeechRecognitionAvailable") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        false
      } else {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
      }
    }

    AsyncFunction("getContacts") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Contacts permission has not been granted")
      }

      val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.TYPE,
        ContactsContract.CommonDataKinds.Phone.LABEL
      )
      val contacts = linkedMapOf<String, Map<String, String>>()
      context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection,
        null,
        null,
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
      )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        val nameColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val typeColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
        val labelColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)

        while (cursor.moveToNext()) {
          val id = cursor.getString(idColumn) ?: continue
          val name = cursor.getString(nameColumn)?.trim().orEmpty()
          val number = cursor.getString(numberColumn)?.trim().orEmpty()
          if (name.isBlank() || number.isBlank()) continue

          val type = cursor.getInt(typeColumn)
          val customLabel = cursor.getString(labelColumn)
          val phoneLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
            context.resources,
            type,
            customLabel
          ).toString()
          val key = "$id:$number"
          contacts.putIfAbsent(
            key,
            mapOf(
              "contactId" to id,
              "displayName" to name,
              "phoneNumber" to number,
              "phoneLabel" to phoneLabel
            )
          )
        }
      }
      contacts.values.toList()
    }

    AsyncFunction("getLaunchableApps") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val packageManager = context.packageManager

      launcherActivities()
        .groupBy { it.activityInfo.packageName }
        .mapNotNull { (packageName, activities) ->
          val defaultActivityName =
            packageManager.getLaunchIntentForPackage(packageName)?.component?.className
          val activity = activities.firstOrNull {
            it.activityInfo.name == defaultActivityName
          } ?: activities.firstOrNull() ?: return@mapNotNull null
          val label = activity.activityInfo.applicationInfo
            .loadLabel(packageManager)
            .toString()
            .trim()

          if (label.isBlank()) return@mapNotNull null

          mapOf(
            "label" to label,
            "packageName" to packageName,
            "activityName" to activity.activityInfo.name
          )
        }
        .sortedBy { it["label"]?.lowercase(Locale.ROOT) }
    }

    AsyncFunction("launchApp") { packageName: String, activityName: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val isStillLaunchable = launcherActivities().any {
        it.activityInfo.packageName == packageName &&
          it.activityInfo.name == activityName
      }
      if (!isStillLaunchable) {
        throw IllegalStateException("That app is no longer available")
      }

      val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(packageName, activityName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("openDialer") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_DIAL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      if (intent.resolveActivity(context.packageManager) == null) {
        throw IllegalStateException("No dialer app is available")
      }
      context.startActivity(intent)
      true
    }

    AsyncFunction("placeDirectCall") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Phone-call permission has not been granted")
      }
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_CALL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }
  }
}
