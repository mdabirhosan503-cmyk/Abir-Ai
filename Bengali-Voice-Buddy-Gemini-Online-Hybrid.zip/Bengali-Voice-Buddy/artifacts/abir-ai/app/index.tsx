import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import * as Speech from 'expo-speech';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  Alert,
  Linking,
  FlatList,
  Keyboard,
  Modal,
  Platform,
  PermissionsAndroid,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  type AssistantLanguage,
  type AssistantIntent,
} from '@/assistant/offlineBrain';
import { getAssistantReply } from '@/assistant/offlineBrain';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber } from '@/assistant/intentParser';
import {
  appActionReply,
  appDiscoveryReply,
  getDeviceContacts,
  getLaunchableApps,
  getOfflineSpeechRecognitionAvailability,
  getOnlineStatus,
  launchInstalledApp,
  openContactDialer,
  placeDirectCall,
  startWakeWord,
  stopWakeWord,
  type LaunchableApp,
} from '@/assistant/androidActions';
import {
  appChoicePrompt,
  matchInstalledApps,
  noMatchingAppReply,
  selectAppChoice,
} from '@/assistant/appNameMatcher';
import {
  formatCallConfirmation,
  formatContactChoicePrompt,
  matchContacts,
  selectContactChoice,
  type ContactPhone,
} from '@/assistant/contactHandler';
import {
  addRecentTopic,
  clearLocalMemory,
  EMPTY_MEMORY,
  handleMemoryCommand,
  loadLocalMemory,
  saveLocalMemory,
  type AssistantMemory,
} from '@/assistant/localMemory';
import {
  DEFAULT_PREFERENCES,
  loadAssistantPreferences,
  saveAssistantPreferences,
  type AssistantPreferences,
  type VoiceGenderPreference,
} from '@/assistant/voicePreferences';
import {
  chooseSpeechVoice,
  loadSpeechVoices,
  voiceFallbackMessage,
  type SpeechVoice,
} from '@/assistant/voiceSelection';
import { speakAssistantText } from '@/assistant/textToSpeech';
import { optionalOnlineAssistant } from '@/assistant/onlineAssistant';
import { listenForText } from '@/assistant/voiceInput';
import { useColors } from '@/hooks/useColors';

type Message = {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  time: number;
  intent?: AssistantIntent;
};

type SavedChat = {
  messages: Message[];
  language: AssistantLanguage;
  autoSpeak: boolean;
};

type UiIconName =
  | 'sparkles'
  | 'volume-high'
  | 'volume-mute'
  | 'volume-medium'
  | 'trash'
  | 'mic'
  | 'arrow-up'
  | 'settings'
  | 'close';

function UiIcon({
  name,
  color,
  size = 20,
}: {
  name: UiIconName;
  color: string;
  size?: number;
}) {
  const strokeProps = {
    fill: 'none',
    stroke: color,
    strokeWidth: 1.8,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };

  let drawing: React.ReactNode;
  switch (name) {
    case 'sparkles':
      drawing = (
        <>
          <Path
            d="M12 3 13.9 8.1 19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"
            {...strokeProps}
          />
          <Path d="M19 15v4M17 17h4" {...strokeProps} />
        </>
      );
      break;
    case 'volume-high':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a9 9 0 0 1 0 11" {...strokeProps} />
        </>
      );
      break;
    case 'volume-medium':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6" {...strokeProps} />
        </>
      );
      break;
    case 'volume-mute':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="m17 9 5 6m0-6-5 6" {...strokeProps} />
        </>
      );
      break;
    case 'trash':
      drawing = (
        <>
          <Path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14" {...strokeProps} />
          <Path d="M9 7V4h6v3" {...strokeProps} />
        </>
      );
      break;
    case 'mic':
      drawing = (
        <>
          <Rect x="9" y="3" width="6" height="12" rx="3" {...strokeProps} />
          <Path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" {...strokeProps} />
        </>
      );
      break;
    case 'arrow-up':
      drawing = <Path d="M12 19V5M6 11l6-6 6 6" {...strokeProps} />;
      break;
    case 'settings':
      drawing = (
        <>
          <Path
            d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z"
            {...strokeProps}
          />
          <Path
            d="m19.4 15 .1.1a1.8 1.8 0 1 1-2.5 2.5l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.3a1.8 1.8 0 1 1-3.6 0v-.2a1.7 1.7 0 0 0-2.9-1.2l-.1.1a1.8 1.8 0 1 1-2.5-2.5l.1-.1a1.7 1.7 0 0 0-1.2-2.9h-.3a1.8 1.8 0 1 1 0-3.6h.2a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a1.8 1.8 0 1 1 2.5-2.5l.1.1a1.7 1.7 0 0 0 2.9-1.2v-.3a1.8 1.8 0 1 1 3.6 0v.2a1.7 1.7 0 0 0 2.9 1.2l.1-.1a1.8 1.8 0 1 1 2.5 2.5l-.1.1a1.7 1.7 0 0 0 1.2 2.9h.3a1.8 1.8 0 1 1 0 3.6h-.2a1.7 1.7 0 0 0-1.2 2.9Z"
            {...strokeProps}
          />
        </>
      );
      break;
    case 'close':
      drawing = <Path d="m6 6 12 12M18 6 6 18" {...strokeProps} />;
      break;
    default:
      drawing = <Circle cx="12" cy="12" r="8" {...strokeProps} />;
  }

  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityRole="image">
      {drawing}
    </Svg>
  );
}

const STORAGE_KEY = 'abir-ai-chat-v1';
const MAX_MESSAGES = 160;

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function welcomeMessage(language: AssistantLanguage): Message {
  return {
    id: 'welcome',
    role: 'assistant',
    text:
      language === 'bn'
        ? 'আসসালামু আলাইকুম! আমি আবির AI—তোমার ছোট্ট অফলাইন সঙ্গী। কী জানতে চাও?'
        : 'Hey, I’m Abir AI—your little offline sidekick. What’s on your mind?',
    time: Date.now(),
  };
}

function isSavedChat(value: unknown): value is SavedChat {
  if (!value || typeof value !== 'object') return false;
  const saved = value as Partial<SavedChat>;
  return (
    Array.isArray(saved.messages) &&
    (saved.language === 'bn' || saved.language === 'en') &&
    typeof saved.autoSpeak === 'boolean' &&
    saved.messages.every(
      (message) =>
        message &&
        typeof message.id === 'string' &&
        (message.role === 'assistant' || message.role === 'user') &&
        typeof message.text === 'string' &&
        typeof message.time === 'number',
    )
  );
}

function getTimeLabel(timestamp: number, language: AssistantLanguage) {
  return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
  }).format(timestamp);
}

function isCancelAppChoice(text: string) {
  return /^(?:cancel|never mind|nevermind|stop|থাক|বাদ দাও|বাতিল|না)$/i.test(
    text.trim(),
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([welcomeMessage('bn')]);
  const [language, setLanguage] = useState<AssistantLanguage>('bn');
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [draft, setDraft] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(true);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [pendingAppChoices, setPendingAppChoices] = useState<
    LaunchableApp[] | null
  >(null);
  const [pendingContactChoices, setPendingContactChoices] = useState<
    ContactPhone[] | null
  >(null);
  const inputRef = useRef<TextInput>(null);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!mounted || !stored) return;
        const parsed: unknown = JSON.parse(stored);
        if (!isSavedChat(parsed)) return;
        setMessages(parsed.messages);
        setLanguage(parsed.language);
        setAutoSpeak(parsed.autoSpeak);
      })
      .catch(() => {
        // A corrupt or unavailable local cache should not prevent a new chat.
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android' || isLoading) return;
    let mounted = true;
    const handleWakeUrl = async (url: string) => {
      if (!url.startsWith('abir-ai://wake')) return;
      const parsed = Linking.parse(url);
      const command = typeof parsed.queryParams?.text === 'string'
        ? parsed.queryParams.text.trim()
        : '';
      if (!mounted) return;
      if (command) {
        await sendText(command, true);
      } else {
        await startVoiceInput();
      }
    };

    const subscription = Linking.addEventListener('url', ({ url }) => {
      void handleWakeUrl(url);
    });
    void Linking.getInitialURL().then((url) => {
      if (url) void handleWakeUrl(url);
    });

    if (wakeWordEnabled) {
      void startWakeWord();
    }

    return () => {
      mounted = false;
      subscription.remove();
    };
  }, [isLoading, wakeWordEnabled]);

  useEffect(() => {
    if (isLoading) return;
    const saved: SavedChat = {
      messages: messages.slice(-MAX_MESSAGES),
      language,
      autoSpeak,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(saved)).catch(() => {
      Alert.alert(
        language === 'bn' ? 'চ্যাট সংরক্ষণ হয়নি' : 'Chat not saved',
        language === 'bn'
          ? 'এই ডিভাইসে চ্যাট সংরক্ষণ করা যায়নি।'
          : 'This chat could not be saved on this device.',
      );
    });
  }, [autoSpeak, isLoading, language, messages]);

  const speakMessage = async (message: Message) => {
    try {
      await Speech.stop();
      setSpeakingId(message.id);
      Speech.speak(message.text, {
        language: language === 'bn' ? 'bn-BD' : 'en-US',
        pitch: 1.04,
        rate: 0.94,
        onDone: () => setSpeakingId(null),
        onStopped: () => setSpeakingId(null),
        onError: () => {
          setSpeakingId(null);
          Alert.alert(
            language === 'bn' ? 'ভয়েস পাওয়া যায়নি' : 'Voice unavailable',
            language === 'bn'
              ? 'এই ভাষার জন্য ফোনে টেক্সট-টু-স্পিচ ভয়েস ইনস্টল আছে কি না দেখে নাও।'
              : 'Check whether a text-to-speech voice for this language is installed on your phone.',
          );
        },
      });
    } catch {
      setSpeakingId(null);
    }
  };

  const sendText = async (rawText: string, forceSpeak = false) => {
    const text = rawText.trim();
    if (!text || isSending) return;

    Keyboard.dismiss();
    setDraft('');
    setIsSending(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

    const userMessage: Message = {
      id: createId(),
      role: 'user',
      text,
      time: Date.now(),
    };

    try {
      const responseLanguage = /[\u0980-\u09FF]/.test(text) ? 'bn' : language;

      if (pendingAppChoices && !extractAppQuery(text)) {
        if (isCancelAppChoice(text)) {
          setPendingAppChoices(null);
          const cancelledMessage: Message = {
            id: createId(),
            role: 'assistant',
            text:
              responseLanguage === 'bn'
                ? 'ঠিক আছে, অ্যাপ খোলা বাতিল করলাম।'
                : 'Okay, I cancelled opening an app.',
            time: Date.now(),
          };
          setMessages((current) =>
            [...current, userMessage, cancelledMessage].slice(-MAX_MESSAGES),
          );
          if (autoSpeak || forceSpeak) void speakMessage(cancelledMessage);
          return;
        }

        const selectedApp = selectAppChoice(text, pendingAppChoices);
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: selectedApp
            ? responseLanguage === 'bn'
              ? `${selectedApp.label} খুলছি…`
              : `Opening ${selectedApp.label}…`
            : appChoicePrompt(pendingAppChoices, responseLanguage),
          intent: 'open-app',
          time: Date.now(),
        };
        setMessages((current) =>
          [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES),
        );

        if (!selectedApp) {
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }

        setPendingAppChoices(null);
        const launchStatus = await launchInstalledApp(selectedApp);
        const responseText = appActionReply(
          launchStatus,
          selectedApp,
          responseLanguage,
        );
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? { ...message, text: responseText }
              : message,
          ),
        );
        if (autoSpeak || forceSpeak) {
          void speakMessage({ ...assistantMessage, text: responseText });
        }
        return;
      }

      if (pendingAppChoices) setPendingAppChoices(null);
      // Try online AI first when an endpoint is configured; if it is
      // unavailable, keep the app fully usable with the offline brain.
      const onlineText = optionalOnlineAssistant.enabled
        ? await optionalOnlineAssistant.respond({
            text,
            language: responseLanguage === 'bn' ? 'bn' : 'en',
          })
        : null;
      const reply = onlineText
        ? {
            text: onlineText,
            intent: 'fallback' as AssistantIntent,
          }
        : await getAssistantReply({
            text,
            language: responseLanguage,
            now: new Date(),
          });
      const assistantMessage: Message = {
        id: createId(),
        role: 'assistant',
        text: reply.text,
        intent: reply.intent,
        time: Date.now(),
      };

      setMessages((current) => {
        const next =
          reply.intent === 'clear-history'
            ? [userMessage, assistantMessage]
            : [...current, userMessage, assistantMessage];
        return next.slice(-MAX_MESSAGES);
      });

      let finalAssistantMessage = assistantMessage;
      if (reply.intent === 'clear-history') setPendingAppChoices(null);

      if (reply.intent === 'open-app' && reply.appQuery) {
        const discovery = await getLaunchableApps();
        let responseText: string;

        if (discovery.status !== 'available') {
          responseText = appDiscoveryReply(discovery.status, responseLanguage);
        } else {
          const matches = matchInstalledApps(reply.appQuery, discovery.apps);
          if (matches.length === 0) {
            responseText = noMatchingAppReply(reply.appQuery);
          } else if (matches.length > 1) {
            const choices = matches.slice(0, 8);
            setPendingAppChoices(choices);
            responseText = appChoicePrompt(choices, responseLanguage);
          } else {
            const launchStatus = await launchInstalledApp(matches[0]);
            responseText = appActionReply(
              launchStatus,
              matches[0],
              responseLanguage,
            );
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      if (reply.intent === 'call-contact' && reply.contactQuery) {
        let responseText = reply.text;
        const directPhoneNumber = extractDirectPhoneNumber(reply.contactQuery);

        if (directPhoneNumber) {
          if (Platform.OS === 'android') {
            const permission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CALL_PHONE,
            );
            if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText =
                responseLanguage === 'bn'
                  ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                  : 'Phone-call permission was not granted. Allow it and try again.';
            } else {
              const callStatus = await placeDirectCall(directPhoneNumber);
              responseText =
                callStatus === 'placed'
                  ? responseLanguage === 'bn'
                    ? `${directPhoneNumber}-এ কল দিচ্ছি।`
                    : `Calling ${directPhoneNumber}.`
                  : responseLanguage === 'bn'
                    ? 'এই নম্বরে কল দেওয়া গেল না।'
                    : 'I could not place the call to this number.';
            }
          } else {
            responseText =
              responseLanguage === 'bn'
                ? 'এই ডিভাইস থেকে সরাসরি ফোন কল সমর্থিত নয়।'
                : 'Direct phone calls are not supported on this device.';
          }
        } else {
          const contactsResult = await getDeviceContacts();

          if (contactsResult.status !== 'available') {
            responseText =
              responseLanguage === 'bn'
                ? 'পরিচিতির নম্বর পড়া গেল না। Contacts অনুমতি চালু আছে কি না দেখে আবার চেষ্টা করো।'
                : 'I could not read your contacts. Check Contacts permission and try again.';
          } else {
            const matches = matchContacts(reply.contactQuery, contactsResult.contacts);
            if (matches.length === 0) {
              responseText =
                responseLanguage === 'bn'
                  ? `${reply.contactQuery} নামে কোনো পরিচিতি খুঁজে পেলাম না।`
                  : `I couldn’t find a contact named ${reply.contactQuery}.`;
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingContactChoices(choices);
              responseText = formatContactChoicePrompt(choices, responseLanguage);
            } else {
              const contact = matches[0];
              if (Platform.OS === 'android') {
                const permission = await PermissionsAndroid.request(
                  PermissionsAndroid.PERMISSIONS.CALL_PHONE,
                );
                if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
                  responseText =
                    responseLanguage === 'bn'
                      ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                      : 'Phone-call permission was not granted. Allow it and try again.';
                } else {
                  const callStatus = await placeDirectCall(contact.phoneNumber);
                  responseText =
                    callStatus === 'placed'
                      ? responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দিচ্ছি।`
                        : `Calling ${contact.displayName}.`
                      : responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দেওয়া গেল না।`
                        : `I couldn’t call ${contact.displayName}.`;
                }
              }
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
    } finally {
      setIsSending(false);
    }
  };

  const startVoiceInput = async () => {
    if (isListening || isSending) return;
    setIsListening(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    try {
      // Voice commands are a conversational mode: always read the action/reply
      // aloud so the user can operate Abir AI without touching the keyboard.
      if (!autoSpeak) setAutoSpeak(true);

      const recognizedText = await listenForText(language);
      if (recognizedText) {
        await sendText(recognizedText, true);
      }
    } catch (error) {
      Alert.alert(
        language === 'bn' ? 'ভয়েস ইনপুট কাজ করেনি' : 'Voice input unavailable',
        error instanceof Error
          ? error.message
          : language === 'bn'
            ? 'মাইক্রোফোন বা স্পিচ সার্ভিসটি পরীক্ষা করে আবার চেষ্টা করো।'
            : 'Check microphone or speech-service availability and try again.',
      );
    } finally {
      setIsListening(false);
    }
  };

  const confirmClear = () => {
    Alert.alert(
      language === 'bn' ? 'চ্যাট পরিষ্কার করবে?' : 'Clear this chat?',
      language === 'bn'
        ? 'সংরক্ষিত কথোপকথন মুছে যাবে।'
        : 'Your saved conversation will be deleted.',
      [
        { text: language === 'bn' ? 'থাক' : 'Cancel', style: 'cancel' },
        {
          text: language === 'bn' ? 'মুছে দাও' : 'Clear',
          style: 'destructive',
          onPress: () => {
            setMessages([welcomeMessage(language)]);
            void Speech.stop();
          },
        },
      ],
    );
  };

  const suggestions =
    language === 'bn'
      ? [
          'একটা কৌতুক বলো',
          'এখন সময় কত?',
          '২ + ২',
          'তুমি কী করতে পারো?',
          'WhatsApp ওপেন করো',
          'YouTube ওপেন করো',
        ]
      : [
          'Tell me a joke',
          'What time is it?',
          '2 + 2',
          'What can you do?',
          'Open WhatsApp',
          'Open YouTube',
        ];

  const inputBackground = { backgroundColor: colors.card };
  const bottomInset =
    Platform.OS === 'web' ? 34 : Math.max(insets.bottom, 10);
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <KeyboardAvoidingView
        style={styles.keyboardFrame}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        <View style={[styles.header, { paddingTop: topInset + 10 }]}>
          <View style={styles.brand}>
            <View
              style={[
                styles.brandMark,
                { backgroundColor: colors.accentSoft, borderColor: colors.border },
              ]}
            >
              <UiIcon name="sparkles" size={21} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.title, { color: colors.foreground }]}>
                Abir AI
              </Text>
              <View style={styles.subtitleRow}>
                <View
                  style={[styles.onlineDot, { backgroundColor: colors.primary }]}
                />
                <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'অফলাইনে প্রস্তুত' : 'Ready offline'}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.headerActions}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                language === 'bn' ? 'ভাষা বদলাও' : 'Change language'
              }
              testID="language-toggle"
              onPress={() =>
                setLanguage((current) => (current === 'bn' ? 'en' : 'bn'))
              }
              style={({ pressed }) => [
                styles.languageButton,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.languageText, { color: colors.foreground }]}>
                {language === 'bn' ? 'EN' : 'বাংলা'}
              </Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                wakeWordEnabled
                  ? language === 'bn' ? 'আবির ওয়েক-ওয়ার্ড বন্ধ' : 'Turn off Abir wake word'
                  : language === 'bn' ? 'আবির ওয়েক-ওয়ার্ড চালু' : 'Turn on Abir wake word'
              }
              testID="wake-word-toggle"
              onPress={() => {
                setWakeWordEnabled((current) => {
                  const next = !current;
                  void (next ? startWakeWord() : stopWakeWord());
                  return next;
                });
              }}
              style={({ pressed }) => [
                styles.iconButton,
                {
                  backgroundColor: wakeWordEnabled ? colors.accent : colors.card,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <UiIcon
                name="mic"
                size={19}
                color={wakeWordEnabled ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                autoSpeak
                  ? language === 'bn'
                    ? 'স্বয়ংক্রিয় ভয়েস বন্ধ'
                    : 'Turn off automatic voice replies'
                  : language === 'bn'
                    ? 'স্বয়ংক্রিয় ভয়েস চালু'
                    : 'Turn on automatic voice replies'
              }
              testID="auto-speech-toggle"
              onPress={() => setAutoSpeak((current) => !current)}
              style={({ pressed }) => [
                styles.iconButton,
                {
                  backgroundColor: autoSpeak ? colors.accent : colors.card,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <UiIcon
                name={autoSpeak ? 'volume-high' : 'volume-mute'}
                size={19}
                color={autoSpeak ? colors.primary : colors.mutedForeground}
              />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'চ্যাট পরিষ্কার' : 'Clear chat'}
              testID="clear-chat"
              onPress={confirmClear}
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <UiIcon name="trash" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>
        </View>

        <FlatList
          inverted
          data={[...messages].reverse()}
          keyExtractor={(item) => item.id}
          style={styles.messages}
          contentContainerStyle={styles.messageList}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          scrollEnabled={messages.length > 0}
          renderItem={({ item }) => {
            const isUser = item.role === 'user';
            return (
              <View
                style={[
                  styles.messageRow,
                  isUser ? styles.userRow : styles.assistantRow,
                ]}
              >
                {!isUser && (
                  <View
                    style={[
                      styles.messageAvatar,
                      { backgroundColor: colors.accentSoft },
                    ]}
                  >
                    <UiIcon name="sparkles" size={13} color={colors.primary} />
                  </View>
                )}
                <View style={styles.messageBody}>
                  <View
                    style={[
                      styles.messageBubble,
                      {
                        backgroundColor: isUser
                          ? colors.userBubble
                          : colors.assistantBubble,
                        borderColor: colors.border,
                      },
                      isUser && styles.userBubble,
                    ]}
                  >
                    <Text
                      selectable
                      style={[
                        styles.messageText,
                        { color: colors.foreground },
                        isUser && styles.userMessageText,
                      ]}
                    >
                      {item.text}
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.messageMeta,
                      isUser && styles.userMeta,
                    ]}
                  >
                    <Text
                      style={[
                        styles.timeText,
                        { color: colors.mutedForeground },
                      ]}
                    >
                      {getTimeLabel(item.time, language)}
                    </Text>
                    {!isUser && (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={
                          language === 'bn' ? 'উত্তরটি শোনো' : 'Play voice reply'
                        }
                        testID={`speak-${item.id}`}
                        onPress={() => void speakMessage(item)}
                        hitSlop={8}
                      >
                        <UiIcon
                          name={speakingId === item.id ? 'volume-high' : 'volume-medium'}
                          size={15}
                          color={colors.mutedForeground}
                        />
                      </Pressable>
                    )}
                  </View>
                </View>
              </View>
            );
          }}
          ListHeaderComponent={
            isSending ? (
              <View style={[styles.typingRow, { borderColor: colors.border }]}>
                <ActivityIndicator size="small" color={colors.primary} />
                <Text style={[styles.typingText, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'একটু ভাবছি…' : 'Thinking…'}
                </Text>
              </View>
            ) : null
          }
        />

        <View style={[styles.composerArea, { paddingBottom: bottomInset }]}>
          {messages.length <= 1 && (
            <View style={styles.suggestions}>
              {suggestions.map((suggestion) => (
                <Pressable
                  key={suggestion}
                  accessibilityRole="button"
                  testID={`suggestion-${suggestion}`}
                  onPress={() => void sendText(suggestion)}
                  style={({ pressed }) => [
                    styles.suggestionChip,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.border,
                      opacity: pressed ? 0.65 : 1,
                    },
                  ]}
                >
                  <Text
                    numberOfLines={1}
                    style={[styles.suggestionText, { color: colors.secondaryForeground }]}
                  >
                    {suggestion}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          <View
            style={[
              styles.composer,
              inputBackground,
              { borderColor: colors.input },
            ]}
          >
            <TextInput
              ref={inputRef}
              testID="chat-input"
              value={draft}
              onChangeText={setDraft}
              onSubmitEditing={() => void sendText(draft)}
              placeholder={
                language === 'bn' ? 'আবিরকে কিছু জিজ্ঞেস করো…' : 'Message Abir…'
              }
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.foreground }]}
              multiline
              maxLength={1000}
              returnKeyType="send"
              blurOnSubmit={false}
              accessibilityLabel={
                language === 'bn' ? 'বার্তা লিখুন' : 'Type a message'
              }
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                isListening
                  ? language === 'bn'
                    ? 'শুনছে'
                    : 'Listening'
                  : language === 'bn'
                    ? 'ভয়েস ইনপুট'
                    : 'Voice input'
              }
              testID="voice-input"
              disabled={isListening || isSending}
              onPress={() => void startVoiceInput()}
              style={({ pressed }) => [
                styles.composerIcon,
                {
                  backgroundColor: isListening ? colors.accent : 'transparent',
                  opacity: pressed ? 0.65 : 1,
                },
              ]}
            >
              {isListening ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <UiIcon name="mic" size={21} color={colors.mutedForeground} />
              )}
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={language === 'bn' ? 'বার্তা পাঠান' : 'Send message'}
              testID="send-message"
              disabled={!draft.trim() || isSending}
              onPress={() => void sendText(draft)}
              style={({ pressed }) => [
                styles.sendButton,
                {
                  backgroundColor: colors.primary,
                  opacity: !draft.trim() || isSending ? 0.45 : pressed ? 0.75 : 1,
                },
              ]}
            >
              <UiIcon name="arrow-up" size={21} color={colors.primaryForeground} />
            </Pressable>
          </View>
          <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
            {language === 'bn'
              ? 'আবির এখন অফলাইন কমান্ডে চলে · কথোপকথন এই ডিভাইসেই থাকে'
              : 'Offline starter commands · chat stays on this device'}
          </Text>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  keyboardFrame: { flex: 1 },
  header: {
    minHeight: 78,
    paddingHorizontal: 18,
    paddingBottom: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: {
    width: 42,
    height: 42,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: -0.3 },
  subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  onlineDot: { width: 6, height: 6, borderRadius: 3 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  languageButton: {
    minWidth: 42,
    height: 36,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  languageText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  messages: { flex: 1 },
  messageList: {
    paddingHorizontal: 17,
    paddingTop: 15,
    paddingBottom: 14,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  messageRow: { flexDirection: 'row', marginBottom: 18, gap: 8, maxWidth: '90%' },
  assistantRow: { alignSelf: 'flex-start', alignItems: 'flex-end' },
  userRow: { alignSelf: 'flex-end' },
  messageAvatar: {
    width: 23,
    height: 23,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  messageBody: { flexShrink: 1 },
  messageBubble: {
    borderWidth: 1,
    borderRadius: 18,
    borderBottomLeftRadius: 6,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  userBubble: { borderBottomLeftRadius: 18, borderBottomRightRadius: 6 },
  messageText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 23,
    letterSpacing: 0.05,
  },
  userMessageText: { fontFamily: 'Inter_500Medium' },
  messageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 5,
    marginLeft: 3,
  },
  userMeta: { justifyContent: 'flex-end', marginRight: 2 },
  timeText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  typingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginLeft: 31,
    marginBottom: 14,
  },
  typingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  composerArea: { paddingHorizontal: 14, paddingTop: 8, gap: 9 },
  suggestions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
    paddingBottom: 1,
  },
  suggestionChip: {
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 11,
    paddingVertical: 8,
    maxWidth: '100%',
  },
  suggestionText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  composer: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingLeft: 13,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 4,
  },
  input: {
    flex: 1,
    maxHeight: 112,
    minHeight: 39,
    paddingTop: 9,
    paddingBottom: 7,
    paddingRight: 5,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 21,
  },
  composerIcon: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButton: {
    width: 39,
    height: 39,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerNote: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    paddingHorizontal: 4,
    paddingBottom: 2,
  },
});
