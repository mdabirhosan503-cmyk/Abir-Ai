export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Gemini Developer API (generateContent).
// The key is supplied only at build time through EXPO_PUBLIC_GEMINI_API_KEY.
// If the key is missing or the request fails, Abir AI falls back to the offline brain.
const apiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const model = process.env.EXPO_PUBLIC_GEMINI_MODEL?.trim() || 'gemini-2.5-flash';
const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

function cleanReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const candidates = Array.isArray(record.candidates) ? record.candidates : [];
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = (first as Record<string, unknown>).content;
  if (!content || typeof content !== 'object') return null;
  const parts = Array.isArray((content as Record<string, unknown>).parts)
    ? (content as Record<string, unknown>).parts
    : [];
  const text = parts
    .filter((part): part is Record<string, unknown> => Boolean(part && typeof part === 'object'))
    .map(part => part.text)
    .filter((part): part is string => typeof part === 'string')
    .join(' ')
    .trim();
  return text || null;
}

export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  enabled: Boolean(apiKey),
  async respond(request) {
    if (!apiKey) return null;

    try {
      const systemInstruction =
        request.language === 'bn'
          ? 'তুমি Abir AI-এর অনলাইন সহকারী। স্বাভাবিক, পরিষ্কার, সংক্ষিপ্ত ও সহায়ক বাংলায় উত্তর দাও। ব্যবহারকারী যদি বাংলায় লেখে, বাংলায় উত্তর দাও। প্রয়োজন হলে ধাপে ধাপে বোঝাও।'
          : 'You are Abir AI, an online assistant. Reply naturally, clearly, and helpfully. If the user writes in English, answer in English.';

      const response = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
          contents: [
            {
              role: 'user',
              parts: [{ text: request.text }],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 700,
          },
        }),
      });

      if (!response.ok) return null;
      return cleanReply(await response.json());
    } catch {
      return null;
    }
  },
};
