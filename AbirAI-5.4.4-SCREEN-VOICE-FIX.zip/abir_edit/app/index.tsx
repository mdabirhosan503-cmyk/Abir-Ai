import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import * as Speech from 'expo-speech';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  AppState,
  Alert,
  Linking,
  FlatList,
  Keyboard,
  Modal,
  Platform,
  PermissionsAndroid,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  Image,
  View,
  ScrollView,
} from 'react-native';
import Svg, { Circle, Path, Rect, Line } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  type AssistantLanguage,
  type AssistantIntent,
} from '@/assistant/offlineBrain';
import { getAssistantReply } from '@/assistant/offlineBrain';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber } from '@/assistant/intentParser';
import { extractMessageRequest, messageAutomationReply, type MessageRequest } from '@/assistant/messageAutomation';
import {
  appActionReply,
  appDiscoveryReply,
  getDeviceContacts,
  getLaunchableApps,
  getOfflineSpeechRecognitionAvailability,
  getOnlineStatus,
  launchInstalledApp,
  openContactDialer,
  placeDirectCall,
  callViaApp,
  searchAndOpenInApp,
  performDeviceAction,
  wakeDeviceScreen,
  adjustDeviceVolume,
  getDeviceVolumePercent,
  setDeviceVolumePercent,
  setFlashlight,
  controlMedia,
  setRingerMode,
  openSystemSettings,
  getCurrentLocation,
  getDeviceDiagnostics,
  scheduleAbirReminder,
  readCurrentScreenText,
  getScreenSnapshot,
  startWakeWord,
  speakNativeText,
  stopNativeSpeaking,
  stopWakeWord,
  canDrawOverlays,
  openOverlaySettings,
  isAccessibilityEnabled,
  openAccessibilitySettings,
  sendMessageViaAccessibility,
  type LaunchableApp,
} from '@/assistant/androidActions';
import {
  appChoicePrompt,
  matchInstalledApps,
  noMatchingAppReply,
  selectAppChoice,
} from '@/assistant/appNameMatcher';
import {
  formatCallConfirmation,
  formatContactChoicePrompt,
  matchContacts,
  selectContactChoice,
  type ContactPhone,
} from '@/assistant/contactHandler';
import {
  addRecentTopic,
  clearLocalMemory,
  EMPTY_MEMORY,
  handleMemoryCommand,
  loadLocalMemory,
  saveLocalMemory,
  type AssistantMemory,
} from '@/assistant/localMemory';
import { getLastLocalAction, recordLocalAction } from '@/assistant/offlineTools';
import { addLocalNote, searchLocalNotes, saveLocalRoutine, findLocalRoutine, learnLocalAlias } from '@/assistant/offlinePlus';
import {
  DEFAULT_PREFERENCES,
  loadAssistantPreferences,
  saveAssistantPreferences,
  type AssistantPreferences,
  type VoiceGenderPreference,
} from '@/assistant/voicePreferences';
import {
  chooseSpeechVoice,
  loadSpeechVoices,
  voiceFallbackMessage,
  type SpeechVoice,
} from '@/assistant/voiceSelection';
import { speakAssistantText } from '@/assistant/textToSpeech';
import { optionalOnlineAssistant } from '@/assistant/onlineAssistant';
import { listenForText, listenForOfflineText } from '@/assistant/voiceInput';
import { useColors } from '@/hooks/useColors';



function FuturisticRobot({ active }: { active: boolean }) {
  return (
    <View style={dashboardStyles.robotStage}>
      <View style={[dashboardStyles.robotGlow, active && dashboardStyles.robotGlowActive]} />
      <Svg width={210} height={180} viewBox="0 0 210 180" style={dashboardStyles.networkSvg}>
        <Circle cx="105" cy="85" r="54" stroke="#1D7BFF" strokeWidth="1" opacity="0.35" fill="none" />
        <Circle cx="105" cy="85" r="39" stroke="#6B4CFF" strokeWidth="1" opacity="0.38" fill="none" />
        <Circle cx="105" cy="85" r="7" fill="#36C8FF" opacity="0.95" />
        <Circle cx="37" cy="42" r="3" fill="#39BFFF" />
        <Circle cx="170" cy="48" r="3" fill="#7C5CFF" />
        <Circle cx="177" cy="128" r="3" fill="#35E0FF" />
        <Circle cx="34" cy="133" r="3" fill="#7C5CFF" />
        <Line x1="37" y1="42" x2="105" y2="85" stroke="#1D7BFF" strokeWidth="1" opacity="0.45" />
        <Line x1="170" y1="48" x2="105" y2="85" stroke="#6B4CFF" strokeWidth="1" opacity="0.45" />
        <Line x1="177" y1="128" x2="105" y2="85" stroke="#35E0FF" strokeWidth="1" opacity="0.45" />
        <Line x1="34" y1="133" x2="105" y2="85" stroke="#7C5CFF" strokeWidth="1" opacity="0.45" />
      </Svg>
      <View style={dashboardStyles.robotAntenna} />
      <View style={dashboardStyles.robotHead}>
        <View style={dashboardStyles.robotEarLeft} />
        <View style={dashboardStyles.robotEarRight} />
        <View style={dashboardStyles.robotFace}>
          <View style={dashboardStyles.robotEye} />
          <View style={dashboardStyles.robotEye} />
        </View>
        <View style={dashboardStyles.robotSmile} />
      </View>
      <View style={dashboardStyles.robotBody}>
        <View style={dashboardStyles.robotChest}>
          <Text style={dashboardStyles.robotA}>A</Text>
        </View>
        <View style={dashboardStyles.robotArmLeft} />
        <View style={dashboardStyles.robotArmRight} />
      </View>
      <View style={dashboardStyles.robotBase} />
    </View>
  );
}

type FuturisticDashboardProps = {
  language: AssistantLanguage;
  messages: Message[];
  draft: string;
  setDraft: (value: string) => void;
  isListening: boolean;
  isSending: boolean;
  isSpeaking: boolean;
  online: boolean;
  voiceHistory: VoiceHistoryItem[];
  onVoice: () => void;
  onSend: (text: string) => void;
  onMenu: () => void;
  onSettings: () => void;
};

function FloatingVoiceOrb({
  active,
  speaking,
  online,
  language,
  onPress,
}: {
  active: boolean;
  speaking: boolean;
  online: boolean;
  language: AssistantLanguage;
  onPress: () => void;
}) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: active || speaking ? 520 : 1200, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: active || speaking ? 520 : 1200, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [active, speaking, pulse]);

  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, active || speaking ? 1.42 : 1.12] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.42, 0.04] });
  const coreScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, active || speaking ? 1.08 : 1.03] });

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={language === 'bn' ? 'ভয়েস কমান্ড' : 'Voice command'}
      onPress={onPress}
      style={dashboardStyles.floatingOrbButton}
    >
      <Animated.View style={[dashboardStyles.orbPulseRing, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
      <Animated.View style={[dashboardStyles.floatingOrbCore, { transform: [{ scale: coreScale }] }]}>
        <View style={dashboardStyles.orbInnerGlow} />
        <View style={dashboardStyles.orbBars}>
          {[0, 1, 2, 3, 4].map((i) => (
            <View key={i} style={[dashboardStyles.orbBar, { height: active || speaking ? 8 + ((i + 1) * 5) % 18 : 8 + (i % 2) * 4 }]} />
          ))}
        </View>
      </Animated.View>
      <View style={dashboardStyles.orbCaption}>
        <View style={[dashboardStyles.orbStatusDot, { backgroundColor: online ? '#36E3A6' : '#77849B' }]} />
        <Text style={dashboardStyles.orbCaptionText}>
          {active
            ? language === 'bn' ? 'শুনছি' : 'Listening'
            : speaking
              ? language === 'bn' ? 'বলছি' : 'Speaking'
              : language === 'bn' ? 'ট্যাপ করে বলো' : 'Tap to talk'}
        </Text>
      </View>
    </Pressable>
  );
}

function FuturisticDashboard({
  language,
  messages,
  draft,
  setDraft,
  isListening,
  isSending,
  isSpeaking,
  online,
  voiceHistory,
  onVoice,
  onSend,
  onMenu,
  onSettings,
}: FuturisticDashboardProps) {
  const bn = language === 'bn';
  const recent = messages.filter(m => m.role === 'user').slice(-5).reverse();
  const resolved = Math.max(3, messages.filter(m => m.role === 'assistant').length - 1);
  const active = isSending ? 1 : 0;

  const activityDefaults = bn
    ? ['App launch workflow', 'Memory local sync', 'Device status check', 'Offline command ready', 'Online fallback ready']
    : ['App launch workflow', 'Local memory sync', 'Device status check', 'Offline command ready', 'Online fallback ready'];

  return (
    <View style={dashboardStyles.root}>
      <LinearGradient
        colors={['#020617', '#03133A', '#020617']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={dashboardStyles.gridGlow} pointerEvents="none" />

      <View style={dashboardStyles.topBar}>
        <View style={dashboardStyles.brandBlock}>
          <View style={dashboardStyles.brandOrb}>
            <Text style={dashboardStyles.brandA}>A</Text>
          </View>
          <View>
            <Text style={dashboardStyles.brandTitle}>ABIR AI</Text>
            <View style={dashboardStyles.statusLine}>
              <View style={dashboardStyles.liveDot} />
              <Text style={dashboardStyles.statusText}>{online ? 'ONLINE · LOCAL-FIRST' : 'OFFLINE · LOCAL-FIRST'}</Text>
            </View>
          </View>
        </View>
        <View style={dashboardStyles.topActions}>
          <Pressable onPress={onSettings} style={dashboardStyles.roundAction}>
            <Text style={dashboardStyles.actionGlyph}>⚙</Text>
          </Pressable>
          <Pressable onPress={onMenu} style={dashboardStyles.roundAction}>
            <Text style={dashboardStyles.actionGlyph}>⋮</Text>
          </Pressable>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={dashboardStyles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <View style={dashboardStyles.heroGrid}>
          <View style={dashboardStyles.leftColumn}>
            <View style={dashboardStyles.metricsGrid}>
              <DashboardMetric label={bn ? 'সক্রিয় কাজ' : 'ACTIVE TASKS'} value={String(active)} trend={active ? 'RUNNING' : 'READY'} />
              <DashboardMetric label="AI CONFIDENCE" value="88%" trend="+4.2%" />
              <DashboardMetric label={bn ? 'আজ সমাধান' : 'RESOLVED TODAY'} value={String(resolved)} trend="+3" />
              <DashboardMetric label={bn ? 'গড় সময়' : 'AVG RESOLUTION'} value="42s" trend="-12%" />
            </View>

            <View style={dashboardStyles.activityCard}>
              <View style={dashboardStyles.cardHeader}>
                <View>
                  <Text style={dashboardStyles.cardEyebrow}>SYSTEM ACTIVITY</Text>
                  <Text style={dashboardStyles.cardTitle}>{bn ? 'সাম্প্রতিক কার্যক্রম' : 'Recent activity'}</Text>
                </View>
                <View style={dashboardStyles.smallBadge}><Text style={dashboardStyles.smallBadgeText}>LIVE</Text></View>
              </View>
              {(recent.length ? recent : activityDefaults.map((text, i) => ({ id: `d-${i}`, role: 'user' as const, text, time: Date.now() }))).map((item, index) => (
                <View key={item.id} style={dashboardStyles.activityRow}>
                  <View style={[dashboardStyles.activityDot, index === 0 && dashboardStyles.activityDotHot]} />
                  <Text numberOfLines={1} style={dashboardStyles.activityText}>{item.text}</Text>
                  <Text style={dashboardStyles.activityTime}>{index === 0 ? 'NOW' : `${index}m`}</Text>
                  <View style={dashboardStyles.miniGraph}><View style={[dashboardStyles.miniGraphBar, { height: 5 + ((index * 7) % 15) }]} /></View>
                </View>
              ))}
            </View>
          </View>

          <View style={dashboardStyles.centerColumn}>
            <View style={dashboardStyles.aiLabelRow}>
              <View style={dashboardStyles.aiPill}><View style={dashboardStyles.aiPillDot} /><Text style={dashboardStyles.aiPillText}>{isListening ? 'LISTENING' : isSending ? 'PROCESSING' : 'AI CORE ONLINE'}</Text></View>
            </View>
            <FuturisticRobot active={isListening || isSending} />
            <Text style={dashboardStyles.heroTitle}>ABIR</Text>
            <Text style={dashboardStyles.heroSubtitle}>{bn ? 'আপনার অফলাইন + অনলাইন সহকারী' : 'YOUR OFFLINE + ONLINE ASSISTANT'}</Text>
            <View style={dashboardStyles.voiceState}>
              <View style={dashboardStyles.voiceWave}><View style={dashboardStyles.waveBar} /><View style={[dashboardStyles.waveBar, { height: 18 }]} /><View style={[dashboardStyles.waveBar, { height: 10 }]} /><View style={[dashboardStyles.waveBar, { height: 23 }]} /><View style={[dashboardStyles.waveBar, { height: 14 }]} /></View>
              <Text style={dashboardStyles.voiceStateText}>{isListening ? (bn ? 'শুনছি… বলো' : 'LISTENING… SPEAK') : isSending ? (bn ? 'ভাবছি…' : 'PROCESSING…') : (bn ? 'কথা বলার জন্য প্রস্তুত' : 'READY FOR VOICE')}</Text>
            </View>
          </View>

          <View style={dashboardStyles.rightColumn}>
            <DashboardPanel title="AI CORE STATUS" subtitle={bn ? 'ইন্টেলিজেন্স পাইপলাইন' : 'Intelligence pipeline'}>
              <StatusLine label={bn ? 'অফলাইন ব্রেইন' : 'Offline brain'} value="READY" />
              <StatusLine label={bn ? 'অনলাইন রাউটিং' : 'Online routing'} value="READY" />
              <StatusLine label={bn ? 'ভয়েস ইঞ্জিন' : 'Voice engine'} value={isListening ? 'ACTIVE' : 'STANDBY'} />
              <StatusLine label={bn ? 'মেমোরি' : 'Memory'} value="200 MAX" />
            </DashboardPanel>

            <DashboardPanel title="ROOT CAUSE ANALYSIS" subtitle={bn ? 'সিস্টেম বিশ্লেষণ' : 'System analysis'}>
              <View style={dashboardStyles.rootCauseRow}>
                <View style={[dashboardStyles.rcNode, dashboardStyles.rcDanger]}><Text style={dashboardStyles.rcText}>!</Text></View>
                <View style={dashboardStyles.rcLine} />
                <View style={[dashboardStyles.rcNode, dashboardStyles.rcOk]}><Text style={dashboardStyles.rcText}>✓</Text></View>
                <View style={dashboardStyles.rcLine} />
                <View style={[dashboardStyles.rcNode, dashboardStyles.rcBlue]}><Text style={dashboardStyles.rcText}>A</Text></View>
              </View>
              <Text style={dashboardStyles.analysisText}>{bn ? 'সব কোর সিস্টেম স্বাভাবিক' : 'Core systems operating normally'}</Text>
            </DashboardPanel>
          </View>
        </View>

        <View style={dashboardStyles.pipelineCard}>
          <View style={dashboardStyles.cardHeader}>
            <View><Text style={dashboardStyles.cardEyebrow}>OBSERVABILITY PIPELINE</Text><Text style={dashboardStyles.cardTitle}>{bn ? 'কমান্ড প্রসেসিং' : 'Command processing'}</Text></View>
            <Text style={dashboardStyles.pipelineLatency}>{isSending ? '320 ms' : 'READY'}</Text>
          </View>
          <View style={dashboardStyles.pipelineRow}>
            {['COLLECT', 'PROCESS', 'ENRICH', 'ROUTE', 'DELIVER'].map((label, i) => (
              <React.Fragment key={label}>
                <View style={dashboardStyles.pipelineNode}><View style={dashboardStyles.pipelineIcon}><Text style={dashboardStyles.pipelineIconText}>{['⌕', '◉', '✦', '⇄', '✓'][i]}</Text></View><Text style={dashboardStyles.pipelineLabel}>{label}</Text></View>
                {i < 4 ? <View style={dashboardStyles.pipelineConnector} /> : null}
              </React.Fragment>
            ))}
          </View>
        </View>

        <View style={dashboardStyles.bottomStatsRow}>
          <DashboardStat label="LATENCY" value={isSending ? '320 ms' : '120 ms'} trend="↓ 3.6x" />
          <DashboardStat label="METRICS" value="12.6K" trend="↑ 8.0%" />
          <DashboardStat label="TRACES" value="4.3M" trend="↑ 12.7%" />
          <DashboardStat label="ALERTS" value={active ? '1' : '0'} trend="STABLE" />
        </View>

        <View style={dashboardStyles.askCard}>
          <View style={dashboardStyles.askHeader}>
            <View style={dashboardStyles.askAvatar}><Text style={dashboardStyles.askAvatarText}>A</Text></View>
            <View style={{ flex: 1 }}><Text style={dashboardStyles.askTitle}>{bn ? 'ABIR AI ASSISTANT' : 'ABIR AI ASSISTANT'}</Text><Text style={dashboardStyles.askSubtitle}>{bn ? 'কমান্ড বলো বা লিখে পাঠাও' : 'Speak or type a command'}</Text></View>
            <View style={dashboardStyles.secureBadge}><Text style={dashboardStyles.secureText}>LOCAL-FIRST</Text></View>
          </View>
          <View style={dashboardStyles.commandBar}>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              onSubmitEditing={() => onSend(draft)}
              placeholder={bn ? 'আবিরকে কমান্ড দাও…' : 'Ask Abir to do something…'}
              placeholderTextColor="#6D86B8"
              style={dashboardStyles.commandInput}
              multiline
              maxLength={1000}
            />
            <Pressable onPress={onVoice} disabled={isListening || isSending} style={[dashboardStyles.voiceButton, (isListening || isSending) && dashboardStyles.voiceButtonActive]}>
              <Text style={dashboardStyles.voiceButtonText}>{isListening ? '●' : 'MIC'}</Text>
            </Pressable>
            <Pressable onPress={() => onSend(draft)} disabled={!draft.trim() || isSending} style={[dashboardStyles.sendButton, (!draft.trim() || isSending) && dashboardStyles.sendButtonDisabled]}>
              <Text style={dashboardStyles.sendButtonText}>➤</Text>
            </Pressable>
          </View>

          {messages.length > 1 ? (
            <View style={dashboardStyles.conversationCard}>
              <View style={dashboardStyles.voiceHistoryHeader}>
                <Text style={dashboardStyles.cardEyebrow}>{bn ? 'CONVERSATION' : 'CONVERSATION'}</Text>
                <Text style={dashboardStyles.voiceHistoryHint}>{bn ? 'সাম্প্রতিক' : 'Recent'}</Text>
              </View>
              {messages.slice(-4).map(item => (
                <View key={item.id} style={[dashboardStyles.conversationRow, item.role === 'user' ? dashboardStyles.conversationUser : dashboardStyles.conversationAssistant]}>
                  <View style={[dashboardStyles.conversationAvatar, item.role === 'user' ? dashboardStyles.conversationUserAvatar : dashboardStyles.conversationAssistantAvatar]}>
                    <Text style={dashboardStyles.conversationAvatarText}>{item.role === 'user' ? 'U' : 'A'}</Text>
                  </View>
                  <View style={[dashboardStyles.conversationBubble, item.role === 'user' ? dashboardStyles.conversationUserBubble : dashboardStyles.conversationAssistantBubble]}>
                    <Text style={dashboardStyles.conversationText}>{item.text}</Text>
                  </View>
                </View>
              ))}
            </View>
          ) : null}

          <View style={dashboardStyles.quickActionsRow}>
            {[
              [bn ? '📞 কল' : '📞 Call', 'কল করো'],
              [bn ? '📱 অ্যাপ' : '📱 App', 'YouTube খোলো'],
              [bn ? '🕐 সময়' : '🕐 Time', 'এখন সময় কত?'],
              [bn ? '🔋 ব্যাটারি' : '🔋 Battery', 'ব্যাটারি কত?'],
            ].map(([label, command]) => (
              <Pressable key={command} onPress={() => onSend(command)} disabled={isSending} style={dashboardStyles.quickActionChip}>
                <Text style={dashboardStyles.quickActionText}>{label}</Text>
              </Pressable>
            ))}
          </View>

          {voiceHistory.length > 0 ? (
            <View style={dashboardStyles.voiceHistoryBox}>
              <View style={dashboardStyles.voiceHistoryHeader}>
                <Text style={dashboardStyles.cardEyebrow}>VOICE HISTORY</Text>
                <Text style={dashboardStyles.voiceHistoryHint}>{voiceHistory.length}/20</Text>
              </View>
              {voiceHistory.slice(0, 3).map(item => (
                <View key={item.id} style={dashboardStyles.voiceHistoryRow}>
                  <View style={dashboardStyles.historyMic}><Text style={dashboardStyles.historyMicText}>⌁</Text></View>
                  <Text numberOfLines={1} style={dashboardStyles.voiceHistoryText}>{item.text}</Text>
                  <Text style={dashboardStyles.voiceHistoryTime}>{new Date(item.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
                </View>
              ))}
            </View>
          ) : null}
        </View>
      </ScrollView>

      <FloatingVoiceOrb
        active={isListening || isSending}
        speaking={isSpeaking}
        online={online}
        language={language}
        onPress={onVoice}
      />
    </View>
  );
}

function DashboardMetric({ label, value, trend }: { label: string; value: string; trend: string }) {
  return (
    <View style={dashboardStyles.metricCard}>
      <Text style={dashboardStyles.metricLabel}>{label}</Text>
      <Text style={dashboardStyles.metricValue}>{value}</Text>
      <View style={dashboardStyles.metricTrendRow}><Text style={dashboardStyles.metricTrend}>{trend}</Text><View style={dashboardStyles.metricSpark}><View style={dashboardStyles.sparkLine} /></View></View>
    </View>
  );
}

function DashboardPanel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <View style={dashboardStyles.panel}>
      <Text style={dashboardStyles.cardEyebrow}>{title}</Text>
      <Text style={dashboardStyles.panelSubtitle}>{subtitle}</Text>
      <View style={dashboardStyles.panelBody}>{children}</View>
    </View>
  );
}

function StatusLine({ label, value }: { label: string; value: string }) {
  return (
    <View style={dashboardStyles.statusItem}>
      <View style={dashboardStyles.statusCheck}><Text style={dashboardStyles.statusCheckText}>✓</Text></View>
      <Text numberOfLines={1} style={dashboardStyles.statusItemLabel}>{label}</Text>
      <Text style={dashboardStyles.statusItemValue}>{value}</Text>
    </View>
  );
}

function DashboardStat({ label, value, trend }: { label: string; value: string; trend: string }) {
  return (
    <View style={dashboardStyles.bottomStat}>
      <Text style={dashboardStyles.metricLabel}>{label}</Text>
      <Text style={dashboardStyles.bottomStatValue}>{value}</Text>
      <Text style={dashboardStyles.metricTrend}>{trend}</Text>
    </View>
  );
}

function getDeviceAction(text: string): 'back' | 'home' | 'recents' | 'notifications' | 'quick-settings' | null {
  const n = text.toLowerCase();
  if (/(?:back|go back|পিছনে যাও|পেছনে যাও)/i.test(n)) return 'back';
  if (/(?:home|go home|হোমে যাও|হোমে নিয়ে যাও)/i.test(n)) return 'home';
  if (/(?:recent apps|recents|সাম্প্রতিক অ্যাপ|রিসেন্ট অ্যাপ)/i.test(n)) return 'recents';
  if (/(?:notifications|notification panel|নোটিফিকেশন|বিজ্ঞপ্তি)/i.test(n)) return 'notifications';
  if (/(?:quick settings|quick panel|কুইক সেটিংস|কুইক প্যানেল)/i.test(n)) return 'quick-settings';
  return null;
}
function replyNeedsDeviceAction(text: string) { return getDeviceAction(text) !== null; }

type Message = {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  time: number;
  intent?: AssistantIntent;
};

type SavedChat = {
  messages: Message[];
  language: AssistantLanguage;
  autoSpeak: boolean;
};

type VoiceHistoryItem = {
  id: string;
  text: string;
  time: number;
};

type UiIconName =
  | 'sparkles'
  | 'volume-high'
  | 'volume-mute'
  | 'volume-medium'
  | 'trash'
  | 'mic'
  | 'arrow-up'
  | 'settings'
  | 'close'
  | 'camera'
  | 'shield'
  | 'more'
  | 'person';

function UiIcon({
  name,
  color,
  size = 20,
}: {
  name: UiIconName;
  color: string;
  size?: number;
}) {
  const strokeProps = {
    fill: 'none',
    stroke: color,
    strokeWidth: 1.8,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };

  let drawing: React.ReactNode;
  switch (name) {
    case 'sparkles':
      drawing = (
        <>
          <Path
            d="M12 3 13.9 8.1 19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"
            {...strokeProps}
          />
          <Path d="M19 15v4M17 17h4" {...strokeProps} />
        </>
      );
      break;
    case 'volume-high':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a9 9 0 0 1 0 11" {...strokeProps} />
        </>
      );
      break;
    case 'volume-medium':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6" {...strokeProps} />
        </>
      );
      break;
    case 'volume-mute':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="m17 9 5 6m0-6-5 6" {...strokeProps} />
        </>
      );
      break;
    case 'trash':
      drawing = (
        <>
          <Path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14" {...strokeProps} />
          <Path d="M9 7V4h6v3" {...strokeProps} />
        </>
      );
      break;
    case 'mic':
      drawing = (
        <>
          <Rect x="9" y="3" width="6" height="12" rx="3" {...strokeProps} />
          <Path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" {...strokeProps} />
        </>
      );
      break;
    case 'arrow-up':
      drawing = <Path d="M12 19V5M6 11l6-6 6 6" {...strokeProps} />;
      break;
    case 'settings':
      drawing = (
        <>
          <Path
            d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z"
            {...strokeProps}
          />
          <Path
            d="m19.4 15 .1.1a1.8 1.8 0 1 1-2.5 2.5l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.3a1.8 1.8 0 1 1-3.6 0v-.2a1.7 1.7 0 0 0-2.9-1.2l-.1.1a1.8 1.8 0 1 1-2.5-2.5l.1-.1a1.7 1.7 0 0 0-1.2-2.9h-.3a1.8 1.8 0 1 1 0-3.6h.2a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a1.8 1.8 0 1 1 2.5-2.5l.1.1a1.7 1.7 0 0 0 2.9-1.2v-.3a1.8 1.8 0 1 1 3.6 0v.2a1.7 1.7 0 0 0 2.9 1.2l.1-.1a1.8 1.8 0 1 1 2.5 2.5l-.1.1a1.7 1.7 0 0 0 1.2 2.9h.3a1.8 1.8 0 1 1 0 3.6h-.2a1.7 1.7 0 0 0-1.2 2.9Z"
            {...strokeProps}
          />
        </>
      );
      break;
    case 'close':
      drawing = <Path d="m6 6 12 12M18 6 6 18" {...strokeProps} />;
      break;
    case 'camera':
      drawing = (
        <>
          <Path d="M4 8h3l1.5-2h7L17 8h3v11H4V8Z" {...strokeProps} />
          <Circle cx="12" cy="13.5" r="3.5" {...strokeProps} />
        </>
      );
      break;
    case 'person':
      drawing = (
        <>
          <Circle cx="12" cy="8" r="3" {...strokeProps} />
          <Path d="M5 20c.8-4 3.1-6 7-6s6.2 2 7 6" {...strokeProps} />
        </>
      );
      break;
    case 'more':
      drawing = (
        <>
          <Circle cx="6" cy="12" r="1.2" fill={color} />
          <Circle cx="12" cy="12" r="1.2" fill={color} />
          <Circle cx="18" cy="12" r="1.2" fill={color} />
        </>
      );
      break;
    case 'shield':
      drawing = (
        <>
          <Path d="M12 3 19 6v5c0 4.5-2.9 8-7 10-4.1-2-7-5.5-7-10V6l7-3Z" {...strokeProps} />
          <Path d="m9 12 2 2 4-4" {...strokeProps} />
        </>
      );
      break;
    default:
      drawing = <Circle cx="12" cy="12" r="8" {...strokeProps} />;
  }

  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityRole="image">
      {drawing}
    </Svg>
  );
}

const STORAGE_KEY = 'abir-ai-chat-v1';
const MAX_MESSAGES = 160;
const CAMERA_MEMORY_KEY = 'abir-ai-camera-memory-v1';
const MAX_CAMERA_MEMORIES = 5;
const APP_LOCK_KEY = 'abir-ai-app-lock-v2';
const WAKE_WORD_KEY = 'abir-ai-wake-word-v2';
const ACCOUNT_KEY = 'abir-ai-account-v2';
const ACCOUNT_EMAIL_KEY = 'abir-ai-account-email-v2';
const ACCOUNT_PASSWORD_KEY = 'abir-ai-account-password-v2';
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';
const SECURITY_LOG_KEY = 'abir-ai-security-log-v1';
const MAX_SECURITY_LOGS = 60;
const VOICE_HISTORY_KEY = 'abir-ai-voice-history-v1';
const MAX_VOICE_HISTORY = 20;

function messagingPackage(app: MessageRequest['app']) {
  return app === 'imo' ? 'com.imo.android.imoim' : 'com.facebook.orca';
}

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function welcomeMessage(language: AssistantLanguage): Message {
  return {
    id: 'welcome',
    role: 'assistant',
    text:
      language === 'bn'
        ? 'হ্যালো! আমি আবির, তোমার মোবাইল AI Assistant। আমি অফলাইন ও অনলাইন—দুইভাবেই কাজ করি। কী করতে হবে বলো, বস?'
        : 'Hi! I’m Abir, your Android Assistant. I can work both offline and online. What would you like me to do?',
    time: Date.now(),
  };
}

function isSavedChat(value: unknown): value is SavedChat {
  if (!value || typeof value !== 'object') return false;
  const saved = value as Partial<SavedChat>;
  return (
    Array.isArray(saved.messages) &&
    (saved.language === 'bn' || saved.language === 'en') &&
    typeof saved.autoSpeak === 'boolean' &&
    saved.messages.every(
      (message) =>
        message &&
        typeof message.id === 'string' &&
        (message.role === 'assistant' || message.role === 'user') &&
        typeof message.text === 'string' &&
        typeof message.time === 'number',
    )
  );
}

function getTimeLabel(timestamp: number, language: AssistantLanguage) {
  return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
  }).format(timestamp);
}

function isCancelAppChoice(text: string) {
  return /^(?:cancel|never mind|nevermind|stop|থাক|বাদ দাও|বাতিল|না)$/i.test(
    text.trim(),
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([welcomeMessage('bn')]);
  const [language, setLanguage] = useState<AssistantLanguage>('bn');
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [voiceGender, setVoiceGender] = useState<VoiceGenderPreference>(DEFAULT_PREFERENCES.voiceGender);
  const [speechVoices, setSpeechVoices] = useState<SpeechVoice[]>([]);
  const [draft, setDraft] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [online, setOnline] = useState(false);
  const [voiceHistory, setVoiceHistory] = useState<VoiceHistoryItem[]>([]);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(true);
  const [wakeWordReady, setWakeWordReady] = useState(false);
  const [savedCameraUris, setSavedCameraUris] = useState<string[]>([]);
  const [cameraPreviewUri, setCameraPreviewUri] = useState<string | null>(null);
  const [ownerVerified, setOwnerVerified] = useState(false);
  const [appLockEnabled, setAppLockEnabled] = useState(false);
  const [appUnlocked, setAppUnlocked] = useState(false);
  const [securityLogs, setSecurityLogs] = useState<Array<{id:string;time:number;event:string;detail?:string}>>([]);
  const [memory, setMemory] = useState<AssistantMemory>(EMPTY_MEMORY);
  const [account, setAccount] = useState<{email:string;apiKey:string} | null>(null);
  const [accountLoggedIn, setAccountLoggedIn] = useState(false);
  const [accountReady, setAccountReady] = useState(false);
  const [accountEmail, setAccountEmail] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [accountApiKey, setAccountApiKey] = useState('');
  const [showAccountSetup, setShowAccountSetup] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [pendingAppChoices, setPendingAppChoices] = useState<
    LaunchableApp[] | null
  >(null);
  const [pendingContactChoices, setPendingContactChoices] = useState<
    ContactPhone[] | null
  >(null);
  const inputRef = useRef<TextInput>(null);
  const voicePulse = useRef(new Animated.Value(1)).current;
  const orbRotation = useRef(new Animated.Value(0)).current;
  const orbRotationReverse = useRef(new Animated.Value(0)).current;
  const lastAssistantText = useRef<string | null>(null);
  const overlayPromptedRef = useRef(false);

  useEffect(() => {
    if (!isListening && !isSending) {
      voicePulse.stopAnimation();
      voicePulse.setValue(1);
      return;
    }

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(voicePulse, {
          toValue: 1.12,
          duration: 650,
          useNativeDriver: true,
        }),
        Animated.timing(voicePulse, {
          toValue: 1,
          duration: 650,
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => {
      loop.stop();
      voicePulse.setValue(1);
    };
  }, [isListening, isSending, voicePulse]);

  useEffect(() => {
    const forward = Animated.loop(Animated.timing(orbRotation, { toValue: 1, duration: 7200, useNativeDriver: true }));
    const reverse = Animated.loop(Animated.timing(orbRotationReverse, { toValue: 1, duration: 9800, useNativeDriver: true }));
    forward.start();
    reverse.start();
    return () => { forward.stop(); reverse.stop(); };
  }, [orbRotation, orbRotationReverse]);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!mounted || !stored) return;
        const parsed: unknown = JSON.parse(stored);
        if (!isSavedChat(parsed)) return;
        setMessages(parsed.messages);
        setLanguage(parsed.language);
      })
      .catch(() => {
        // A corrupt or unavailable local cache should not prevent a new chat.
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });

    AsyncStorage.getItem(VOICE_HISTORY_KEY)
      .then(raw => {
        if (!raw || !mounted) return;
        try {
          const parsed: unknown = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            const valid = parsed.filter((item): item is VoiceHistoryItem =>
              Boolean(item) &&
              typeof item === 'object' &&
              typeof (item as VoiceHistoryItem).id === 'string' &&
              typeof (item as VoiceHistoryItem).text === 'string' &&
              typeof (item as VoiceHistoryItem).time === 'number',
            );
            setVoiceHistory(valid.slice(-MAX_VOICE_HISTORY).reverse());
          }
        } catch {}
      })
      .catch(() => {});

    AsyncStorage.getItem('abir-ai-auto-speak-v1').then(value => {
      if (value === 'on') setAutoSpeak(true);
      if (value === 'off') setAutoSpeak(false);
    }).catch(() => {});
    AsyncStorage.getItem(WAKE_WORD_KEY).then(value => {
      if (value === 'on') setWakeWordEnabled(true);
      else if (value === 'off') setWakeWordEnabled(false);
      setWakeWordReady(true);
    }).catch(() => setWakeWordReady(true));

    Promise.all([
      AsyncStorage.getItem(APP_LOCK_KEY),
      SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY),
      SecureStore.getItemAsync(ACCOUNT_API_KEY),
      SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY),
      AsyncStorage.getItem(SECURITY_LOG_KEY),
    ]).then(([lock, email, key, savedPassword, logs]) => {
      setAppLockEnabled(lock === 'enabled');
      setAppUnlocked(lock !== 'enabled');
      if (email) {
        setAccountEmail(email);
        setAccountApiKey(key ?? '');
        setAccount({ email, apiKey: key ?? '' });
        setAccountLoggedIn(false);
      }
      if (logs) {
        try { const v = JSON.parse(logs); if (Array.isArray(v)) setSecurityLogs(v.slice(-MAX_SECURITY_LOGS)); } catch {}
      }
      setAccountReady(true);
    }).catch(() => setAccountReady(true));

    loadLocalMemory().then(setMemory).catch(() => setMemory(EMPTY_MEMORY));
    Promise.all([loadAssistantPreferences(), loadSpeechVoices()])
      .then(([preferences, voices]) => {
        setVoiceGender(preferences.voiceGender);
        setSpeechVoices(voices);
      })
      .catch(() => {});

    AsyncStorage.getItem(CAMERA_MEMORY_KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setSavedCameraUris(
            parsed
              .filter((value): value is string => typeof value === 'string')
              .slice(0, MAX_CAMERA_MEMORIES),
          );
        }
      })
      .catch(() => {});

    // Owner verification uses the phone's built-in biometric system.
    // Abir does not store or compare face/fingerprint templates itself.

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android' || isLoading || !wakeWordReady) return;
    let mounted = true;
    let lastWakeUrl = '';
    let lastWakeHandledAt = 0;
    const handleWakeUrl = async (url: string) => {
      if (!url.startsWith('abir-ai://wake')) return;
      const now = Date.now();
      if (url === lastWakeUrl && now - lastWakeHandledAt < 2500) return;
      lastWakeUrl = url;
      lastWakeHandledAt = now;
      const parsed = Linking.parse(url);
      const command = typeof parsed.queryParams?.text === 'string'
        ? parsed.queryParams.text.trim()
        : '';
      if (!mounted) return;
      if (command) {
        await sendText(command, true);
      } else {
        await startVoiceInput();
      }
    };

    const subscription = Linking.addEventListener('url', ({ url }) => {
      void handleWakeUrl(url);
    });
    void Linking.getInitialURL().then((url) => {
      if (url) void handleWakeUrl(url);
    });

    let appStateSub: { remove: () => void } | null = null;
    if (wakeWordEnabled) {
      void enableWakeWord();
      appStateSub = AppState.addEventListener('change', state => {
        if (state === 'active' && wakeWordEnabled) void enableWakeWord();
      });
    }

    return () => {
      mounted = false;
      subscription.remove();
      appStateSub?.remove();
      void stopWakeWord();
    };
  }, [isLoading, wakeWordEnabled, wakeWordReady]);

  const ensureMicrophonePermission = async () => {
    if (Platform.OS !== 'android') return true;
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    return permission === PermissionsAndroid.RESULTS.GRANTED;
  };

  useEffect(() => {
    let mounted = true;
    const refresh = async () => {
      try {
        const value = await getOnlineStatus();
        if (mounted) setOnline(Boolean(value));
      } catch {
        if (mounted) setOnline(false);
      }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 10000);
    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, []);

  const enableWakeWord = async () => {
    const granted = await ensureMicrophonePermission();
    if (!granted) {
      setWakeWordEnabled(false);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'off').catch(() => {});
      return false;
    }
    const overlayReady = await canDrawOverlays();
    if (!overlayReady && !overlayPromptedRef.current) {
      overlayPromptedRef.current = true;
      Alert.alert(
        language === 'bn' ? 'ছোট Voice UI-এর অনুমতি দরকার' : 'Small voice UI permission',
        language === 'bn'
          ? 'অ্যাপের বাইরে ছোট Abir voice UI দেখাতে “Display over other apps” অনুমতি দাও। অনুমতি না দিলেও Wake Word শুনতে চেষ্টা করবে।'
          : 'Allow “Display over other apps” for the small Abir voice UI. Wake Word will still try to work without this permission.',
        [
          { text: language === 'bn' ? 'এখন না' : 'Not now', style: 'cancel' },
          { text: language === 'bn' ? 'সেটিংস' : 'Settings', onPress: () => void openOverlaySettings() },
        ],
      );
    }
    const started = await startWakeWord();
    if (!started) {
      setWakeWordEnabled(false);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'off').catch(() => {});
    } else {
      setWakeWordEnabled(true);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'on').catch(() => {});
    }
    return started;
  };

  useEffect(() => {
    if (isLoading) return;
    const saved: SavedChat = {
      messages: messages.slice(-MAX_MESSAGES),
      language,
      autoSpeak,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(saved)).catch(() => {
      Alert.alert(
        language === 'bn' ? 'চ্যাট সংরক্ষণ হয়নি' : 'Chat not saved',
        language === 'bn'
          ? 'এই ডিভাইসে চ্যাট সংরক্ষণ করা যায়নি।'
          : 'This chat could not be saved on this device.',
      );
    });
  }, [autoSpeak, isLoading, language, messages]);

  const speakMessage = async (message: Message) => {
    try {
      setSpeakingId(message.id);
      const speechLanguage: AssistantLanguage = /[\u0980-\u09FF]/.test(message.text) ? 'bn' : language;
      const languageTag = speechLanguage === 'bn' ? 'bn-BD' : 'en-US';

      // Android native TTS is the primary path because some Android TTS engines
      // can silently ignore an Expo voice identifier even though the UI looks active.
      if (Platform.OS === 'android') {
        const nativeStarted = await speakNativeText(message.text, languageTag, voiceGender);
        if (nativeStarted) {
          const approxMs = Math.min(12000, Math.max(1200, message.text.length * (speechLanguage === 'bn' ? 58 : 52)));
          setTimeout(() => setSpeakingId(current => current === message.id ? null : current), approxMs);
          return;
        }
      }

      await speakAssistantText({
        text: message.text,
        language: speechLanguage,
        voiceGender,
        voices: speechVoices,
        onDone: () => setSpeakingId(null),
        onError: () => {
          setSpeakingId(null);
          Alert.alert(
            language === 'bn' ? 'ভয়েস পাওয়া যায়নি' : 'Voice unavailable',
            language === 'bn'
              ? 'ফোনের Text-to-Speech-এ বাংলা/পছন্দের ভয়েস ইনস্টল আছে কি না দেখে নাও।'
              : 'Check that the phone has a compatible Text-to-Speech voice installed.',
          );
        },
      });
    } catch {
      setSpeakingId(null);
    }
  };

  const repeatLastAssistantReply = async () => {
    const lastAssistant = [...messages].reverse().find(item => item.role === 'assistant');
    if (!lastAssistant) {
      Alert.alert(
        language === 'bn' ? 'এখনো কোনো উত্তর নেই' : 'No reply yet',
        language === 'bn' ? 'Abir-এর কোনো আগের উত্তর পাওয়া যায়নি।' : 'There is no previous Abir reply to repeat.',
      );
      return;
    }
    await speakMessage(lastAssistant);
  };

  const stopVoiceReply = async () => {
    try {
      await Promise.all([Speech.stop(), stopNativeSpeaking()]);
    } finally {
      setSpeakingId(null);
    }
  };

  const addSecurityLog = async (event: string, detail?: string) => {
    const entry = { id: createId(), time: Date.now(), event, detail };
    setSecurityLogs(current => {
      const next = [...current, entry].slice(-MAX_SECURITY_LOGS);
      AsyncStorage.setItem(SECURITY_LOG_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  const authenticateSensitiveDeviceAction = async (action: string) => {
    try {
      // High-risk device actions require a live offline voice authorization first.
      // This is a voice challenge, not a claim of biometric speaker recognition.
      // Android biometric/device credential verification remains the final gate.
      const challenge = language === 'bn'
        ? 'আমি আবিরের মালিক'
        : 'I am the owner of Abir';
      const heard = await listenForOfflineText(language);
      if (!heard) {
        await addSecurityLog('sensitive-action-blocked', `${action}:offline-voice-unavailable`);
        return false;
      }
      const normalizeVoice = (value: string) => value
        .toLowerCase()
        .replace(/[.!?,،。]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      const voiceOk = normalizeVoice(heard) === normalizeVoice(challenge);
      await addSecurityLog(voiceOk ? 'voice-authorization-passed' : 'voice-authorization-denied', action);
      if (!voiceOk) return false;

      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      const level = await LocalAuthentication.getEnrolledLevelAsync();
      const hasDeviceCredential = level !== LocalAuthentication.SecurityLevel.NONE;
      if (!hasHardware && !hasDeviceCredential) {
        await addSecurityLog('sensitive-action-blocked', `${action}:no-device-auth`);
        return false;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'মালিক যাচাই শেষ করো' : 'Complete owner verification',
        promptSubtitle: language === 'bn' ? 'Fingerprint/Face/PIN/Password দিয়ে নিশ্চিত করো' : 'Confirm with Fingerprint/Face/PIN/Password',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      await addSecurityLog(result.success ? 'sensitive-action-authorized' : 'sensitive-action-denied', action);
      return result.success;
    } catch {
      await addSecurityLog('sensitive-action-error', action);
      return false;
    }
  };

  const authenticateOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      const level = await LocalAuthentication.getEnrolledLevelAsync();
      const hasDeviceCredential = level !== LocalAuthentication.SecurityLevel.NONE;
      if (!hasHardware && !hasDeviceCredential) return false;
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'Abir AI আনলক করো' : 'Unlock Abir AI',
        promptSubtitle: 'Fingerprint/Face/PIN/Password',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      await addSecurityLog(result.success ? 'unlock-success' : 'unlock-failed');
      return result.success;
    } catch {
      await addSecurityLog('unlock-error');
      return false;
    }
  };

  const configureAppLock = async () => {
    const ok = await authenticateOwner();
    if (!ok) {
      Alert.alert(
        language === 'bn' ? 'ভেরিফিকেশন দরকার' : 'Verification required',
        language === 'bn' ? 'ফোনের fingerprint/face/PIN/password দিয়ে যাচাই করো।' : 'Verify with the phone fingerprint/face/PIN/password.',
      );
      return;
    }
    setOwnerVerified(true);
    const next = !appLockEnabled;
    await AsyncStorage.setItem(APP_LOCK_KEY, next ? 'enabled' : 'disabled');
    setAppLockEnabled(next);
    setAppUnlocked(true);
    await addSecurityLog(next ? 'app-lock-enabled' : 'app-lock-disabled');
    Alert.alert(
      next ? (language === 'bn' ? 'App Lock চালু' : 'App Lock enabled') : (language === 'bn' ? 'App Lock বন্ধ' : 'App Lock disabled'),
      next
        ? (language === 'bn' ? 'Abir background-এ গেলে আবার lock হবে।' : 'Abir will lock when it goes to the background.')
        : (language === 'bn' ? 'এখন আর App Lock থাকবে না।' : 'App Lock is now disabled.'),
    );
  };

  const saveAccount = async () => {
    const email = accountEmail.trim();
    const password = accountPassword.trim();
    const key = accountApiKey.trim();
    if (!email || !password) {
      Alert.alert(
        language === 'bn' ? 'তথ্য অসম্পূর্ণ' : 'Missing information',
        language === 'bn' ? 'Email এবং password দাও।' : 'Enter email and password.',
      );
      return;
    }
    await SecureStore.setItemAsync(ACCOUNT_EMAIL_KEY, email);
    await SecureStore.setItemAsync(ACCOUNT_PASSWORD_KEY, password);
    if (key) await SecureStore.setItemAsync(ACCOUNT_API_KEY, key);
    else await SecureStore.deleteItemAsync(ACCOUNT_API_KEY);
    const value = { email, apiKey: key };
    setAccount(value);
    setAccountLoggedIn(true);
    setAccountPassword('');
    setShowAccountSetup(false);
    await addSecurityLog('account-configured', email);
    Alert.alert(
      language === 'bn' ? 'Login সেট হয়েছে' : 'Login configured',
      language === 'bn' ? 'Email, password এবং API key এই ফোনে নিরাপদ storage-এ রাখা হয়েছে।' : 'Email, password and API key are stored in secure device storage.',
    );
  };

  const loginAccount = async () => {
    const email = accountEmail.trim();
    const password = accountPassword;
    const savedEmail = await SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY);
    const savedPassword = await SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY);
    if (email && password && email === savedEmail && password === savedPassword) {
      setAccountLoggedIn(true);
      setAccount({ email, apiKey: accountApiKey.trim() });
      setAccountPassword('');
      setShowAccountSetup(false);
      await addSecurityLog('account-login-success', email);
      return;
    }
    Alert.alert(language === 'bn' ? 'Login ব্যর্থ' : 'Login failed', language === 'bn' ? 'Email বা password ভুল।' : 'Email or password is incorrect.');
    await addSecurityLog('account-login-failed', email || 'unknown');
  };

  useEffect(() => {
    if (isLoading || !accountReady || !appLockEnabled) return;
    const sub = AppState.addEventListener('change', state => {
      if (state === 'background' || state === 'inactive') {
        setAppUnlocked(false);
        void addSecurityLog('app-backgrounded');
      }
      if (state === 'active' && !appUnlocked) {
        void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); });
      }
    });
    if (!appUnlocked) void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); });
    return () => sub.remove();
  }, [isLoading, appLockEnabled, appUnlocked]);

  const sendText = async (rawText: string, forceSpeak = false) => {
    const text = rawText.trim();
    if (!text || isSending) return;

    Keyboard.dismiss();
    setDraft('');
    setIsSending(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

    const userMessage: Message = {
      id: createId(),
      role: 'user',
      text,
      time: Date.now(),
    };

    // Reply in the language of the current message: Bengali script -> Bengali,
    // otherwise English. This makes “hello” return English even when the UI is Bengali.
    const responseLanguage: AssistantLanguage = /[\u0980-\u09FF]/.test(text) ? 'bn' : 'en';

    // Voice-first convenience: repeat or stop can work immediately without
    // sending the phrase to Gemini or the offline fallback brain.
    if (/^(?:আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat that|say that again|say it again|again)$/i.test(text)) {
      const previous = lastAssistantText.current;
      if (previous) {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: previous, intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      } else {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'এখনো আবার বলার মতো কোনো আগের উত্তর নেই।' : 'There is no previous answer to repeat yet.', intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      }
      setIsSending(false);
      return;
    }
    if (/^(?:থামো|চুপ|চুপ করো|stop talking|stop speaking|be quiet)$/i.test(text)) {
      await Speech.stop();
      const stopMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'ঠিক আছে, কথা বলা থামালাম।' : 'Okay, I stopped speaking.', intent: 'casual', time: Date.now() };
      setMessages(current => [...current, userMessage, stopMessage].slice(-MAX_MESSAGES));
      setIsSending(false);
      return;
    }

    try {
      const memoryResult = handleMemoryCommand(text, memory);
      if (memoryResult) {
        setMemory(memoryResult.memory);
        await saveLocalMemory(memoryResult.memory);
        const assistantMessage: Message = {
          id: createId(), role: 'assistant', text: memoryResult.reply, intent: 'memory', time: Date.now(),
        };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      const messageRequest = extractMessageRequest(text);
      if (messageRequest && Platform.OS === 'android') {
        const enabled = await isAccessibilityEnabled();
        if (!enabled) {
          const responseText = messageAutomationReply(messageRequest, responseLanguage, 'not-enabled');
          const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
          setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
          await addSecurityLog('message-automation-blocked', `${messageRequest.app}:${messageRequest.recipient}`);
          Alert.alert(
            responseLanguage === 'bn' ? 'Accessibility দরকার' : 'Accessibility required',
            responseLanguage === 'bn' ? 'Messenger/IMO চালাতে Abir AI-কে Accessibility permission দিতে হবে। Settings খুলব?' : 'Abir AI needs Accessibility permission to operate Messenger/IMO. Open Settings?',
            [
              { text: responseLanguage === 'bn' ? 'না' : 'Cancel', style: 'cancel' },
              { text: 'Settings', onPress: () => void openAccessibilitySettings() },
            ],
          );
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }
        const sent = await sendMessageViaAccessibility(
          messagingPackage(messageRequest.app),
          messageRequest.recipient,
          messageRequest.message,
        );
        const responseText = messageAutomationReply(messageRequest, responseLanguage, sent ? 'sent' : 'failed');
        const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await addSecurityLog(sent ? 'message-sent' : 'message-failed', `${messageRequest.app}:${messageRequest.recipient}`);
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      if (pendingAppChoices && !extractAppQuery(text)) {
        if (isCancelAppChoice(text)) {
          setPendingAppChoices(null);
          const cancelledMessage: Message = {
            id: createId(),
            role: 'assistant',
            text:
              responseLanguage === 'bn'
                ? 'ঠিক আছে, অ্যাপ খোলা বাতিল করলাম।'
                : 'Okay, I cancelled opening an app.',
            time: Date.now(),
          };
          setMessages((current) =>
            [...current, userMessage, cancelledMessage].slice(-MAX_MESSAGES),
          );
          if (autoSpeak || forceSpeak) void speakMessage(cancelledMessage);
          return;
        }

        const selectedApp = selectAppChoice(text, pendingAppChoices);
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: selectedApp
            ? responseLanguage === 'bn'
              ? `${selectedApp.label} খুলছি…`
              : `Opening ${selectedApp.label}…`
            : appChoicePrompt(pendingAppChoices, responseLanguage),
          intent: 'open-app',
          time: Date.now(),
        };
        setMessages((current) =>
          [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES),
        );

        if (!selectedApp) {
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }

        setPendingAppChoices(null);
        const launchStatus = await launchInstalledApp(selectedApp);
        const responseText = appActionReply(
          launchStatus,
          selectedApp,
          responseLanguage,
        );
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? { ...message, text: responseText }
              : message,
          ),
        );
        if (autoSpeak || forceSpeak) {
          void speakMessage({ ...assistantMessage, text: responseText });
        }
        return;
      }

      if (pendingAppChoices) setPendingAppChoices(null);
      // Run the local command/brain first. This is important: device controls,
      // app opening, calls, memory and other deterministic actions must work
      // even with the internet completely disabled. Only unresolved questions
      // are sent to Gemini when online.
      const offlineReply = await getAssistantReply({
        text,
        language: responseLanguage,
        now: new Date(),
        memory,
        conversationContext: messages.slice(-8).map(item => ({ role: item.role, text: item.text })),
      });
      const onlineText = offlineReply.intent === 'fallback' && optionalOnlineAssistant.enabled
        ? await optionalOnlineAssistant.respond({
            text,
            language: responseLanguage === 'bn' ? 'bn' : 'en',
            conversationContext: messages.slice(-8).map(item => ({ role: item.role, text: item.text })),
          })
        : null;
      const reply = onlineText
        ? { text: onlineText, intent: 'fallback' as AssistantIntent }
        : offlineReply;
      const assistantMessage: Message = {
        id: createId(),
        role: 'assistant',
        text: reply.text,
        intent: reply.intent,
        time: Date.now(),
      };

      setMessages((current) => {
        const next =
          reply.intent === 'clear-history'
            ? [userMessage, assistantMessage]
            : [...current, userMessage, assistantMessage];
        return next.slice(-MAX_MESSAGES);
      });

      let finalAssistantMessage = assistantMessage;
      lastAssistantText.current = assistantMessage.text;
      if (reply.intent === 'clear-history') setPendingAppChoices(null);

      if (reply.intent === 'location') {
        let responseText: string;
        try {
          if (Platform.OS !== 'android') throw new Error('unsupported');
          const permission = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          );
          if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
            responseText = responseLanguage === 'bn'
              ? 'বস, তোমার বর্তমান অবস্থান জানতে Location/GPS permission দিতে হবে।'
              : 'Boss, I need Location/GPS permission to tell you where you are.';
          } else {
            const location = await getCurrentLocation();
            if (!location) {
              responseText = responseLanguage === 'bn'
                ? 'বস, GPS অবস্থান পাওয়া গেল না। ফোনের Location/GPS চালু করে বাইরে বা খোলা জায়গায় আবার চেষ্টা করো।'
                : 'Boss, I could not get your GPS location. Turn on Location/GPS and try again in an open area.';
            } else {
              const address = location.address?.trim();
              const coords = typeof location.latitude === 'number' && typeof location.longitude === 'number'
                ? `\nLatitude: ${location.latitude.toFixed(6)}, Longitude: ${location.longitude.toFixed(6)}`
                : '';
              responseText = responseLanguage === 'bn'
                ? `বস, তুমি এখন ${address || 'এই অবস্থানে'} আছো।${coords}`
                : `Boss, you are currently at ${address || 'this location'}.${coords}`;
            }
          }
        } catch {
          responseText = responseLanguage === 'bn'
            ? 'বস, তোমার অবস্থান বের করতে পারিনি। Location/GPS permission ও GPS চালু আছে কি না দেখো।'
            : 'Boss, I could not determine your location. Check Location/GPS permission and try again.';
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        lastAssistantText.current = responseText;
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
        return;
      }

      if (reply.intent === 'memory' && reply.noteText && reply.noteQuery) {
        await learnLocalAlias(reply.noteText, reply.noteQuery);
        const responseText = responseLanguage === 'bn' ? `বস, “${reply.noteText}” কমান্ডটা এখন থেকে “${reply.noteQuery}” হিসেবে বুঝব।` : `Boss, I’ll interpret “${reply.noteText}” as “${reply.noteQuery}” from now on.`;
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'notes') {
        let responseText = reply.text;
        if (reply.noteText) {
          await addLocalNote(reply.noteText);
        } else if (reply.noteQuery !== undefined) {
          const notes = await searchLocalNotes(reply.noteQuery);
          responseText = notes.length
            ? (responseLanguage === 'bn' ? `বস, পাওয়া নোট:
${notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}` : `Boss, matching notes:\n${notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}`)
            : (responseLanguage === 'bn' ? 'কোনো মিল থাকা লোকাল নোট পেলাম না।' : 'I found no matching local notes.');
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'routine') {
        let responseText = reply.text;
        if (reply.routineName && reply.routineCommand) {
          await saveLocalRoutine(reply.routineName, reply.routineCommand);
          responseText = responseLanguage === 'bn' ? `বস, “${reply.routineName}” রুটিন সেভ করেছি।` : `Boss, I saved the “${reply.routineName}” routine.`;
        } else if (reply.routineName) {
          const routine = await findLocalRoutine(reply.routineName);
          if (routine) {
            responseText = responseLanguage === 'bn' ? `বস, “${routine.name}” রুটিন চালাচ্ছি।` : `Boss, running the “${routine.name}” routine.`;
            finalAssistantMessage = { ...assistantMessage, text: responseText };
            setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
            await sendText(routine.command, forceSpeak);
            return;
          }
          responseText = responseLanguage === 'bn' ? 'এই নামে কোনো লোকাল রুটিন নেই।' : 'I could not find a local routine with that name.';
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'task-plan' && reply.plannedTasks?.length) {
        // Execute deterministic sub-commands sequentially. The original memory limit is untouched.
        for (const task of reply.plannedTasks) {
          await sendText(task, forceSpeak);
        }
        return;
      }

      if (reply.intent === 'diagnostics') {
        const d = await getDeviceDiagnostics();
        let responseText: string;
        if (!d) {
          responseText = responseLanguage === 'bn' ? 'বস, ফোনের ডিভাইস তথ্য পাওয়া গেল না।' : 'Boss, I could not read the device status.';
        } else {
          const freeGB = typeof d.freeStorageBytes === 'number' ? (d.freeStorageBytes / 1073741824).toFixed(1) : '?';
          const totalGB = typeof d.totalStorageBytes === 'number' ? (d.totalStorageBytes / 1073741824).toFixed(1) : '?';
          const battery = typeof d.batteryPercent === 'number' && d.batteryPercent >= 0 ? `${d.batteryPercent}%` : '?';
          const network = d.wifi ? 'Wi-Fi' : d.cellular ? 'Mobile data' : d.online ? 'Online' : 'Offline';
          responseText = responseLanguage === 'bn'
            ? `বস, ফোনের অবস্থা:\n🔋 ব্যাটারি: ${battery}\n💾 ফাঁকা স্টোরেজ: ${freeGB} GB / ${totalGB} GB\n🌐 নেটওয়ার্ক: ${network}\n📱 Android SDK: ${d.sdk ?? '?'}`
            : `Boss, device status:\n🔋 Battery: ${battery}\n💾 Free storage: ${freeGB} GB / ${totalGB} GB\n🌐 Network: ${network}\n📱 Android SDK: ${d.sdk ?? '?'}`;
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'reminder' && reply.reminderText && reply.reminderDelayMs) {
        let ok = false;
        if (Platform.OS === 'android' && Number(Platform.Version) >= 33) {
          try {
            const permission = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
            ok = permission === PermissionsAndroid.RESULTS.GRANTED;
          } catch { ok = false; }
        } else { ok = true; }
        if (ok) ok = await scheduleAbirReminder(reply.reminderText, reply.reminderDelayMs);
        const responseText = ok
          ? reply.text
          : (responseLanguage === 'bn' ? 'বস, Reminder notification permission দেওয়া হয়নি, তাই reminder সেট করতে পারিনি।' : 'Boss, notification permission was not granted, so I could not set the reminder.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'device-action' && reply.deviceAction) {
        let ok = false;
        // Screen locking is a sensitive device action. Never execute it solely
        // because a voice/text command was heard: require Android's own
        // biometric/device-credential verification first. This also protects
        // wake-word/background command paths from an unauthorised speaker.
        if (reply.deviceAction === 'wake-screen') {
          // Waking the display is reversible and does not unlock the device.
          // Android's secure lock screen remains in place.
          ok = await wakeDeviceScreen();
        } else if (reply.deviceAction === 'lock-screen' || reply.deviceAction === 'power-menu') {
          const verified = ownerVerified || await authenticateSensitiveDeviceAction(reply.deviceAction);
          if (verified) {
            ok = await performDeviceAction(reply.deviceAction);
            if (ok) setOwnerVerified(true);
          }
        }
        else if (reply.deviceAction === 'volume-up') ok = await adjustDeviceVolume('up');
        else if (reply.deviceAction === 'volume-down') ok = await adjustDeviceVolume('down');
        else if (reply.deviceAction === 'volume-mute') ok = await adjustDeviceVolume('mute');
        else if (reply.deviceAction === 'volume-set' && typeof reply.deviceValue === 'number') ok = await setDeviceVolumePercent(reply.deviceValue);
        else if (reply.deviceAction === 'flashlight-on') ok = await setFlashlight(true);
        else if (reply.deviceAction === 'flashlight-off') ok = await setFlashlight(false);
        else if (reply.deviceAction === 'media-play') ok = await controlMedia('play');
        else if (reply.deviceAction === 'media-pause') ok = await controlMedia('pause');
        else if (reply.deviceAction === 'media-next') ok = await controlMedia('next');
        else if (reply.deviceAction === 'media-previous') ok = await controlMedia('previous');
        else if (reply.deviceAction === 'vibrate') ok = await setRingerMode('vibrate');
        else if (reply.deviceAction === 'ringer-normal') ok = await setRingerMode('normal');
        else if (reply.deviceAction === 'wifi-settings' || reply.deviceAction === 'bluetooth-settings' || reply.deviceAction === 'mobile-data-panel') {
          ok = await openSystemSettings(reply.deviceAction);
        } else if (reply.deviceAction === 'settings') {
          ok = await openSystemSettings('settings');
        } else {
          ok = await performDeviceAction(reply.deviceAction);
        }
        let responseText = ok
          ? reply.text
          : ((reply.deviceAction === 'lock-screen' || reply.deviceAction === 'power-menu')
            ? (responseLanguage === 'bn'
              ? 'বস, Owner voice authorization বা Fingerprint/Face/PIN/Password যাচাই সম্পূর্ণ হয়নি, তাই কাজটি করিনি।'
              : 'Boss, I did not perform the power action because owner voice authorization or device verification was not completed.')
            : (responseLanguage === 'bn' ? 'বস, এই ফোনে কাজটি করা গেল না। প্রয়োজনীয় Android permission/Accessibility চালু আছে কি না দেখে আবার চেষ্টা করো।' : 'I could not perform that action on this phone. Check the required Android permission/Accessibility access and try again.'));
        if (ok && (reply.deviceAction === 'volume-up' || reply.deviceAction === 'volume-down' || reply.deviceAction === 'volume-set')) {
          const actual = await getDeviceVolumePercent();
          if (actual !== null && actual >= 0) {
            const shown = Math.round(actual);
            responseText = responseLanguage === 'bn' ? `মিডিয়া ভলিউম এখন প্রায় ${shown}%।` : `Media volume is now about ${shown}%.`;
          }
        }
        if (ok && ['volume-up','volume-down','volume-set','flashlight-on','flashlight-off','media-play','media-pause','media-next','media-previous','vibrate','ringer-normal'].includes(reply.deviceAction)) {
          void recordLocalAction({ action: reply.deviceAction, value: reply.deviceValue, time: Date.now() });
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'undo') {
        const last = await getLastLocalAction();
        let ok = false;
        let responseText = responseLanguage === 'bn' ? 'বস, আগের কাজটা নিরাপদভাবে ফিরিয়ে দিতে পারিনি।' : 'Boss, I could not safely undo the last action.';
        if (last?.action === 'volume-up') ok = await adjustDeviceVolume('down');
        else if (last?.action === 'volume-down') ok = await adjustDeviceVolume('up');
        else if (last?.action === 'flashlight-on') ok = await setFlashlight(false);
        else if (last?.action === 'flashlight-off') ok = await setFlashlight(true);
        else if (last?.action === 'media-play') ok = await controlMedia('pause');
        else if (last?.action === 'media-pause') ok = await controlMedia('play');
        if (ok) responseText = responseLanguage === 'bn' ? 'বস, আগের reversible কাজটা ফিরিয়ে দিয়েছি।' : 'Boss, I undid the last reversible action.';
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'screen-control' && reply.screenAction) {
        const enabled = await isAccessibilityEnabled();
        let ok = false;
        if (enabled) {
          if (reply.screenAction === 'click' && reply.screenTarget) {
            ok = await (await import('@/assistant/androidActions')).clickTextOnScreen(reply.screenTarget);
            if (!ok) ok = await smartScreenAction(reply.screenTarget);
          }
          else if (reply.screenAction === 'type' && reply.screenTarget) ok = await (await import('@/assistant/androidActions')).typeIntoFocusedField(reply.screenTarget);
          else if (reply.screenAction === 'scroll' && reply.screenTarget) ok = await (await import('@/assistant/androidActions')).scrollScreen(reply.screenTarget as 'up' | 'down' | 'left' | 'right');
        }
        const responseText = ok
          ? (responseLanguage === 'bn' ? 'বস, কাজটা করে দিয়েছি।' : 'Done, Boss.')
          : (responseLanguage === 'bn' ? 'বস, স্ক্রিনে কাজটা করতে পারিনি। Accessibility permission চালু আছে কি না দেখে আবার চেষ্টা করো।' : 'I could not control the current screen. Check Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'screen-read') {
        const screenText = await readCurrentScreenText();
        const responseText = screenText
          ? (responseLanguage === 'bn' ? `বর্তমান স্ক্রিনে যা দেখা যাচ্ছে:\n${screenText}` : `Here is the readable text on the current screen:\n${screenText}`)
          : (responseLanguage === 'bn' ? 'বস, বর্তমান স্ক্রিনের লেখা পড়তে পারিনি। Accessibility permission চালু আছে কি না দেখো।' : 'I could not read the current screen. Check Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'universal-screen-control' && reply.appQuery && reply.automationQuery) {
        const enabled = await isAccessibilityEnabled();
        let responseText = reply.text;

        if (!enabled) {
          responseText = responseLanguage === 'bn'
            ? 'এই কাজের জন্য Accessibility permission চালু করতে হবে। Settings → Accessibility থেকে Abir AI চালু করে আবার বলো।'
            : 'Accessibility permission is required. Enable Abir AI in Settings → Accessibility and try again.';
        } else {
          const discovery = await getLaunchableApps();
          if (discovery.status !== 'available') {
            responseText = appDiscoveryReply(discovery.status, responseLanguage);
          } else {
            const matches = matchInstalledApps(reply.appQuery, discovery.apps);
            if (matches.length === 0) {
              responseText = noMatchingAppReply(reply.appQuery);
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingAppChoices(choices);
              responseText = responseLanguage === 'bn'
                ? `একাধিক "${reply.appQuery}" অ্যাপ পাওয়া গেছে। আগে একটি বেছে নাও:\n${appChoicePrompt(choices, responseLanguage)}`
                : `I found multiple matches for "${reply.appQuery}". Choose one first.\n${appChoicePrompt(choices, responseLanguage)}`;
            } else {
              const ok = await searchAndOpenInApp(matches[0].packageName, reply.automationQuery);
              responseText = ok
                ? (responseLanguage === 'bn'
                    ? `${matches[0].label}-এ "${reply.automationQuery}" খুঁজে প্রথম উপযুক্ত ফল খোলার চেষ্টা করেছি।`
                    : `I searched ${matches[0].label} for "${reply.automationQuery}" and tried to open the first suitable result.`)
                : (responseLanguage === 'bn'
                    ? `${matches[0].label} খুলতে/টাইপ করতে পারিনি। Accessibility permission ও অ্যাপের UI দেখে আবার চেষ্টা করো।`
                    : `I could not complete the search in ${matches[0].label}. Check Accessibility access and try again.`);
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id ? finalAssistantMessage : message,
          ),
        );
      }

      if (reply.intent === 'open-app' && reply.appQuery) {
        const discovery = await getLaunchableApps();
        let responseText: string;

        if (discovery.status !== 'available') {
          responseText = appDiscoveryReply(discovery.status, responseLanguage);
        } else {
          const matches = matchInstalledApps(reply.appQuery, discovery.apps);
          if (matches.length === 0) {
            responseText = noMatchingAppReply(reply.appQuery);
          } else if (matches.length > 1) {
            const choices = matches.slice(0, 8);
            setPendingAppChoices(choices);
            responseText = appChoicePrompt(choices, responseLanguage);
          } else {
            const launchStatus = await launchInstalledApp(matches[0]);
            responseText = appActionReply(
              launchStatus,
              matches[0],
              responseLanguage,
            );
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      if (reply.intent === 'call-via-app' && reply.contactQuery && reply.appCallTarget) {
        const enabled = await isAccessibilityEnabled();
        const responseText = enabled
          ? (await callViaApp(reply.appCallTarget, reply.contactQuery))
            ? (responseLanguage === 'bn' ? `${reply.appCallTarget === 'whatsapp' ? 'WhatsApp' : reply.appCallTarget === 'messenger' ? 'Messenger' : 'IMO'}-এ ${reply.contactQuery}-কে কল শুরু করেছি।` : `I started a call to ${reply.contactQuery} on ${reply.appCallTarget}.`)
            : (responseLanguage === 'bn' ? `${reply.appCallTarget}-এ ${reply.contactQuery}-কে কল শুরু করা গেল না।` : `I could not start the ${reply.appCallTarget} call.`)
          : (responseLanguage === 'bn' ? 'এই কাজের জন্য Accessibility permission চালু করতে হবে।' : 'Accessibility permission is required for this app call.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'call-contact' && reply.contactQuery) {
        let responseText = reply.text;
        const directPhoneNumber = extractDirectPhoneNumber(reply.contactQuery);

        if (directPhoneNumber) {
          if (Platform.OS === 'android') {
            const permission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CALL_PHONE,
            );
            if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText =
                responseLanguage === 'bn'
                  ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                  : 'Phone-call permission was not granted. Allow it and try again.';
            } else {
              const callStatus = await placeDirectCall(directPhoneNumber);
              responseText =
                callStatus === 'placed'
                  ? responseLanguage === 'bn'
                    ? `${directPhoneNumber}-এ কল দিচ্ছি।`
                    : `Calling ${directPhoneNumber}.`
                  : responseLanguage === 'bn'
                    ? 'এই নম্বরে কল দেওয়া গেল না।'
                    : 'I could not place the call to this number.';
            }
          } else {
            responseText =
              responseLanguage === 'bn'
                ? 'এই ডিভাইস থেকে সরাসরি ফোন কল সমর্থিত নয়।'
                : 'Direct phone calls are not supported on this device.';
          }
        } else {
          if (Platform.OS === 'android') {
            const contactsPermission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
            );
            if (contactsPermission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText = responseLanguage === 'bn'
                ? 'Contacts পড়ার অনুমতি দেওয়া হয়নি। Contacts permission চালু করে আবার বলো।'
                : 'Contacts permission was not granted. Allow it and try again.';
              finalAssistantMessage = { ...assistantMessage, text: responseText };
              lastAssistantText.current = responseText;
              setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
              if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
              return;
            }
          }

          const contactsResult = await getDeviceContacts();

          if (contactsResult.status !== 'available') {
            responseText =
              responseLanguage === 'bn'
                ? 'পরিচিতির নম্বর পড়া গেল না। Contacts অনুমতি চালু আছে কি না দেখে আবার চেষ্টা করো।'
                : 'I could not read your contacts. Check Contacts permission and try again.';
          } else {
            const matches = matchContacts(reply.contactQuery, contactsResult.contacts);
            if (matches.length === 0) {
              responseText =
                responseLanguage === 'bn'
                  ? `${reply.contactQuery} নামে কোনো পরিচিতি খুঁজে পেলাম না।`
                  : `I couldn’t find a contact named ${reply.contactQuery}.`;
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingContactChoices(choices);
              responseText = formatContactChoicePrompt(choices, responseLanguage);
            } else {
              const contact = matches[0];
              if (Platform.OS === 'android') {
                const permission = await PermissionsAndroid.request(
                  PermissionsAndroid.PERMISSIONS.CALL_PHONE,
                );
                if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
                  responseText =
                    responseLanguage === 'bn'
                      ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                      : 'Phone-call permission was not granted. Allow it and try again.';
                } else {
                  const callStatus = await placeDirectCall(contact.phoneNumber);
                  responseText =
                    callStatus === 'placed'
                      ? responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দিচ্ছি।`
                        : `Calling ${contact.displayName}.`
                      : responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দেওয়া গেল না।`
                        : `I couldn’t call ${contact.displayName}.`;
                }
              }
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      const updatedMemory = addRecentTopic(memory, text);
      if (updatedMemory !== memory) {
        setMemory(updatedMemory);
        await saveLocalMemory(updatedMemory);
      }
      if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
    } finally {
      setIsSending(false);
    }
  };

  const captureCameraPhoto = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          language === 'bn' ? 'ক্যামেরা অনুমতি দরকার' : 'Camera permission needed',
          language === 'bn' ? 'ক্যামেরা চালু করার অনুমতি দাও।' : 'Allow camera access to take a photo.',
        );
        return;
      }
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: false,
        base64: true,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const asset = result.assets[0];
      const uri = asset.uri;
      setCameraPreviewUri(uri);

      // The camera is for showing Abir something, not for building a personal
      // photo collection. Keep only the current preview URI locally.
      setSavedCameraUris([uri]);

      if (!asset.base64) {
        const fallback = language === 'bn'
          ? 'ছবিটি পাওয়া গেছে, কিন্তু বিশ্লেষণের জন্য ছবির ডেটা পাওয়া যায়নি। আবার চেষ্টা করো।'
          : 'I got the photo, but could not read its image data for analysis. Please try again.';
        await sendText(fallback, true);
        return;
      }

      setIsSending(true);
      try {
        const onlineText = optionalOnlineAssistant.enabled
          ? await optionalOnlineAssistant.respond({
              text: language === 'bn'
                ? 'এই ছবিটা দেখে বলো এখানে কী আছে। যা নিশ্চিতভাবে দেখা যাচ্ছে শুধু সেটাই বলো। মানুষ থাকলে পরিচয় অনুমান করবে না; শুধু দৃশ্যমান বৈশিষ্ট্য ও পরিস্থিতি বর্ণনা করো।'
                : 'Look at this image and tell me what is in it. Only state what is visibly supported. If a person is present, do not guess their identity; describe only visible features and context.',
              language: language === 'bn' ? 'bn' : 'en',
              imageBase64: asset.base64,
              imageMimeType: asset.mimeType || 'image/jpeg',
            })
          : null;

        const responseText = onlineText || (language === 'bn'
          ? 'ছবিটা দেখেছি, কিন্তু এখন অনলাইন Gemini চালু নেই—তাই ছবিটা কী তা বিশ্লেষণ করতে পারছি না।'
          : 'I received the image, but Gemini is not available online right now, so I cannot analyze what is in it.');

        const userMessage: Message = {
          id: createId(),
          role: 'user',
          text: language === 'bn' ? '📷 এটা কী?' : '📷 What is this?',
          time: Date.now(),
        };
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: responseText,
          intent: 'fallback',
          time: Date.now(),
        };
        setMessages((current) => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await speakMessage(assistantMessage);
      } finally {
        setIsSending(false);
      }
    } catch {
      Alert.alert(
        language === 'bn' ? 'ক্যামেরা খোলা যায়নি' : 'Camera unavailable',
        language === 'bn' ? 'আবার চেষ্টা করো।' : 'Please try again.',
      );
    }
  };

  const verifyOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      if (!hasHardware || !enrolled) {
        Alert.alert(
          language === 'bn' ? 'Owner verification সেট করা নেই' : 'Owner verification unavailable',
          language === 'bn'
            ? 'ফোনের Settings থেকে fingerprint/face unlock সেট করলে Abir সেটা দিয়ে তোমাকে যাচাই করতে পারবে।'
            : 'Set up fingerprint or face unlock in phone Settings so Abir can verify the device owner.',
        );
        return false;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'এটা কি তুমি?' : 'Is this you?',
        promptSubtitle: 'Abir AI owner verification',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      const verified = result.success;
      setOwnerVerified(verified);
      Alert.alert(
        verified
          ? language === 'bn' ? 'তুমি যাচাই হয়েছ' : 'Owner verified'
          : language === 'bn' ? 'যাচাই হয়নি' : 'Not verified',
        verified
          ? language === 'bn' ? 'এই সেশনে Abir তোমাকে ফোনের মালিক হিসেবে ধরবে।' : 'Abir will treat you as the verified device owner for this session.'
          : language === 'bn' ? 'ভেরিফিকেশন সফল হয়নি।' : 'The verification did not succeed.',
      );
      return verified;
    } catch {
      setOwnerVerified(false);
      return false;
    }
  };

  const startVoiceInput = async () => {
    if (isListening || isSending) return;
    setIsListening(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    try {
      // Voice commands are a conversational mode: always read the action/reply
      // aloud so the user can operate Abir AI without touching the keyboard.
      if (!autoSpeak) setAutoSpeak(true);

      const recognizedText = await listenForText(language);
      if (recognizedText) {
        const historyItem: VoiceHistoryItem = {
          id: createId(),
          text: recognizedText,
          time: Date.now(),
        };
        setVoiceHistory(current => {
          const next = [historyItem, ...current].slice(0, MAX_VOICE_HISTORY);
          void AsyncStorage.setItem(VOICE_HISTORY_KEY, JSON.stringify(next)).catch(() => {});
          return next;
        });
        await sendText(recognizedText, true);
      } else {
        const message: Message = {
          id: createId(),
          role: 'assistant',
          text: language === 'bn'
            ? 'আমি শুনতে পাইনি। আবার বলো—যেমন “Abir YouTube খোলো” বা “আবির ভলিউম কমাও”।'
            : 'I didn’t catch that. Try again, for example: “Abir open YouTube” or “Abir lower the volume.”',
          time: Date.now(),
          intent: 'fallback',
        };
        setMessages(current => [...current, message].slice(-MAX_MESSAGES));
        await speakMessage(message);
      }
    } catch (error) {
      Alert.alert(
        language === 'bn' ? 'ভয়েস ইনপুট কাজ করেনি' : 'Voice input unavailable',
        error instanceof Error
          ? error.message
          : language === 'bn'
            ? 'মাইক্রোফোন বা স্পিচ সার্ভিসটি পরীক্ষা করে আবার চেষ্টা করো।'
            : 'Check microphone or speech-service availability and try again.',
      );
    } finally {
      setIsListening(false);
    }
  };

  const confirmClear = () => {
    Alert.alert(
      language === 'bn' ? 'চ্যাট পরিষ্কার করবে?' : 'Clear this chat?',
      language === 'bn'
        ? 'সংরক্ষিত কথোপকথন মুছে যাবে।'
        : 'Your saved conversation will be deleted.',
      [
        { text: language === 'bn' ? 'থাক' : 'Cancel', style: 'cancel' },
        {
          text: language === 'bn' ? 'মুছে দাও' : 'Clear',
          style: 'destructive',
          onPress: () => {
            setMessages([welcomeMessage(language)]);
            void Speech.stop();
          },
        },
      ],
    );
  };

  const suggestions =
    language === 'bn'
      ? [
          'একটা কৌতুক বলো',
          'এখন সময় কত?',
          '২ + ২',
          'তুমি কী করতে পারো?',
          'WhatsApp ওপেন করো',
          'YouTube ওপেন করো',
        ]
      : [
          'Tell me a joke',
          'What time is it?',
          '2 + 2',
          'What can you do?',
          'Open WhatsApp',
          'Open YouTube',
        ];

  const inputBackground = { backgroundColor: colors.card };
  const bottomInset =
    Platform.OS === 'web' ? 34 : Math.max(insets.bottom, 10);
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  if (isLoading || !accountReady) {
    return (
      <View style={[styles.lockScreen, { backgroundColor: '#020617' }]}>
        <StatusBar style="light" />
        <View style={dashboardStyles.loadingOrb}><Text style={dashboardStyles.loadingA}>A</Text></View>
        <Text style={[styles.lockTitle, { color: '#F2F7FF', marginTop: 18 }]}>
          {language === 'bn' ? 'Abir AI প্রস্তুত হচ্ছে…' : 'Preparing Abir AI…'}
        </Text>
      </View>
    );
  }

  if (appLockEnabled && !appUnlocked) {
    return (
      <View style={[styles.lockScreen, { backgroundColor: '#020617' }]}>
        <StatusBar style="light" />
        <View style={dashboardStyles.loadingOrb}><Text style={dashboardStyles.loadingA}>A</Text></View>
        <Text style={[styles.lockTitle, { color: '#F2F7FF', marginTop: 18 }]}>
          {language === 'bn' ? 'Abir AI লক করা আছে' : 'Abir AI is locked'}
        </Text>
        <Text style={[styles.lockText, { color: '#8CA6D5' }]}>
          {language === 'bn' ? 'Fingerprint/Face/PIN/Password দিয়ে আনলক করো।' : 'Unlock with your phone fingerprint/face/PIN/password.'}
        </Text>
        <Pressable onPress={() => void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); })} style={[styles.unlockButton, { backgroundColor: '#126BFF' }]}>
          <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>{language === 'bn' ? 'আনলক' : 'Unlock'}</Text>
        </Pressable>
        <Pressable onPress={() => setShowSettings(true)} style={[styles.accountLink, { borderColor: '#1D3D73' }]}>
          <Text style={{ color: '#DDE9FF' }}>Settings</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <>
      <FuturisticDashboard
        language={language}
        messages={messages}
        draft={draft}
        setDraft={setDraft}
        isListening={isListening}
        isSending={isSending}
        isSpeaking={speakingId !== null}
        online={online}
        voiceHistory={voiceHistory}
        onVoice={() => void startVoiceInput()}
        onSend={(text) => void sendText(text)}
        onMenu={() => setShowQuickMenu(true)}
        onSettings={() => setShowSettings(true)}
      />

      <Modal
        visible={Boolean(cameraPreviewUri)}
        transparent
        animationType="fade"
        onRequestClose={() => setCameraPreviewUri(null)}
      >
        <View style={styles.cameraModal}>
          <View style={styles.cameraCard}>
            <Text style={[styles.cameraTitle, { color: colors.foreground }]}>
              {language === 'bn' ? 'তোলা ছবি' : 'Captured photo'}
            </Text>
            {cameraPreviewUri ? (
              <Image source={{ uri: cameraPreviewUri }} style={styles.cameraImage} resizeMode="contain" />
            ) : null}
            <Text style={[styles.cameraHint, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? `${savedCameraUris.length}টি ছবি এই ডিভাইসে রাখা হয়েছে। এগুলো Abir-এর face-recognition database নয়।`
                : `${savedCameraUris.length} photos are kept on this device. They are not used as an Abir face-recognition database.`}
            </Text>
            <Pressable
              onPress={() => setCameraPreviewUri(null)}
              style={[styles.cameraCloseButton, { backgroundColor: colors.primary }]}
            >
              <Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>
                {language === 'bn' ? 'বন্ধ' : 'Close'}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showQuickMenu} transparent animationType="fade" onRequestClose={() => setShowQuickMenu(false)}>
        <Pressable style={styles.quickMenuOverlay} onPress={() => setShowQuickMenu(false)}>
          <Pressable style={[styles.quickMenuCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => {}}>
            <View style={styles.quickMenuTitleRow}>
              <View>
                <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 20, marginTop: 0 }]}>Abir AI</Text>
                <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'সব নিয়ন্ত্রণ এক জায়গায়' : 'All controls in one place'}
                </Text>
              </View>
              <Pressable onPress={() => setShowQuickMenu(false)} style={styles.iconButton}>
                <UiIcon name="close" size={19} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <View style={styles.quickMenuGrid}>
              <Pressable style={[styles.menuTile, { backgroundColor: accountLoggedIn ? colors.accentSoft : colors.muted, borderColor: accountLoggedIn ? colors.primary : colors.border }]} onPress={() => { setShowQuickMenu(false); setShowAccountSetup(true); }}>
                <UiIcon name="person" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{accountLoggedIn ? (language === 'bn' ? 'অ্যাকাউন্ট' : 'Account') : 'Login'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: autoSpeak ? colors.accentSoft : colors.muted, borderColor: colors.border }]} onPress={() => { const next=!autoSpeak; setAutoSpeak(next); void AsyncStorage.setItem('abir-ai-auto-speak-v1', next?'on':'off'); }}>
                <UiIcon name={autoSpeak ? 'volume-high' : 'volume-mute'} size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'অটো ভয়েস' : 'Auto voice'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: wakeWordEnabled ? colors.accentSoft : colors.muted, borderColor: colors.border }]} onPress={() => { if (wakeWordEnabled) { setWakeWordEnabled(false); void AsyncStorage.setItem(WAKE_WORD_KEY, 'off'); void stopWakeWord(); } else { void enableWakeWord(); } }}>
                <UiIcon name="mic" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'Wake Word' : 'Wake word'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => setLanguage(v => v === 'bn' ? 'en' : 'bn')}>
                <Text style={{ color: colors.primary, fontSize: 17, fontWeight: '900' }}>{language === 'bn' ? 'EN' : 'বাংলা'}</Text>
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ভাষা' : 'Language'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); setShowSettings(true); }}>
                <UiIcon name="settings" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'সেটিংস' : 'Settings'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void captureCameraPhoto(); }}>
                <UiIcon name="camera" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ক্যামেরা' : 'Camera'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void configureAppLock(); }}>
                <UiIcon name="shield" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'App Lock' : 'App Lock'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => void repeatLastAssistantReply()}>
                <UiIcon name="volume-medium" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'আবার বলো' : 'Repeat'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void stopVoiceReply(); }}>
                <UiIcon name="volume-mute" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ভয়েস থামাও' : 'Stop voice'}</Text>
              </Pressable>
            </View>
            <Pressable onPress={() => { setShowQuickMenu(false); confirmClear(); }} style={[styles.menuDanger, { borderColor: colors.border }]}>
              <UiIcon name="trash" size={19} color={colors.destructive} />
              <Text style={{ color: colors.destructive, fontWeight: '800' }}>{language === 'bn' ? 'সব চ্যাট মুছে দাও' : 'Delete all chats'}</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={showSettings} transparent animationType="slide" onRequestClose={() => setShowSettings(false)}>
        <View style={styles.accountOverlay}>
          <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.settingsHeader}>
              <View>
                <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 22 }]}>
                  {language === 'bn' ? 'Abir AI Settings' : 'Abir AI Settings'}
                </Text>
                <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'ভয়েস, Wake Word, Lock ও Chat নিয়ন্ত্রণ' : 'Voice, wake word, lock and chat controls'}
                </Text>
              </View>
              <Pressable onPress={() => setShowSettings(false)} style={styles.iconButton}>
                <UiIcon name="close" size={20} color={colors.mutedForeground} />
              </Pressable>
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>স্বয়ংক্রিয় ভয়েস</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>প্রতিটি উত্তরের পর Abir নিজে থেকে বলবে</Text>
              </View>
              <Switch value={autoSpeak} onValueChange={value => { setAutoSpeak(value); void AsyncStorage.setItem('abir-ai-auto-speak-v1', value ? 'on' : 'off'); }} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>“Abir” Wake Word</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>অ্যাপ বন্ধ/ব্যাকগ্রাউন্ডে থাকলেও শুনতে চেষ্টা করবে</Text>
              </View>
              <Switch value={wakeWordEnabled} onValueChange={value => { if (value) void enableWakeWord(); else { setWakeWordEnabled(false); void AsyncStorage.setItem(WAKE_WORD_KEY, 'off'); void stopWakeWord(); } }} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>App Lock</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>ফোনের fingerprint/face/PIN/password দিয়ে সুরক্ষা</Text>
              </View>
              <Switch value={appLockEnabled} onValueChange={() => void configureAppLock()} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>Voice</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>বর্তমান: {voiceGender === 'female' ? 'Female' : 'Male'}</Text>
              </View>
              <Pressable onPress={() => { const next: VoiceGenderPreference = voiceGender === 'female' ? 'male' : 'female'; setVoiceGender(next); void loadAssistantPreferences().then(current => saveAssistantPreferences({ ...current, voiceGender: next })).catch(() => {}); }} style={[styles.settingButton, { borderColor: colors.border }]}>
                <Text style={{ color: colors.foreground, fontWeight: '700' }}>{voiceGender === 'female' ? '♀' : '♂'}</Text>
              </Pressable>
            </View>

            <Pressable onPress={confirmClear} style={[styles.dangerButton, { borderColor: colors.border }]}>
              <UiIcon name="trash" size={18} color="#ff6b6b" />
              <Text style={{ color: '#ff6b6b', fontWeight: '800' }}>{language === 'bn' ? 'সব Chat মুছে দাও' : 'Delete all chats'}</Text>
            </Pressable>

            <Pressable onPress={() => setShowSettings(false)} style={[styles.cameraCloseButton, { backgroundColor: colors.primary, marginTop: 12 }]}>
              <Text style={{ color: colors.primaryForeground, fontWeight: '800' }}>{language === 'bn' ? 'সম্পন্ন' : 'Done'}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showAccountSetup} transparent animationType="slide" onRequestClose={() => setShowAccountSetup(false)}>
        <View style={styles.accountOverlay}>
          <View style={[styles.accountCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 22 }]}>Abir Account</Text>
            <Text style={[styles.lockText, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? 'নতুন ফোনে একই settings/API key ব্যবহার করার জন্য email ও API key রাখতে পারো। Password এখানে সংরক্ষণ করা হয় না।'
                : 'Save your email and API key for device setup. Your password is not stored in this app.'}
            </Text>
            <TextInput value={accountEmail} onChangeText={setAccountEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountPassword} onChangeText={setAccountPassword} secureTextEntry placeholder={language === 'bn' ? 'Password' : 'Password'} placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountApiKey} onChangeText={setAccountApiKey} autoCapitalize="none" placeholder="Gemini API key" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <Pressable onPress={() => setShowAccountSetup(false)} style={[styles.accountAction, { borderColor: colors.border }]}><Text style={{ color: colors.foreground }}>{language === 'bn' ? 'বন্ধ' : 'Close'}</Text></Pressable>
              <Pressable onPress={() => void (accountLoggedIn ? loginAccount() : saveAccount())} style={[styles.accountAction, { backgroundColor: colors.primary, borderColor: colors.primary }]}><Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>{accountLoggedIn ? (language === 'bn' ? 'Login' : 'Login') : (language === 'bn' ? 'Create/Login' : 'Create/Login')}</Text></Pressable>
            </View>
            <Text style={[styles.footerNote, { color: colors.mutedForeground, marginTop: 12 }]}>
              {account ? `${language === 'bn' ? 'Configured:' : 'Configured:'} ${account.email}` : (language === 'bn' ? 'Account এখনো সেট করা হয়নি।' : 'No account configured yet.')}
            </Text>
          </View>
        </View>
      </Modal>
    </>
  );
}

const dashboardStyles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#020617' },
  gridGlow: { position: 'absolute', left: -120, right: -120, top: 80, height: 520, borderRadius: 260, backgroundColor: '#063D9A', opacity: 0.13 },
  topBar: { paddingTop: 48, paddingHorizontal: 14, paddingBottom: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brandBlock: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandOrb: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, borderColor: '#1C6BFF', backgroundColor: '#061A43', alignItems: 'center', justifyContent: 'center', shadowColor: '#1C6BFF', shadowOpacity: 0.65, shadowRadius: 12, elevation: 12 },
  brandA: { color: '#55CFFF', fontSize: 20, fontWeight: '900' },
  brandTitle: { color: '#F2F7FF', fontSize: 18, fontWeight: '900', letterSpacing: 2 },
  statusLine: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#25E7A4' },
  statusText: { color: '#6F8FCA', fontSize: 7, fontWeight: '800', letterSpacing: 0.5 },
  topActions: { flexDirection: 'row', gap: 8 },
  roundAction: { width: 39, height: 39, borderRadius: 20, backgroundColor: '#071A3B', borderWidth: 1, borderColor: '#1A427F', alignItems: 'center', justifyContent: 'center' },
  actionGlyph: { color: '#B7D3FF', fontSize: 22, fontWeight: '800' },
  scrollContent: { paddingHorizontal: 10, paddingBottom: 22 },
  heroGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'stretch' },
  leftColumn: { flex: 1, minWidth: 112, gap: 8 },
  centerColumn: { flex: 1.45, minWidth: 150, minHeight: 380, borderRadius: 24, borderWidth: 1, borderColor: '#0E4EAA', backgroundColor: 'rgba(3,18,55,0.82)', overflow: 'hidden', alignItems: 'center', justifyContent: 'center', paddingVertical: 10 },
  rightColumn: { flex: 1, minWidth: 112, gap: 8 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  metricCard: { flexBasis: '47%', flexGrow: 1, minHeight: 88, borderRadius: 13, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#061631', padding: 10 },
  metricLabel: { color: '#6382BA', fontSize: 7, fontWeight: '900', letterSpacing: 0.7 },
  metricValue: { color: '#F3F8FF', fontSize: 20, fontWeight: '900', marginTop: 5 },
  metricTrendRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  metricTrend: { color: '#28D9A1', fontSize: 8, fontWeight: '800' },
  metricSpark: { width: 32, height: 14, justifyContent: 'flex-end', overflow: 'hidden' },
  sparkLine: { width: 44, height: 20, borderTopWidth: 2, borderRightWidth: 2, borderColor: '#3D8BFF', transform: [{ rotate: '-13deg' }] },
  activityCard: { borderRadius: 16, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#061631', padding: 10, minHeight: 210 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  cardEyebrow: { color: '#4D77B8', fontSize: 7, fontWeight: '900', letterSpacing: 1 },
  cardTitle: { color: '#DCEAFF', fontSize: 12, fontWeight: '800', marginTop: 3 },
  smallBadge: { borderRadius: 8, backgroundColor: '#063C3A', borderWidth: 1, borderColor: '#0E806D', paddingHorizontal: 6, paddingVertical: 3 },
  smallBadgeText: { color: '#2EE0A7', fontSize: 6, fontWeight: '900' },
  activityRow: { minHeight: 31, borderTopWidth: 1, borderTopColor: '#0B2954', flexDirection: 'row', alignItems: 'center', gap: 6 },
  activityDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#5A6D91' },
  activityDotHot: { backgroundColor: '#2BE5A6' },
  activityText: { color: '#A8C0E9', fontSize: 7, flex: 1 },
  activityTime: { color: '#5673A7', fontSize: 6, fontWeight: '800' },
  miniGraph: { width: 18, height: 18, justifyContent: 'flex-end', alignItems: 'center' },
  miniGraphBar: { width: 3, backgroundColor: '#246EFF', borderRadius: 2 },
  aiLabelRow: { width: '100%', alignItems: 'center' },
  aiPill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 10, borderWidth: 1, borderColor: '#1753A7', backgroundColor: '#061A40', paddingHorizontal: 8, paddingVertical: 5 },
  aiPillDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#25D9FF' },
  aiPillText: { color: '#79B9FF', fontSize: 6, fontWeight: '900', letterSpacing: 0.8 },
  robotStage: { width: 210, height: 210, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  networkSvg: { position: 'absolute' },
  robotGlow: { position: 'absolute', width: 105, height: 105, borderRadius: 53, backgroundColor: '#0B4CFF', opacity: 0.12 },
  robotGlowActive: { opacity: 0.26 },
  robotAntenna: { position: 'absolute', top: 28, width: 3, height: 18, backgroundColor: '#1B83FF', borderRadius: 2 },
  robotHead: { width: 88, height: 67, borderRadius: 27, backgroundColor: '#BFD7F8', borderWidth: 3, borderColor: '#5E9DFF', alignItems: 'center', justifyContent: 'center', shadowColor: '#2B8DFF', shadowOpacity: 0.75, shadowRadius: 18, elevation: 18, zIndex: 3 },
  robotEarLeft: { position: 'absolute', left: -10, width: 15, height: 25, borderRadius: 8, borderWidth: 2, borderColor: '#21A6FF', backgroundColor: '#06275A' },
  robotEarRight: { position: 'absolute', right: -10, width: 15, height: 25, borderRadius: 8, borderWidth: 2, borderColor: '#21A6FF', backgroundColor: '#06275A' },
  robotFace: { width: 67, height: 35, borderRadius: 15, backgroundColor: '#03132E', borderWidth: 1, borderColor: '#328DFF', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-evenly' },
  robotEye: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#2EE4FF', shadowColor: '#2EE4FF', shadowOpacity: 1, shadowRadius: 7, elevation: 8 },
  robotSmile: { position: 'absolute', bottom: 10, width: 18, height: 4, borderBottomWidth: 2, borderColor: '#6AAEFF', borderRadius: 10 },
  robotBody: { position: 'absolute', top: 123, width: 94, height: 61, borderRadius: 27, backgroundColor: '#C7DCF8', borderWidth: 3, borderColor: '#548FFF', alignItems: 'center', justifyContent: 'center', zIndex: 2 },
  robotChest: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#09214A', borderWidth: 2, borderColor: '#29C9FF', alignItems: 'center', justifyContent: 'center' },
  robotA: { color: '#EAF6FF', fontWeight: '900', fontSize: 16 },
  robotArmLeft: { position: 'absolute', left: -24, top: 17, width: 30, height: 13, borderRadius: 8, backgroundColor: '#AFCBF0', transform: [{ rotate: '28deg' }] },
  robotArmRight: { position: 'absolute', right: -28, top: 4, width: 34, height: 13, borderRadius: 8, backgroundColor: '#AFCBF0', transform: [{ rotate: '-48deg' }] },
  robotBase: { position: 'absolute', bottom: 8, width: 92, height: 12, borderRadius: 50, backgroundColor: '#0D4ED0', opacity: 0.7, shadowColor: '#2C89FF', shadowOpacity: 0.9, shadowRadius: 16, elevation: 12 },
  heroTitle: { color: '#F1F7FF', fontSize: 25, fontWeight: '900', letterSpacing: 5, marginTop: -3 },
  heroSubtitle: { color: '#6E91C9', fontSize: 7, fontWeight: '800', letterSpacing: 0.7, marginTop: 2 },
  voiceState: { marginTop: 10, flexDirection: 'row', alignItems: 'center', gap: 7 },
  voiceWave: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  waveBar: { width: 3, height: 12, borderRadius: 3, backgroundColor: '#2FD8FF' },
  voiceStateText: { color: '#7CA0D6', fontSize: 7, fontWeight: '800' },
  panel: { borderRadius: 16, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#061631', padding: 10 },
  panelSubtitle: { color: '#5578B5', fontSize: 7, marginTop: 2 },
  panelBody: { marginTop: 8 },
  statusItem: { flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 28, borderTopWidth: 1, borderTopColor: '#0B2954' },
  statusCheck: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#083B35', alignItems: 'center', justifyContent: 'center' },
  statusCheckText: { color: '#2FE1A7', fontSize: 8, fontWeight: '900' },
  statusItemLabel: { color: '#A8C0E9', fontSize: 7, flex: 1 },
  statusItemValue: { color: '#32DCA9', fontSize: 6, fontWeight: '900' },
  rootCauseRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: 9 },
  rcNode: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  rcDanger: { backgroundColor: '#351225', borderColor: '#FF3F68' },
  rcOk: { backgroundColor: '#0A3029', borderColor: '#2DE3A9' },
  rcBlue: { backgroundColor: '#082854', borderColor: '#2A9EFF' },
  rcText: { color: '#F4F8FF', fontSize: 10, fontWeight: '900' },
  rcLine: { width: 25, height: 1, backgroundColor: '#1B5AA7' },
  analysisText: { color: '#83A4D6', fontSize: 7, textAlign: 'center' },
  pipelineCard: { marginTop: 8, borderRadius: 17, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#061631', padding: 11 },
  pipelineLatency: { color: '#38CFFF', fontSize: 9, fontWeight: '900' },
  pipelineRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 7 },
  pipelineNode: { alignItems: 'center', minWidth: 39 },
  pipelineIcon: { width: 29, height: 29, borderRadius: 9, borderWidth: 1, borderColor: '#1B5CAA', backgroundColor: '#061D43', alignItems: 'center', justifyContent: 'center' },
  pipelineIconText: { color: '#39C9FF', fontSize: 12, fontWeight: '900' },
  pipelineLabel: { color: '#5E7FB8', fontSize: 5, fontWeight: '900', marginTop: 4 },
  pipelineConnector: { flex: 1, height: 1, backgroundColor: '#144B8F', marginHorizontal: 2 },
  bottomStatsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 8 },
  bottomStat: { flex: 1, minWidth: 75, borderRadius: 13, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#061631', padding: 9 },
  bottomStatValue: { color: '#F0F6FF', fontSize: 17, fontWeight: '900', marginTop: 3 },
  askCard: { marginTop: 9, borderRadius: 20, borderWidth: 1, borderColor: '#1B5FB5', backgroundColor: '#061A3B', padding: 11, shadowColor: '#0A6CFF', shadowOpacity: 0.18, shadowRadius: 20, elevation: 8 },
  askHeader: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 8 },
  askAvatar: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#082C68', borderWidth: 1, borderColor: '#238CFF', alignItems: 'center', justifyContent: 'center' },
  askAvatarText: { color: '#42CFFF', fontSize: 15, fontWeight: '900' },
  askTitle: { color: '#E9F3FF', fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  askSubtitle: { color: '#6688BF', fontSize: 7, marginTop: 2 },
  secureBadge: { borderRadius: 7, backgroundColor: '#073C36', borderWidth: 1, borderColor: '#117C6A', paddingHorizontal: 5, paddingVertical: 4 },
  secureText: { color: '#2EE0A7', fontSize: 5, fontWeight: '900' },
  commandBar: { minHeight: 52, borderRadius: 15, borderWidth: 1, borderColor: '#164C92', backgroundColor: '#020E25', flexDirection: 'row', alignItems: 'center', paddingLeft: 10, paddingRight: 5 },
  commandInput: { flex: 1, minHeight: 40, maxHeight: 80, color: '#EAF4FF', fontSize: 12, paddingVertical: 7 },
  voiceButton: { width: 39, height: 39, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0A2855', borderWidth: 1, borderColor: '#1C5BAA' },
  voiceButtonActive: { backgroundColor: '#083F58', borderColor: '#25D7FF' },
  voiceButtonText: { color: '#55CFFF', fontSize: 8, fontWeight: '900' },
  sendButton: { width: 39, height: 39, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginLeft: 5, backgroundColor: '#126BFF' },
  sendButtonDisabled: { opacity: 0.4 },
  sendButtonText: { color: '#FFFFFF', fontSize: 19, fontWeight: '900' },
  floatingOrbButton: { position: 'absolute', right: 18, bottom: 118, width: 92, height: 112, alignItems: 'center', justifyContent: 'center', zIndex: 30 },
  orbPulseRing: { position: 'absolute', width: 70, height: 70, borderRadius: 35, borderWidth: 2, borderColor: '#39CFFF', backgroundColor: '#0A4DFF' },
  floatingOrbCore: { width: 58, height: 58, borderRadius: 29, borderWidth: 1.5, borderColor: '#53D7FF', backgroundColor: '#061A42', alignItems: 'center', justifyContent: 'center', shadowColor: '#27BFFF', shadowOpacity: 0.75, shadowRadius: 18, elevation: 16, overflow: 'hidden' },
  orbInnerGlow: { position: 'absolute', width: 38, height: 38, borderRadius: 19, backgroundColor: '#0D6CFF', opacity: 0.34 },
  orbBars: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  orbBar: { width: 3, borderRadius: 3, backgroundColor: '#B8F5FF' },
  orbCaption: { position: 'absolute', bottom: -1, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#041126', borderWidth: 1, borderColor: '#123C78', borderRadius: 10, paddingHorizontal: 7, paddingVertical: 4 },
  orbStatusDot: { width: 5, height: 5, borderRadius: 3 },
  orbCaptionText: { color: '#9BB8E5', fontSize: 7, fontWeight: '800' },
  conversationCard: { marginTop: 10, borderRadius: 17, borderWidth: 1, borderColor: '#123C78', backgroundColor: '#041329', padding: 10 },
  conversationRow: { flexDirection: 'row', gap: 7, marginTop: 7, maxWidth: '94%' },
  conversationUser: { alignSelf: 'flex-end', flexDirection: 'row-reverse' },
  conversationAssistant: { alignSelf: 'flex-start' },
  conversationAvatar: { width: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  conversationUserAvatar: { backgroundColor: '#1455B8' },
  conversationAssistantAvatar: { backgroundColor: '#083C4B' },
  conversationAvatarText: { color: '#DDF7FF', fontSize: 7, fontWeight: '900' },
  conversationBubble: { borderRadius: 14, paddingHorizontal: 10, paddingVertical: 8, flexShrink: 1 },
  conversationUserBubble: { backgroundColor: '#0A3A80', borderTopRightRadius: 4 },
  conversationAssistantBubble: { backgroundColor: '#071E3B', borderTopLeftRadius: 4 },
  conversationText: { color: '#D5E6FF', fontSize: 9, lineHeight: 14 },
  quickActionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 9 },
  quickActionChip: { borderWidth: 1, borderColor: '#164C92', backgroundColor: '#061631', borderRadius: 14, paddingHorizontal: 10, paddingVertical: 8 },
  quickActionText: { color: '#B8D3FA', fontSize: 9, fontWeight: '800' },
  voiceHistoryBox: { marginTop: 10, borderTopWidth: 1, borderTopColor: '#0E315F', paddingTop: 8 },
  voiceHistoryHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 },
  voiceHistoryHint: { color: '#4D77B8', fontSize: 7, fontWeight: '800' },
  voiceHistoryRow: { minHeight: 29, flexDirection: 'row', alignItems: 'center', gap: 6, borderTopWidth: 1, borderTopColor: '#0B2954' },
  historyMic: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#082854', alignItems: 'center', justifyContent: 'center' },
  historyMicText: { color: '#56D7FF', fontSize: 11, fontWeight: '900' },
  voiceHistoryText: { flex: 1, color: '#8EABD7', fontSize: 8 },
  voiceHistoryTime: { color: '#4F6E9F', fontSize: 7, fontWeight: '700' },
  loadingOrb: { width: 86, height: 86, borderRadius: 43, backgroundColor: '#06265D', borderWidth: 2, borderColor: '#2187FF', alignItems: 'center', justifyContent: 'center', shadowColor: '#2187FF', shadowOpacity: 0.8, shadowRadius: 20, elevation: 16 },
  loadingA: { color: '#51D5FF', fontSize: 32, fontWeight: '900' },
});

const styles = StyleSheet.create({
  screen: { flex: 1 },
  keyboardFrame: { flex: 1 },
  header: {
    minHeight: 84,
    paddingHorizontal: 18,
    paddingBottom: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: {
    width: 42,
    height: 42,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: -0.3 },
  subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  onlineDot: { width: 6, height: 6, borderRadius: 3 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerAccountButton: {
    minWidth: 42,
    height: 38,
    paddingHorizontal: 9,
    borderRadius: 13,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  headerAccountText: { fontSize: 11, fontWeight: '800' },
  languageText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  moreButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  messages: { flex: 1 },
  messageList: {
    paddingHorizontal: 18,
    paddingTop: 112,
    paddingBottom: 14,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  messageRow: { flexDirection: 'row', marginBottom: 18, gap: 8, maxWidth: '90%' },
  assistantRow: { alignSelf: 'flex-start', alignItems: 'flex-end' },
  userRow: { alignSelf: 'flex-end' },
  messageAvatar: {
    width: 23,
    height: 23,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  messageBody: { flexShrink: 1 },
  messageBubble: {
    borderWidth: 1,
    borderRadius: 22,
    borderBottomLeftRadius: 6,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  userBubble: { borderBottomLeftRadius: 18, borderBottomRightRadius: 6 },
  messageText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 23,
    letterSpacing: 0.05,
  },
  userMessageText: { fontFamily: 'Inter_500Medium' },
  messageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 5,
    marginLeft: 3,
  },
  userMeta: { justifyContent: 'flex-end', marginRight: 2 },
  timeText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  typingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginLeft: 31,
    marginBottom: 14,
  },
  typingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  composerArea: { paddingHorizontal: 14, paddingTop: 8, gap: 9 },
  suggestions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
    paddingBottom: 1,
  },
  suggestionChip: {
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 11,
    paddingVertical: 8,
    maxWidth: '100%',
  },
  suggestionText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  composer: {
    minHeight: 62,
    borderWidth: 1,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingLeft: 13,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 4,
  },
  input: {
    flex: 1,
    maxHeight: 112,
    minHeight: 39,
    paddingTop: 9,
    paddingBottom: 7,
    paddingRight: 5,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 21,
  },
  composerIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerOrbLayer: {
    position: 'absolute',
    top: '46%',
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 10,
    pointerEvents: 'box-none',
  },
  orbOrbit: { position: 'absolute', width: 72, height: 72, borderRadius: 36, borderWidth: 1, borderStyle: 'dashed', opacity: 0.65 },
  orbOrbitInner: { position: 'absolute', width: 62, height: 62, borderRadius: 31, borderWidth: 1, opacity: 0.5 },
  centerOrbGlow: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerOrb: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 16,
    shadowOpacity: 0.32,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
  },
  orbLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 7, letterSpacing: 2.2, marginTop: 4 },
  orbStatus: { fontFamily: 'Inter_500Medium', fontSize: 8, marginTop: 1 },
  voiceBars: { height: 30, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 3 },
  voiceBar: { width: 3, borderRadius: 3 },
  quickMenuOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.48)', alignItems: 'flex-end', paddingTop: 68, paddingHorizontal: 12 },
  quickMenuCard: { width: '94%', maxWidth: 440, borderRadius: 24, borderWidth: 1, padding: 15, elevation: 14 },
  quickMenuTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  quickMenuGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  menuTile: { width: '23.2%', minWidth: 78, flexGrow: 1, minHeight: 78, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center', padding: 7 },
  menuTileText: { fontSize: 10, fontWeight: '800', marginTop: 6, textAlign: 'center' },
  menuDanger: { height: 48, borderRadius: 15, borderWidth: 1, marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  cameraModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 22,
  },
  cameraCard: {
    width: '100%',
    maxWidth: 420,
    borderRadius: 24,
    padding: 18,
    backgroundColor: '#12191A',
  },
  cameraTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  cameraImage: {
    width: '100%',
    height: 320,
    borderRadius: 16,
    backgroundColor: '#050707',
  },
  cameraHint: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 10,
  },
  cameraCloseButton: {
    alignSelf: 'flex-end',
    marginTop: 14,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 14,
  },
  voiceBubbleWrap: {
    position: 'absolute',
    right: 18,
    zIndex: 20,
  },
  voiceBubble: {
    width: 62,
    height: 62,
    borderRadius: 31,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 7,
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  footerNote: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    paddingHorizontal: 4,
    paddingBottom: 2,
  },

  lockScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  lockTitle: { marginTop: 18, fontSize: 24, fontWeight: '800', textAlign: 'center' },
  lockText: { marginTop: 10, fontSize: 15, lineHeight: 22, textAlign: 'center' },
  unlockButton: { marginTop: 22, minWidth: 150, alignItems: 'center', paddingVertical: 13, paddingHorizontal: 24, borderRadius: 18 },
  accountLink: { marginTop: 12, paddingVertical: 10, paddingHorizontal: 18, borderWidth: 1, borderRadius: 14 },
  accountOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.58)' },
  settingsCard: { width: '92%', maxWidth: 520, borderRadius: 24, borderWidth: 1, padding: 18 },
  settingsHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  settingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, borderBottomWidth: 1 },
  settingCopy: { flex: 1, paddingRight: 14 },
  settingTitle: { fontSize: 15, fontWeight: '800' },
  settingDesc: { fontSize: 12, lineHeight: 17, marginTop: 3 },
  settingButton: { minWidth: 44, height: 38, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  dangerButton: { height: 48, borderRadius: 14, borderWidth: 1, marginTop: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  accountCard: { borderTopWidth: 1, borderLeftWidth: 1, borderRightWidth: 1, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 30 },
  accountInput: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginTop: 10 },
  accountAction: { flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 14, borderWidth: 1 },
});
