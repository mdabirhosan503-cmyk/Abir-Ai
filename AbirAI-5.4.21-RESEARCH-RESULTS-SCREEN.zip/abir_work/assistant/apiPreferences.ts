import * as SecureStore from 'expo-secure-store';

export type ApiProvider = 'gemini' | 'openai-compatible';

export type ApiPreferences = {
  provider: ApiProvider;
  baseUrl: string;
  model: string;
};

export const DEFAULT_API_PREFERENCES: ApiPreferences = {
  provider: 'gemini',
  baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
  model: 'gemini-2.5-flash',
};

export const API_PROVIDER_KEY = 'abir-ai-api-provider-v1';
export const API_BASE_URL_KEY = 'abir-ai-api-base-url-v1';
export const API_MODEL_KEY = 'abir-ai-api-model-v1';
export const API_KEY_KEY = 'abir-ai-account-api-key-v2';

function normalizeBaseUrl(value: string, provider: ApiProvider) {
  const raw = value.trim().replace(/\/+$/, '');
  if (!raw) return DEFAULT_API_PREFERENCES.baseUrl;
  if (provider === 'gemini') return raw.replace(/\/models$/i, '').replace(/\/openai$/i, '');
  return raw.replace(/\/chat\/completions$/i, '');
}

export async function loadApiPreferences(): Promise<ApiPreferences> {
  const providerRaw = await SecureStore.getItemAsync(API_PROVIDER_KEY);
  const provider: ApiProvider = providerRaw === 'openai-compatible' ? 'openai-compatible' : 'gemini';
  const baseUrl = normalizeBaseUrl(
    (await SecureStore.getItemAsync(API_BASE_URL_KEY)) || DEFAULT_API_PREFERENCES.baseUrl,
    provider,
  );
  const model = ((await SecureStore.getItemAsync(API_MODEL_KEY)) ||
    (provider === 'gemini' ? DEFAULT_API_PREFERENCES.model : 'gpt-4o-mini')).trim();
  return { provider, baseUrl, model };
}

export async function saveApiPreferences(value: ApiPreferences) {
  const provider = value.provider === 'openai-compatible' ? 'openai-compatible' : 'gemini';
  const baseUrl = normalizeBaseUrl(value.baseUrl, provider);
  const model = value.model.trim() || (provider === 'gemini' ? DEFAULT_API_PREFERENCES.model : 'gpt-4o-mini');
  await SecureStore.setItemAsync(API_PROVIDER_KEY, provider);
  await SecureStore.setItemAsync(API_BASE_URL_KEY, baseUrl);
  await SecureStore.setItemAsync(API_MODEL_KEY, model);
  return { provider, baseUrl, model };
}
