import * as SecureStore from 'expo-secure-store';
import { DEFAULT_API_PREFERENCES, loadApiPreferences } from './apiPreferences';
export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
  imageBase64?: string;
  imageMimeType?: string;
  conversationContext?: Array<{ role: 'user' | 'assistant'; text: string }>;
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Online API layer: Gemini native (with Google Search grounding) or any
// OpenAI-compatible Chat Completions provider. This keeps the app provider-agnostic
// while preserving Gemini Search when Gemini is selected.
const buildApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const buildGeminiModel = process.env.EXPO_PUBLIC_GEMINI_MODEL?.trim() || DEFAULT_API_PREFERENCES.model;
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';

function joinUrl(base: string, path: string) {
  return `${base.replace(/\/+$/, '')}/${path.replace(/^\/+/, '')}`;
}

function cleanOpenAIReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const choices = Array.isArray(record.choices) ? record.choices : [];
  const first = choices[0];
  if (!first || typeof first !== 'object') return null;
  const message = (first as Record<string, unknown>).message;
  if (!message || typeof message !== 'object') return null;
  const content = (message as Record<string, unknown>).content;
  if (typeof content === 'string') return content.trim() || null;
  if (Array.isArray(content)) {
    const text = content.map(item => {
      if (!item || typeof item !== 'object') return '';
      const part = item as Record<string, unknown>;
      return typeof part.text === 'string' ? part.text : '';
    }).join(' ').trim();
    return text || null;
  }
  return null;
}

function cleanReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const candidates = Array.isArray(record.candidates) ? record.candidates : [];
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = (first as Record<string, unknown>).content;
  if (!content || typeof content !== 'object') return null;
  const parts = Array.isArray((content as Record<string, unknown>).parts)
    ? (content as Record<string, unknown>).parts
    : [];
  const text = parts
    .filter((part): part is Record<string, unknown> => Boolean(part && typeof part === 'object'))
    .map(part => part.text)
    .filter((part): part is string => typeof part === 'string')
    .join(' ')
    .trim();
  const metadata = record.candidates && Array.isArray(record.candidates) ? (record.candidates[0] as Record<string, unknown> | undefined)?.groundingMetadata : undefined;
  const chunks = metadata && typeof metadata === 'object' && Array.isArray((metadata as Record<string, unknown>).groundingChunks) ? (metadata as Record<string, unknown>).groundingChunks as unknown[] : [];
  const sources = chunks.map((chunk) => {
    if (!chunk || typeof chunk !== 'object') return null;
    const web = (chunk as Record<string, unknown>).web;
    if (!web || typeof web !== 'object') return null;
    const item = web as Record<string, unknown>;
    return typeof item.uri === 'string' ? `• ${String(item.title || item.uri)}: ${item.uri}` : null;
  }).filter((x): x is string => Boolean(x));
  const uniqueSources = [...new Set(sources)].slice(0, 6);
  return text ? `${text}${uniqueSources.length ? `\n\nসূত্র / Sources:\n${uniqueSources.join('\n')}` : ''}` : null;
}

export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  // Runtime API keys are stored in SecureStore from the app settings.
  // Keep this enabled so a user-supplied key can activate online mode even
  // when no build-time EXPO_PUBLIC_GEMINI_API_KEY was injected. respond()
  // still returns null immediately when no key exists.
  enabled: true,
  async respond(request) {
    const preferences = await loadApiPreferences();
    const apiKey = (await SecureStore.getItemAsync(ACCOUNT_API_KEY))?.trim() || buildApiKey;
    if (!apiKey) return null;

    try {
      const systemInstruction =
        request.language === 'bn'
          ? 'তুমি Abir AI-এর অনলাইন সহকারী। ব্যবহারকারী স্বাভাবিক বাংলা, Banglish বা English-এ কথা বললে উদ্দেশ্য বুঝে উত্তর দাও। বর্তমান/সাম্প্রতিক তথ্য, ওয়েব গবেষণা, fact-check বা সূত্র চাইলে পাওয়া web-search capability ব্যবহার করো। কোনো live action সত্যিই না হলে হয়েছে বলে দাবি করো না। ফোনের action স্থানীয় action engine চালায়।'
          : 'You are Abir AI, the online assistant. Understand natural Bengali, Banglish, English, and mixed conversational requests. For current/recent information, web research, fact-checking, or sources, use an available web-search capability. Never claim a live action happened unless the local action engine or configured connector actually performed it.';

      const needsLiveResearch = /(?:web search|search the web|research online|latest|current news|fact.?check|sources|internet|ইন্টারনেট|অনলাইন|ওয়েব|ওয়েব|খুঁজে|সার্চ|তথ্য সংগ্রহ|তথ্য এনে|সূত্রসহ|লিংকসহ|সাম্প্রতিক খবর|তথ্য যাচাই|ওয়েব সার্চ|ওয়েব সার্চ|লিংক বিশ্লেষণ|পেজ পড়ে|পেজ পড়ে)/iu.test(request.text);
      const contextText = request.conversationContext?.length
        ? `Recent conversation context:\n${request.conversationContext.map(item => `${item.role}: ${item.text}`).join('\n')}\n\nCurrent request:\n${request.text}`
        : request.text;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), needsLiveResearch ? 60000 : 25000);

      if (preferences.provider === 'openai-compatible') {
        const response = await fetch(joinUrl(preferences.baseUrl || 'https://api.openai.com/v1', 'chat/completions'), {
          method: 'POST',
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: preferences.model || 'gpt-4o-mini',
            messages: [
              { role: 'system', content: systemInstruction },
              { role: 'user', content: contextText },
            ],
            temperature: 0.7,
            max_tokens: 4096,
          }),
        });
        if (!response.ok) return null;
        return cleanOpenAIReply(await response.json());
      }

      const model = preferences.model || buildGeminiModel;
      const endpoint = `${joinUrl(preferences.baseUrl || DEFAULT_API_PREFERENCES.baseUrl, `models/${encodeURIComponent(model)}:generateContent`)}?key=${encodeURIComponent(apiKey)}`;
      const response = await fetch(endpoint, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents: [{
            role: 'user',
            parts: [
              { text: contextText },
              ...(request.imageBase64 ? [{ inlineData: { mimeType: request.imageMimeType || 'image/jpeg', data: request.imageBase64 } }] : []),
            ],
          }],
          ...(needsLiveResearch ? { tools: [{ google_search: {} }] } : {}),
          generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
        }),
      });
      if (!response.ok) return null;
      return cleanReply(await response.json());
    } catch {
      return null;
    } finally {
      clearTimeout(timeout);
    }
  },
};
