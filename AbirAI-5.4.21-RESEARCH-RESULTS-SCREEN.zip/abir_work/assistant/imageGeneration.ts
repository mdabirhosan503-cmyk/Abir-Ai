import * as SecureStore from 'expo-secure-store';

const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';
const buildApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const IMAGE_MODEL = process.env.EXPO_PUBLIC_GEMINI_IMAGE_MODEL?.trim() || 'gemini-2.5-flash-image';

type GeneratedImageResult = {
  dataUri: string;
  mimeType: string;
};

function findImage(value: unknown): GeneratedImageResult | null {
  if (!value || typeof value !== 'object') return null;
  const root = value as Record<string, unknown>;
  const steps = Array.isArray(root.steps) ? root.steps : [];
  for (const step of steps) {
    if (!step || typeof step !== 'object') continue;
    const stepRecord = step as Record<string, unknown>;
    const content = Array.isArray(stepRecord.content) ? stepRecord.content : [];
    for (const block of content) {
      if (!block || typeof block !== 'object') continue;
      const item = block as Record<string, unknown>;
      if (item.type === 'image' && typeof item.data === 'string') {
        const mimeType = typeof item.mime_type === 'string' ? item.mime_type : 'image/png';
        return { dataUri: `data:${mimeType};base64,${item.data}`, mimeType };
      }
      if (item.type === 'image' && typeof item.data === 'object' && item.data) {
        const nested = item.data as Record<string, unknown>;
        if (typeof nested.data === 'string') {
          const mimeType = typeof nested.mime_type === 'string' ? nested.mime_type : 'image/png';
          return { dataUri: `data:${mimeType};base64,${nested.data}`, mimeType };
        }
      }
    }
  }
  return null;
}

export async function generateAbirImage(prompt: string): Promise<GeneratedImageResult | null> {
  const apiKey = (await SecureStore.getItemAsync(ACCOUNT_API_KEY))?.trim() || buildApiKey;
  if (!apiKey || !prompt.trim()) return null;

  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/interactions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        model: IMAGE_MODEL,
        input: prompt.trim(),
        response_format: {
          type: 'image',
          aspect_ratio: '1:1',
        },
      }),
    });

    if (!response.ok) return null;
    return findImage(await response.json());
  } catch {
    return null;
  }
}
