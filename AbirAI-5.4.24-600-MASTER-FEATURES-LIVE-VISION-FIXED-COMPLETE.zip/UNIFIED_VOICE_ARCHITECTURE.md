# Abir AI 5.4.18 — Unified Voice Architecture

- Foreground voice chat, owner voice enrollment, and owner voice verification use one JavaScript microphone gate: `assistant/voiceManager.ts`.
- Before a foreground microphone operation starts, the background Wake Word service is stopped so Android does not have competing microphone owners.
- Voice verification remains enabled for sensitive device actions and is followed by Android device authentication (Fingerprint/Face/PIN/Password) where required by the existing security flow.
- Owner voice samples remain local in AsyncStorage through `speakerVerification.ts`.
- Memory limit and existing Bengali/English/offline functionality are unchanged.
