import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import * as Speech from 'expo-speech';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  AppState,
  Alert,
  Linking,
  FlatList,
  Keyboard,
  Modal,
  Platform,
  PermissionsAndroid,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  Image,
  View,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import Svg, { Circle, Path, Rect, Line } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  type AssistantLanguage,
  type AssistantIntent,
} from '@/assistant/offlineBrain';
import { getAssistantReply } from '@/assistant/offlineBrain';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber } from '@/assistant/intentParser';
import { extractMessageRequest, extractVoiceMessageRequest, messageAutomationReply, type MessageRequest } from '@/assistant/messageAutomation';
import {
  appActionReply,
  appDiscoveryReply,
  getDeviceContacts,
  getLaunchableApps,
  getOfflineSpeechRecognitionAvailability,
  getOnlineStatus,
  launchInstalledApp,
  openContactDialer,
  placeDirectCall,
  setCallAssistantEnabled,
  isDefaultDialer,
  requestDefaultDialerRole,
  endCurrentCall,
  callViaApp,
  searchAndOpenInApp,
  performDeviceAction,
  wakeDeviceScreen,
  adjustDeviceVolume,
  getDeviceVolumePercent,
  setDeviceVolumePercent,
  setFlashlight,
  controlMedia,
  setRingerMode,
  openSystemSettings,
  getCurrentLocation,
  getDeviceDiagnostics,
  scheduleAbirReminder,
  readCurrentScreenText,
  getScreenSnapshot,
  startWakeWord,
  speakNativeText,
  stopNativeSpeaking,
  stopWakeWord,
  isIgnoringBatteryOptimizations,
  requestBatteryOptimizationExemption,
  canDrawOverlays,
  openOverlaySettings,
  isAccessibilityEnabled,
  openAccessibilitySettings,
  sendMessageViaAccessibility,
  sendVoiceMessageViaAccessibility,
  type LaunchableApp,
} from '@/assistant/androidActions';
import {
  appChoicePrompt,
  matchInstalledApps,
  noMatchingAppReply,
  selectAppChoice,
} from '@/assistant/appNameMatcher';
import {
  formatCallConfirmation,
  formatContactChoicePrompt,
  matchContacts,
  selectContactChoice,
  type ContactPhone,
} from '@/assistant/contactHandler';
import {
  addRecentTopic,
  clearLocalMemory,
  EMPTY_MEMORY,
  handleMemoryCommand,
  loadLocalMemory,
  saveLocalMemory,
  type AssistantMemory,
} from '@/assistant/localMemory';
import { getLastLocalAction, recordLocalAction } from '@/assistant/offlineTools';
import { addLocalNote, searchLocalNotes, saveLocalRoutine, findLocalRoutine, learnLocalAlias } from '@/assistant/offlinePlus';
import {
  DEFAULT_PREFERENCES,
  loadAssistantPreferences,
  saveAssistantPreferences,
  type AssistantPreferences,
  type VoiceGenderPreference,
} from '@/assistant/voicePreferences';
import {
  chooseSpeechVoice,
  loadSpeechVoices,
  voiceFallbackMessage,
  type SpeechVoice,
} from '@/assistant/voiceSelection';
import { speakAssistantText } from '@/assistant/textToSpeech';
import { optionalOnlineAssistant } from '@/assistant/onlineAssistant';
import { getSpeakerProfile, clearSpeakerProfile, MAX_SPEAKER_SAMPLES } from '@/assistant/speakerVerification';
import { enrollOwnerVoiceWithUnifiedManager, listenWithUnifiedVoiceManager, verifyOwnerVoiceWithUnifiedManager } from '@/assistant/voiceManager';
import { useColors } from '@/hooks/useColors';
import { ExactReferenceDashboard } from '@/components/ExactReferenceDashboard';
import { AbirLoginScreen, type LoginProvider } from '@/components/AbirLoginScreen';
import { OFFLINE_100_FEATURES, OFFLINE_100_FEATURE_COUNT } from '@/assistant/offline100Features';
import { MASTER_600_FEATURES, MASTER_600_FEATURE_COUNT } from '@/assistant/master600Features';



function NaturalVoiceCore({ active, speaking, online }: { active: boolean; speaking: boolean; online: boolean }) {
  const float = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const floatLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(float, { toValue: 1, duration: active || speaking ? 650 : 1400, useNativeDriver: true }),
        Animated.timing(float, { toValue: 0, duration: active || speaking ? 650 : 1400, useNativeDriver: true }),
      ]),
    );
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: active || speaking ? 520 : 1500, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: active || speaking ? 520 : 1500, useNativeDriver: true }),
      ]),
    );
    floatLoop.start();
    pulseLoop.start();
    return () => {
      floatLoop.stop();
      pulseLoop.stop();
    };
  }, [active, speaking, float, pulse]);

  const translateY = float.interpolate({ inputRange: [0, 1], outputRange: [4, -7] });
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, active || speaking ? 1.38 : 1.12] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.32, 0.02] });

  const bars = [10, 17, 25, 15, 29, 18, 11];

  return (
    <View style={dashboardStyles.naturalVoiceStage}>
      <Animated.View style={[dashboardStyles.naturalVoiceGlow, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
      <Animated.View style={[dashboardStyles.naturalVoiceRing, { transform: [{ scale: ringScale }] }]} />
      <Animated.View style={[dashboardStyles.naturalVoiceOrb, { transform: [{ translateY }] }]}>
        <View style={dashboardStyles.naturalVoiceOrbInner} />
        <View style={dashboardStyles.naturalVoiceBars}>
          {bars.map((height, i) => (
            <Animated.View
              key={i}
              style={[
                dashboardStyles.naturalVoiceBar,
                { height: active || speaking ? height : 8 + (i % 3) * 3 },
              ]}
            />
          ))}
        </View>
      </Animated.View>
      <View style={dashboardStyles.naturalVoiceStatus}>
        <View style={[dashboardStyles.naturalVoiceDot, { backgroundColor: online ? '#FF4558' : '#8A7378' }]} />
        <Text style={dashboardStyles.naturalVoiceStatusText}>
          {speaking ? 'SPEAKING' : active ? 'LISTENING' : online ? 'READY' : 'OFFLINE READY'}
        </Text>
      </View>
    </View>
  );
}

type FuturisticDashboardProps = {
  language: AssistantLanguage;
  messages: Message[];
  draft: string;
  setDraft: (value: string) => void;
  isListening: boolean;
  continuousVoice: boolean;
  isSending: boolean;
  isSpeaking: boolean;
  online: boolean;
  voiceHistory: VoiceHistoryItem[];
  onVoice: () => void;
  onSend: (text: string) => void;
  onMenu: () => void;
  onSettings: () => void;
};

function FloatingVoiceOrb({
  active,
  speaking,
  online,
  language,
  onPress,
}: {
  active: boolean;
  speaking: boolean;
  online: boolean;
  language: AssistantLanguage;
  onPress: () => void;
}) {
  const pulse = useRef(new Animated.Value(0)).current;
  const breathe = useRef(new Animated.Value(0)).current;
  const barPulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: active || speaking ? 420 : 1050, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: active || speaking ? 420 : 1050, useNativeDriver: true }),
      ]),
    );
    const breatheLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, { toValue: 1, duration: active || speaking ? 650 : 1500, useNativeDriver: true }),
        Animated.timing(breathe, { toValue: 0, duration: active || speaking ? 650 : 1500, useNativeDriver: true }),
      ]),
    );
    const barLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(barPulse, { toValue: 1, duration: active || speaking ? 300 : 900, useNativeDriver: false }),
        Animated.timing(barPulse, { toValue: 0, duration: active || speaking ? 300 : 900, useNativeDriver: false }),
      ]),
    );
    loop.start();
    breatheLoop.start();
    barLoop.start();
    return () => {
      loop.stop();
      breatheLoop.stop();
      barLoop.stop();
    };
  }, [active, speaking, pulse, breathe, barPulse]);

  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, active || speaking ? 1.42 : 1.12] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.42, 0.04] });
  const coreScale = Animated.add(
    pulse.interpolate({ inputRange: [0, 1], outputRange: [1, active || speaking ? 1.06 : 1.025] }),
    breathe.interpolate({ inputRange: [0, 1], outputRange: [0, active || speaking ? 0.025 : 0.012] }),
  );

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={language === 'bn' ? 'ভয়েস কমান্ড' : 'Voice command'}
      onPress={onPress}
      style={dashboardStyles.floatingOrbButton}
    >
      <Animated.View style={[dashboardStyles.orbPulseRing, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
      <Animated.View style={[dashboardStyles.floatingOrbCore, { transform: [{ scale: coreScale }] }]}>
        <View style={dashboardStyles.orbInnerGlow} />
        <View style={dashboardStyles.orbBars}>
          {[0, 1, 2, 3, 4].map((i) => {
            const base = active || speaking ? 10 + ((i + 1) * 5) % 18 : 7 + (i % 2) * 4;
            const animatedHeight = barPulse.interpolate({
              inputRange: [0, 1],
              outputRange: [base, base + (active || speaking ? 9 + i * 2 : 3)],
            });
            return (
              <Animated.View
                key={i}
                style={[dashboardStyles.orbBar, { height: animatedHeight }]}
              />
            );
          })}
        </View>
      </Animated.View>
      <View style={dashboardStyles.orbCaption}>
        <View style={[dashboardStyles.orbStatusDot, { backgroundColor: online ? '#FF4658' : '#7F7075' }]} />
        <Text style={dashboardStyles.orbCaptionText}>
          {active
            ? language === 'bn' ? 'শুনছি' : 'Listening'
            : speaking
              ? language === 'bn' ? 'বলছি' : 'Speaking'
              : language === 'bn' ? 'ট্যাপ করে বলো' : 'Tap to talk'}
        </Text>
      </View>
    </Pressable>
  );
}


function LivingNeuralBackground({ active }: { active: boolean }) {
  const master = useRef(new Animated.Value(0)).current;
  const drift = useRef(new Animated.Value(0)).current;
  const nodes = useRef(
    Array.from({ length: 14 }, (_, i) => ({
      x: [8, 23, 39, 56, 74, 90, 15, 48, 82, 31, 67, 5, 58, 94][i],
      y: [14, 9, 22, 13, 27, 11, 42, 36, 48, 62, 58, 78, 72, 82][i],
      size: [3, 4, 3, 5, 3, 4, 3, 5, 3, 4, 3, 4, 3, 4][i],
      delay: i * 90,
    })),
  ).current;

  useEffect(() => {
    const masterLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(master, { toValue: 1, duration: active ? 900 : 2200, useNativeDriver: true }),
        Animated.timing(master, { toValue: 0, duration: active ? 900 : 2200, useNativeDriver: true }),
      ]),
    );
    const driftLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(drift, { toValue: 1, duration: active ? 1800 : 4200, useNativeDriver: true }),
        Animated.timing(drift, { toValue: 0, duration: active ? 1800 : 4200, useNativeDriver: true }),
      ]),
    );
    masterLoop.start();
    driftLoop.start();
    return () => {
      masterLoop.stop();
      driftLoop.stop();
    };
  }, [active, drift, master]);

  const translateX = drift.interpolate({ inputRange: [0, 1], outputRange: [-10, 10] });
  const translateY = master.interpolate({ inputRange: [0, 1], outputRange: [5, -5] });
  const networkOpacity = master.interpolate({ inputRange: [0, 1], outputRange: [0.22, active ? 0.62 : 0.38] });

  const links: Array<[number, number]> = [
    [0, 1], [1, 3], [3, 4], [4, 5], [0, 6], [6, 7], [7, 8],
    [6, 9], [9, 10], [10, 8], [9, 11], [11, 12], [12, 13], [2, 7],
  ];

  return (
    <View pointerEvents="none" style={dashboardStyles.livingBackground}>
      <Animated.View style={[dashboardStyles.neuralField, { opacity: networkOpacity, transform: [{ translateX }, { translateY }] }]}>
        {links.map(([a, b], i) => {
          const p1 = nodes[a];
          const p2 = nodes[b];
          const dx = p2.x - p1.x;
          const dy = p2.y - p1.y;
          const length = Math.sqrt(dx * dx + dy * dy);
          const angle = Math.atan2(dy, dx) + 'rad';
          return (
            <View
              key={`link-${i}`}
              style={[
                dashboardStyles.neuralLink,
                {
                  left: `${p1.x}%`,
                  top: `${p1.y}%`,
                  width: `${length}%`,
                  transform: [{ rotate: angle }],
                },
              ]}
            />
          );
        })}
        {nodes.map((node, i) => (
          <Animated.View
            key={`node-${i}`}
            style={[
              dashboardStyles.neuralNode,
              {
                left: `${node.x}%`,
                top: `${node.y}%`,
                width: node.size,
                height: node.size,
                borderRadius: node.size / 2,
                opacity: master.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.18 + (i % 3) * 0.08, active ? 0.95 : 0.58],
                }),
                transform: [{ scale: master.interpolate({ inputRange: [0, 1], outputRange: [0.7, active ? 1.8 : 1.25] }) }],
              },
            ]}
          />
        ))}
      </Animated.View>
      <Animated.View style={[dashboardStyles.energyHalo, { opacity: master.interpolate({ inputRange: [0, 1], outputRange: [0.05, active ? 0.18 : 0.11] }), transform: [{ scale: master.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1.08] }) }] }]} />
      <Animated.View style={[dashboardStyles.scanLine, { transform: [{ translateY: master.interpolate({ inputRange: [0, 1], outputRange: [-180, 420] }) }] }]} />
    </View>
  );
}

function FuturisticDashboard({
  language,
  messages,
  draft,
  setDraft,
  isListening,
  continuousVoice,
  isSending,
  isSpeaking,
  online,
  voiceHistory,
  onVoice,
  onSend,
  onMenu,
  onSettings,
}: FuturisticDashboardProps) {
  const { width } = useWindowDimensions();
  const bn = language === 'bn';
  const [typed, setTyped] = useState(draft);

  useEffect(() => setTyped(draft), [draft]);

  const send = (text: string) => {
    const value = text.trim();
    if (!value || isSending) return;
    setDraft(value);
    setTyped(value);
    onSend(value);
  };

  const status = isListening
    ? (bn ? 'শুনছি…' : 'Listening…')
    : isSending
      ? (bn ? 'ভাবছি…' : 'Thinking…')
      : isSpeaking
        ? (bn ? 'বলছি…' : 'Speaking…')
        : (bn ? 'প্রস্তুত' : 'Ready');

  const recentMessages = messages.slice(-8);
  const assistantReplies = messages.filter(item => item.role === 'assistant').length;
  const activeTasks = (isListening ? 1 : 0) + (isSending ? 1 : 0) + (isSpeaking ? 1 : 0);
  const confidence = isSending ? 92 : messages.at(-1)?.intent ? 98 : 96;
  const lastReplyTime = messages.filter(item => item.role === 'assistant').at(-1)?.time;

  const quickCommands = bn
    ? [
        ['📱', 'WhatsApp খোলো', 'WhatsApp খোলো'],
        ['▶', 'YouTube খোলো', 'YouTube খোলো'],
        ['📞', 'কল করো', 'কল করো'],
        ['💬', 'মেসেজ পাঠাও', 'একটা মেসেজ পাঠাও'],
        ['🔊', 'ভলিউম বাড়াও', 'ভলিউম বাড়াও'],
        ['⚙', 'সেটিংস', 'সেটিংস খোলো'],
      ]
    : [
        ['📱', 'Open WhatsApp', 'Open WhatsApp'],
        ['▶', 'Open YouTube', 'Open YouTube'],
        ['📞', 'Call someone', 'Call someone'],
        ['💬', 'Send message', 'Send a message'],
        ['🔊', 'Increase volume', 'Increase volume'],
        ['⚙', 'Open settings', 'Open settings'],
      ];

  return (
    <View style={realDashboardStyles.root}>
      <LivingNeuralBackground active={isListening || isSending || isSpeaking} />

      <ScrollView
        style={realDashboardStyles.scroll}
        contentContainerStyle={realDashboardStyles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Real header — no screenshot/reference image. */}
        <View style={realDashboardStyles.header}>
          <View style={realDashboardStyles.brandRow}>
            <View style={realDashboardStyles.brandOrb}>
              <Text style={realDashboardStyles.brandA}>A</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={realDashboardStyles.brandTitle}>Abir AI</Text>
              <Text style={realDashboardStyles.brandSub}>
                {bn ? 'তোমার Android AI Assistant' : 'Your Android AI Assistant'}
              </Text>
            </View>
          </View>

          <Pressable onPress={() => send(bn ? 'বাংলা ভাষা' : 'English language')} style={realDashboardStyles.headerPill}>
            <Text style={realDashboardStyles.headerPillText}>{bn ? 'বাংলা + English' : 'English + বাংলা'}</Text>
          </Pressable>
          <Pressable onPress={onSettings} style={realDashboardStyles.headerButton}>
            <Text style={realDashboardStyles.headerButtonText}>⚙</Text>
          </Pressable>
        </View>

        {/* Live assistant hero */}
        <LinearGradient
          colors={['#071B3D', '#08102A', '#130A30']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={realDashboardStyles.hero}
        >
          <View style={realDashboardStyles.heroCopy}>
            <View style={realDashboardStyles.statusLine}>
              <View style={[realDashboardStyles.statusDot, { backgroundColor: online ? '#25F0A2' : '#F0B84A' }]} />
              <Text style={realDashboardStyles.statusText}>{online ? 'ONLINE + OFFLINE' : 'OFFLINE READY'}</Text>
            </View>
            <Text style={realDashboardStyles.heroTitle}>
              {isListening ? (bn ? 'আমি শুনছি…' : 'I’m listening…') : isSending ? (bn ? 'ভাবছি…' : 'Thinking…') : isSpeaking ? (bn ? 'বলছি…' : 'Speaking…') : 'Abir AI'}
            </Text>
            <Text style={realDashboardStyles.heroSubtitle}>
              {bn ? 'কথা বলো, টাইপ করো, বা কোনো কাজ দাও।' : 'Talk, type, or give me a real device task.'}
            </Text>
          </View>

          <Pressable onPress={onVoice} style={realDashboardStyles.heroOrbButton} accessibilityLabel="Ask Abir">
            <Animated.View style={[realDashboardStyles.heroOrbGlow, { transform: [{ scale: isListening || isSpeaking ? 1.15 : 1 }] }]} />
            <View style={realDashboardStyles.heroOrb}>
              <Text style={realDashboardStyles.heroOrbText}>A</Text>
              <View style={realDashboardStyles.heroBars}>
                {[10, 18, 28, 16, 24, 12].map((height, index) => (
                  <View key={index} style={[realDashboardStyles.heroBar, { height: isListening || isSpeaking ? height : 8 + (index % 2) * 3 }]} />
                ))}
              </View>
            </View>
          </Pressable>

          <View style={realDashboardStyles.heroRight}>
            <Text style={realDashboardStyles.heroRightLabel}>{bn ? 'Voice' : 'Voice'}</Text>
            <Text style={realDashboardStyles.heroRightValue}>{isListening ? 'Listening' : 'Ready'}</Text>
            <Pressable onPress={onVoice} style={realDashboardStyles.heroVoiceButton}>
              <Text style={realDashboardStyles.heroVoiceIcon}>🎙</Text>
              <Text style={realDashboardStyles.heroVoiceText}>{continuousVoice ? (bn ? 'থামাও' : 'Stop') : (bn ? 'কথা বলো' : 'Speak')}</Text>
            </Pressable>
          </View>
        </LinearGradient>

        {/* Live metrics */}
        <View style={realDashboardStyles.metricsRow}>
          <MetricRing label={bn ? 'Confidence' : 'Confidence'} value={`${confidence}%`} ring="green" />
          <MetricRing label={bn ? 'Active Tasks' : 'Active Tasks'} value={String(activeTasks)} ring="blue" />
          <MetricRing label={bn ? 'Replies' : 'Replies'} value={String(assistantReplies)} ring="purple" />
          <MetricRing label={bn ? 'Memory' : 'Memory'} value={`${Math.min(messages.length, 200)}/200`} ring="blue" />
        </View>

        <View style={realDashboardStyles.twoColumn}>
          {/* Conversation is real state, not an image. */}
          <View style={[realDashboardStyles.card, realDashboardStyles.conversationCard]}>
            <View style={realDashboardStyles.cardHeader}>
              <View>
                <Text style={realDashboardStyles.cardTitle}>{bn ? 'Live Conversation' : 'Live Conversation'}</Text>
                <Text style={realDashboardStyles.cardSubtitle}>{status}</Text>
              </View>
              <View style={realDashboardStyles.liveBadge}>
                <View style={realDashboardStyles.liveBadgeDot} />
                <Text style={realDashboardStyles.liveBadgeText}>{bn ? 'LIVE' : 'LIVE'}</Text>
              </View>
            </View>

            <View style={realDashboardStyles.messageList}>
              {recentMessages.length === 0 ? (
                <Text style={realDashboardStyles.emptyText}>{bn ? 'এখনও কোনো কথা হয়নি।' : 'No conversation yet.'}</Text>
              ) : recentMessages.map(message => (
                <View key={message.id} style={[realDashboardStyles.messageBubble, message.role === 'user' ? realDashboardStyles.userBubble : realDashboardStyles.assistantBubble]}>
                  <View style={realDashboardStyles.messageMetaRow}>
                    <Text style={realDashboardStyles.messageRole}>{message.role === 'user' ? (bn ? 'তুমি' : 'You') : 'Abir'}</Text>
                    <Text style={realDashboardStyles.messageTime}>{getTimeLabel(message.time, language)}</Text>
                  </View>
                  <Text style={realDashboardStyles.messageText}>{message.text}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Real-time system state */}
          <View style={realDashboardStyles.card}>
            <View style={realDashboardStyles.cardHeader}>
              <View>
                <Text style={realDashboardStyles.cardTitle}>{bn ? 'System Status' : 'System Status'}</Text>
                <Text style={realDashboardStyles.cardSubtitle}>{bn ? 'বর্তমান ডিভাইস state' : 'Current device state'}</Text>
              </View>
            </View>
            {[
              [bn ? 'Offline Brain' : 'Offline Brain', 'ACTIVE'],
              [bn ? 'Voice Engine' : 'Voice Engine', isListening ? 'LISTENING' : 'READY'],
              [bn ? 'Online API' : 'Online API', online ? 'CONNECTED' : 'OFFLINE'],
              [bn ? 'Memory' : 'Memory', `${Math.min(messages.length, 200)}/200`],
              [bn ? 'Last Reply' : 'Last Reply', lastReplyTime ? getTimeLabel(lastReplyTime, language) : '—'],
            ].map(([label, value]) => (
              <View key={label} style={realDashboardStyles.systemRow}>
                <View style={realDashboardStyles.systemDot} />
                <Text style={realDashboardStyles.systemLabel}>{label}</Text>
                <Text style={realDashboardStyles.systemValue}>{value}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Real quick commands */}
        <View style={realDashboardStyles.card}>
          <View style={realDashboardStyles.cardHeader}>
            <View>
              <Text style={realDashboardStyles.cardTitle}>{bn ? 'Quick Commands' : 'Quick Commands'}</Text>
              <Text style={realDashboardStyles.cardSubtitle}>{bn ? 'চাপ দিলে সত্যিকারের command পাঠাবে' : 'Each button sends a real command'}</Text>
            </View>
          </View>
          <View style={realDashboardStyles.quickGrid}>
            {quickCommands.map(([icon, title, command]) => (
              <Pressable key={title} onPress={() => send(command)} style={({ pressed }) => [realDashboardStyles.quickButton, pressed && realDashboardStyles.quickButtonPressed]}>
                <Text style={realDashboardStyles.quickIcon}>{icon}</Text>
                <Text style={realDashboardStyles.quickText}>{title}</Text>
                <Text style={realDashboardStyles.quickArrow}>›</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Voice history */}
        {voiceHistory.length > 0 && (
          <View style={realDashboardStyles.card}>
            <View style={realDashboardStyles.cardHeader}>
              <View>
                <Text style={realDashboardStyles.cardTitle}>{bn ? 'Voice History' : 'Voice History'}</Text>
                <Text style={realDashboardStyles.cardSubtitle}>{bn ? 'শেষের voice commands' : 'Recent voice commands'}</Text>
              </View>
            </View>
            {voiceHistory.slice(0, 5).map(item => (
              <View key={item.id} style={realDashboardStyles.historyRow}>
                <View style={realDashboardStyles.historyMic}><Text>🎙</Text></View>
                <Text numberOfLines={2} style={realDashboardStyles.historyText}>{item.text}</Text>
                <Text style={realDashboardStyles.historyTime}>{getTimeLabel(item.time, language)}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Real input dock */}
      <View style={realDashboardStyles.inputDockWrap}>
        <View style={realDashboardStyles.inputDock}>
          <TextInput
            value={typed}
            onChangeText={value => { setTyped(value); setDraft(value); }}
            onSubmitEditing={() => send(typed)}
            placeholder={bn ? 'আবিরকে কিছু বলো…' : 'Ask Abir anything…'}
            placeholderTextColor="#7894B7"
            style={realDashboardStyles.input}
            returnKeyType="send"
            multiline={false}
            editable={!isSending}
          />
          <Pressable onPress={onVoice} style={[realDashboardStyles.inputButton, isListening && realDashboardStyles.inputButtonActive]}>
            <Text style={realDashboardStyles.inputButtonText}>🎙</Text>
          </Pressable>
          <Pressable onPress={() => send(typed)} disabled={!typed.trim() || isSending} style={[realDashboardStyles.sendButton, (!typed.trim() || isSending) && realDashboardStyles.disabledButton]}>
            {isSending ? <ActivityIndicator size="small" color="#FFFFFF" /> : <Text style={realDashboardStyles.sendButtonText}>➤</Text>}
          </Pressable>
        </View>
        <View style={realDashboardStyles.bottomActions}>
          <Pressable onPress={onVoice} style={realDashboardStyles.bottomAction}><Text style={realDashboardStyles.bottomActionIcon}>🎙</Text><Text style={realDashboardStyles.bottomActionText}>{bn ? 'Voice' : 'Voice'}</Text></Pressable>
          <Pressable onPress={onMenu} style={realDashboardStyles.bottomAction}><Text style={realDashboardStyles.bottomActionIcon}>🧰</Text><Text style={realDashboardStyles.bottomActionText}>{bn ? 'Tools' : 'Tools'}</Text></Pressable>
          <Pressable onPress={onSettings} style={realDashboardStyles.bottomAction}><Text style={realDashboardStyles.bottomActionIcon}>⚙</Text><Text style={realDashboardStyles.bottomActionText}>{bn ? 'Settings' : 'Settings'}</Text></Pressable>
        </View>
      </View>
    </View>
  );
}

function MetricRing({ label, value, ring }: { label: string; value: string; ring: 'green' | 'blue' | 'purple' }) {
  return (
    <View style={dashboardStyles.metricRingCard}>
      <View style={[dashboardStyles.metricRing, ring === 'green' ? dashboardStyles.ringGreen : ring === 'purple' ? dashboardStyles.ringPurple : dashboardStyles.ringBlue]}>
        <Text style={dashboardStyles.metricRingValue}>{value}</Text>
      </View>
      <Text numberOfLines={1} style={dashboardStyles.metricRingLabel}>{label}</Text>
    </View>
  );
}

function SmallMetric({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <View style={dashboardStyles.smallMetric}>
      {icon ? <Text style={dashboardStyles.smallMetricIcon}>{icon}</Text> : null}
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={dashboardStyles.smallMetricLabel}>{label}</Text>
        <Text style={dashboardStyles.smallMetricValue}>{value}</Text>
      </View>
    </View>
  );
}

function DashboardPanel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <View style={dashboardStyles.panel}>
      <Text style={dashboardStyles.cardEyebrow}>{title}</Text>
      <Text style={dashboardStyles.panelSubtitle}>{subtitle}</Text>
      <View style={dashboardStyles.panelBody}>{children}</View>
    </View>
  );
}

function StatusLine({ label, value }: { label: string; value: string }) {
  return (
    <View style={dashboardStyles.statusItem}>
      <View style={dashboardStyles.statusCheck}><Text style={dashboardStyles.statusCheckText}>✓</Text></View>
      <Text numberOfLines={1} style={dashboardStyles.statusItemLabel}>{label}</Text>
      <Text style={dashboardStyles.statusItemValue}>{value}</Text>
    </View>
  );
}

function DashboardStat({ label, value, trend }: { label: string; value: string; trend: string }) {
  return (
    <View style={dashboardStyles.bottomStat}>
      <Text style={dashboardStyles.metricLabel}>{label}</Text>
      <Text style={dashboardStyles.bottomStatValue}>{value}</Text>
      <Text style={dashboardStyles.metricTrend}>{trend}</Text>
    </View>
  );
}

function getDeviceAction(text: string): 'back' | 'home' | 'recents' | 'notifications' | 'quick-settings' | null {
  const n = text.toLowerCase();
  if (/(?:back|go back|পিছনে যাও|পেছনে যাও)/i.test(n)) return 'back';
  if (/(?:home|go home|হোমে যাও|হোমে নিয়ে যাও)/i.test(n)) return 'home';
  if (/(?:recent apps|recents|সাম্প্রতিক অ্যাপ|রিসেন্ট অ্যাপ)/i.test(n)) return 'recents';
  if (/(?:notifications|notification panel|নোটিফিকেশন|বিজ্ঞপ্তি)/i.test(n)) return 'notifications';
  if (/(?:quick settings|quick panel|কুইক সেটিংস|কুইক প্যানেল)/i.test(n)) return 'quick-settings';
  return null;
}
function replyNeedsDeviceAction(text: string) { return getDeviceAction(text) !== null; }

type Message = {
  id: string;
  role: 'assistant' | 'user';
  text: string;
  time: number;
  intent?: AssistantIntent;
};

type SavedChat = {
  messages: Message[];
  language: AssistantLanguage;
  autoSpeak: boolean;
};

type VoiceHistoryItem = {
  id: string;
  text: string;
  time: number;
};

type UiIconName =
  | 'sparkles'
  | 'volume-high'
  | 'volume-mute'
  | 'volume-medium'
  | 'trash'
  | 'mic'
  | 'arrow-up'
  | 'settings'
  | 'close'
  | 'camera'
  | 'shield'
  | 'more'
  | 'person';

function UiIcon({
  name,
  color,
  size = 20,
}: {
  name: UiIconName;
  color: string;
  size?: number;
}) {
  const strokeProps = {
    fill: 'none',
    stroke: color,
    strokeWidth: 1.8,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };

  let drawing: React.ReactNode;
  switch (name) {
    case 'sparkles':
      drawing = (
        <>
          <Path
            d="M12 3 13.9 8.1 19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"
            {...strokeProps}
          />
          <Path d="M19 15v4M17 17h4" {...strokeProps} />
        </>
      );
      break;
    case 'volume-high':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6M18.5 6.5a9 9 0 0 1 0 11" {...strokeProps} />
        </>
      );
      break;
    case 'volume-medium':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="M16 9a5 5 0 0 1 0 6" {...strokeProps} />
        </>
      );
      break;
    case 'volume-mute':
      drawing = (
        <>
          <Path d="M4 9v6h4l5 4V5L8 9H4Z" {...strokeProps} />
          <Path d="m17 9 5 6m0-6-5 6" {...strokeProps} />
        </>
      );
      break;
    case 'trash':
      drawing = (
        <>
          <Path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14" {...strokeProps} />
          <Path d="M9 7V4h6v3" {...strokeProps} />
        </>
      );
      break;
    case 'mic':
      drawing = (
        <>
          <Rect x="9" y="3" width="6" height="12" rx="3" {...strokeProps} />
          <Path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" {...strokeProps} />
        </>
      );
      break;
    case 'arrow-up':
      drawing = <Path d="M12 19V5M6 11l6-6 6 6" {...strokeProps} />;
      break;
    case 'settings':
      drawing = (
        <>
          <Path
            d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z"
            {...strokeProps}
          />
          <Path
            d="m19.4 15 .1.1a1.8 1.8 0 1 1-2.5 2.5l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.3a1.8 1.8 0 1 1-3.6 0v-.2a1.7 1.7 0 0 0-2.9-1.2l-.1.1a1.8 1.8 0 1 1-2.5-2.5l.1-.1a1.7 1.7 0 0 0-1.2-2.9h-.3a1.8 1.8 0 1 1 0-3.6h.2a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a1.8 1.8 0 1 1 2.5-2.5l.1.1a1.7 1.7 0 0 0 2.9-1.2v-.3a1.8 1.8 0 1 1 3.6 0v.2a1.7 1.7 0 0 0 2.9 1.2l.1-.1a1.8 1.8 0 1 1 2.5 2.5l-.1.1a1.7 1.7 0 0 0 1.2 2.9h.3a1.8 1.8 0 1 1 0 3.6h-.2a1.7 1.7 0 0 0-1.2 2.9Z"
            {...strokeProps}
          />
        </>
      );
      break;
    case 'close':
      drawing = <Path d="m6 6 12 12M18 6 6 18" {...strokeProps} />;
      break;
    case 'camera':
      drawing = (
        <>
          <Path d="M4 8h3l1.5-2h7L17 8h3v11H4V8Z" {...strokeProps} />
          <Circle cx="12" cy="13.5" r="3.5" {...strokeProps} />
        </>
      );
      break;
    case 'person':
      drawing = (
        <>
          <Circle cx="12" cy="8" r="3" {...strokeProps} />
          <Path d="M5 20c.8-4 3.1-6 7-6s6.2 2 7 6" {...strokeProps} />
        </>
      );
      break;
    case 'more':
      drawing = (
        <>
          <Circle cx="6" cy="12" r="1.2" fill={color} />
          <Circle cx="12" cy="12" r="1.2" fill={color} />
          <Circle cx="18" cy="12" r="1.2" fill={color} />
        </>
      );
      break;
    case 'shield':
      drawing = (
        <>
          <Path d="M12 3 19 6v5c0 4.5-2.9 8-7 10-4.1-2-7-5.5-7-10V6l7-3Z" {...strokeProps} />
          <Path d="m9 12 2 2 4-4" {...strokeProps} />
        </>
      );
      break;
    default:
      drawing = <Circle cx="12" cy="12" r="8" {...strokeProps} />;
  }

  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityRole="image">
      {drawing}
    </Svg>
  );
}

const STORAGE_KEY = 'abir-ai-chat-v1';
const MAX_MESSAGES = 160;
const CAMERA_MEMORY_KEY = 'abir-ai-camera-memory-v1';
const MAX_CAMERA_MEMORIES = 5;
const APP_LOCK_KEY = 'abir-ai-app-lock-v2';
const WAKE_WORD_KEY = 'abir-ai-wake-word-v2';
const ACCOUNT_KEY = 'abir-ai-account-v2';
const ACCOUNT_EMAIL_KEY = 'abir-ai-account-email-v2';
const ACCOUNT_PASSWORD_KEY = 'abir-ai-account-password-v2';
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';
const SECURITY_LOG_KEY = 'abir-ai-security-log-v1';
const MAX_SECURITY_LOGS = 60;
const VOICE_HISTORY_KEY = 'abir-ai-voice-history-v1';
const MAX_VOICE_HISTORY = 20;

function messagingPackage(app: MessageRequest['app']) {
  return app === 'imo' ? 'com.imo.android.imoim' : 'com.facebook.orca';
}

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function welcomeMessage(language: AssistantLanguage): Message {
  return {
    id: 'welcome',
    role: 'assistant',
    text:
      language === 'bn'
        ? 'হ্যালো! আমি আবির, তোমার মোবাইল AI Assistant। আমি অফলাইন ও অনলাইন—দুইভাবেই কাজ করি। কী করতে হবে বলো, বস?'
        : 'Hi! I’m Abir, your Android Assistant. I can work both offline and online. What would you like me to do?',
    time: Date.now(),
  };
}

function isSavedChat(value: unknown): value is SavedChat {
  if (!value || typeof value !== 'object') return false;
  const saved = value as Partial<SavedChat>;
  return (
    Array.isArray(saved.messages) &&
    (saved.language === 'bn' || saved.language === 'en') &&
    typeof saved.autoSpeak === 'boolean' &&
    saved.messages.every(
      (message) =>
        message &&
        typeof message.id === 'string' &&
        (message.role === 'assistant' || message.role === 'user') &&
        typeof message.text === 'string' &&
        typeof message.time === 'number',
    )
  );
}

function getTimeLabel(timestamp: number, language: AssistantLanguage) {
  return new Intl.DateTimeFormat(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
  }).format(timestamp);
}

function isCancelAppChoice(text: string) {
  return /^(?:cancel|never mind|nevermind|stop|থাক|বাদ দাও|বাতিল|না)$/i.test(
    text.trim(),
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([welcomeMessage('bn')]);
  const [language, setLanguage] = useState<AssistantLanguage>('bn');
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [voiceGender, setVoiceGender] = useState<VoiceGenderPreference>(DEFAULT_PREFERENCES.voiceGender);
  const [speechVoices, setSpeechVoices] = useState<SpeechVoice[]>([]);
  const [draft, setDraft] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [continuousVoice, setContinuousVoice] = useState(false);
  const voiceLoopRef = useRef(false);
  const voiceRunIdRef = useRef(0);
  const [online, setOnline] = useState(false);
  const [voiceHistory, setVoiceHistory] = useState<VoiceHistoryItem[]>([]);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(true);
  const [wakeWordReady, setWakeWordReady] = useState(false);
  const [savedCameraUris, setSavedCameraUris] = useState<string[]>([]);
  const [cameraPreviewUri, setCameraPreviewUri] = useState<string | null>(null);
  const [liveCameraVisible, setLiveCameraVisible] = useState(false);
  const [liveCameraFacing, setLiveCameraFacing] = useState<'back' | 'front'>('back');
  const [liveCameraBusy, setLiveCameraBusy] = useState(false);
  const [liveCameraQuestion, setLiveCameraQuestion] = useState('');
  const liveCameraRef = useRef<CameraView>(null);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [ownerVerified, setOwnerVerified] = useState(false);
  const [speakerSampleCount, setSpeakerSampleCount] = useState(0);
  const [speakerRecording, setSpeakerRecording] = useState(false);
  const [appLockEnabled, setAppLockEnabled] = useState(false);
  const [appUnlocked, setAppUnlocked] = useState(false);
  const [securityLogs, setSecurityLogs] = useState<Array<{id:string;time:number;event:string;detail?:string}>>([]);
  const [memory, setMemory] = useState<AssistantMemory>(EMPTY_MEMORY);
  const [account, setAccount] = useState<{email:string;apiKey:string} | null>(null);
  const [accountLoggedIn, setAccountLoggedIn] = useState(false);
  const [accountReady, setAccountReady] = useState(false);
  const [accountEmail, setAccountEmail] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [accountApiKey, setAccountApiKey] = useState('');
  const [showAccountSetup, setShowAccountSetup] = useState(false);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [pendingAppChoices, setPendingAppChoices] = useState<
    LaunchableApp[] | null
  >(null);
  const [pendingContactChoices, setPendingContactChoices] = useState<
    ContactPhone[] | null
  >(null);
  const inputRef = useRef<TextInput>(null);
  const voicePulse = useRef(new Animated.Value(1)).current;
  const orbRotation = useRef(new Animated.Value(0)).current;
  const orbRotationReverse = useRef(new Animated.Value(0)).current;
  const lastAssistantText = useRef<string | null>(null);
  const overlayPromptedRef = useRef(false);
  const batteryPromptedRef = useRef(false);

  useEffect(() => {
    if (!isListening && !isSending) {
      voicePulse.stopAnimation();
      voicePulse.setValue(1);
      return;
    }

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(voicePulse, {
          toValue: 1.12,
          duration: 650,
          useNativeDriver: true,
        }),
        Animated.timing(voicePulse, {
          toValue: 1,
          duration: 650,
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => {
      loop.stop();
      voicePulse.setValue(1);
    };
  }, [isListening, isSending, voicePulse]);

  useEffect(() => {
    const forward = Animated.loop(Animated.timing(orbRotation, { toValue: 1, duration: 7200, useNativeDriver: true }));
    const reverse = Animated.loop(Animated.timing(orbRotationReverse, { toValue: 1, duration: 9800, useNativeDriver: true }));
    forward.start();
    reverse.start();
    return () => { forward.stop(); reverse.stop(); };
  }, [orbRotation, orbRotationReverse]);

  useEffect(() => {
    void getSpeakerProfile().then(profile => setSpeakerSampleCount(profile?.samples.length ?? 0));
  }, []);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!mounted || !stored) return;
        const parsed: unknown = JSON.parse(stored);
        if (!isSavedChat(parsed)) return;
        setMessages(parsed.messages);
        setLanguage(parsed.language);
      })
      .catch(() => {
        // A corrupt or unavailable local cache should not prevent a new chat.
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });

    AsyncStorage.getItem(VOICE_HISTORY_KEY)
      .then(raw => {
        if (!raw || !mounted) return;
        try {
          const parsed: unknown = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            const valid = parsed.filter((item): item is VoiceHistoryItem =>
              Boolean(item) &&
              typeof item === 'object' &&
              typeof (item as VoiceHistoryItem).id === 'string' &&
              typeof (item as VoiceHistoryItem).text === 'string' &&
              typeof (item as VoiceHistoryItem).time === 'number',
            );
            setVoiceHistory(valid.slice(-MAX_VOICE_HISTORY).reverse());
          }
        } catch {}
      })
      .catch(() => {});

    AsyncStorage.getItem('abir-ai-auto-speak-v1').then(value => {
      if (value === 'on') setAutoSpeak(true);
      if (value === 'off') setAutoSpeak(false);
    }).catch(() => {});
    AsyncStorage.getItem(WAKE_WORD_KEY).then(value => {
      if (value === 'on') setWakeWordEnabled(true);
      else if (value === 'off') setWakeWordEnabled(false);
      setWakeWordReady(true);
    }).catch(() => setWakeWordReady(true));

    Promise.all([
      AsyncStorage.getItem(APP_LOCK_KEY),
      SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY),
      SecureStore.getItemAsync(ACCOUNT_API_KEY),
      SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY),
      AsyncStorage.getItem(SECURITY_LOG_KEY),
    ]).then(([lock, email, key, savedPassword, logs]) => {
      setAppLockEnabled(lock === 'enabled');
      setAppUnlocked(lock !== 'enabled');
      if (email) {
        setAccountEmail(email);
        setAccountApiKey(key ?? '');
        setAccount({ email, apiKey: key ?? '' });
        setAccountLoggedIn(false);
      }
      if (logs) {
        try { const v = JSON.parse(logs); if (Array.isArray(v)) setSecurityLogs(v.slice(-MAX_SECURITY_LOGS)); } catch {}
      }
      setAccountReady(true);
    }).catch(() => setAccountReady(true));

    loadLocalMemory().then(setMemory).catch(() => setMemory(EMPTY_MEMORY));
    Promise.all([loadAssistantPreferences(), loadSpeechVoices()])
      .then(([preferences, voices]) => {
        setVoiceGender(preferences.voiceGender);
        setSpeechVoices(voices);
      })
      .catch(() => {});

    AsyncStorage.getItem(CAMERA_MEMORY_KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setSavedCameraUris(
            parsed
              .filter((value): value is string => typeof value === 'string')
              .slice(0, MAX_CAMERA_MEMORIES),
          );
        }
      })
      .catch(() => {});

    // Owner verification uses the phone's built-in biometric system.
    // Abir does not store or compare face/fingerprint templates itself.

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'android' || isLoading || !wakeWordReady || !accountLoggedIn) return;
    let mounted = true;
    let lastWakeUrl = '';
    let lastWakeHandledAt = 0;
    const handleWakeUrl = async (url: string) => {
      if (!url.startsWith('abir-ai://wake')) return;
      const now = Date.now();
      if (url === lastWakeUrl && now - lastWakeHandledAt < 2500) return;
      lastWakeUrl = url;
      lastWakeHandledAt = now;
      const parsed = Linking.parse(url);
      const command = typeof parsed.queryParams?.text === 'string'
        ? parsed.queryParams.text.trim()
        : '';
      if (!mounted) return;
      if (command) {
        await sendText(command, true);
      } else {
        await startVoiceInput();
      }
    };

    const subscription = Linking.addEventListener('url', ({ url }) => {
      void handleWakeUrl(url);
    });
    void Linking.getInitialURL().then((url) => {
      if (url) void handleWakeUrl(url);
    });

    let appStateSub: { remove: () => void } | null = null;
    if (wakeWordEnabled) {
      // The foreground UI uses its own SpeechRecognizer. Running the
      // background WakeWordService at the same time makes two recognizers
      // compete for the microphone, which causes beeps, open/close cycles,
      // missed speech and "it heard one command then stopped" behavior.
      //
      // Keep the service for background wake-word listening only.
      if (AppState.currentState === 'background' || AppState.currentState === 'inactive') {
        void enableWakeWord();
      } else {
        void stopWakeWord();
      }

      appStateSub = AppState.addEventListener('change', state => {
        if (!wakeWordEnabled) return;

        if (state === 'active') {
          // Foreground recognizer owns the microphone.
          void stopWakeWord();
        } else if (state === 'background' || state === 'inactive') {
          // Background wake-word service owns the microphone.
          void enableWakeWord();
        }
      });
    }

    return () => {
      mounted = false;
      subscription.remove();
      appStateSub?.remove();
      void stopWakeWord();
    };
  }, [accountLoggedIn, isLoading, wakeWordEnabled, wakeWordReady]);

  const ensureMicrophonePermission = async () => {
    if (Platform.OS !== 'android') return true;
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    return permission === PermissionsAndroid.RESULTS.GRANTED;
  };

  useEffect(() => {
    let mounted = true;
    const refresh = async () => {
      try {
        const value = await getOnlineStatus();
        if (mounted) setOnline(Boolean(value));
      } catch {
        if (mounted) setOnline(false);
      }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 10000);
    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, []);

  const enableWakeWord = async () => {
    const granted = await ensureMicrophonePermission();
    if (!granted) {
      setWakeWordEnabled(false);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'off').catch(() => {});
      return false;
    }
    const overlayReady = await canDrawOverlays();
    if (!overlayReady && !overlayPromptedRef.current) {
      overlayPromptedRef.current = true;
      Alert.alert(
        language === 'bn' ? 'ছোট Voice UI-এর অনুমতি দরকার' : 'Small voice UI permission',
        language === 'bn'
          ? 'অ্যাপের বাইরে ছোট Abir voice UI দেখাতে “Display over other apps” অনুমতি দাও। অনুমতি না দিলেও Wake Word শুনতে চেষ্টা করবে।'
          : 'Allow “Display over other apps” for the small Abir voice UI. Wake Word will still try to work without this permission.',
        [
          { text: language === 'bn' ? 'এখন না' : 'Not now', style: 'cancel' },
          { text: language === 'bn' ? 'সেটিংস' : 'Settings', onPress: () => void openOverlaySettings() },
        ],
      );
    }
    const batterySafe = await isIgnoringBatteryOptimizations().catch(() => true);
    if (!batterySafe && !batteryPromptedRef.current) {
      batteryPromptedRef.current = true;
      Alert.alert(
        language === 'bn' ? 'Background voice স্থির রাখতে একটি অনুমতি দরকার' : 'One permission helps background voice stay alive',
        language === 'bn'
          ? 'তোমার ফোনের battery optimization Abir-কে কয়েক সেকেন্ড পর বন্ধ করে দিতে পারে। এখন Battery optimization থেকে Abir AI-কে বাদ দেওয়ার Settings খুলব?'
          : 'Battery optimization can stop Abir after a few seconds in the background. Open the setting to allow Abir AI to stay active?',
        [
          { text: language === 'bn' ? 'এখন না' : 'Not now', style: 'cancel' },
          { text: 'Settings', onPress: () => { void requestBatteryOptimizationExemption(); } },
        ],
      );
    }

    const started = await startWakeWord();
    if (!started) {
      setWakeWordEnabled(false);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'off').catch(() => {});
    } else {
      setWakeWordEnabled(true);
      await AsyncStorage.setItem(WAKE_WORD_KEY, 'on').catch(() => {});
    }
    return started;
  };

  useEffect(() => {
    if (isLoading) return;
    const saved: SavedChat = {
      messages: messages.slice(-MAX_MESSAGES),
      language,
      autoSpeak,
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(saved)).catch(() => {
      Alert.alert(
        language === 'bn' ? 'চ্যাট সংরক্ষণ হয়নি' : 'Chat not saved',
        language === 'bn'
          ? 'এই ডিভাইসে চ্যাট সংরক্ষণ করা যায়নি।'
          : 'This chat could not be saved on this device.',
      );
    });
  }, [autoSpeak, isLoading, language, messages]);

  const speakMessage = async (message: Message) => {
    try {
      setSpeakingId(message.id);
      const speechLanguage: AssistantLanguage = /[\u0980-\u09FF]/.test(message.text) ? 'bn' : language;
      const languageTag = speechLanguage === 'bn' ? 'bn-BD' : 'en-US';

      // Android native TTS is the primary path because some Android TTS engines
      // can silently ignore an Expo voice identifier even though the UI looks active.
      if (Platform.OS === 'android') {
        const nativeStarted = await speakNativeText(message.text, languageTag, voiceGender);
        if (nativeStarted) {
          const approxMs = Math.min(12000, Math.max(1200, message.text.length * (speechLanguage === 'bn' ? 58 : 52)));
          setTimeout(() => setSpeakingId(current => current === message.id ? null : current), approxMs);
          return;
        }
      }

      await speakAssistantText({
        text: message.text,
        language: speechLanguage,
        voiceGender,
        voices: speechVoices,
        onDone: () => setSpeakingId(null),
        onError: () => {
          setSpeakingId(null);
          Alert.alert(
            language === 'bn' ? 'ভয়েস পাওয়া যায়নি' : 'Voice unavailable',
            language === 'bn'
              ? 'ফোনের Text-to-Speech-এ বাংলা/পছন্দের ভয়েস ইনস্টল আছে কি না দেখে নাও।'
              : 'Check that the phone has a compatible Text-to-Speech voice installed.',
          );
        },
      });
    } catch {
      setSpeakingId(null);
    }
  };

  const repeatLastAssistantReply = async () => {
    const lastAssistant = [...messages].reverse().find(item => item.role === 'assistant');
    if (!lastAssistant) {
      Alert.alert(
        language === 'bn' ? 'এখনো কোনো উত্তর নেই' : 'No reply yet',
        language === 'bn' ? 'Abir-এর কোনো আগের উত্তর পাওয়া যায়নি।' : 'There is no previous Abir reply to repeat.',
      );
      return;
    }
    await speakMessage(lastAssistant);
  };

  const stopVoiceReply = async () => {
    try {
      await Promise.all([Speech.stop(), stopNativeSpeaking()]);
    } finally {
      setSpeakingId(null);
    }
  };

  const addSecurityLog = async (event: string, detail?: string) => {
    const entry = { id: createId(), time: Date.now(), event, detail };
    setSecurityLogs(current => {
      const next = [...current, entry].slice(-MAX_SECURITY_LOGS);
      AsyncStorage.setItem(SECURITY_LOG_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  const authenticateSensitiveDeviceAction = async (action: string) => {
    try {
      const speaker = await verifyOwnerVoiceWithUnifiedManager();
      await addSecurityLog(
        speaker.verified ? 'speaker-verification-passed' : 'speaker-verification-denied',
        `${action}:${speaker.score.toFixed(3)}`,
      );
      if (!speaker.enrolled || !speaker.verified) return false;

      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      const level = await LocalAuthentication.getEnrolledLevelAsync();
      const hasDeviceCredential = level !== LocalAuthentication.SecurityLevel.NONE;
      if ((!hasHardware && !hasDeviceCredential) || !enrolled) {
        await addSecurityLog('sensitive-action-blocked', `${action}:no-device-auth`);
        return false;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'মালিক যাচাই শেষ করো' : 'Complete owner verification',
        promptSubtitle: language === 'bn' ? 'ভয়েস + Fingerprint/Face/PIN যাচাই' : 'Voice + Fingerprint/Face/PIN verification',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      await addSecurityLog(result.success ? 'sensitive-action-authorized' : 'sensitive-action-denied', action);
      return result.success;
    } catch {
      await addSecurityLog('sensitive-action-error', action);
      return false;
    }
  };


  const authenticateOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      const level = await LocalAuthentication.getEnrolledLevelAsync();
      const hasDeviceCredential = level !== LocalAuthentication.SecurityLevel.NONE;
      if (!hasHardware && !hasDeviceCredential) return false;
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'Abir AI আনলক করো' : 'Unlock Abir AI',
        promptSubtitle: 'Fingerprint/Face/PIN/Password',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      await addSecurityLog(result.success ? 'unlock-success' : 'unlock-failed');
      return result.success;
    } catch {
      await addSecurityLog('unlock-error');
      return false;
    }
  };

  const setupSpeakerProfile = async () => {
    if (speakerRecording) return;
    setSpeakerRecording(true);
    try {
      let count = speakerSampleCount;
      for (let i = count; i < MAX_SPEAKER_SAMPLES; i += 1) {
        const prompt = language === 'bn'
          ? `ভয়েস নমুনা ${i + 1}/${MAX_SPEAKER_SAMPLES}\nস্বাভাবিকভাবে ২–৩ সেকেন্ড কথা বলো।`
          : `Voice sample ${i + 1}/${MAX_SPEAKER_SAMPLES}\nSpeak naturally for 2–3 seconds.`;
        await new Promise<void>(resolve => {
          Alert.alert(language === 'bn' ? 'Owner Voice Record' : 'Owner Voice Record', prompt, [
            { text: language === 'bn' ? 'রেকর্ড' : 'Record', onPress: () => resolve() },
          ], { cancelable: false });
        });
        const result = await enrollOwnerVoiceWithUnifiedManager();
        if (!result.ok) {
          Alert.alert(
            language === 'bn' ? 'রেকর্ড হয়নি' : 'Recording failed',
            language === 'bn' ? 'মাইক্রোফোন permission ও ফোনের microphone পরীক্ষা করো।' : 'Check microphone permission and the phone microphone.',
          );
          break;
        }
        count = result.count;
        setSpeakerSampleCount(count);
      }
      if (count >= 3) {
        Alert.alert(
          language === 'bn' ? 'Owner Voice প্রস্তুত' : 'Owner Voice ready',
          language === 'bn'
            ? `${count}টি voice sample রাখা হয়েছে। Screen off/on-এর sensitive command-এ speaker verification ব্যবহার হবে।`
            : `${count} voice samples are stored locally. Sensitive screen commands will use speaker verification.`,
        );
      }
    } finally {
      setSpeakerRecording(false);
    }
  };

  const configureAppLock = async () => {
    const ok = await authenticateOwner();
    if (!ok) {
      Alert.alert(
        language === 'bn' ? 'ভেরিফিকেশন দরকার' : 'Verification required',
        language === 'bn' ? 'ফোনের fingerprint/face/PIN/password দিয়ে যাচাই করো।' : 'Verify with the phone fingerprint/face/PIN/password.',
      );
      return;
    }
    setOwnerVerified(true);
    const next = !appLockEnabled;
    await AsyncStorage.setItem(APP_LOCK_KEY, next ? 'enabled' : 'disabled');
    setAppLockEnabled(next);
    setAppUnlocked(true);
    await addSecurityLog(next ? 'app-lock-enabled' : 'app-lock-disabled');
    Alert.alert(
      next ? (language === 'bn' ? 'App Lock চালু' : 'App Lock enabled') : (language === 'bn' ? 'App Lock বন্ধ' : 'App Lock disabled'),
      next
        ? (language === 'bn' ? 'Abir background-এ গেলে আবার lock হবে।' : 'Abir will lock when it goes to the background.')
        : (language === 'bn' ? 'এখন আর App Lock থাকবে না।' : 'App Lock is now disabled.'),
    );
  };

  const saveAccount = async (_provider: LoginProvider = 'gemini', supplied?: { email: string; password: string; apiKey: string }) => {
    const email = (supplied?.email ?? accountEmail).trim();
    const password = supplied?.password ?? accountPassword;
    const key = (supplied?.apiKey ?? accountApiKey).trim();
    if (!email || !password) {
      Alert.alert(
        language === 'bn' ? 'তথ্য অসম্পূর্ণ' : 'Missing information',
        language === 'bn' ? 'Email এবং password দাও।' : 'Enter email and password.',
      );
      return;
    }
    await SecureStore.setItemAsync(ACCOUNT_EMAIL_KEY, email);
    await SecureStore.setItemAsync(ACCOUNT_PASSWORD_KEY, password);
    if (key) await SecureStore.setItemAsync(ACCOUNT_API_KEY, key);
    else await SecureStore.deleteItemAsync(ACCOUNT_API_KEY);
    await SecureStore.setItemAsync('abir-ai-account-provider-v1', _provider);
    const value = { email, apiKey: key };
    setAccount(value);
    setAccountLoggedIn(true);
    setAccountPassword('');
    setShowAccountSetup(false);
    await addSecurityLog('account-configured', email);
    Alert.alert(
      language === 'bn' ? 'Login সেট হয়েছে' : 'Login configured',
      language === 'bn' ? 'Email, password এবং API key এই ফোনে নিরাপদ storage-এ রাখা হয়েছে।' : 'Email, password and API key are stored in secure device storage.',
    );
  };

  const submitLoginScreen = async (email: string, password: string, apiKey: string, provider: LoginProvider) => {
    const savedEmail = await SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY);
    const savedPassword = await SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY);
    if (savedEmail && savedPassword) {
      if (email === savedEmail && password === savedPassword) {
        if (apiKey) await SecureStore.setItemAsync(ACCOUNT_API_KEY, apiKey);
        setAccountEmail(email);
        setAccountPassword('');
        setAccountApiKey(apiKey);
        setAccount({ email, apiKey });
        setAccountLoggedIn(true);
        await SecureStore.setItemAsync('abir-ai-account-provider-v1', provider);
        await addSecurityLog('account-login-success', email);
        return;
      }
      Alert.alert(language === 'bn' ? 'Login ব্যর্থ' : 'Login failed', language === 'bn' ? 'Email বা password ভুল।' : 'Email or password is incorrect.');
      await addSecurityLog('account-login-failed', email || 'unknown');
      return;
    }
    await saveAccount(provider, { email, password, apiKey });
  };

  const loginAccount = async () => {
    const email = accountEmail.trim();
    const password = accountPassword;
    const savedEmail = await SecureStore.getItemAsync(ACCOUNT_EMAIL_KEY);
    const savedPassword = await SecureStore.getItemAsync(ACCOUNT_PASSWORD_KEY);
    if (email && password && email === savedEmail && password === savedPassword) {
      setAccountLoggedIn(true);
      setAccount({ email, apiKey: accountApiKey.trim() });
      setAccountPassword('');
      setShowAccountSetup(false);
      await addSecurityLog('account-login-success', email);
      return;
    }
    Alert.alert(language === 'bn' ? 'Login ব্যর্থ' : 'Login failed', language === 'bn' ? 'Email বা password ভুল।' : 'Email or password is incorrect.');
    await addSecurityLog('account-login-failed', email || 'unknown');
  };

  useEffect(() => {
    if (isLoading || !accountReady || !appLockEnabled) return;
    const sub = AppState.addEventListener('change', state => {
      if (state === 'background' || state === 'inactive') {
        setAppUnlocked(false);
        void addSecurityLog('app-backgrounded');
      }
      if (state === 'active' && !appUnlocked) {
        void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); });
      }
    });
    if (!appUnlocked) void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); });
    return () => sub.remove();
  }, [isLoading, appLockEnabled, appUnlocked]);

  const sendText = async (rawText: string, forceSpeak = false) => {
    const text = rawText.trim();
    if (!text || isSending) return;

    Keyboard.dismiss();
    setDraft('');
    setIsSending(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

    const userMessage: Message = {
      id: createId(),
      role: 'user',
      text,
      time: Date.now(),
    };

    // Reply in the language of the current message: Bengali script -> Bengali,
    // otherwise English. This makes “hello” return English even when the UI is Bengali.
    const responseLanguage: AssistantLanguage = /[\u0980-\u09FF]/.test(text) ? 'bn' : 'en';

    // Voice-first convenience: repeat or stop can work immediately without
    // sending the phrase to Gemini or the offline fallback brain.
    if (/^(?:আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat that|say that again|say it again|again)$/i.test(text)) {
      const previous = lastAssistantText.current;
      if (previous) {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: previous, intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      } else {
        const repeatMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'এখনো আবার বলার মতো কোনো আগের উত্তর নেই।' : 'There is no previous answer to repeat yet.', intent: 'casual', time: Date.now() };
        setMessages(current => [...current, userMessage, repeatMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(repeatMessage);
      }
      setIsSending(false);
      return;
    }
    if (/^(?:থামো|চুপ|চুপ করো|stop talking|stop speaking|be quiet)$/i.test(text)) {
      await Speech.stop();
      const stopMessage: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'ঠিক আছে, কথা বলা থামালাম।' : 'Okay, I stopped speaking.', intent: 'casual', time: Date.now() };
      setMessages(current => [...current, userMessage, stopMessage].slice(-MAX_MESSAGES));
      setIsSending(false);
      return;
    }


    if (/কল রিসিভ করে কথা বলো|কল রিসিভ করে কথা বল|কল ধরো আর কথা বলো|answer calls and talk|answer the call and talk|call assistant/i.test(text)) {
      if (Platform.OS !== 'android') {
        const msg: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'এই Call Assistant এখন Android-এ চালু করা যাবে।' : 'Call Assistant is available on Android.', intent: 'fallback', time: Date.now() };
        setMessages(current => [...current, userMessage, msg].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(msg);
        setIsSending(false);
        return;
      }
      const result = await setCallAssistantEnabled(true);
      const role = await isDefaultDialer();
      const textReply = role
        ? (responseLanguage === 'bn'
          ? 'Call Assistant চালু করেছি। এখন incoming SIM call এ Abir কল রিসিভ করার জন্য প্রস্তুত। তবে Android-এর সীমাবদ্ধতার কারণে সব ফোনে কলের দুই পাশের audio Abir সরাসরি শুনতে বা বলতে পারবে না।'
          : 'Call Assistant is enabled. Abir is ready for incoming SIM calls, but Android may restrict direct two-way call audio on some phones.')
        : (responseLanguage === 'bn'
          ? 'Call Assistant চালু করার প্রস্তুতি হয়েছে। Android-এর Default Phone App হিসেবে Abir AI-কে অনুমতি দাও, তারপর incoming SIM call Abir answer করতে পারবে।'
          : 'Call Assistant is enabled. Please allow Abir AI to become the default phone app so it can answer incoming SIM calls.');
      const msg: Message = { id: createId(), role: 'assistant', text: textReply, intent: 'fallback', time: Date.now() };
      setMessages(current => [...current, userMessage, msg].slice(-MAX_MESSAGES));
      if (autoSpeak || forceSpeak) void speakMessage(msg);
      setIsSending(false);
      return;
    }

    if (/কল assistant বন্ধ|কল রিসিভ বন্ধ|stop call assistant|disable call assistant/i.test(text)) {
      await setCallAssistantEnabled(false).catch(() => 'failed');
      const msg: Message = { id: createId(), role: 'assistant', text: responseLanguage === 'bn' ? 'Call Assistant বন্ধ করেছি।' : 'Call Assistant is disabled.', intent: 'fallback', time: Date.now() };
      setMessages(current => [...current, userMessage, msg].slice(-MAX_MESSAGES));
      if (autoSpeak || forceSpeak) void speakMessage(msg);
      setIsSending(false);
      return;
    }

    if (/কল শেষ করো|কল কেটে দাও|end current call|hang up/i.test(text)) {
      const ended = await endCurrentCall();
      const msg: Message = { id: createId(), role: 'assistant', text: ended
        ? (responseLanguage === 'bn' ? 'কল শেষ করেছি।' : 'I ended the call.')
        : (responseLanguage === 'bn' ? 'এই কলটি Abir-এর মাধ্যমে শেষ করা যাচ্ছে না।' : 'I could not end this call through Abir.'), intent: 'fallback', time: Date.now() };
      setMessages(current => [...current, userMessage, msg].slice(-MAX_MESSAGES));
      if (autoSpeak || forceSpeak) void speakMessage(msg);
      setIsSending(false);
      return;
    }

    try {
      const memoryResult = handleMemoryCommand(text, memory);
      if (memoryResult) {
        setMemory(memoryResult.memory);
        await saveLocalMemory(memoryResult.memory);
        const assistantMessage: Message = {
          id: createId(), role: 'assistant', text: memoryResult.reply, intent: 'memory', time: Date.now(),
        };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      const voiceMessageRequest = extractVoiceMessageRequest(text);
      if (voiceMessageRequest && Platform.OS === 'android') {
        const enabled = await isAccessibilityEnabled();
        const label = voiceMessageRequest.app === 'whatsapp' ? 'WhatsApp' : voiceMessageRequest.app === 'messenger' ? 'Messenger' : 'IMO';
        if (!enabled) {
          const responseText = responseLanguage === 'bn'
            ? 'ভয়েস মেসেজ পাঠাতে Accessibility permission দরকার। Settings খুলে Abir AI-কে অনুমতি দাও।'
            : 'Accessibility permission is required to send a voice message.';
          const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
          setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }
        const seconds = Math.round(voiceMessageRequest.durationMs / 1000);
        const intro = responseLanguage === 'bn'
          ? `${label}-এ ${voiceMessageRequest.recipient}-এর chat খুলে প্রায় ${seconds} সেকেন্ডের voice message record করছি। এখন কথা বলো।`
          : `Opening ${label} for ${voiceMessageRequest.recipient}. Speak now; I will record for about ${seconds} seconds.`;
        const introMessage: Message = { id: createId(), role: 'assistant', text: intro, intent: 'fallback', time: Date.now() };
        setMessages(current => [...current, userMessage, introMessage].slice(-MAX_MESSAGES));
        if (autoSpeak || forceSpeak) await speakMessage(introMessage);
        const sent = await sendVoiceMessageViaAccessibility(
          messagingPackage(voiceMessageRequest.app),
          voiceMessageRequest.recipient,
          voiceMessageRequest.durationMs,
        );
        const responseText = sent
          ? (responseLanguage === 'bn' ? `${label}-এ ${voiceMessageRequest.recipient}-কে voice message পাঠিয়ে দিয়েছি।` : `I sent the voice message to ${voiceMessageRequest.recipient} on ${label}.`)
          : (responseLanguage === 'bn' ? `${label}-এ voice message পাঠানো গেল না। অ্যাপের UI/permission দেখে আবার চেষ্টা করো।` : `I could not send the voice message on ${label}. Check the app UI and permissions and try again.`);
        const finalMessage: Message = { ...introMessage, text: responseText };
        setMessages(current => current.map(m => m.id === introMessage.id ? finalMessage : m));
        if (autoSpeak || forceSpeak) void speakMessage(finalMessage);
        return;
      }

      const messageRequest = extractMessageRequest(text);
      if (messageRequest && Platform.OS === 'android') {
        const enabled = await isAccessibilityEnabled();
        if (!enabled) {
          const responseText = messageAutomationReply(messageRequest, responseLanguage, 'not-enabled');
          const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
          setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
          await addSecurityLog('message-automation-blocked', `${messageRequest.app}:${messageRequest.recipient}`);
          Alert.alert(
            responseLanguage === 'bn' ? 'Accessibility দরকার' : 'Accessibility required',
            responseLanguage === 'bn' ? 'Messenger/IMO চালাতে Abir AI-কে Accessibility permission দিতে হবে। Settings খুলব?' : 'Abir AI needs Accessibility permission to operate WhatsApp, Messenger or IMO. Open Settings?',
            [
              { text: responseLanguage === 'bn' ? 'না' : 'Cancel', style: 'cancel' },
              { text: 'Settings', onPress: () => void openAccessibilitySettings() },
            ],
          );
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }
        const sent = await sendMessageViaAccessibility(
          messagingPackage(messageRequest.app),
          messageRequest.recipient,
          messageRequest.message,
        );
        const responseText = messageAutomationReply(messageRequest, responseLanguage, sent ? 'sent' : 'failed');
        const assistantMessage: Message = { id: createId(), role: 'assistant', text: responseText, intent: 'fallback', time: Date.now() };
        setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await addSecurityLog(sent ? 'message-sent' : 'message-failed', `${messageRequest.app}:${messageRequest.recipient}`);
        if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
        return;
      }

      if (pendingAppChoices && !extractAppQuery(text)) {
        if (isCancelAppChoice(text)) {
          setPendingAppChoices(null);
          const cancelledMessage: Message = {
            id: createId(),
            role: 'assistant',
            text:
              responseLanguage === 'bn'
                ? 'ঠিক আছে, অ্যাপ খোলা বাতিল করলাম।'
                : 'Okay, I cancelled opening an app.',
            time: Date.now(),
          };
          setMessages((current) =>
            [...current, userMessage, cancelledMessage].slice(-MAX_MESSAGES),
          );
          if (autoSpeak || forceSpeak) void speakMessage(cancelledMessage);
          return;
        }

        const selectedApp = selectAppChoice(text, pendingAppChoices);
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: selectedApp
            ? responseLanguage === 'bn'
              ? `${selectedApp.label} খুলছি…`
              : `Opening ${selectedApp.label}…`
            : appChoicePrompt(pendingAppChoices, responseLanguage),
          intent: 'open-app',
          time: Date.now(),
        };
        setMessages((current) =>
          [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES),
        );

        if (!selectedApp) {
          if (autoSpeak || forceSpeak) void speakMessage(assistantMessage);
          return;
        }

        setPendingAppChoices(null);
        const launchStatus = await launchInstalledApp(selectedApp);
        const responseText = appActionReply(
          launchStatus,
          selectedApp,
          responseLanguage,
        );
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? { ...message, text: responseText }
              : message,
          ),
        );
        if (autoSpeak || forceSpeak) {
          void speakMessage({ ...assistantMessage, text: responseText });
        }
        return;
      }

      if (pendingAppChoices) setPendingAppChoices(null);
      // Run the local command/brain first. This is important: device controls,
      // app opening, calls, memory and other deterministic actions must work
      // even with the internet completely disabled. Only unresolved questions
      // are sent to Gemini when online.
      const offlineReply = await getAssistantReply({
        text,
        language: responseLanguage,
        now: new Date(),
        memory,
        conversationContext: messages.slice(-8).map(item => ({ role: item.role, text: item.text })),
      });
      // Online mode is an enhancement for unresolved/natural conversation,
      // not a replacement for deterministic local phone actions. Greetings,
      // casual chat, coding and genuine fallbacks can become much more natural
      // with Gemini when a key/network is available. Time, weather, device
      // controls, calls, apps and other local actions stay local.
      const onlineConversationEligible = optionalOnlineAssistant.enabled &&
        ['fallback', 'casual', 'greeting', 'coding'].includes(offlineReply.intent);
      const onlineText = onlineConversationEligible
        ? await optionalOnlineAssistant.respond({
            text,
            language: responseLanguage === 'bn' ? 'bn' : 'en',
            conversationContext: messages.slice(-12).map(item => ({ role: item.role, text: item.text })),
          })
        : null;
      const reply = onlineText
        ? { text: onlineText, intent: 'fallback' as AssistantIntent }
        : offlineReply;
      const assistantMessage: Message = {
        id: createId(),
        role: 'assistant',
        text: reply.text,
        intent: reply.intent,
        time: Date.now(),
      };

      setMessages((current) => {
        const next =
          reply.intent === 'clear-history'
            ? [userMessage, assistantMessage]
            : [...current, userMessage, assistantMessage];
        return next.slice(-MAX_MESSAGES);
      });

      let finalAssistantMessage = assistantMessage;
      lastAssistantText.current = assistantMessage.text;
      if (reply.intent === 'clear-history') setPendingAppChoices(null);

      if (reply.intent === 'location') {
        let responseText: string;
        try {
          if (Platform.OS !== 'android') throw new Error('unsupported');
          const permission = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          );
          if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
            responseText = responseLanguage === 'bn'
              ? 'বস, তোমার বর্তমান অবস্থান জানতে Location/GPS permission দিতে হবে।'
              : 'Boss, I need Location/GPS permission to tell you where you are.';
          } else {
            const location = await getCurrentLocation();
            if (!location) {
              responseText = responseLanguage === 'bn'
                ? 'বস, GPS অবস্থান পাওয়া গেল না। ফোনের Location/GPS চালু করে বাইরে বা খোলা জায়গায় আবার চেষ্টা করো।'
                : 'Boss, I could not get your GPS location. Turn on Location/GPS and try again in an open area.';
            } else {
              const address = location.address?.trim();
              const coords = typeof location.latitude === 'number' && typeof location.longitude === 'number'
                ? `\nLatitude: ${location.latitude.toFixed(6)}, Longitude: ${location.longitude.toFixed(6)}`
                : '';
              responseText = responseLanguage === 'bn'
                ? `বস, তুমি এখন ${address || 'এই অবস্থানে'} আছো।${coords}`
                : `Boss, you are currently at ${address || 'this location'}.${coords}`;
            }
          }
        } catch {
          responseText = responseLanguage === 'bn'
            ? 'বস, তোমার অবস্থান বের করতে পারিনি। Location/GPS permission ও GPS চালু আছে কি না দেখো।'
            : 'Boss, I could not determine your location. Check Location/GPS permission and try again.';
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        lastAssistantText.current = responseText;
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
        return;
      }

      if (reply.intent === 'memory' && reply.noteText && reply.noteQuery) {
        await learnLocalAlias(reply.noteText, reply.noteQuery);
        const responseText = responseLanguage === 'bn' ? `বস, “${reply.noteText}” কমান্ডটা এখন থেকে “${reply.noteQuery}” হিসেবে বুঝব।` : `Boss, I’ll interpret “${reply.noteText}” as “${reply.noteQuery}” from now on.`;
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'notes') {
        let responseText = reply.text;
        if (reply.noteText) {
          await addLocalNote(reply.noteText);
        } else if (reply.noteQuery !== undefined) {
          const notes = await searchLocalNotes(reply.noteQuery);
          responseText = notes.length
            ? (responseLanguage === 'bn' ? `বস, পাওয়া নোট:
${notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}` : `Boss, matching notes:\n${notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}`)
            : (responseLanguage === 'bn' ? 'কোনো মিল থাকা লোকাল নোট পেলাম না।' : 'I found no matching local notes.');
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'routine') {
        let responseText = reply.text;
        if (reply.routineName && reply.routineCommand) {
          await saveLocalRoutine(reply.routineName, reply.routineCommand);
          responseText = responseLanguage === 'bn' ? `বস, “${reply.routineName}” রুটিন সেভ করেছি।` : `Boss, I saved the “${reply.routineName}” routine.`;
        } else if (reply.routineName) {
          const routine = await findLocalRoutine(reply.routineName);
          if (routine) {
            responseText = responseLanguage === 'bn' ? `বস, “${routine.name}” রুটিন চালাচ্ছি।` : `Boss, running the “${routine.name}” routine.`;
            finalAssistantMessage = { ...assistantMessage, text: responseText };
            setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
            await sendText(routine.command, forceSpeak);
            return;
          }
          responseText = responseLanguage === 'bn' ? 'এই নামে কোনো লোকাল রুটিন নেই।' : 'I could not find a local routine with that name.';
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'task-plan' && reply.plannedTasks?.length) {
        // Execute deterministic sub-commands sequentially. The original memory limit is untouched.
        for (const task of reply.plannedTasks) {
          await sendText(task, forceSpeak);
        }
        return;
      }

      if (reply.intent === 'diagnostics') {
        const d = await getDeviceDiagnostics();
        let responseText: string;
        if (!d) {
          responseText = responseLanguage === 'bn' ? 'বস, ফোনের ডিভাইস তথ্য পাওয়া গেল না।' : 'Boss, I could not read the device status.';
        } else {
          const freeGB = typeof d.freeStorageBytes === 'number' ? (d.freeStorageBytes / 1073741824).toFixed(1) : '?';
          const totalGB = typeof d.totalStorageBytes === 'number' ? (d.totalStorageBytes / 1073741824).toFixed(1) : '?';
          const battery = typeof d.batteryPercent === 'number' && d.batteryPercent >= 0 ? `${d.batteryPercent}%` : '?';
          const network = d.wifi ? 'Wi-Fi' : d.cellular ? 'Mobile data' : d.online ? 'Online' : 'Offline';
          responseText = responseLanguage === 'bn'
            ? `বস, ফোনের অবস্থা:\n🔋 ব্যাটারি: ${battery}\n💾 ফাঁকা স্টোরেজ: ${freeGB} GB / ${totalGB} GB\n🌐 নেটওয়ার্ক: ${network}\n📱 Android SDK: ${d.sdk ?? '?'}`
            : `Boss, device status:\n🔋 Battery: ${battery}\n💾 Free storage: ${freeGB} GB / ${totalGB} GB\n🌐 Network: ${network}\n📱 Android SDK: ${d.sdk ?? '?'}`;
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'reminder' && reply.reminderText && reply.reminderDelayMs) {
        let ok = false;
        if (Platform.OS === 'android' && Number(Platform.Version) >= 33) {
          try {
            const permission = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
            ok = permission === PermissionsAndroid.RESULTS.GRANTED;
          } catch { ok = false; }
        } else { ok = true; }
        if (ok) ok = await scheduleAbirReminder(reply.reminderText, reply.reminderDelayMs);
        const responseText = ok
          ? reply.text
          : (responseLanguage === 'bn' ? 'বস, Reminder notification permission দেওয়া হয়নি, তাই reminder সেট করতে পারিনি।' : 'Boss, notification permission was not granted, so I could not set the reminder.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'device-action' && reply.deviceAction) {
        let ok = false;
        // Screen locking is a sensitive device action. Never execute it solely
        // because a voice/text command was heard: require Android's own
        // biometric/device-credential verification first. This also protects
        // wake-word/background command paths from an unauthorised speaker.
        if (reply.deviceAction === 'wake-screen' || reply.deviceAction === 'lock-screen') {
          const verified = await authenticateSensitiveDeviceAction(reply.deviceAction);
          if (verified) {
            ok = reply.deviceAction === 'wake-screen'
              ? await wakeDeviceScreen()
              : await performDeviceAction(reply.deviceAction);
            // Require a fresh voice + device verification for every sensitive command.
          }
        } else if (reply.deviceAction === 'power-menu') {
          const verified = await authenticateSensitiveDeviceAction(reply.deviceAction);
          if (verified) {
            ok = await performDeviceAction(reply.deviceAction);
          }
        }
        else if (reply.deviceAction === 'volume-up') ok = await adjustDeviceVolume('up');
        else if (reply.deviceAction === 'volume-down') ok = await adjustDeviceVolume('down');
        else if (reply.deviceAction === 'volume-mute') ok = await adjustDeviceVolume('mute');
        else if (reply.deviceAction === 'volume-set' && typeof reply.deviceValue === 'number') ok = await setDeviceVolumePercent(reply.deviceValue);
        else if (reply.deviceAction === 'flashlight-on') ok = await setFlashlight(true);
        else if (reply.deviceAction === 'flashlight-off') ok = await setFlashlight(false);
        else if (reply.deviceAction === 'media-play') ok = await controlMedia('play');
        else if (reply.deviceAction === 'media-pause') ok = await controlMedia('pause');
        else if (reply.deviceAction === 'media-next') ok = await controlMedia('next');
        else if (reply.deviceAction === 'media-previous') ok = await controlMedia('previous');
        else if (reply.deviceAction === 'vibrate') ok = await setRingerMode('vibrate');
        else if (reply.deviceAction === 'ringer-normal') ok = await setRingerMode('normal');
        else if (reply.deviceAction === 'wifi-settings' || reply.deviceAction === 'bluetooth-settings' || reply.deviceAction === 'mobile-data-panel') {
          ok = await openSystemSettings(reply.deviceAction);
        } else if (reply.deviceAction === 'settings') {
          ok = await openSystemSettings('settings');
        } else {
          ok = await performDeviceAction(reply.deviceAction);
        }
        let responseText = ok
          ? reply.text
          : ((reply.deviceAction === 'lock-screen' || reply.deviceAction === 'wake-screen' || reply.deviceAction === 'power-menu')
            ? (responseLanguage === 'bn'
              ? 'বস, Owner voice authorization বা Fingerprint/Face/PIN/Password যাচাই সম্পূর্ণ হয়নি, তাই কাজটি করিনি।'
              : 'Boss, I did not perform the power action because owner voice authorization or device verification was not completed.')
            : (responseLanguage === 'bn' ? 'বস, এই ফোনে কাজটি করা গেল না। প্রয়োজনীয় Android permission/Accessibility চালু আছে কি না দেখে আবার চেষ্টা করো।' : 'I could not perform that action on this phone. Check the required Android permission/Accessibility access and try again.'));
        if (ok && (reply.deviceAction === 'volume-up' || reply.deviceAction === 'volume-down' || reply.deviceAction === 'volume-set')) {
          const actual = await getDeviceVolumePercent();
          if (actual !== null && actual >= 0) {
            const shown = Math.round(actual);
            responseText = responseLanguage === 'bn' ? `মিডিয়া ভলিউম এখন প্রায় ${shown}%।` : `Media volume is now about ${shown}%.`;
          }
        }
        if (ok && ['volume-up','volume-down','volume-set','flashlight-on','flashlight-off','media-play','media-pause','media-next','media-previous','vibrate','ringer-normal'].includes(reply.deviceAction)) {
          void recordLocalAction({ action: reply.deviceAction, value: reply.deviceValue, time: Date.now() });
        }
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'undo') {
        const last = await getLastLocalAction();
        let ok = false;
        let responseText = responseLanguage === 'bn' ? 'বস, আগের কাজটা নিরাপদভাবে ফিরিয়ে দিতে পারিনি।' : 'Boss, I could not safely undo the last action.';
        if (last?.action === 'volume-up') ok = await adjustDeviceVolume('down');
        else if (last?.action === 'volume-down') ok = await adjustDeviceVolume('up');
        else if (last?.action === 'flashlight-on') ok = await setFlashlight(false);
        else if (last?.action === 'flashlight-off') ok = await setFlashlight(true);
        else if (last?.action === 'media-play') ok = await controlMedia('pause');
        else if (last?.action === 'media-pause') ok = await controlMedia('play');
        if (ok) responseText = responseLanguage === 'bn' ? 'বস, আগের reversible কাজটা ফিরিয়ে দিয়েছি।' : 'Boss, I undid the last reversible action.';
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
        if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
      }

      if (reply.intent === 'screen-control' && reply.screenAction) {
        const enabled = await isAccessibilityEnabled();
        let ok = false;
        if (enabled) {
          if (reply.screenAction === 'click' && reply.screenTarget) {
            ok = await (await import('@/assistant/androidActions')).clickTextOnScreen(reply.screenTarget);
            if (!ok) ok = await smartScreenAction(reply.screenTarget);
          }
          else if (reply.screenAction === 'type' && reply.screenTarget) ok = await (await import('@/assistant/androidActions')).typeIntoFocusedField(reply.screenTarget);
          else if (reply.screenAction === 'scroll' && reply.screenTarget) ok = await (await import('@/assistant/androidActions')).scrollScreen(reply.screenTarget as 'up' | 'down' | 'left' | 'right');
        }
        const responseText = ok
          ? (responseLanguage === 'bn' ? 'বস, কাজটা করে দিয়েছি।' : 'Done, Boss.')
          : (responseLanguage === 'bn' ? 'বস, স্ক্রিনে কাজটা করতে পারিনি। Accessibility permission চালু আছে কি না দেখে আবার চেষ্টা করো।' : 'I could not control the current screen. Check Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'screen-read') {
        const screenText = await readCurrentScreenText();
        const responseText = screenText
          ? (responseLanguage === 'bn' ? `বর্তমান স্ক্রিনে যা দেখা যাচ্ছে:\n${screenText}` : `Here is the readable text on the current screen:\n${screenText}`)
          : (responseLanguage === 'bn' ? 'বস, বর্তমান স্ক্রিনের লেখা পড়তে পারিনি। Accessibility permission চালু আছে কি না দেখো।' : 'I could not read the current screen. Check Accessibility access and try again.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'universal-screen-control' && reply.appQuery && reply.automationQuery) {
        const enabled = await isAccessibilityEnabled();
        let responseText = reply.text;

        if (!enabled) {
          responseText = responseLanguage === 'bn'
            ? 'এই কাজের জন্য Accessibility permission চালু করতে হবে। Settings → Accessibility থেকে Abir AI চালু করে আবার বলো।'
            : 'Accessibility permission is required. Enable Abir AI in Settings → Accessibility and try again.';
        } else {
          const discovery = await getLaunchableApps();
          if (discovery.status !== 'available') {
            responseText = appDiscoveryReply(discovery.status, responseLanguage);
          } else {
            const matches = matchInstalledApps(reply.appQuery, discovery.apps);
            if (matches.length === 0) {
              responseText = noMatchingAppReply(reply.appQuery);
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingAppChoices(choices);
              responseText = responseLanguage === 'bn'
                ? `একাধিক "${reply.appQuery}" অ্যাপ পাওয়া গেছে। আগে একটি বেছে নাও:\n${appChoicePrompt(choices, responseLanguage)}`
                : `I found multiple matches for "${reply.appQuery}". Choose one first.\n${appChoicePrompt(choices, responseLanguage)}`;
            } else {
              const ok = await searchAndOpenInApp(matches[0].packageName, reply.automationQuery);
              responseText = ok
                ? (responseLanguage === 'bn'
                    ? `${matches[0].label}-এ "${reply.automationQuery}" খুঁজে প্রথম উপযুক্ত ফল খোলার চেষ্টা করেছি।`
                    : `I searched ${matches[0].label} for "${reply.automationQuery}" and tried to open the first suitable result.`)
                : (responseLanguage === 'bn'
                    ? `${matches[0].label} খুলতে/টাইপ করতে পারিনি। Accessibility permission ও অ্যাপের UI দেখে আবার চেষ্টা করো।`
                    : `I could not complete the search in ${matches[0].label}. Check Accessibility access and try again.`);
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id ? finalAssistantMessage : message,
          ),
        );
      }

      if (reply.intent === 'open-app' && reply.appQuery) {
        const discovery = await getLaunchableApps();
        let responseText: string;

        if (discovery.status !== 'available') {
          responseText = appDiscoveryReply(discovery.status, responseLanguage);
        } else {
          const matches = matchInstalledApps(reply.appQuery, discovery.apps);
          if (matches.length === 0) {
            responseText = noMatchingAppReply(reply.appQuery);
          } else if (matches.length > 1) {
            const choices = matches.slice(0, 8);
            setPendingAppChoices(choices);
            responseText = appChoicePrompt(choices, responseLanguage);
          } else {
            const launchStatus = await launchInstalledApp(matches[0]);
            responseText = appActionReply(
              launchStatus,
              matches[0],
              responseLanguage,
            );
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      if (reply.intent === 'call-via-app' && reply.contactQuery && reply.appCallTarget) {
        const enabled = await isAccessibilityEnabled();
        const responseText = enabled
          ? (await callViaApp(reply.appCallTarget, reply.contactQuery))
            ? (responseLanguage === 'bn' ? `${reply.appCallTarget === 'whatsapp' ? 'WhatsApp' : reply.appCallTarget === 'messenger' ? 'Messenger' : 'IMO'}-এ ${reply.contactQuery}-কে কল শুরু করেছি।` : `I started a call to ${reply.contactQuery} on ${reply.appCallTarget}.`)
            : (responseLanguage === 'bn' ? `${reply.appCallTarget}-এ ${reply.contactQuery}-কে কল শুরু করা গেল না।` : `I could not start the ${reply.appCallTarget} call.`)
          : (responseLanguage === 'bn' ? 'এই কাজের জন্য Accessibility permission চালু করতে হবে।' : 'Accessibility permission is required for this app call.');
        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
      }

      if (reply.intent === 'call-contact' && reply.contactQuery) {
        let responseText = reply.text;
        const directPhoneNumber = extractDirectPhoneNumber(reply.contactQuery);

        if (directPhoneNumber) {
          if (Platform.OS === 'android') {
            const permission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.CALL_PHONE,
            );
            if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText =
                responseLanguage === 'bn'
                  ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                  : 'Phone-call permission was not granted. Allow it and try again.';
            } else {
              const callStatus = await placeDirectCall(directPhoneNumber);
              responseText =
                callStatus === 'placed'
                  ? responseLanguage === 'bn'
                    ? `${directPhoneNumber}-এ কল দিচ্ছি।`
                    : `Calling ${directPhoneNumber}.`
                  : responseLanguage === 'bn'
                    ? 'এই নম্বরে কল দেওয়া গেল না।'
                    : 'I could not place the call to this number.';
            }
          } else {
            responseText =
              responseLanguage === 'bn'
                ? 'এই ডিভাইস থেকে সরাসরি ফোন কল সমর্থিত নয়।'
                : 'Direct phone calls are not supported on this device.';
          }
        } else {
          if (Platform.OS === 'android') {
            const contactsPermission = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
            );
            if (contactsPermission !== PermissionsAndroid.RESULTS.GRANTED) {
              responseText = responseLanguage === 'bn'
                ? 'Contacts পড়ার অনুমতি দেওয়া হয়নি। Contacts permission চালু করে আবার বলো।'
                : 'Contacts permission was not granted. Allow it and try again.';
              finalAssistantMessage = { ...assistantMessage, text: responseText };
              lastAssistantText.current = responseText;
              setMessages(current => current.map(message => message.id === assistantMessage.id ? finalAssistantMessage : message));
              if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
              return;
            }
          }

          const contactsResult = await getDeviceContacts();

          if (contactsResult.status !== 'available') {
            responseText =
              responseLanguage === 'bn'
                ? 'পরিচিতির নম্বর পড়া গেল না। Contacts অনুমতি চালু আছে কি না দেখে আবার চেষ্টা করো।'
                : 'I could not read your contacts. Check Contacts permission and try again.';
          } else {
            const matches = matchContacts(reply.contactQuery, contactsResult.contacts);
            if (matches.length === 0) {
              responseText =
                responseLanguage === 'bn'
                  ? `${reply.contactQuery} নামে কোনো পরিচিতি খুঁজে পেলাম না।`
                  : `I couldn’t find a contact named ${reply.contactQuery}.`;
            } else if (matches.length > 1) {
              const choices = matches.slice(0, 8);
              setPendingContactChoices(choices);
              responseText = formatContactChoicePrompt(choices, responseLanguage);
            } else {
              const contact = matches[0];
              if (Platform.OS === 'android') {
                const permission = await PermissionsAndroid.request(
                  PermissionsAndroid.PERMISSIONS.CALL_PHONE,
                );
                if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
                  responseText =
                    responseLanguage === 'bn'
                      ? 'ফোন করার অনুমতি দেওয়া হয়নি। অনুমতি দিলে আবার বলো।'
                      : 'Phone-call permission was not granted. Allow it and try again.';
                } else {
                  const callStatus = await placeDirectCall(contact.phoneNumber);
                  responseText =
                    callStatus === 'placed'
                      ? responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দিচ্ছি।`
                        : `Calling ${contact.displayName}.`
                      : responseLanguage === 'bn'
                        ? `${contact.displayName}-কে কল দেওয়া গেল না।`
                        : `I couldn’t call ${contact.displayName}.`;
                }
              }
            }
          }
        }

        finalAssistantMessage = { ...assistantMessage, text: responseText };
        lastAssistantText.current = responseText;
        setMessages((current) =>
          current.map((message) =>
            message.id === assistantMessage.id
              ? finalAssistantMessage
              : message,
          ),
        );
      }

      const updatedMemory = addRecentTopic(memory, text);
      if (updatedMemory !== memory) {
        setMemory(updatedMemory);
        await saveLocalMemory(updatedMemory);
      }
      if (autoSpeak || forceSpeak) void speakMessage(finalAssistantMessage);
    } finally {
      setIsSending(false);
    }
  };

  const openLiveCamera = async () => {
    try {
      let permission = cameraPermission;
      if (!permission?.granted) permission = await requestCameraPermission();
      if (!permission?.granted) {
        Alert.alert(
          language === 'bn' ? 'ক্যামেরা অনুমতি দরকার' : 'Camera permission needed',
          language === 'bn' ? 'Live Vision ব্যবহার করতে ক্যামেরার অনুমতি দাও।' : 'Allow camera access to use Live Vision.',
        );
        return;
      }
      setLiveCameraQuestion('');
      setLiveCameraVisible(true);
    } catch {
      Alert.alert(language === 'bn' ? 'ক্যামেরা চালু হয়নি' : 'Camera unavailable');
    }
  };

  const analyzeLiveCamera = async (question?: string) => {
    if (liveCameraBusy) return;
    const camera = liveCameraRef.current;
    if (!camera) return;
    setLiveCameraBusy(true);
    try {
      const photo = await camera.takePictureAsync({ quality: 0.55, base64: true, skipProcessing: true });
      if (!photo?.base64) throw new Error('No image data');
      const prompt = question?.trim() || (language === 'bn'
        ? 'লাইভ ক্যামেরার এই দৃশ্যটি দেখে কী কী স্পষ্টভাবে দেখা যাচ্ছে বলো। নিশ্চিত নও এমন কিছু অনুমান করবে না।'
        : 'Describe what is clearly visible in this live camera frame. Do not guess uncertain details.');
      const response = optionalOnlineAssistant.enabled
        ? await optionalOnlineAssistant.respond({
            text: prompt,
            language: language === 'bn' ? 'bn' : 'en',
            imageBase64: photo.base64,
            imageMimeType: 'image/jpeg',
          })
        : null;
      const answer = response || (language === 'bn'
        ? 'ক্যামেরার ছবি নেওয়া হয়েছে, কিন্তু দৃশ্য বিশ্লেষণের জন্য অনলাইন Vision সংযোগ চালু নেই। ক্যামেরা লাইভ দেখা যাচ্ছে; বিশ্লেষণে অনলাইন Vision/API প্রয়োজন।'
        : 'The camera frame was captured, but online Vision is not connected for image analysis. Live preview works; analysis requires an online Vision/API connection.');
      const userMessage: Message = { id: createId(), role: 'user', text: `📷 ${prompt}`, time: Date.now() };
      const assistantMessage: Message = { id: createId(), role: 'assistant', text: answer, intent: 'fallback', time: Date.now() };
      setMessages(current => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
      setLiveCameraQuestion('');
      await speakMessage(assistantMessage);
    } catch {
      Alert.alert(
        language === 'bn' ? 'বিশ্লেষণ করা যায়নি' : 'Could not analyze frame',
        language === 'bn' ? 'ক্যামেরা প্রস্তুত হলে আবার চেষ্টা করো।' : 'Please try again when the camera is ready.',
      );
    } finally {
      setLiveCameraBusy(false);
    }
  };

  const askLiveCameraByVoice = async () => {
    if (isListening || liveCameraBusy) return;
    setIsListening(true);
    try {
      if (Platform.OS === 'android') await stopWakeWord();
      const spoken = await listenWithUnifiedVoiceManager(language);
      if (spoken?.trim()) await analyzeLiveCamera(spoken.trim());
    } catch {
      Alert.alert(language === 'bn' ? 'কথা বোঝা যায়নি' : 'Voice not recognized');
    } finally {
      setIsListening(false);
      if (wakeWordEnabled) void startWakeWord().catch(() => false);
    }
  };

  const captureCameraPhoto = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          language === 'bn' ? 'ক্যামেরা অনুমতি দরকার' : 'Camera permission needed',
          language === 'bn' ? 'ক্যামেরা চালু করার অনুমতি দাও।' : 'Allow camera access to take a photo.',
        );
        return;
      }
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: false,
        base64: true,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const asset = result.assets[0];
      const uri = asset.uri;
      setCameraPreviewUri(uri);

      // The camera is for showing Abir something, not for building a personal
      // photo collection. Keep only the current preview URI locally.
      setSavedCameraUris([uri]);

      if (!asset.base64) {
        const fallback = language === 'bn'
          ? 'ছবিটি পাওয়া গেছে, কিন্তু বিশ্লেষণের জন্য ছবির ডেটা পাওয়া যায়নি। আবার চেষ্টা করো।'
          : 'I got the photo, but could not read its image data for analysis. Please try again.';
        await sendText(fallback, true);
        return;
      }

      setIsSending(true);
      try {
        const onlineText = optionalOnlineAssistant.enabled
          ? await optionalOnlineAssistant.respond({
              text: language === 'bn'
                ? 'এই ছবিটা দেখে বলো এখানে কী আছে। যা নিশ্চিতভাবে দেখা যাচ্ছে শুধু সেটাই বলো। মানুষ থাকলে পরিচয় অনুমান করবে না; শুধু দৃশ্যমান বৈশিষ্ট্য ও পরিস্থিতি বর্ণনা করো।'
                : 'Look at this image and tell me what is in it. Only state what is visibly supported. If a person is present, do not guess their identity; describe only visible features and context.',
              language: language === 'bn' ? 'bn' : 'en',
              imageBase64: asset.base64,
              imageMimeType: asset.mimeType || 'image/jpeg',
            })
          : null;

        const responseText = onlineText || (language === 'bn'
          ? 'ছবিটা দেখেছি, কিন্তু এখন অনলাইন Gemini চালু নেই—তাই ছবিটা কী তা বিশ্লেষণ করতে পারছি না।'
          : 'I received the image, but Gemini is not available online right now, so I cannot analyze what is in it.');

        const userMessage: Message = {
          id: createId(),
          role: 'user',
          text: language === 'bn' ? '📷 এটা কী?' : '📷 What is this?',
          time: Date.now(),
        };
        const assistantMessage: Message = {
          id: createId(),
          role: 'assistant',
          text: responseText,
          intent: 'fallback',
          time: Date.now(),
        };
        setMessages((current) => [...current, userMessage, assistantMessage].slice(-MAX_MESSAGES));
        await speakMessage(assistantMessage);
      } finally {
        setIsSending(false);
      }
    } catch {
      Alert.alert(
        language === 'bn' ? 'ক্যামেরা খোলা যায়নি' : 'Camera unavailable',
        language === 'bn' ? 'আবার চেষ্টা করো।' : 'Please try again.',
      );
    }
  };

  const verifyOwner = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      if (!hasHardware || !enrolled) {
        Alert.alert(
          language === 'bn' ? 'Owner verification সেট করা নেই' : 'Owner verification unavailable',
          language === 'bn'
            ? 'ফোনের Settings থেকে fingerprint/face unlock সেট করলে Abir সেটা দিয়ে তোমাকে যাচাই করতে পারবে।'
            : 'Set up fingerprint or face unlock in phone Settings so Abir can verify the device owner.',
        );
        return false;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: language === 'bn' ? 'এটা কি তুমি?' : 'Is this you?',
        promptSubtitle: 'Abir AI owner verification',
        biometricsSecurityLevel: 'weak',
        disableDeviceFallback: false,
        requireConfirmation: false,
      });
      const verified = result.success;
      setOwnerVerified(verified);
      Alert.alert(
        verified
          ? language === 'bn' ? 'তুমি যাচাই হয়েছ' : 'Owner verified'
          : language === 'bn' ? 'যাচাই হয়নি' : 'Not verified',
        verified
          ? language === 'bn' ? 'এই সেশনে Abir তোমাকে ফোনের মালিক হিসেবে ধরবে।' : 'Abir will treat you as the verified device owner for this session.'
          : language === 'bn' ? 'ভেরিফিকেশন সফল হয়নি।' : 'The verification did not succeed.',
      );
      return verified;
    } catch {
      setOwnerVerified(false);
      return false;
    }
  };

  const startVoiceInput = async () => {
    if (isListening || isSending) return;
    voiceLoopRef.current = true;
    setContinuousVoice(true);
    const runId = ++voiceRunIdRef.current;

    // UnifiedVoiceManager owns the microphone. It stops the background
    // wake-word recognizer before every foreground recognition session.
    if (Platform.OS === 'android') {
      await stopWakeWord();
    }

    setIsListening(true);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    try {
      // Voice commands are a conversational mode: always read the action/reply
      // aloud so the user can operate Abir AI without touching the keyboard.
      if (!autoSpeak) setAutoSpeak(true);

      // Continuous conversational listening. One recognition session is
      // allowed to finish before the next one starts, so Android never has
      // two SpeechRecognizer instances fighting for the microphone.
      while (voiceLoopRef.current && runId === voiceRunIdRef.current) {
        setIsListening(true);

        const recognizedText = await listenWithUnifiedVoiceManager(language);

        if (!voiceLoopRef.current || runId !== voiceRunIdRef.current) break;

        if (recognizedText?.trim()) {
          const historyItem: VoiceHistoryItem = {
            id: createId(),
            text: recognizedText.trim(),
            time: Date.now(),
          };
          setVoiceHistory(current => {
            const next = [historyItem, ...current].slice(0, MAX_VOICE_HISTORY);
            void AsyncStorage.setItem(VOICE_HISTORY_KEY, JSON.stringify(next)).catch(() => {});
            return next;
          });

          // sendText waits for the normal response/TTS path. The next
          // recognition session therefore starts after Abir finishes talking.
          await sendText(recognizedText.trim(), true);
        }

        if (!voiceLoopRef.current || runId !== voiceRunIdRef.current) break;

        // Small breathing room prevents Android's recognizer from being
        // restarted at the exact same instant that the previous instance
        // is being destroyed.
        await new Promise(resolve => setTimeout(resolve, 350));
      }
    } catch (error) {
      if (voiceLoopRef.current && runId === voiceRunIdRef.current) {
        Alert.alert(
          language === 'bn' ? 'ভয়েস ইনপুট কাজ করেনি' : 'Voice input unavailable',
          error instanceof Error
            ? error.message
            : language === 'bn'
              ? 'মাইক্রোফোন বা স্পিচ সার্ভিসটি পরীক্ষা করে আবার চেষ্টা করো।'
              : 'Check microphone or speech-service availability and try again.',
        );
      }
    } finally {
      if (runId === voiceRunIdRef.current) {
        voiceLoopRef.current = false;
        setContinuousVoice(false);
        setIsListening(false);
      }
    }
  };

  const stopContinuousVoice = async () => {
    voiceLoopRef.current = false;
    voiceRunIdRef.current += 1;
    setContinuousVoice(false);
    setIsListening(false);

    // Stop any active TTS/recognizer and return microphone ownership to the
    // background wake-word service only when the app actually goes away.
    try {
      await stopNativeSpeaking();
      await Speech.stop();
    } catch {}
  };

  const confirmClear = () => {
    Alert.alert(
      language === 'bn' ? 'চ্যাট পরিষ্কার করবে?' : 'Clear this chat?',
      language === 'bn'
        ? 'সংরক্ষিত কথোপকথন মুছে যাবে।'
        : 'Your saved conversation will be deleted.',
      [
        { text: language === 'bn' ? 'থাক' : 'Cancel', style: 'cancel' },
        {
          text: language === 'bn' ? 'মুছে দাও' : 'Clear',
          style: 'destructive',
          onPress: () => {
            setMessages([welcomeMessage(language)]);
            void Speech.stop();
          },
        },
      ],
    );
  };

  const suggestions =
    language === 'bn'
      ? [
          'একটা কৌতুক বলো',
          'এখন সময় কত?',
          '২ + ২',
          'তুমি কী করতে পারো?',
          'WhatsApp ওপেন করো',
          'YouTube ওপেন করো',
        ]
      : [
          'Tell me a joke',
          'What time is it?',
          '2 + 2',
          'What can you do?',
          'Open WhatsApp',
          'Open YouTube',
        ];

  const inputBackground = { backgroundColor: colors.card };
  const bottomInset =
    Platform.OS === 'web' ? 34 : Math.max(insets.bottom, 10);
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  if (isLoading || !accountReady) {
    return (
      <View style={[styles.lockScreen, { backgroundColor: '#050505' }]}>
        <StatusBar style="light" />
        <View style={dashboardStyles.loadingOrb}><Text style={dashboardStyles.loadingA}>A</Text></View>
        <Text style={[styles.lockTitle, { color: '#FFF5F6', marginTop: 18 }]}>
          {language === 'bn' ? 'Abir AI প্রস্তুত হচ্ছে…' : 'Preparing Abir AI…'}
        </Text>
      </View>
    );
  }

  if (appLockEnabled && !appUnlocked) {
    return (
      <View style={[styles.lockScreen, { backgroundColor: '#050505' }]}>
        <StatusBar style="light" />
        <View style={dashboardStyles.loadingOrb}><Text style={dashboardStyles.loadingA}>A</Text></View>
        <Text style={[styles.lockTitle, { color: '#FFF5F6', marginTop: 18 }]}>
          {language === 'bn' ? 'Abir AI লক করা আছে' : 'Abir AI is locked'}
        </Text>
        <Text style={[styles.lockText, { color: '#BD8189' }]}>
          {language === 'bn' ? 'Fingerprint/Face/PIN/Password দিয়ে আনলক করো।' : 'Unlock with your phone fingerprint/face/PIN/password.'}
        </Text>
        <Pressable onPress={() => void authenticateOwner().then(ok => { setAppUnlocked(ok); if (ok) setOwnerVerified(true); })} style={[styles.unlockButton, { backgroundColor: '#FF1F3D' }]}>
          <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>{language === 'bn' ? 'আনলক' : 'Unlock'}</Text>
        </Pressable>
        <Pressable onPress={() => setShowSettings(true)} style={[styles.accountLink, { borderColor: '#3E0C12' }]}>
          <Text style={{ color: '#F4E1E4' }}>Settings</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <>
      {!accountLoggedIn ? (
        <AbirLoginScreen
          language={language}
          initialEmail={accountEmail}
          initialApiKey={accountApiKey}
          onSubmit={(email, password, apiKey, provider) => {
            void submitLoginScreen(email, password, apiKey, provider);
          }}
        />
      ) : (
        <ExactReferenceDashboard
          language={language}
          messages={messages}
          draft={draft}
          setDraft={setDraft}
          isListening={isListening}
          continuousVoice={continuousVoice}
          isSending={isSending}
          isSpeaking={speakingId !== null}
          online={online}
          voiceHistory={voiceHistory}
          memory={memory}
          voiceGender={voiceGender}
          wakeWordEnabled={wakeWordEnabled}
          accountLoggedIn={accountLoggedIn}
          onVoice={() => {
            if (continuousVoice || isListening) {
              void stopContinuousVoice();
            } else {
              void startVoiceInput();
            }
          }}
          onSend={(text) => void sendText(text)}
          onMenu={() => setShowQuickMenu(true)}
          onSettings={() => setShowSettings(true)}
          onAccount={() => setShowAccountSetup(true)}
          onFeatures={() => setShowFeatures(true)}
        />
      )}

      <Modal
        visible={liveCameraVisible}
        animationType="slide"
        onRequestClose={() => setLiveCameraVisible(false)}
      >
        <View style={{ flex: 1, backgroundColor: '#050B14', paddingTop: Math.max(insets.top, 12), paddingBottom: Math.max(insets.bottom, 12), paddingHorizontal: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 }}>
            <View>
              <Text style={{ color: '#FFFFFF', fontSize: 20, fontWeight: '900' }}>ABIR LIVE VISION</Text>
              <Text style={{ color: '#7DD3FC', fontSize: 11, marginTop: 3 }}>{language === 'bn' ? 'ক্যামেরা চালু • বিশ্লেষণ তোমার নির্দেশে' : 'Camera on • Analyze only when you ask'}</Text>
            </View>
            <Pressable onPress={() => setLiveCameraVisible(false)} style={{ padding: 10, borderRadius: 14, backgroundColor: '#17263A' }}>
              <UiIcon name="close" size={22} color="#FFFFFF" />
            </Pressable>
          </View>
          <View style={{ flex: 1, borderRadius: 22, overflow: 'hidden', backgroundColor: '#101827', borderWidth: 1, borderColor: '#245078' }}>
            <CameraView ref={liveCameraRef} style={{ flex: 1 }} facing={liveCameraFacing} mode="picture" />
            <View pointerEvents="none" style={{ position: 'absolute', top: 14, left: 14, backgroundColor: 'rgba(0,0,0,0.55)', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10 }}>
              <Text style={{ color: '#7CFFB2', fontSize: 11, fontWeight: '900' }}>● LIVE</Text>
            </View>
          </View>
          <TextInput
            value={liveCameraQuestion}
            onChangeText={setLiveCameraQuestion}
            placeholder={language === 'bn' ? 'ক্যামেরায় যা দেখাচ্ছি, সেটা সম্পর্কে জিজ্ঞেস করো…' : 'Ask about what I am showing…'}
            placeholderTextColor="#91A4BA"
            style={{ marginTop: 12, minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: '#29445F', color: '#FFFFFF', backgroundColor: '#101827', paddingHorizontal: 14, paddingVertical: 10 }}
          />
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
            <Pressable onPress={() => setLiveCameraFacing(v => v === 'back' ? 'front' : 'back')} style={{ flex: 1, padding: 13, borderRadius: 14, alignItems: 'center', backgroundColor: '#17263A' }}>
              <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>{language === 'bn' ? 'ক্যামেরা ঘোরাও' : 'Flip camera'}</Text>
            </Pressable>
            <Pressable disabled={liveCameraBusy} onPress={() => void askLiveCameraByVoice()} style={{ flex: 1, padding: 13, borderRadius: 14, alignItems: 'center', backgroundColor: '#173B5B', opacity: liveCameraBusy ? 0.6 : 1 }}>
              <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>{isListening ? (language === 'bn' ? 'শুনছি…' : 'Listening…') : (language === 'bn' ? 'ভয়েসে জিজ্ঞেস' : 'Ask by voice')}</Text>
            </Pressable>
            <Pressable disabled={liveCameraBusy} onPress={() => void analyzeLiveCamera(liveCameraQuestion)} style={{ flex: 1.2, padding: 13, borderRadius: 14, alignItems: 'center', backgroundColor: '#2563EB', opacity: liveCameraBusy ? 0.6 : 1 }}>
              {liveCameraBusy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={{ color: '#FFFFFF', fontWeight: '900' }}>{language === 'bn' ? 'বিশ্লেষণ' : 'Analyze'}</Text>}
            </Pressable>
          </View>
          <Text style={{ color: '#91A4BA', fontSize: 11, lineHeight: 16, marginTop: 9, textAlign: 'center' }}>
            {language === 'bn' ? 'ভিডিও বা ছবি স্বয়ংক্রিয়ভাবে পাঠানো হয় না। Analyze চাপলে শুধু একটি ফ্রেম বিশ্লেষণের জন্য পাঠানো হয়; বন্ধ করলে ক্যামেরা বন্ধ হয়।' : 'No video or images are sent automatically. Analyze sends one frame for analysis; closing this screen stops the camera.'}
          </Text>
        </View>
      </Modal>

      <Modal
        visible={Boolean(cameraPreviewUri)}
        transparent
        animationType="fade"
        onRequestClose={() => setCameraPreviewUri(null)}
      >
        <View style={styles.cameraModal}>
          <View style={styles.cameraCard}>
            <Text style={[styles.cameraTitle, { color: colors.foreground }]}>
              {language === 'bn' ? 'তোলা ছবি' : 'Captured photo'}
            </Text>
            {cameraPreviewUri ? (
              <Image source={{ uri: cameraPreviewUri }} style={styles.cameraImage} resizeMode="contain" />
            ) : null}
            <Text style={[styles.cameraHint, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? `${savedCameraUris.length}টি ছবি এই ডিভাইসে রাখা হয়েছে। এগুলো Abir-এর face-recognition database নয়।`
                : `${savedCameraUris.length} photos are kept on this device. They are not used as an Abir face-recognition database.`}
            </Text>
            <Pressable
              onPress={() => setCameraPreviewUri(null)}
              style={[styles.cameraCloseButton, { backgroundColor: colors.primary }]}
            >
              <Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>
                {language === 'bn' ? 'বন্ধ' : 'Close'}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showFeatures} animationType="slide" onRequestClose={() => setShowFeatures(false)}>
        <View style={[styles.settingsCard, { flex: 1, width: '100%', maxWidth: undefined, borderRadius: 0, backgroundColor: colors.background, borderColor: colors.border, paddingTop: Math.max(insets.top, 14) }]}>
          <View style={styles.settingsHeader}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.lockTitle, { color: colors.foreground, marginTop: 0, fontSize: 20 }]}>{language === 'bn' ? '600 Feature Master Pack' : '600 Feature Master Pack'}</Text>
              <Text style={[styles.lockText, { color: colors.mutedForeground, marginTop: 3, fontSize: 12 }]}>{MASTER_600_FEATURE_COUNT}/600 {language === 'bn' ? 'টি master feature — Memory 200 অপরিবর্তিত' : 'master features — Memory 200 unchanged'}</Text>
            </View>
            <Pressable onPress={() => setShowFeatures(false)} style={styles.iconButton}><UiIcon name="close" size={20} color={colors.mutedForeground} /></Pressable>
          </View>
          <FlatList
            data={MASTER_600_FEATURES}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingBottom: 30 }}
            renderItem={({ item }) => (
              <View style={[styles.settingRow, { borderColor: colors.border }]}>
                <View style={{ width: 34, height: 28, borderRadius: 9, backgroundColor: colors.muted, alignItems: 'center', justifyContent: 'center', marginRight: 9 }}>
                  <Text style={{ color: colors.foreground, fontSize: 10, fontWeight: '900' }}>{item.number}</Text>
                </View>
                <View style={styles.settingCopy}>
                  <Text style={[styles.settingTitle, { color: colors.foreground, fontSize: 12 }]}>{language === 'bn' ? item.bengali : item.name}</Text>
                  <Text style={[styles.settingDesc, { color: colors.mutedForeground, fontSize: 10 }]}>{item.status} • {item.note}</Text>
                </View>
              </View>
            )}
          />
        </View>
      </Modal>

      <Modal visible={showQuickMenu} transparent animationType="fade" onRequestClose={() => setShowQuickMenu(false)}>
        <Pressable style={styles.quickMenuOverlay} onPress={() => setShowQuickMenu(false)}>
          <Pressable style={[styles.quickMenuCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => {}}>
            <View style={styles.quickMenuTitleRow}>
              <View>
                <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 20, marginTop: 0 }]}>Abir AI</Text>
                <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'সব নিয়ন্ত্রণ এক জায়গায়' : 'All controls in one place'}
                </Text>
              </View>
              <Pressable onPress={() => setShowQuickMenu(false)} style={styles.iconButton}>
                <UiIcon name="close" size={19} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <View style={styles.quickMenuGrid}>
              <Pressable style={[styles.menuTile, { backgroundColor: accountLoggedIn ? colors.accentSoft : colors.muted, borderColor: accountLoggedIn ? colors.primary : colors.border }]} onPress={() => { setShowQuickMenu(false); setShowAccountSetup(true); }}>
                <UiIcon name="person" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{accountLoggedIn ? (language === 'bn' ? 'অ্যাকাউন্ট' : 'Account') : 'Login'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: autoSpeak ? colors.accentSoft : colors.muted, borderColor: colors.border }]} onPress={() => { const next=!autoSpeak; setAutoSpeak(next); void AsyncStorage.setItem('abir-ai-auto-speak-v1', next?'on':'off'); }}>
                <UiIcon name={autoSpeak ? 'volume-high' : 'volume-mute'} size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'অটো ভয়েস' : 'Auto voice'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: wakeWordEnabled ? colors.accentSoft : colors.muted, borderColor: colors.border }]} onPress={() => { if (wakeWordEnabled) { setWakeWordEnabled(false); void AsyncStorage.setItem(WAKE_WORD_KEY, 'off'); void stopWakeWord(); } else { void enableWakeWord(); } }}>
                <UiIcon name="mic" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'Wake Word' : 'Wake word'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => setLanguage(v => v === 'bn' ? 'en' : 'bn')}>
                <Text style={{ color: colors.primary, fontSize: 17, fontWeight: '900' }}>{language === 'bn' ? 'EN' : 'বাংলা'}</Text>
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ভাষা' : 'Language'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); setShowSettings(true); }}>
                <UiIcon name="settings" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'সেটিংস' : 'Settings'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.accentSoft, borderColor: colors.primary }]} onPress={() => { setShowQuickMenu(false); void openLiveCamera(); }}>
                <UiIcon name="camera" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'Live Vision' : 'Live Vision'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void captureCameraPhoto(); }}>
                <UiIcon name="camera" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ছবি তোলো' : 'Take photo'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void configureAppLock(); }}>
                <UiIcon name="shield" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'App Lock' : 'App Lock'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => void repeatLastAssistantReply()}>
                <UiIcon name="volume-medium" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'আবার বলো' : 'Repeat'}</Text>
              </Pressable>
              <Pressable style={[styles.menuTile, { backgroundColor: colors.muted, borderColor: colors.border }]} onPress={() => { setShowQuickMenu(false); void stopVoiceReply(); }}>
                <UiIcon name="volume-mute" size={21} color={colors.primary} />
                <Text style={[styles.menuTileText, { color: colors.foreground }]}>{language === 'bn' ? 'ভয়েস থামাও' : 'Stop voice'}</Text>
              </Pressable>
            </View>
            <Pressable onPress={() => { setShowQuickMenu(false); confirmClear(); }} style={[styles.menuDanger, { borderColor: colors.border }]}>
              <UiIcon name="trash" size={19} color={colors.destructive} />
              <Text style={{ color: colors.destructive, fontWeight: '800' }}>{language === 'bn' ? 'সব চ্যাট মুছে দাও' : 'Delete all chats'}</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={showSettings} transparent animationType="slide" onRequestClose={() => setShowSettings(false)}>
        <View style={styles.accountOverlay}>
          <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.settingsHeader}>
              <View>
                <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 22 }]}>
                  {language === 'bn' ? 'Abir AI Settings' : 'Abir AI Settings'}
                </Text>
                <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
                  {language === 'bn' ? 'ভয়েস, Wake Word, Lock ও Chat নিয়ন্ত্রণ' : 'Voice, wake word, lock and chat controls'}
                </Text>
              </View>
              <Pressable onPress={() => setShowSettings(false)} style={styles.iconButton}>
                <UiIcon name="close" size={20} color={colors.mutedForeground} />
              </Pressable>
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>স্বয়ংক্রিয় ভয়েস</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>প্রতিটি উত্তরের পর Abir নিজে থেকে বলবে</Text>
              </View>
              <Switch value={autoSpeak} onValueChange={value => { setAutoSpeak(value); void AsyncStorage.setItem('abir-ai-auto-speak-v1', value ? 'on' : 'off'); }} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>“Abir” Wake Word</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>অ্যাপ বন্ধ/ব্যাকগ্রাউন্ডে থাকলেও শুনতে চেষ্টা করবে</Text>
              </View>
              <Switch value={wakeWordEnabled} onValueChange={value => { if (value) void enableWakeWord(); else { setWakeWordEnabled(false); void AsyncStorage.setItem(WAKE_WORD_KEY, 'off'); void stopWakeWord(); } }} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>Owner Voice</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>
                  {speakerSampleCount}/{MAX_SPEAKER_SAMPLES} samples · শুধু voice vector রাখা হয়
                </Text>
              </View>
              <Pressable
                disabled={speakerRecording}
                onPress={() => void setupSpeakerProfile()}
                style={[styles.settingButton, { borderColor: colors.border, opacity: speakerRecording ? 0.5 : 1 }]}
              >
                <Text style={{ color: colors.foreground, fontWeight: '700' }}>{speakerRecording ? '…' : 'REC'}</Text>
              </Pressable>
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>Owner Voice Reset</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>আগের voice profile মুছে নতুন করে record করা যাবে</Text>
              </View>
              <Pressable onPress={() => void clearSpeakerProfile().then(() => setSpeakerSampleCount(0))} style={[styles.settingButton, { borderColor: colors.border }]}>
                <Text style={{ color: '#FF4B5F', fontWeight: '700' }}>RESET</Text>
              </Pressable>
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>App Lock</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>ফোনের fingerprint/face/PIN/password দিয়ে সুরক্ষা</Text>
              </View>
              <Switch value={appLockEnabled} onValueChange={() => void configureAppLock()} />
            </View>

            <View style={[styles.settingRow, { borderColor: colors.border }]}>
              <View style={styles.settingCopy}>
                <Text style={[styles.settingTitle, { color: colors.foreground }]}>Voice</Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground }]}>বর্তমান: {voiceGender === 'female' ? 'Female' : 'Male'}</Text>
              </View>
              <Pressable onPress={() => { const next: VoiceGenderPreference = voiceGender === 'female' ? 'male' : 'female'; setVoiceGender(next); void loadAssistantPreferences().then(current => saveAssistantPreferences({ ...current, voiceGender: next })).catch(() => {}); }} style={[styles.settingButton, { borderColor: colors.border }]}>
                <Text style={{ color: colors.foreground, fontWeight: '700' }}>{voiceGender === 'female' ? '♀' : '♂'}</Text>
              </Pressable>
            </View>

            <Pressable onPress={confirmClear} style={[styles.dangerButton, { borderColor: colors.border }]}>
              <UiIcon name="trash" size={18} color="#FF4B5F" />
              <Text style={{ color: '#FF4B5F', fontWeight: '800' }}>{language === 'bn' ? 'সব Chat মুছে দাও' : 'Delete all chats'}</Text>
            </Pressable>

            <Pressable onPress={() => setShowSettings(false)} style={[styles.cameraCloseButton, { backgroundColor: colors.primary, marginTop: 12 }]}>
              <Text style={{ color: colors.primaryForeground, fontWeight: '800' }}>{language === 'bn' ? 'সম্পন্ন' : 'Done'}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showAccountSetup} transparent animationType="slide" onRequestClose={() => setShowAccountSetup(false)}>
        <View style={styles.accountOverlay}>
          <View style={[styles.accountCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.lockTitle, { color: colors.foreground, fontSize: 22 }]}>Abir Account</Text>
            <Text style={[styles.lockText, { color: colors.mutedForeground }]}>
              {language === 'bn'
                ? 'নতুন ফোনে একই settings/API key ব্যবহার করার জন্য email ও API key রাখতে পারো। Password এখানে সংরক্ষণ করা হয় না।'
                : 'Save your email and API key for device setup. Your password is not stored in this app.'}
            </Text>
            <TextInput value={accountEmail} onChangeText={setAccountEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountPassword} onChangeText={setAccountPassword} secureTextEntry placeholder={language === 'bn' ? 'Password' : 'Password'} placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <TextInput value={accountApiKey} onChangeText={setAccountApiKey} autoCapitalize="none" placeholder="Gemini API key" placeholderTextColor={colors.mutedForeground} style={[styles.accountInput, { color: colors.foreground, borderColor: colors.border }]} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <Pressable onPress={() => setShowAccountSetup(false)} style={[styles.accountAction, { borderColor: colors.border }]}><Text style={{ color: colors.foreground }}>{language === 'bn' ? 'বন্ধ' : 'Close'}</Text></Pressable>
              <Pressable onPress={() => void (accountLoggedIn ? loginAccount() : saveAccount())} style={[styles.accountAction, { backgroundColor: colors.primary, borderColor: colors.primary }]}><Text style={{ color: colors.primaryForeground, fontWeight: '700' }}>{accountLoggedIn ? (language === 'bn' ? 'Login' : 'Login') : (language === 'bn' ? 'Create/Login' : 'Create/Login')}</Text></Pressable>
            </View>
            <Text style={[styles.footerNote, { color: colors.mutedForeground, marginTop: 12 }]}>
              {account ? `${language === 'bn' ? 'Configured:' : 'Configured:'} ${account.email}` : (language === 'bn' ? 'Account এখনো সেট করা হয়নি।' : 'No account configured yet.')}
            </Text>
          </View>
        </View>
      </Modal>
    </>
  );
}



const realDashboardStyles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#020817' },
  scroll: { flex: 1 },
  content: { padding: 14, paddingTop: 10, paddingBottom: 205 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  brandRow: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandOrb: { width: 48, height: 48, borderRadius: 15, borderWidth: 1.5, borderColor: '#36BFFF', backgroundColor: '#071C43', alignItems: 'center', justifyContent: 'center', shadowColor: '#6C4DFF', shadowOpacity: 0.7, shadowRadius: 16, elevation: 10 },
  brandA: { color: '#E6D6FF', fontSize: 27, fontWeight: '900', textShadowColor: '#38CFFF', textShadowRadius: 10 },
  brandTitle: { color: '#F5FAFF', fontSize: 20, fontWeight: '900' },
  brandSub: { color: '#7F9FC4', fontSize: 10, marginTop: 2 },
  headerPill: { borderWidth: 1, borderColor: '#1C5798', backgroundColor: '#071833', borderRadius: 18, paddingHorizontal: 10, paddingVertical: 8 },
  headerPillText: { color: '#BBD8F5', fontSize: 9, fontWeight: '800' },
  headerButton: { width: 38, height: 38, borderRadius: 12, borderWidth: 1, borderColor: '#225B99', backgroundColor: '#071833', alignItems: 'center', justifyContent: 'center' },
  headerButtonText: { color: '#CBE7FF', fontSize: 19 },
  hero: { minHeight: 210, borderRadius: 24, borderWidth: 1.5, borderColor: '#1B76D1', padding: 16, flexDirection: 'row', alignItems: 'center', overflow: 'hidden', shadowColor: '#278FFF', shadowOpacity: 0.25, shadowRadius: 20, elevation: 12 },
  heroCopy: { flex: 1 },
  statusLine: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { color: '#9DC2E8', fontSize: 9, fontWeight: '900', letterSpacing: 0.7 },
  heroTitle: { color: '#F5FBFF', fontSize: 28, fontWeight: '900', marginTop: 14 },
  heroSubtitle: { color: '#8AA9CB', fontSize: 11, lineHeight: 17, marginTop: 6, maxWidth: 220 },
  heroOrbButton: { width: 150, height: 150, alignItems: 'center', justifyContent: 'center' },
  heroOrbGlow: { position: 'absolute', width: 138, height: 138, borderRadius: 69, backgroundColor: '#6C4DFF', opacity: 0.18 },
  heroOrb: { width: 108, height: 108, borderRadius: 54, borderWidth: 2, borderColor: '#43D7FF', backgroundColor: '#071D46', alignItems: 'center', justifyContent: 'center', shadowColor: '#8A54FF', shadowOpacity: 0.9, shadowRadius: 26, elevation: 18 },
  heroOrbText: { color: '#D7C5FF', fontSize: 38, fontWeight: '900', textShadowColor: '#36D5FF', textShadowRadius: 14 },
  heroBars: { position: 'absolute', bottom: 22, flexDirection: 'row', alignItems: 'center', gap: 3 },
  heroBar: { width: 3, borderRadius: 3, backgroundColor: '#DFFBFF' },
  heroRight: { width: 80, alignItems: 'center' },
  heroRightLabel: { color: '#7197BE', fontSize: 9 },
  heroRightValue: { color: '#24E7A1', fontSize: 10, fontWeight: '900', marginTop: 3 },
  heroVoiceButton: { marginTop: 13, width: 68, height: 68, borderRadius: 22, borderWidth: 1, borderColor: '#5C73FF', backgroundColor: '#0A2351', alignItems: 'center', justifyContent: 'center' },
  heroVoiceIcon: { fontSize: 24 },
  heroVoiceText: { color: '#B9D7F5', fontSize: 8, fontWeight: '800', marginTop: 3 },
  metricsRow: { flexDirection: 'row', gap: 8, marginTop: 10, marginBottom: 10, backgroundColor: '#06152D', borderRadius: 18, borderWidth: 1, borderColor: '#123F72', padding: 10 },
  twoColumn: { gap: 10 },
  card: { borderRadius: 18, borderWidth: 1, borderColor: '#15569B', backgroundColor: 'rgba(5,20,43,0.96)', padding: 12, marginBottom: 10, shadowColor: '#168EFF', shadowOpacity: 0.12, shadowRadius: 12, elevation: 5 },
  conversationCard: { minHeight: 230 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  cardTitle: { color: '#EAF6FF', fontSize: 15, fontWeight: '900' },
  cardSubtitle: { color: '#7898BC', fontSize: 9, marginTop: 2 },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 12, borderWidth: 1, borderColor: '#168F6D', backgroundColor: '#062A28', paddingHorizontal: 8, paddingVertical: 5 },
  liveBadgeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#20F09A' },
  liveBadgeText: { color: '#20F09A', fontSize: 8, fontWeight: '900' },
  messageList: { gap: 7 },
  messageBubble: { borderRadius: 14, borderWidth: 1, padding: 9 },
  userBubble: { alignSelf: 'flex-end', width: '86%', backgroundColor: '#0B2B58', borderColor: '#287EDB' },
  assistantBubble: { alignSelf: 'flex-start', width: '92%', backgroundColor: '#081C39', borderColor: '#24558D' },
  messageMetaRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3 },
  messageRole: { color: '#54D7FF', fontSize: 8, fontWeight: '900' },
  messageTime: { color: '#607F9F', fontSize: 8 },
  messageText: { color: '#DDEEFF', fontSize: 11, lineHeight: 16 },
  emptyText: { color: '#7898BC', fontSize: 11, textAlign: 'center', paddingVertical: 24 },
  systemRow: { minHeight: 35, borderTopWidth: 1, borderTopColor: '#10365E', flexDirection: 'row', alignItems: 'center', gap: 7 },
  systemDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#20EAA0', shadowColor: '#20EAA0', shadowOpacity: 0.8, shadowRadius: 6 },
  systemLabel: { color: '#9DB8D5', fontSize: 10, flex: 1 },
  systemValue: { color: '#25E7A3', fontSize: 9, fontWeight: '900' },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  quickButton: { width: '48%', minHeight: 54, borderRadius: 14, borderWidth: 1, borderColor: '#1A5799', backgroundColor: '#071A38', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, gap: 8 },
  quickButtonPressed: { backgroundColor: '#0D3563', borderColor: '#43CFFF' },
  quickIcon: { fontSize: 18 },
  quickText: { color: '#D9EBFF', fontSize: 10, fontWeight: '800', flex: 1 },
  quickArrow: { color: '#55CFFF', fontSize: 20, fontWeight: '900' },
  historyRow: { minHeight: 43, borderTopWidth: 1, borderTopColor: '#10365E', flexDirection: 'row', alignItems: 'center', gap: 8 },
  historyMic: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#0A2B58', alignItems: 'center', justifyContent: 'center' },
  historyText: { color: '#C5D9EE', fontSize: 10, flex: 1 },
  historyTime: { color: '#6484A5', fontSize: 8 },
  inputDockWrap: { position: 'absolute', left: 10, right: 10, bottom: 8 },
  inputDock: { minHeight: 58, borderRadius: 20, borderWidth: 1.5, borderColor: '#1D86FF', backgroundColor: '#061A3A', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, shadowColor: '#1A8FFF', shadowOpacity: 0.35, shadowRadius: 16, elevation: 15 },
  input: { flex: 1, minHeight: 44, color: '#F2F8FF', fontSize: 13, paddingHorizontal: 9 },
  inputButton: { width: 43, height: 43, borderRadius: 15, backgroundColor: '#0A2A50', borderWidth: 1, borderColor: '#2B79C7', alignItems: 'center', justifyContent: 'center' },
  inputButtonActive: { backgroundColor: '#1B2B70', borderColor: '#A16DFF' },
  inputButtonText: { fontSize: 20 },
  sendButton: { width: 43, height: 43, borderRadius: 15, marginLeft: 6, backgroundColor: '#7350FF', alignItems: 'center', justifyContent: 'center' },
  sendButtonText: { color: '#FFFFFF', fontSize: 20, fontWeight: '900' },
  disabledButton: { opacity: 0.4 },
  bottomActions: { height: 40, marginTop: 6, borderRadius: 18, borderWidth: 1, borderColor: '#123F72', backgroundColor: 'rgba(3,17,40,0.97)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  bottomAction: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 14 },
  bottomActionIcon: { fontSize: 14 },
  bottomActionText: { color: '#9DB8D5', fontSize: 8, fontWeight: '800' },
});

const exactUiStyles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000000' },
  canvas: { flex: 1, overflow: 'hidden', position: 'relative' },
  commandOverlay: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    borderRadius: 24,
    backgroundColor: 'rgba(3, 17, 40, 0.30)',
  },
  commandInput: {
    flex: 1,
    height: 48,
    color: '#F4FBFF',
    fontSize: 15,
    fontWeight: '700',
    paddingHorizontal: 10,
  },
  commandMic: {
    width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(8, 40, 82, 0.62)', borderWidth: 1, borderColor: 'rgba(82, 216, 255, 0.65)',
  },
  commandMicText: { fontSize: 19 },
  commandSend: {
    width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginLeft: 6,
    backgroundColor: 'rgba(111, 73, 255, 0.86)',
  },
  commandSendText: { color: '#FFFFFF', fontSize: 20, fontWeight: '900' },
  liveBadge: {
    position: 'absolute', flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12,
    backgroundColor: 'rgba(2, 15, 34, 0.70)', borderWidth: 1, borderColor: 'rgba(54, 191, 255, 0.55)',
  },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveText: { color: '#E7F8FF', fontSize: 7, fontWeight: '900' },
  thinkingBadge: {
    position: 'absolute', flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 9, paddingVertical: 5, borderRadius: 12,
    backgroundColor: 'rgba(4, 20, 45, 0.85)', borderWidth: 1, borderColor: '#5C73FF',
  },
  thinkingText: { color: '#CFEFFF', fontSize: 7, fontWeight: '800' },
});

const dashboardStyles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#020817' },
  livingBackground: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, overflow: 'hidden' },
  neuralField: { position: 'absolute', left: -12, right: -12, top: 70, bottom: 0 },
  neuralLink: { position: 'absolute', height: 1, backgroundColor: '#237BFF', transformOrigin: 'left center' as any },
  neuralNode: { position: 'absolute', backgroundColor: '#39A8FF', shadowColor: '#39A8FF', shadowOpacity: 0.9, shadowRadius: 8, elevation: 5 },
  energyHalo: { position: 'absolute', width: 360, height: 360, borderRadius: 180, alignSelf: 'center', top: 250, backgroundColor: '#092A63', borderWidth: 1, borderColor: '#1A64D8', opacity: 0.42 },
  scanLine: { position: 'absolute', left: 0, right: 0, height: 1, backgroundColor: '#5AC8FF', opacity: 0.14, shadowColor: '#5AC8FF', shadowOpacity: 0.7, shadowRadius: 10, elevation: 3 },
  gridGlow: { position: 'absolute', left: -120, right: -120, top: 80, height: 520, borderRadius: 260, backgroundColor: '#1746B8', opacity: 0.12 },

  topBar: { paddingTop: 38, paddingHorizontal: 10, paddingBottom: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
  brandBlock: { flex: 1.1, minWidth: 125, flexDirection: 'row', alignItems: 'center', gap: 7 },
  brandOrb: { width: 43, height: 43, borderRadius: 14, borderWidth: 1.5, borderColor: '#238EFF', backgroundColor: '#071A3A', alignItems: 'center', justifyContent: 'center', shadowColor: '#238EFF', shadowOpacity: 0.75, shadowRadius: 14, elevation: 12 },
  brandA: { color: '#B58CFF', fontSize: 24, fontWeight: '900', textShadowColor: '#2FB7FF', textShadowRadius: 10 },
  brandTitle: { color: '#F6FBFF', fontSize: 17, fontWeight: '900', letterSpacing: 0.8 },
  brandSubtitle: { color: '#9DB6D8', fontSize: 7.5, fontWeight: '700', marginTop: 1 },
  brandTiny: { color: '#4CA7E9', fontSize: 5.5, fontWeight: '800', marginTop: 2 },
  topControls: { flex: 1.05, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 5 },
  profileCircle: { width: 32, height: 32, borderRadius: 16, borderWidth: 1.5, borderColor: '#6E55FF', backgroundColor: '#0B1736', alignItems: 'center', justifyContent: 'center' },
  profileGlyph: { color: '#F3C7FF', fontSize: 14, fontWeight: '900' },
  topPill: { minHeight: 31, borderRadius: 16, borderWidth: 1, borderColor: '#205BA7', backgroundColor: '#071833', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, gap: 4 },
  topPillIcon: { color: '#B98BFF', fontSize: 10, fontWeight: '900' },
  topPillText: { color: '#D8E9FF', fontSize: 6.5, fontWeight: '800' },
  settingsCircle: { width: 31, height: 31, borderRadius: 16, borderWidth: 1, borderColor: '#2363A9', backgroundColor: '#071833', alignItems: 'center', justifyContent: 'center' },
  settingsGlyph: { color: '#D6E8FF', fontSize: 16 },

  listeningBar: { flex: 1.25, minWidth: 145, height: 58, borderRadius: 30, borderWidth: 1.5, borderColor: '#1C8BFF', backgroundColor: '#061938', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 11, overflow: 'hidden', shadowColor: '#168EFF', shadowOpacity: 0.55, shadowRadius: 17, elevation: 12 },
  listeningBarActive: { borderColor: '#A16DFF', shadowColor: '#9B5CFF', shadowOpacity: 0.85 },
  waveBars: { width: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 3 },
  waveBarTop: { width: 3, borderRadius: 3, backgroundColor: '#46D7FF' },
  listeningTitle: { color: '#F3F8FF', fontSize: 14, fontWeight: '900', letterSpacing: 0.3 },
  listeningSub: { color: '#80A5D1', fontSize: 7, marginTop: 2 },
  listeningGlow: { position: 'absolute', right: -18, width: 90, height: 90, borderRadius: 45, backgroundColor: '#7C48FF', opacity: 0.12 },

  scrollContent: { paddingHorizontal: 8, paddingBottom: 106 },
  dashboardGrid: { flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  leftColumn: { flex: 1, minWidth: 110, gap: 7 },
  centerColumn: { flex: 1.35, minWidth: 150, gap: 7 },
  rightColumn: { flex: 1, minWidth: 110, gap: 7 },

  sectionCard: { borderRadius: 14, borderWidth: 1, borderColor: '#15569B', backgroundColor: 'rgba(3,17,43,0.91)', padding: 8, overflow: 'hidden', shadowColor: '#168EFF', shadowOpacity: 0.15, shadowRadius: 10, elevation: 4 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7 },
  sectionTitle: { color: '#E8F4FF', fontSize: 8.5, fontWeight: '900', letterSpacing: 0.25 },
  viewAll: { color: '#39D5FF', fontSize: 6.5, fontWeight: '900' },
  onlineBadge: { borderRadius: 11, borderWidth: 1, borderColor: '#1DAA80', backgroundColor: '#062A2B', paddingHorizontal: 6, paddingVertical: 3, flexDirection: 'row', alignItems: 'center', gap: 4 },
  greenDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#20F09A', shadowColor: '#20F09A', shadowRadius: 6, shadowOpacity: 1 },
  onlineText: { color: '#20F09A', fontSize: 6, fontWeight: '900' },

  metricGrid: { flexDirection: 'row', gap: 4 },
  metricRingCard: { flex: 1, alignItems: 'center', minWidth: 0 },
  metricRing: { width: 48, height: 48, borderRadius: 24, borderWidth: 3, alignItems: 'center', justifyContent: 'center', backgroundColor: '#061B37', shadowRadius: 9, shadowOpacity: 0.6 },
  ringGreen: { borderColor: '#20EAA0', shadowColor: '#20EAA0' },
  ringBlue: { borderColor: '#348CFF', shadowColor: '#348CFF' },
  ringPurple: { borderColor: '#A85BFF', shadowColor: '#A85BFF' },
  metricRingValue: { color: '#F6FBFF', fontSize: 10, fontWeight: '900' },
  metricRingLabel: { color: '#A6BEDA', fontSize: 5.5, fontWeight: '800', marginTop: 4, textAlign: 'center' },
  smallMetricRow: { flexDirection: 'row', gap: 4, marginTop: 8 },
  smallMetric: { flex: 1, minWidth: 0, minHeight: 39, borderRadius: 8, borderWidth: 1, borderColor: '#164A82', backgroundColor: '#06162F', padding: 5, flexDirection: 'row', alignItems: 'center', gap: 4 },
  smallMetricIcon: { color: '#4AD4FF', fontSize: 11 },
  smallMetricLabel: { color: '#8EA8C8', fontSize: 5.5, fontWeight: '800' },
  smallMetricValue: { color: '#F2F8FF', fontSize: 9, fontWeight: '900', marginTop: 1 },
  metricLabel: { color: '#89A6C7', fontSize: 6, fontWeight: '800' },
  metricTrend: { color: '#20EAA0', fontSize: 7, fontWeight: '900', marginTop: 2 },

  activityRow: { minHeight: 29, borderTopWidth: 1, borderTopColor: '#0F3767', flexDirection: 'row', alignItems: 'center', gap: 5 },
  activityIcon: { width: 19, height: 19, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  activityGreen: { backgroundColor: '#063C35', borderWidth: 1, borderColor: '#15B88C' },
  activityBlue: { backgroundColor: '#0B2B58', borderWidth: 1, borderColor: '#287EDB' },
  activityIconText: { color: '#E9F8FF', fontSize: 7, fontWeight: '900' },
  activityText: { color: '#B8CBE0', fontSize: 6.5, flex: 1 },
  activityTime: { color: '#6C8BAB', fontSize: 5.5, fontWeight: '800' },

  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
  quickButton: { width: '48%', minHeight: 32, borderRadius: 8, borderWidth: 1, borderColor: '#1A5799', backgroundColor: '#071A38', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 6 },
  quickButtonText: { color: '#D9EBFF', fontSize: 6.5, fontWeight: '800' },
  quickArrow: { color: '#55CFFF', fontSize: 13, fontWeight: '900' },

  memoryCount: { color: '#35D8FF', fontSize: 6.5 },
  memoryTabs: { flexDirection: 'row', gap: 3, marginBottom: 6 },
  memoryTab: { flex: 1, paddingVertical: 5, borderRadius: 6, alignItems: 'center', backgroundColor: '#07162E' },
  memoryTabActive: { backgroundColor: '#0D3563', borderWidth: 1, borderColor: '#1C8DFF' },
  memoryTabText: { color: '#B9CDE5', fontSize: 5.5, fontWeight: '800' },
  memorySearch: { height: 27, borderRadius: 8, borderWidth: 1, borderColor: '#174C84', backgroundColor: '#05142C', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, gap: 5 },
  searchIcon: { color: '#55CFFF', fontSize: 11 },
  memorySearchText: { color: '#6383A8', fontSize: 6 },
  memoryLine: { color: '#C3D6EB', fontSize: 6.5, marginTop: 7 },

  centerStage: { minHeight: 440, borderRadius: 18, borderWidth: 1, borderColor: '#1B68C5', backgroundColor: 'rgba(4,25,55,0.78)', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', position: 'relative', shadowColor: '#158EFF', shadowOpacity: 0.25, shadowRadius: 18, elevation: 10 },
  avatarImage: { width: '74%', height: '76%', position: 'absolute', top: 18, borderRadius: 22, opacity: 0.98 },
  avatarHaloOuter: { position: 'absolute', width: '92%', height: 350, borderRadius: 175, borderWidth: 1, borderColor: '#2D8CFF', opacity: 0.28, shadowColor: '#3BA7FF', shadowRadius: 22, shadowOpacity: 0.7 },
  avatarHaloInner: { position: 'absolute', width: '70%', height: 260, borderRadius: 130, borderWidth: 1, borderColor: '#9B5CFF', opacity: 0.36 },
  centerOrbGlow: { position: 'absolute', bottom: 37, width: 92, height: 92, borderRadius: 46, backgroundColor: '#A653FF', opacity: 0.65, shadowColor: '#B14DFF', shadowOpacity: 1, shadowRadius: 28 },
  centerOrb: { position: 'absolute', bottom: 50, width: 70, height: 70, borderRadius: 35, borderWidth: 2, borderColor: '#3ED8FF', backgroundColor: '#071C43', alignItems: 'center', justifyContent: 'center', shadowColor: '#B54CFF', shadowOpacity: 0.9, shadowRadius: 22, elevation: 20 },
  centerOrbA: { color: '#F0C4FF', fontSize: 39, fontWeight: '900', textShadowColor: '#43BFFF', textShadowRadius: 14 },
  centerPillText: { color: '#DDF4FF', fontSize: 5.5, fontWeight: '900' },
  centerPillLeft: { position: 'absolute', left: 7, top: '42%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },
  centerPillRight: { position: 'absolute', right: 7, top: '42%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },
  centerPillLeft2: { position: 'absolute', left: 9, top: '51%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },
  centerPillRight2: { position: 'absolute', right: 9, top: '51%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },
  centerPillLeft3: { position: 'absolute', left: 6, top: '60%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },
  centerPillRight3: { position: 'absolute', right: 6, top: '60%', borderRadius: 7, borderWidth: 1, borderColor: '#2077D8', backgroundColor: '#061A3A', paddingHorizontal: 7, paddingVertical: 5 },

  centerStats: { flexDirection: 'row', gap: 5 },
  bottomStat: { flex: 1, minWidth: 0, borderRadius: 10, borderWidth: 1, borderColor: '#155BA3', backgroundColor: '#06162F', padding: 7 },
  bottomStatValue: { color: '#F4FAFF', fontSize: 12, fontWeight: '900', marginTop: 3 },
  centerLowerRow: { flexDirection: 'row', gap: 6 },
  centerActivityCard: { flex: 1.3, borderRadius: 12, borderWidth: 1, borderColor: '#155BA3', backgroundColor: '#05152E', padding: 7 },
  voiceAssistantCard: { flex: 0.72, borderRadius: 12, borderWidth: 1, borderColor: '#1E72C5', backgroundColor: '#071A3A', alignItems: 'center', padding: 7 },
  bigMicCircle: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: '#5C73FF', backgroundColor: '#0A1E55', alignItems: 'center', justifyContent: 'center', marginTop: 7, shadowColor: '#B34FFF', shadowOpacity: 0.85, shadowRadius: 16 },
  bigMic: { color: '#68DFFF', fontSize: 25 },
  voiceAssistantText: { color: '#E4F3FF', fontSize: 7, fontWeight: '900', marginTop: 7 },
  voiceAssistantHint: { color: '#7B9FC5', fontSize: 5.5, marginTop: 2, textAlign: 'center' },

  analysisHeading: { color: '#F0F7FF', fontSize: 7.5, fontWeight: '900', marginBottom: 5 },
  deepAnalysis: { color: '#30D9FF', fontSize: 5.5, fontWeight: '900' },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5 },
  checkCircle: { width: 15, height: 15, borderRadius: 8, backgroundColor: '#06422F', borderWidth: 1, borderColor: '#22E6A0', alignItems: 'center', justifyContent: 'center' },
  checkText: { color: '#27F1A1', fontSize: 8, fontWeight: '900' },
  checkLabel: { color: '#BBD0E7', fontSize: 6.5, fontWeight: '700', flex: 1 },
  brainCircle: { position: 'absolute', right: 9, bottom: 8, width: 64, height: 64, borderRadius: 32, borderWidth: 1, borderColor: '#43BFFF', backgroundColor: '#082354', alignItems: 'center', justifyContent: 'center', opacity: 0.9 },
  brainText: { color: '#8E7BFF', fontSize: 32, textShadowColor: '#38CFFF', textShadowRadius: 14 },

  liveChart: { height: 72, flexDirection: 'row', alignItems: 'flex-end', gap: 3, paddingHorizontal: 4, paddingBottom: 6, borderBottomWidth: 1, borderBottomColor: '#15558F' },
  chartBar: { flex: 1, minWidth: 2, borderRadius: 3, backgroundColor: '#1CC8FF', shadowColor: '#8B5CFF', shadowRadius: 6, shadowOpacity: 0.8 },
  liveNumbers: { flexDirection: 'row', gap: 3, marginTop: 7 },

  statusItem: { minHeight: 27, borderTopWidth: 1, borderTopColor: '#0F3767', flexDirection: 'row', alignItems: 'center', gap: 5 },
  statusCheck: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#063E30', borderWidth: 1, borderColor: '#1DE6A0', alignItems: 'center', justifyContent: 'center' },
  statusCheckText: { color: '#2BF0A5', fontSize: 8, fontWeight: '900' },
  statusItemLabel: { color: '#AFC5DE', fontSize: 6.5, flex: 1 },
  statusItemValue: { color: '#24E7A1', fontSize: 5.5, fontWeight: '900' },

  latestRow: { minHeight: 37, borderTopWidth: 1, borderTopColor: '#0F3767', flexDirection: 'row', alignItems: 'center', gap: 6 },
  latestIcon: { width: 24, height: 24, borderRadius: 8, backgroundColor: '#0B2D59', color: '#43D9FF', textAlign: 'center', textAlignVertical: 'center', fontSize: 11 },
  latestTitle: { color: '#DCEBFA', fontSize: 6.5, fontWeight: '900' },
  latestText: { color: '#8DA8C7', fontSize: 5.5, marginTop: 1 },
  latestTime: { color: '#6683A4', fontSize: 5.5 },

  notificationRow: { minHeight: 30, borderTopWidth: 1, borderTopColor: '#0F3767', flexDirection: 'row', alignItems: 'center', gap: 5 },
  notificationIcon: { width: 19, height: 19, borderRadius: 6, backgroundColor: '#122A55', borderWidth: 1, borderColor: '#3B8DFF', alignItems: 'center', justifyContent: 'center' },

  backgroundCard: { borderRadius: 14, borderWidth: 1, borderColor: '#16599D', backgroundColor: '#06172F', padding: 8, minHeight: 70 },
  backgroundText: { color: '#89A8C9', fontSize: 6, flex: 1, marginTop: 7, marginBottom: 5 },

  stateTabs: { flexDirection: 'row', gap: 5, marginTop: 7 },
  stateTab: { flex: 1, minHeight: 39, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#07142A' },
  stateTabText: { fontSize: 7, fontWeight: '900' },

  commandCard: { marginTop: 7, borderRadius: 17, borderWidth: 1.5, borderColor: '#1D86FF', backgroundColor: '#061A3A', padding: 8, shadowColor: '#1A8FFF', shadowOpacity: 0.32, shadowRadius: 18, elevation: 10 },
  commandHeader: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 7 },
  commandAvatar: { width: 34, height: 34, borderRadius: 12, borderWidth: 1, borderColor: '#6D5CFF', backgroundColor: '#0C2452', alignItems: 'center', justifyContent: 'center' },
  commandAvatarText: { color: '#D4B9FF', fontSize: 17, fontWeight: '900' },
  commandTitle: { color: '#F4FAFF', fontSize: 11, fontWeight: '900' },
  commandSubtitle: { color: '#7FA4CA', fontSize: 6.5, marginTop: 2 },
  commandMic: { color: '#52D8FF', fontSize: 20 },
  commandBar: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: '#1C5796', backgroundColor: '#031126', flexDirection: 'row', alignItems: 'center', paddingLeft: 9, paddingRight: 4 },
  commandInput: { flex: 1, minHeight: 38, maxHeight: 80, color: '#F2F8FF', fontSize: 11, paddingVertical: 6 },
  voiceButton: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0A2A50', borderWidth: 1, borderColor: '#2B79C7' },
  voiceButtonActive: { backgroundColor: '#132C67', borderColor: '#9A65FF' },
  voiceButtonText: { color: '#5AD9FF', fontSize: 7, fontWeight: '900' },
  sendButton: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginLeft: 4, backgroundColor: '#7350FF' },
  sendButtonDisabled: { opacity: 0.4 },
  sendButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: '900' },

  quickVoice: { position: 'absolute', left: 9, bottom: 74, width: 112, height: 55, borderRadius: 28, borderWidth: 1, borderColor: '#2167B7', backgroundColor: '#061A3A', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, gap: 7, zIndex: 30, shadowColor: '#238EFF', shadowOpacity: 0.5, shadowRadius: 13 },
  quickVoiceCircle: { width: 43, height: 43, borderRadius: 22, borderWidth: 2, borderColor: '#3C7DFF', backgroundColor: '#0A2451', alignItems: 'center', justifyContent: 'center', shadowColor: '#B54DFF', shadowOpacity: 0.9, shadowRadius: 13 },
  quickVoiceIcon: { color: '#65E0FF', fontSize: 24 },
  quickVoiceTitle: { color: '#DFF4FF', fontSize: 7, fontWeight: '900' },
  quickVoiceText: { color: '#7798B8', fontSize: 5.5, marginTop: 2 },

  bottomNav: { position: 'absolute', left: '18%', right: '18%', bottom: 8, height: 55, borderRadius: 28, borderWidth: 1.5, borderColor: '#1D6BC1', backgroundColor: 'rgba(3,17,40,0.96)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', zIndex: 40, shadowColor: '#1B8FFF', shadowOpacity: 0.35, shadowRadius: 16, elevation: 15 },
  bottomNavItem: { flex: 1, alignItems: 'center', justifyContent: 'center', height: 48, borderRadius: 18 },
  bottomNavActive: { backgroundColor: '#0B2F61' },
  bottomNavIcon: { color: '#72B7E9', fontSize: 15 },
  bottomNavLabel: { color: '#B9D0E8', fontSize: 5.5, fontWeight: '800', marginTop: 2 },

  // Kept for the floating voice component and older dashboard helpers.
  floatingOrbButton: { position: 'absolute', right: 7, bottom: 72, width: 70, height: 70, alignItems: 'center', justifyContent: 'center', zIndex: 31 },
  orbPulseRing: { position: 'absolute', width: 55, height: 55, borderRadius: 28, borderWidth: 2, borderColor: '#3ED8FF', backgroundColor: '#4E5AFF' },
  floatingOrbCore: { width: 44, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: '#65DFFF', backgroundColor: '#071C43', alignItems: 'center', justifyContent: 'center', shadowColor: '#A34DFF', shadowOpacity: 0.8, shadowRadius: 15, elevation: 16, overflow: 'hidden' },
  orbInnerGlow: { position: 'absolute', width: 30, height: 30, borderRadius: 15, backgroundColor: '#8C4CFF', opacity: 0.45 },
  orbBars: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  orbBar: { width: 3, borderRadius: 3, backgroundColor: '#EAFBFF' },
  orbCaption: { position: 'absolute', bottom: -3, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#06162F', borderWidth: 1, borderColor: '#1B4E85', borderRadius: 10, paddingHorizontal: 6, paddingVertical: 3 },
  orbStatusDot: { width: 5, height: 5, borderRadius: 3 },
  orbCaptionText: { color: '#B6CBE2', fontSize: 5.5, fontWeight: '800' },

  naturalVoiceStage: { width: 210, height: 210, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  naturalVoiceGlow: { position: 'absolute', width: 150, height: 150, borderRadius: 75, backgroundColor: '#6B4BFF', opacity: 0.22 },
  naturalVoiceRing: { position: 'absolute', width: 132, height: 132, borderRadius: 66, borderWidth: 1.5, borderColor: '#36BFFF', backgroundColor: 'rgba(5,24,58,0.22)' },
  naturalVoiceOrb: { width: 104, height: 104, borderRadius: 52, borderWidth: 1.5, borderColor: '#4ED9FF', backgroundColor: '#071C43', alignItems: 'center', justifyContent: 'center', shadowColor: '#7E55FF', shadowOpacity: 0.8, shadowRadius: 24, elevation: 18 },
  naturalVoiceOrbInner: { position: 'absolute', width: 74, height: 74, borderRadius: 37, backgroundColor: '#6C4DFF', opacity: 0.22 },
  naturalVoiceBars: { height: 40, flexDirection: 'row', alignItems: 'center', gap: 4 },
  naturalVoiceBar: { width: 4, borderRadius: 4, backgroundColor: '#DDF8FF' },
  naturalVoiceStatus: { position: 'absolute', bottom: 20, flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderColor: '#20578F', borderRadius: 12, backgroundColor: '#06162F', paddingHorizontal: 8, paddingVertical: 4 },
  naturalVoiceDot: { width: 5, height: 5, borderRadius: 3 },
  naturalVoiceStatusText: { color: '#9AB5D2', fontSize: 6, fontWeight: '900', letterSpacing: 0.8 },

  // Legacy helper styles retained so the rest of the file stays compatible.
  panel: { borderRadius: 14, borderWidth: 1, borderColor: '#15569B', backgroundColor: '#06172F', padding: 8 },
  panelSubtitle: { color: '#6F91B5', fontSize: 6, marginTop: 2 },
  panelBody: { marginTop: 6 },
  loadingOrb: { width: 86, height: 86, borderRadius: 43, backgroundColor: '#082354', borderWidth: 2, borderColor: '#3AD8FF', alignItems: 'center', justifyContent: 'center', shadowColor: '#7A5CFF', shadowOpacity: 0.8, shadowRadius: 20, elevation: 16 },
  loadingA: { color: '#CDB4FF', fontSize: 32, fontWeight: '900' },
});

const styles = StyleSheet.create({
  screen: { flex: 1 },
  keyboardFrame: { flex: 1 },
  header: {
    minHeight: 84,
    paddingHorizontal: 18,
    paddingBottom: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: {
    width: 42,
    height: 42,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 18, letterSpacing: -0.3 },
  subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  onlineDot: { width: 6, height: 6, borderRadius: 3 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerAccountButton: {
    minWidth: 42,
    height: 38,
    paddingHorizontal: 9,
    borderRadius: 13,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  headerAccountText: { fontSize: 11, fontWeight: '800' },
  languageText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  moreButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  messages: { flex: 1 },
  messageList: {
    paddingHorizontal: 18,
    paddingTop: 112,
    paddingBottom: 14,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  messageRow: { flexDirection: 'row', marginBottom: 18, gap: 8, maxWidth: '90%' },
  assistantRow: { alignSelf: 'flex-start', alignItems: 'flex-end' },
  userRow: { alignSelf: 'flex-end' },
  messageAvatar: {
    width: 23,
    height: 23,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  messageBody: { flexShrink: 1 },
  messageBubble: {
    borderWidth: 1,
    borderRadius: 22,
    borderBottomLeftRadius: 6,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  userBubble: { borderBottomLeftRadius: 18, borderBottomRightRadius: 6 },
  messageText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 23,
    letterSpacing: 0.05,
  },
  userMessageText: { fontFamily: 'Inter_500Medium' },
  messageMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 5,
    marginLeft: 3,
  },
  userMeta: { justifyContent: 'flex-end', marginRight: 2 },
  timeText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  typingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginLeft: 31,
    marginBottom: 14,
  },
  typingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  composerArea: { paddingHorizontal: 14, paddingTop: 8, gap: 9 },
  suggestions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
    paddingBottom: 1,
  },
  suggestionChip: {
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 11,
    paddingVertical: 8,
    maxWidth: '100%',
  },
  suggestionText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  composer: {
    minHeight: 62,
    borderWidth: 1,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingLeft: 13,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 4,
  },
  input: {
    flex: 1,
    maxHeight: 112,
    minHeight: 39,
    paddingTop: 9,
    paddingBottom: 7,
    paddingRight: 5,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    lineHeight: 21,
  },
  composerIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerOrbLayer: {
    position: 'absolute',
    top: '46%',
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 10,
    pointerEvents: 'box-none',
  },
  orbOrbit: { position: 'absolute', width: 72, height: 72, borderRadius: 36, borderWidth: 1, borderStyle: 'dashed', opacity: 0.65 },
  orbOrbitInner: { position: 'absolute', width: 62, height: 62, borderRadius: 31, borderWidth: 1, opacity: 0.5 },
  centerOrbGlow: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerOrb: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 16,
    shadowOpacity: 0.32,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
  },
  orbLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 7, letterSpacing: 2.2, marginTop: 4 },
  orbStatus: { fontFamily: 'Inter_500Medium', fontSize: 8, marginTop: 1 },
  voiceBars: { height: 30, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 3 },
  voiceBar: { width: 3, borderRadius: 3 },
  quickMenuOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.48)', alignItems: 'flex-end', paddingTop: 68, paddingHorizontal: 12 },
  quickMenuCard: { width: '94%', maxWidth: 440, borderRadius: 24, borderWidth: 1, padding: 15, elevation: 14 },
  quickMenuTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  quickMenuGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  menuTile: { width: '23.2%', minWidth: 78, flexGrow: 1, minHeight: 78, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center', padding: 7 },
  menuTileText: { fontSize: 10, fontWeight: '800', marginTop: 6, textAlign: 'center' },
  menuDanger: { height: 48, borderRadius: 15, borderWidth: 1, marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  cameraModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 22,
  },
  cameraCard: {
    width: '100%',
    maxWidth: 420,
    borderRadius: 24,
    padding: 18,
    backgroundColor: '#12191A',
  },
  cameraTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  cameraImage: {
    width: '100%',
    height: 320,
    borderRadius: 16,
    backgroundColor: '#050505',
  },
  cameraHint: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 10,
  },
  cameraCloseButton: {
    alignSelf: 'flex-end',
    marginTop: 14,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 14,
  },
  voiceBubbleWrap: {
    position: 'absolute',
    right: 18,
    zIndex: 20,
  },
  voiceBubble: {
    width: 62,
    height: 62,
    borderRadius: 31,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 7,
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  footerNote: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    paddingHorizontal: 4,
    paddingBottom: 2,
  },

  lockScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  lockTitle: { marginTop: 18, fontSize: 24, fontWeight: '800', textAlign: 'center' },
  lockText: { marginTop: 10, fontSize: 15, lineHeight: 22, textAlign: 'center' },
  unlockButton: { marginTop: 22, minWidth: 150, alignItems: 'center', paddingVertical: 13, paddingHorizontal: 24, borderRadius: 18 },
  accountLink: { marginTop: 12, paddingVertical: 10, paddingHorizontal: 18, borderWidth: 1, borderRadius: 14 },
  accountOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.58)' },
  settingsCard: { width: '92%', maxWidth: 520, borderRadius: 24, borderWidth: 1, padding: 18 },
  settingsHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  settingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, borderBottomWidth: 1 },
  settingCopy: { flex: 1, paddingRight: 14 },
  settingTitle: { fontSize: 15, fontWeight: '800' },
  settingDesc: { fontSize: 12, lineHeight: 17, marginTop: 3 },
  settingButton: { minWidth: 44, height: 38, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  dangerButton: { height: 48, borderRadius: 14, borderWidth: 1, marginTop: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  accountCard: { borderTopWidth: 1, borderLeftWidth: 1, borderRightWidth: 1, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 30 },
  accountInput: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginTop: 10 },
  accountAction: { flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 14, borderWidth: 1 },
});
