import { Platform, PermissionsAndroid } from 'react-native';
import { listenForText } from './voiceInput';
import {
  enrollSpeakerSample,
  verifyLiveSpeaker,
  type SpeakerVerificationResult,
} from './speakerVerification';
import { stopWakeWord } from './androidActions';
import type { AssistantLanguage } from './offlineBrain';

/**
 * Abir AI's single JavaScript microphone gate.
 *
 * Every foreground voice operation (conversation + owner voice verification)
 * passes through this gate. Before taking the microphone we always stop the
 * background wake-word service so Android never has two recognizers/recorders
 * competing for RECORD_AUDIO.
 */
let activeOperation: Promise<unknown> = Promise.resolve();

async function acquireMicrophone(): Promise<() => void> {
  let release!: () => void;
  const previous = activeOperation;
  activeOperation = new Promise<void>(resolve => { release = resolve; });
  await previous;

  if (Platform.OS === 'android') {
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
      release();
      throw new Error('Microphone permission is required.');
    }
    // The native background wake-word recognizer must never own the mic while
    // a foreground operation is running.
    await stopWakeWord().catch(() => {});
  }

  return release;
}

async function exclusive<T>(operation: () => Promise<T>): Promise<T> {
  const release = await acquireMicrophone();
  try {
    return await operation();
  } finally {
    release();
  }
}

export async function listenWithUnifiedVoiceManager(
  language: AssistantLanguage,
): Promise<string | null> {
  return exclusive(() => listenForText(language));
}

export async function enrollOwnerVoiceWithUnifiedManager() {
  return exclusive(() => enrollSpeakerSample());
}

export async function verifyOwnerVoiceWithUnifiedManager(): Promise<SpeakerVerificationResult> {
  return exclusive(() => verifyLiveSpeaker());
}
