import AsyncStorage from '@react-native-async-storage/async-storage';
import { recordSpeakerSample } from './androidActions';

const PROFILE_KEY = 'abir-ai-speaker-profile-v1';
const MAX_SAMPLES = 5;
const DEFAULT_THRESHOLD = 0.91;

type SpeakerProfile = {
  version: 1;
  samples: number[][];
  threshold: number;
  createdAt: number;
};

const normalize = (v: number[]) => {
  let sum = 0;
  for (const x of v) sum += x * x;
  const norm = Math.sqrt(sum);
  return norm > 1e-9 ? v.map(x => x / norm) : [];
};

function cosine(a: number[], b: number[]) {
  if (!a.length || !b.length || a.length !== b.length) return -1;
  let dot = 0;
  let aa = 0;
  let bb = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    aa += a[i] * a[i];
    bb += b[i] * b[i];
  }
  if (aa <= 1e-9 || bb <= 1e-9) return -1;
  return dot / Math.sqrt(aa * bb);
}

export async function getSpeakerProfile(): Promise<SpeakerProfile | null> {
  try {
    const raw = await AsyncStorage.getItem(PROFILE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SpeakerProfile;
    if (parsed?.version !== 1 || !Array.isArray(parsed.samples)) return null;
    const samples = parsed.samples.filter(v => Array.isArray(v) && v.length > 0);
    return samples.length ? { ...parsed, samples } : null;
  } catch {
    return null;
  }
}

export async function clearSpeakerProfile() {
  await AsyncStorage.removeItem(PROFILE_KEY);
}

export async function enrollSpeakerSample(): Promise<{ ok: boolean; count: number }> {
  const vector = await recordSpeakerSample(2600);
  if (!vector.length) return { ok: false, count: (await getSpeakerProfile())?.samples.length ?? 0 };

  const current = await getSpeakerProfile();
  const samples = [...(current?.samples ?? []), normalize(vector)].slice(-MAX_SAMPLES);
  const profile: SpeakerProfile = {
    version: 1,
    samples,
    threshold: current?.threshold ?? DEFAULT_THRESHOLD,
    createdAt: current?.createdAt ?? Date.now(),
  };
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  return { ok: true, count: samples.length };
}

export type SpeakerVerificationResult = { verified: boolean; score: number; enrolled: boolean };

export async function verifyLiveSpeaker(): Promise<SpeakerVerificationResult> {
  const profile = await getSpeakerProfile();
  if (!profile || profile.samples.length < 3) {
    return { verified: false, score: 0, enrolled: false };
  }

  const vector = normalize(await recordSpeakerSample(2400));
  if (!vector.length) return { verified: false, score: 0, enrolled: true };

  // Compare against every enrolled sample and use the strongest two-sample
  // consensus. This reduces sensitivity to one noisy enrollment recording.
  const scores = profile.samples
    .map(sample => cosine(vector, sample))
    .filter(score => score >= -1)
    .sort((a, b) => b - a);
  if (!scores.length) return { verified: false, score: 0, enrolled: true };
  const top = scores.slice(0, Math.min(2, scores.length));
  const score = top.reduce((sum, value) => sum + value, 0) / top.length;
  return { verified: score >= profile.threshold, score, enrolled: true };
}

export { MAX_SAMPLES as MAX_SPEAKER_SAMPLES };
