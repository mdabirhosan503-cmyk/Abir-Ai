import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';

export type LoginProvider = 'gemini' | 'compatible' | 'custom';

type Props = {
  language: 'bn' | 'en';
  initialEmail?: string;
  initialApiKey?: string;
  onSubmit: (email: string, password: string, apiKey: string, provider: LoginProvider) => void;
};

function LoginAvatar() {
  return (
    <Svg width={94} height={94} viewBox="0 0 94 94">
      <Circle cx="47" cy="47" r="43" fill="#071C42" stroke="#2ED8FF" strokeWidth="2" />
      <Circle cx="47" cy="40" r="18" fill="#A6DBFF" stroke="#75ECFF" strokeWidth="1.5" />
      <Path d="M28 70c4-14 11-21 19-21s15 7 19 21" fill="#101A42" stroke="#9B4DFF" strokeWidth="2" />
      <Path d="M30 39c3-15 10-23 19-23 12 0 19 9 19 23-7-5-12-9-18-15-5 8-11 13-20 15Z" fill="#151B4D" />
      <Circle cx="41" cy="41" r="2.5" fill="#09152F" /><Circle cx="54" cy="41" r="2.5" fill="#09152F" />
      <Path d="M42 51c3 2 7 2 10 0" fill="none" stroke="#25537B" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  );
}

export function AbirLoginScreen({ language, initialEmail = '', initialApiKey = '', onSubmit }: Props) {
  const bn = language === 'bn';
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');
  const [apiKey, setApiKey] = useState(initialApiKey);
  const [provider, setProvider] = useState<LoginProvider>('gemini');
  const [showPassword, setShowPassword] = useState(false);

  return (
    <LinearGradient colors={['#010817', '#061B3C', '#090522']} style={styles.root}>
      <View pointerEvents="none" style={styles.stars}>{Array.from({ length: 22 }).map((_, i) => <View key={i} style={[styles.star, { left: `${(i * 41) % 100}%`, top: `${(i * 59) % 100}%` }]} />)}</View>
      <View style={styles.card}>
        <View style={styles.logo}><Text style={styles.logoA}>A</Text></View>
        <LoginAvatar />
        <Text style={styles.title}>Abir AI</Text>
        <Text style={styles.subtitle}>{bn ? 'তোমার Personal AI Assistant' : 'Your Personal AI Assistant'}</Text>
        <Text style={styles.caption}>{bn ? 'Email + Password + API দিয়ে Login' : 'Login with Email + Password + API'}</Text>

        <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor="#6684A8" style={styles.input} />
        <View style={styles.passwordRow}>
          <TextInput value={password} onChangeText={setPassword} secureTextEntry={!showPassword} placeholder="Password" placeholderTextColor="#6684A8" style={[styles.input, { flex: 1, borderWidth: 0, marginTop: 0 }]} />
          <Pressable onPress={() => setShowPassword(v => !v)}><Text style={styles.show}>{showPassword ? 'Hide' : 'Show'}</Text></Pressable>
        </View>
        <TextInput value={apiKey} onChangeText={setApiKey} autoCapitalize="none" placeholder={bn ? 'API Key' : 'API Key'} placeholderTextColor="#6684A8" style={styles.input} />

        <Text style={styles.providerLabel}>{bn ? 'AI Provider' : 'AI Provider'}</Text>
        <View style={styles.providerRow}>
          {([
            ['gemini', 'Gemini + Web'],
            ['compatible', 'Any Compatible'],
            ['custom', 'Custom API'],
          ] as const).map(([id, label]) => (
            <Pressable key={id} onPress={() => setProvider(id)} style={[styles.provider, provider === id && styles.providerActive]}>
              <Text style={[styles.providerText, provider === id && styles.providerTextActive]}>{label}</Text>
            </Pressable>
          ))}
        </View>

        <Pressable onPress={() => onSubmit(email.trim(), password, apiKey.trim(), provider)} style={styles.loginButton}>
          <Text style={styles.loginText}>{bn ? 'Login / Create Account' : 'Login / Create Account'}</Text>
        </Pressable>
        <Text style={styles.note}>{bn ? 'API Key শুধু Secure Storage-এ রাখা হবে। Provider অনুযায়ী online engine ব্যবহার করবে; offline brain সবসময় থাকবে।' : 'The API key is kept in secure storage. The selected provider powers online features; the offline brain remains available.'}</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 18 },
  stars: { ...StyleSheet.absoluteFillObject },
  star: { position: 'absolute', width: 2, height: 2, borderRadius: 1, backgroundColor: '#5CE4FF', opacity: 0.7 },
  card: { width: '100%', maxWidth: 430, borderWidth: 1.5, borderColor: '#1769B1', borderRadius: 28, backgroundColor: 'rgba(3,13,35,0.95)', padding: 20, alignItems: 'center', shadowColor: '#2EBDFF', shadowOpacity: 0.4, shadowRadius: 24, elevation: 16 },
  logo: { width: 54, height: 54, borderRadius: 17, borderWidth: 1.5, borderColor: '#31D7FF', backgroundColor: '#0A2450', alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  logoA: { color: '#F0E8FF', fontSize: 32, fontWeight: '900', textShadowColor: '#35D8FF', textShadowRadius: 10 },
  title: { color: '#F4FBFF', fontSize: 27, fontWeight: '900', marginTop: 5 },
  subtitle: { color: '#93B8DD', fontSize: 12, marginTop: 3 },
  caption: { color: '#55DFFF', fontSize: 10, fontWeight: '800', marginTop: 13, marginBottom: 9 },
  input: { width: '100%', minHeight: 48, borderWidth: 1, borderColor: '#174E85', borderRadius: 14, backgroundColor: '#06162F', color: '#E9F7FF', paddingHorizontal: 14, marginTop: 9 },
  passwordRow: { width: '100%', minHeight: 48, borderWidth: 1, borderColor: '#174E85', borderRadius: 14, backgroundColor: '#06162F', flexDirection: 'row', alignItems: 'center', marginTop: 9, paddingRight: 10 },
  show: { color: '#5CE3FF', fontSize: 10, fontWeight: '900' },
  providerLabel: { alignSelf: 'flex-start', color: '#A9C9E7', fontSize: 9, fontWeight: '800', marginTop: 12 },
  providerRow: { width: '100%', flexDirection: 'row', gap: 5, marginTop: 6 },
  provider: { flex: 1, minHeight: 37, borderWidth: 1, borderColor: '#174E85', borderRadius: 11, backgroundColor: '#06162F', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  providerActive: { borderColor: '#35DFFF', backgroundColor: '#0A2B50' },
  providerText: { color: '#789ABB', fontSize: 7, textAlign: 'center', fontWeight: '800' },
  providerTextActive: { color: '#E7FAFF' },
  loginButton: { width: '100%', minHeight: 50, borderRadius: 16, backgroundColor: '#087ED1', borderWidth: 1, borderColor: '#4BE7FF', alignItems: 'center', justifyContent: 'center', marginTop: 15, shadowColor: '#23BFFF', shadowOpacity: 0.55, shadowRadius: 14, elevation: 8 },
  loginText: { color: '#FFFFFF', fontSize: 12, fontWeight: '900' },
  note: { color: '#6485A8', fontSize: 8, lineHeight: 13, textAlign: 'center', marginTop: 11 },
});
