package expo.modules.abirapp

import android.Manifest
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.os.Handler
import android.app.AlarmManager
import android.app.PendingIntent
import android.os.BatteryManager
import android.os.StatFs
import android.os.Looper
import org.json.JSONObject
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import java.util.Locale

class AbirAppLauncherModule : Module() {
  private var textToSpeech: TextToSpeech? = null
  private var textToSpeechReady = false
  private val ttsHandler = Handler(Looper.getMainLooper())
  private val ttsWaiters = mutableListOf<() -> Unit>()

  private suspend fun speakAndroidText(text: String, languageTag: String, gender: String): Boolean =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
      val context = appContext.reactContext
        ?: run {
          continuation.resume(false) {}
          return@suspendCancellableCoroutine
        }

      ttsHandler.post {
        fun speakNow() {
          if (!continuation.isActive) return
          val tts = textToSpeech
          if (!textToSpeechReady || tts == null) {
            continuation.resume(false) {}
            return
          }
          val requested = Locale.forLanguageTag(languageTag)
          var localeResult = tts.setLanguage(requested)
          if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            localeResult = tts.setLanguage(Locale.US)
          }
          if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            continuation.resume(false) {}
            return
          }
          tts.setPitch(if (gender.equals("male", true)) 0.92f else 1.02f)
          tts.setSpeechRate(if (languageTag.startsWith("bn")) 0.9f else 0.94f)
          val utteranceId = "abir-${System.nanoTime()}"
          val result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, android.os.Bundle(), utteranceId)
          continuation.resume(result == TextToSpeech.SUCCESS) {}
        }

        if (textToSpeechReady && textToSpeech != null) {
          speakNow()
          return@post
        }

        ttsWaiters.add { speakNow() }
        if (textToSpeech == null) {
          textToSpeech = TextToSpeech(context.applicationContext) { status ->
            ttsHandler.post {
              textToSpeechReady = status == TextToSpeech.SUCCESS
              val waiters = ttsWaiters.toList()
              ttsWaiters.clear()
              waiters.forEach { waiter -> waiter() }
            }
          }
        }
      }

      // If the JS caller cancels, the waiter remains harmless because speakNow
      // checks continuation.isActive before speaking/resuming.
    }

  private fun deviceDiagnosticsJson(): String {
    val context = appContext.reactContext ?: return "{}"
    val battery = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
    val batteryPct = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    val stat = StatFs(context.filesDir.absolutePath)
    val freeStorage = stat.availableBytes
    val totalStorage = stat.totalBytes
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val network = cm?.activeNetwork
    val caps = if (network != null) cm.getNetworkCapabilities(network) else null
    val online = caps != null
    val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    return JSONObject()
      .put("batteryPercent", batteryPct)
      .put("freeStorageBytes", freeStorage)
      .put("totalStorageBytes", totalStorage)
      .put("online", online)
      .put("wifi", wifi)
      .put("cellular", cellular)
      .put("sdk", Build.VERSION.SDK_INT)
      .toString()
  }

  private fun scheduleReminderInternal(text: String, delayMs: Long): Boolean {
    val context = appContext.reactContext ?: return false
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
    val intent = Intent(context, AbirReminderReceiver::class.java).putExtra("text", text)
    val requestCode = (System.currentTimeMillis() and 0x7fffffff).toInt()
    val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val trigger = System.currentTimeMillis() + delayMs
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
      else alarm.set(AlarmManager.RTC_WAKEUP, trigger, pending)
      true
    } catch (_: Exception) { false }
  }

  private fun stopAndroidText() {
    ttsHandler.post {
      try { textToSpeech?.stop() } catch (_: Exception) {}
    }
  }

  private suspend fun getCurrentLocationJson(): String =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
      val context = appContext.reactContext
        ?: run {
          continuation.resume("") {}
          return@suspendCancellableCoroutine
        }

      if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
      ) {
        continuation.resume("") {}
        return@suspendCancellableCoroutine
      }

      val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        ?: run {
          continuation.resume("") {}
          return@suspendCancellableCoroutine
        }

      val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        .filter { provider ->
          try { manager.isProviderEnabled(provider) } catch (_: Exception) { false }
        }

      if (providers.isEmpty()) {
        continuation.resume("") {}
        return@suspendCancellableCoroutine
      }

      var finished = false
      val handler = Handler(Looper.getMainLooper())
      lateinit var listener: LocationListener

      fun finish(location: Location?) {
        if (finished || !continuation.isActive) return
        finished = true
        try { manager.removeUpdates(listener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)

        if (location == null) {
          continuation.resume("") {}
          return
        }

        var addressText = ""
        try {
          @Suppress("DEPRECATION")
          val addresses: List<Address>? = Geocoder(context, Locale.getDefault()).getFromLocation(
            location.latitude,
            location.longitude,
            1,
          )
          val address = addresses?.firstOrNull()
          if (address != null) {
            val parts = listOfNotNull(
              address.getAddressLine(0)?.takeIf { it.isNotBlank() },
              address.locality?.takeIf { it.isNotBlank() },
              address.subAdminArea?.takeIf { it.isNotBlank() },
              address.adminArea?.takeIf { it.isNotBlank() },
              address.countryName?.takeIf { it.isNotBlank() },
            ).distinct()
            addressText = parts.joinToString(", ")
          }
        } catch (_: Exception) {
          addressText = ""
        }

        val result = JSONObject()
          .put("latitude", location.latitude)
          .put("longitude", location.longitude)
          .put("accuracy", location.accuracy.toDouble())
          .put("provider", location.provider ?: "")
          .put("address", addressText)
          .toString()
        continuation.resume(result) {}
      }

      listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
          finish(location)
        }
        override fun onProviderDisabled(provider: String) {}
        override fun onProviderEnabled(provider: String) {}
      }

      // Prefer a recent cached location for a fast answer, but request a fresh fix
      // when the cache is unavailable or clearly stale.
      var bestCached: Location? = null
      for (provider in providers) {
        try {
          val cached = manager.getLastKnownLocation(provider)
          if (cached != null && (bestCached == null || cached.time > bestCached!!.time)) bestCached = cached
        } catch (_: SecurityException) {}
      }
      if (bestCached != null && System.currentTimeMillis() - bestCached!!.time < 120_000L) {
        finish(bestCached)
        return@suspendCancellableCoroutine
      }

      try {
        for (provider in providers) {
          manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        }
      } catch (_: SecurityException) {
        finish(null)
        return@suspendCancellableCoroutine
      }

      handler.postDelayed({
        if (!finished) finish(bestCached)
      }, 12_000L)

      continuation.invokeOnCancellation {
        try { manager.removeUpdates(listener) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
      }
    }

  private fun launcherActivities(): List<ResolveInfo> {
    val context = appContext.reactContext
      ?: throw IllegalStateException("Android context is unavailable")
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val packageManager = context.packageManager

    @Suppress("DEPRECATION")
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      packageManager.queryIntentActivities(
        intent,
        PackageManager.ResolveInfoFlags.of(0L)
      )
    } else {
      packageManager.queryIntentActivities(intent, 0)
    }
  }

  override fun definition() = ModuleDefinition {
    Name("AbirAppLauncher")


    AsyncFunction("startWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Microphone permission has not been granted")
      }
      val intent = Intent(context, WakeWordService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
      true
    }

    AsyncFunction("stopWakeWord") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.stopService(Intent(context, WakeWordService::class.java))
      true
    }

    AsyncFunction("speakText") Coroutine { text: String, languageTag: String, gender: String ->
      speakAndroidText(text, languageTag, gender)
    }

    AsyncFunction("stopSpeaking") {
      stopAndroidText()
      true
    }

    AsyncFunction("getDeviceDiagnostics") {
      deviceDiagnosticsJson()
    }

    AsyncFunction("scheduleReminder") { text: String, delayMs: Double ->
      scheduleReminderInternal(text, delayMs.toLong())
    }

    AsyncFunction("getCurrentLocation") Coroutine { ->
      getCurrentLocationJson()
    }

    AsyncFunction("canDrawOverlays") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) true
      else Settings.canDrawOverlays(context)
    }

    AsyncFunction("openOverlaySettings") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }
      true
    }

    AsyncFunction("isAccessibilityEnabled") {
      AbirAccessibilityService.isRunning()
    }

    AsyncFunction("performGlobalAction") { action: String ->
      AbirAccessibilityService.performGlobal(action)
    }

    AsyncFunction("readCurrentScreenText") {
      AbirAccessibilityService.readScreen()
    }

    AsyncFunction("getScreenSnapshot") {
      AbirAccessibilityService.screenSnapshot()
    }

    AsyncFunction("getVolumePercent") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction -1.0
      val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
      if (max <= 0) return@AsyncFunction 0.0
      val current = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
      current.toDouble() * 100.0 / max.toDouble()
    }

    AsyncFunction("setVolumePercent") { percent: Double ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      val clamped = percent.coerceIn(0.0, 100.0)
      val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
      val target = kotlin.math.round(max * clamped / 100.0).toInt().coerceIn(0, max)
      audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, target, 0)
      true
    }

    AsyncFunction("setFlashlight") { enabled: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return@AsyncFunction false
      val camera = context.getSystemService(Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
        ?: return@AsyncFunction false
      val cameraId = camera.cameraIdList.firstOrNull { id ->
        camera.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
      } ?: return@AsyncFunction false
      try {
        camera.setTorchMode(cameraId, enabled)
        true
      } catch (_: Exception) {
        false
      }
    }

    AsyncFunction("controlMedia") { action: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      val key = when (action.lowercase(Locale.ROOT)) {
        "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
        "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
        "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
        "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
        else -> return@AsyncFunction false
      }
      val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key)
      val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key)
      audio.dispatchMediaKeyEvent(down)
      audio.dispatchMediaKeyEvent(up)
      true
    }

    AsyncFunction("setRingerMode") { mode: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      when (mode.lowercase(Locale.ROOT)) {
        "normal" -> audio.ringerMode = android.media.AudioManager.RINGER_MODE_NORMAL
        "vibrate" -> audio.ringerMode = android.media.AudioManager.RINGER_MODE_VIBRATE
        else -> return@AsyncFunction false
      }
      true
    }

    AsyncFunction("adjustVolume") { direction: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val audio = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        ?: return@AsyncFunction false
      when (direction.lowercase(Locale.ROOT)) {
        "up" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_RAISE, 0)
        "down" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_LOWER, 0)
        "mute" -> audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_MUTE, 0)
        else -> return@AsyncFunction false
      }
      true
    }

    AsyncFunction("openSystemSettings") { kind: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      // Deliberately do not expose the general Android Settings screen.
      // Wi-Fi/Bluetooth/mobile-data commands only open the OS-provided control
      // panel. Android normally blocks ordinary apps from silently toggling
      // these protected radios on behalf of the user.
      val normalized = kind.lowercase(Locale.ROOT)
      val intent = when (normalized) {
        "wifi-settings" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          Intent(Settings.Panel.ACTION_WIFI)
        } else {
          Intent(Settings.ACTION_WIFI_SETTINGS)
        }
        "bluetooth-settings" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "mobile-data-panel" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
          Intent(Settings.ACTION_WIRELESS_SETTINGS)
        }
        "settings" -> Intent(Settings.ACTION_SETTINGS)
        else -> return@AsyncFunction false
      }
      context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      true
    }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
      true
    }

    AsyncFunction("sendMessageViaAccessibility") {
      packageName: String, recipient: String, message: String ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.sendMessage(packageName, recipient, message) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(12, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("searchAndOpenInApp") Coroutine { packageName: String, query: String ->
      kotlinx.coroutines.suspendCancellableCoroutine<Boolean> { continuation ->
        AbirAccessibilityService.searchAndOpenInApp(packageName, query) { ok ->
          if (continuation.isActive) continuation.resume(ok) {}
        }
      }
    }

    AsyncFunction("typeIntoFocusedField") { text: String ->
      AbirAccessibilityService.typeIntoFocusedField(text)
    }

    AsyncFunction("clickTextOnScreen") { text: String ->
      AbirAccessibilityService.clickTextOnScreen(text)
    }

    AsyncFunction("pressImeEnter") {
      AbirAccessibilityService.pressImeEnter()
    }

    AsyncFunction("scrollScreen") { direction: String ->
      AbirAccessibilityService.scrollScreen(direction)
    }

    AsyncFunction("callViaApp") { appName: String, recipient: String ->
      val lock = java.util.concurrent.CountDownLatch(1)
      var result = false
      AbirAccessibilityService.callContact(appName, recipient) { ok ->
        result = ok
        lock.countDown()
      }
      lock.await(15, java.util.concurrent.TimeUnit.SECONDS)
      result
    }

    AsyncFunction("isOnline") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val manager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
          ?: return@AsyncFunction false
      val activeNetwork = manager.activeNetwork ?: return@AsyncFunction false
      val capabilities = manager.getNetworkCapabilities(activeNetwork)
        ?: return@AsyncFunction false
      capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    AsyncFunction("isOfflineSpeechRecognitionAvailable") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        false
      } else {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
      }
    }

    // Standard Android speech recognition fallback. It can use the installed
    // speech service when true on-device recognition is unavailable.
    AsyncFunction("recognizeSpeech") Coroutine { localeTag: String, preferOffline: Boolean ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")

      kotlinx.coroutines.suspendCancellableCoroutine<List<String>> { continuation ->
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var recognizer: SpeechRecognizer? = null
        var bestPartial: List<String> = emptyList()
        val cleanup = {
          try { recognizer?.destroy() } catch (_: Exception) {}
          recognizer = null
        }

        mainHandler.post {
          try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
              override fun onReadyForSpeech(params: android.os.Bundle?) {}
              override fun onBeginningOfSpeech() {}
              override fun onRmsChanged(rmsdB: Float) {}
              override fun onBufferReceived(buffer: ByteArray?) {}
              override fun onEndOfSpeech() {}
              override fun onPartialResults(partialResults: android.os.Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() } ?: emptyList()
                if (partial.isNotEmpty()) bestPartial = partial.take(5)
              }
              override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
              override fun onError(error: Int) {
                if (continuation.isActive) continuation.resume(bestPartial) {}
                cleanup()
              }
              override fun onResults(results: android.os.Bundle?) {
                val matches = results
                  ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                  ?.filter { it.isNotBlank() }
                  ?.take(5)
                  ?: emptyList()
                if (continuation.isActive) continuation.resume(matches) {}
                cleanup()
              }
            })

            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
              putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1900L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 650L)
            }
            recognizer?.startListening(intent)
          } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(emptyList()) {}
            cleanup()
          }
        }

        continuation.invokeOnCancellation {
          mainHandler.post { cleanup() }
        }
      }
    }

    // True on-device speech recognition. This path never asks the network for speech data.
    // Android 12+ is required for the on-device recognizer API.
    AsyncFunction("recognizeOffline") Coroutine { localeTag: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
        return@Coroutine emptyList<String>()
      }

      kotlinx.coroutines.suspendCancellableCoroutine<List<String>> { continuation ->
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var recognizer: SpeechRecognizer? = null
        var bestPartial: List<String> = emptyList()
        val cleanup = {
          try { recognizer?.destroy() } catch (_: Exception) {}
          recognizer = null
        }

        mainHandler.post {
          try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
              override fun onReadyForSpeech(params: android.os.Bundle?) {}
              override fun onBeginningOfSpeech() {}
              override fun onRmsChanged(rmsdB: Float) {}
              override fun onBufferReceived(buffer: ByteArray?) {}
              override fun onEndOfSpeech() {}
              override fun onPartialResults(partialResults: android.os.Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() } ?: emptyList()
                if (partial.isNotEmpty()) bestPartial = partial.take(5)
              }
              override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
              override fun onError(error: Int) {
                if (continuation.isActive) continuation.resume(bestPartial) {}
                cleanup()
              }
              override fun onResults(results: android.os.Bundle?) {
                val matches = results
                  ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                  ?.filter { it.isNotBlank() }
                  ?.take(5)
                  ?: emptyList()
                if (continuation.isActive) continuation.resume(matches) {}
                cleanup()
              }
            })

            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
              putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
              putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1900L)
              putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            }
            recognizer?.startListening(intent)
          } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(emptyList()) {}
            cleanup()
          }
        }

        continuation.invokeOnCancellation {
          mainHandler.post { cleanup() }
        }
      }
    }

    AsyncFunction("getContacts") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Contacts permission has not been granted")
      }

      val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.TYPE,
        ContactsContract.CommonDataKinds.Phone.LABEL
      )
      val contacts = linkedMapOf<String, Map<String, String>>()
      context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection,
        null,
        null,
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
      )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
        val nameColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val typeColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
        val labelColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)

        while (cursor.moveToNext()) {
          val id = cursor.getString(idColumn) ?: continue
          val name = cursor.getString(nameColumn)?.trim().orEmpty()
          val number = cursor.getString(numberColumn)?.trim().orEmpty()
          if (name.isBlank() || number.isBlank()) continue

          val type = cursor.getInt(typeColumn)
          val customLabel = cursor.getString(labelColumn)
          val phoneLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
            context.resources,
            type,
            customLabel
          ).toString()
          val key = "$id:$number"
          contacts.putIfAbsent(
            key,
            mapOf(
              "contactId" to id,
              "displayName" to name,
              "phoneNumber" to number,
              "phoneLabel" to phoneLabel
            )
          )
        }
      }
      contacts.values.toList()
    }

    AsyncFunction("getLaunchableApps") {
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val packageManager = context.packageManager

      launcherActivities()
        .groupBy { it.activityInfo.packageName }
        .mapNotNull { (packageName, activities) ->
          val defaultActivityName =
            packageManager.getLaunchIntentForPackage(packageName)?.component?.className
          val activity = activities.firstOrNull {
            it.activityInfo.name == defaultActivityName
          } ?: activities.firstOrNull() ?: return@mapNotNull null
          val label = activity.activityInfo.applicationInfo
            .loadLabel(packageManager)
            .toString()
            .trim()

          if (label.isBlank()) return@mapNotNull null

          mapOf(
            "label" to label,
            "packageName" to packageName,
            "activityName" to activity.activityInfo.name
          )
        }
        .sortedBy { it["label"]?.lowercase(Locale.ROOT) }
    }

    AsyncFunction("launchApp") { packageName: String, activityName: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val isStillLaunchable = launcherActivities().any {
        it.activityInfo.packageName == packageName &&
          it.activityInfo.name == activityName
      }
      if (!isStillLaunchable) {
        throw IllegalStateException("That app is no longer available")
      }

      val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(packageName, activityName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }

    AsyncFunction("openDialer") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_DIAL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      if (intent.resolveActivity(context.packageManager) == null) {
        throw IllegalStateException("No dialer app is available")
      }
      context.startActivity(intent)
      true
    }

    AsyncFunction("placeDirectCall") { phoneNumber: String ->
      val context = appContext.reactContext
        ?: throw IllegalStateException("Android context is unavailable")
      if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        throw SecurityException("Phone-call permission has not been granted")
      }
      val sanitized = phoneNumber.trim()
      if (sanitized.isBlank()) throw IllegalArgumentException("Phone number is empty")
      val intent = Intent(
        Intent.ACTION_CALL,
        Uri.fromParts("tel", sanitized, null)
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      true
    }
  }
}
