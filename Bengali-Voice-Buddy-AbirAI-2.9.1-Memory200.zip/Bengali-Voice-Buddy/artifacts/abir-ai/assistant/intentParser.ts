export function extractAppQuery(text: string) {
  const openingRequested =
    /(?:\bopen\b|\blaunch\b|\bstart\b|\bgo\s+to\b|ওপেন|খোলো|খুলুন|খুলে|চালু)/i.test(
      text,
    );
  if (!openingRequested) return null;

  const query = text
    .replace(
      /\b(?:please|kindly|can you|could you|the|my|app)\b/gi,
      ' ',
    )
    .replace(/\b(?:open|launch|start|go\s+to)\b/gi, ' ')
    .replace(
      /(?:দয়া করে|দয়া করে|আমাকে|একটু|ওপেন|খুলে দাও|খুলে দিন|খুলে দিও|খুলুন|খোলো|খুলে|চালু করে দাও|চালু করো|চালু করুন|চালু|করো|করুন|দাও|দিন|দিয়ে দাও|অ্যাপটি|অ্যাপ|টা|টাকে)/g,
      ' ',
    )
    .replace(/[?!।,]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractCallQuery(text: string) {
  const english = text.match(
    /^\s*(?:please\s+)?(?:call|phone|dial|ring)\s+(?:my\s+)?(.+?)\s*$/i,
  );

  // Natural Bengali forms, e.g.
  // "Ashik নামে নাম্বারে কল দাও", "Ashik-কে কল করো",
  // "Ashik এর কাছে ফোন দাও", "আম্মুকে কল করো".
  const bengali = text.match(
    /^\s*(?:আমাকে\s+)?(.+?)(?:\s+নামে)?(?:\s+নাম্বারে|\s+নম্বরে|\s+এর\s+কাছে|\s+কে)?\s+(?:কল|ফোন|ডায়াল|ডায়াল)(?:\s+(?:দাও|দিন|দিতে পারো|করো|করুন|করবে|দিতে পারবে))?\s*$/u,
  );

  const prefix = text.match(
    /^\s*(?:আমাকে\s*)?(?:কল|ফোন|ডায়াল|ডায়াল)\s+(?:(?:করো|করুন|দাও|দিন)\s+)?(.+?)\s*$/u,
  );

  const rawQuery = english?.[1] ?? bengali?.[1] ?? prefix?.[1];
  if (!rawQuery) return null;

  const query = rawQuery
    .replace(/\b(?:please|now|my)\b/gi, ' ')
    .replace(/[-–—]?\s*কে$/u, ' ')
    .replace(
      /(?:দয়া করে|দয়া করে|একটু|আমার|নামে|নাম্বারে|নম্বরে|এর|কাছে|কে|কল|ফোন|ডায়াল|ডায়াল|করো|করুন|দাও|দিন|দিতে পারো|দিতে পারবে|করবে|এখন)/gu,
      ' ',
    )
    .replace(/[?!।,.:;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractDirectPhoneNumber(text: string) {
  const normalizedDigits = text.replace(/[০-৯]/g, (digit) =>
    String('০১২৩৪৫৬৭৮৯'.indexOf(digit)),
  );

  const match = normalizedDigits.match(/(?:^|\s|["“'‘(])((?:\+?\d[\d\s().-]{7,}\d))(?:$|\s|["”'’)]|[-–—])/);
  if (!match) return null;

  const number = match[1].replace(/[^+\d]/g, '');
  const digitsOnly = number.replace(/\D/g, '');
  if (digitsOnly.length < 8 || digitsOnly.length > 15) return null;
  return number;
}
