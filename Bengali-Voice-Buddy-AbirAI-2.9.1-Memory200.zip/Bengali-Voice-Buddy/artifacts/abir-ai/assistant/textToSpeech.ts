import * as Speech from 'expo-speech';
import type { AssistantLanguage } from './offlineBrain';
import { chooseSpeechVoice, type SpeechVoice } from './voiceSelection';
import type { VoiceGenderPreference } from './voicePreferences';

export type SpeechStartOptions = {
  text: string;
  language: AssistantLanguage;
  voiceGender: VoiceGenderPreference;
  voices: SpeechVoice[];
  onDone?: () => void;
  onError?: () => void;
};

export async function speakAssistantText({
  text,
  language,
  voiceGender,
  voices,
  onDone,
  onError,
}: SpeechStartOptions) {
  const selection = chooseSpeechVoice(voices, voiceGender, language);
  await Speech.stop();
  Speech.speak(text, {
    language: language === 'bn' ? 'bn-BD' : 'en-US',
    ...(selection.voice ? { voice: selection.voice.identifier } : {}),
    pitch: 1.02,
    rate: 0.94,
    onDone,
    onStopped: onDone,
    onError,
  });
  return selection;
}
