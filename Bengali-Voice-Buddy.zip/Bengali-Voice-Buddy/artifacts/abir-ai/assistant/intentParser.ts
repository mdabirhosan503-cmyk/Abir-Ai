export function extractAppQuery(text: string) {
  const openingRequested =
    /(?:\bopen\b|\blaunch\b|\bstart\b|\bgo\s+to\b|ওপেন|খোলো|খুলুন|খুলে|চালু)/i.test(
      text,
    );
  if (!openingRequested) return null;

  const query = text
    .replace(
      /\b(?:please|kindly|can you|could you|the|my|app)\b/gi,
      ' ',
    )
    .replace(/\b(?:open|launch|start|go\s+to)\b/gi, ' ')
    .replace(
      /(?:দয়া করে|দয়া করে|আমাকে|একটু|ওপেন|খুলে দাও|খুলে দিন|খুলে দিও|খুলুন|খোলো|খুলে|চালু করে দাও|চালু করো|চালু করুন|চালু|করো|করুন|দাও|দিন|দিয়ে দাও|অ্যাপটি|অ্যাপ|টা|টাকে)/g,
      ' ',
    )
    .replace(/[?!।,]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractCallQuery(text: string) {
  const english = text.match(
    /^\s*(?:please\s+)?(?:call|phone|dial|ring)\s+(?:my\s+)?(.+?)\s*$/i,
  );
  const bengaliSuffix = text.match(
    /^\s*(?:আমাকে\s+)?(.+?)(?:\s*কে)?\s+(?:কল|ফোন)(?:\s+(?:করো|করুন|দাও|দিন|দিতে পারো|করবে))?\s*$/u,
  );
  const bengaliPrefix = text.match(
    /^\s*(?:আমাকে\s*)?(?:কল|ফোন)\s+(?:(?:করো|করুন|দাও|দিন)\s+)?(.+?)\s*$/u,
  );
  const rawQuery = english?.[1] ?? bengaliSuffix?.[1] ?? bengaliPrefix?.[1];
  if (!rawQuery) return null;

  const query = rawQuery
    .replace(/\b(?:please|now)\b/gi, ' ')
    .replace(/(?:দয়া করে|দয়া করে|একটু|আমার|কে|দয়া|করো|করুন|দাও|দিন|এখন)/gu, ' ')
    .replace(/[?!।,.:;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return query || null;
}
