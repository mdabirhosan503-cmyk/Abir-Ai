import type { AssistantMemory } from './localMemory';
import { extractAppQuery, extractCallQuery } from './intentParser';

export type AssistantLanguage = 'bn' | 'en';

export interface AssistantRequest {
  text: string;
  language: AssistantLanguage;
  now?: Date;
  memory?: AssistantMemory;
}

export type AssistantIntent =
  | 'greeting'
  | 'casual'
  | 'help'
  | 'time'
  | 'date'
  | 'joke'
  | 'calculator'
  | 'clear-history'
  | 'open-app'
  | 'call-contact'
  | 'memory'
  | 'fallback';

export interface AssistantReply {
  text: string;
  intent: AssistantIntent;
  appQuery?: string;
  contactQuery?: string;
}

export interface AssistantExtension {
  id: string;
  handle(request: AssistantRequest): Promise<AssistantReply | null>;
}

const hasBengali = (text: string) => /[\u0980-\u09FF]/.test(text);
let responseCursor = 0;

function variant<T>(items: T[]) {
  const selected = items[responseCursor % items.length];
  responseCursor += 1;
  return selected;
}

function normalizeNumerals(text: string) {
  const bengaliDigits = '০১২৩৪৫৬৭৮৯';
  return text
    .replace(/[০-৯]/g, (digit) => String(bengaliDigits.indexOf(digit)))
    .trim()
    .toLowerCase()
    .replace(/[?!।,]/g, '')
    .replace(/\s+/g, ' ');
}

function calculate(text: string): number | null {
  const expression = text
    .replace(/^(?:calculate|solve|what is|কত|গণনা করো)\s*/i, '')
    .replace(/[×x]/g, '*')
    .replace(/÷/g, '/')
    .trim();
  const match = expression.match(
    /^(-?(?:\d+(?:\.\d*)?|\.\d+))\s*([+\-*/])\s*(-?(?:\d+(?:\.\d*)?|\.\d+))$/,
  );
  if (!match) return null;

  const left = Number(match[1]);
  const right = Number(match[3]);
  switch (match[2]) {
    case '+':
      return left + right;
    case '-':
      return left - right;
    case '*':
      return left * right;
    case '/':
      return right === 0 ? null : left / right;
    default:
      return null;
  }
}

function rememberedName(memory?: AssistantMemory) {
  const fact = memory?.facts.find((item) =>
    /^(?:my name is|আমার নাম)\s*/i.test(item),
  );
  return fact?.replace(/^(?:my name is|আমার নাম)\s*/i, '').trim() || null;
}

export const offlineCommandExtension: AssistantExtension = {
  id: 'offline-command-and-conversation-brain',
  async handle({ text, language, now = new Date(), memory }) {
    const normalized = normalizeNumerals(text);
    const bengali = hasBengali(text) || language === 'bn';
    const reply = (bn: string, en: string, intent: AssistantIntent) => ({
      text: bengali ? bn : en,
      intent,
    });

    const callQuery = extractCallQuery(text);
    if (callQuery) {
      return {
        ...reply(
          `${callQuery}-এর নম্বর খুঁজছি…`,
          `Looking for ${callQuery} in your contacts…`,
          'call-contact',
        ),
        contactQuery: callQuery,
      };
    }

    const appQuery = extractAppQuery(text);
    if (appQuery) {
      return {
        ...reply(
          'ইনস্টল করা অ্যাপটি খুঁজছি…',
          'Looking for that installed app…',
          'open-app',
        ),
        appQuery,
      };
    }

    if (/^(?:clear|clear chat|reset chat|চ্যাট মুছো|সব মুছে দাও)$/.test(normalized)) {
      return reply(
        'ঠিক আছে, পুরোনো কথাগুলো সরিয়ে দিলাম। এবার নতুন করে শুরু করি!',
        'Done. I cleared the old messages. Fresh start!',
        'clear-history',
      );
    }

    if (
      /^(?:hi|hello|hey|good morning|good evening|হাই|হ্যালো|আসসালামু আলাইকুম|সালাম)$/.test(
        normalized,
      )
    ) {
      const name = rememberedName(memory);
      return reply(
        variant([
          `হ্যালো${name ? ` ${name}` : ''}! আজ কী নিয়ে একটু বুদ্ধি খাটাব?`,
          `সালাম${name ? ` ${name}` : ''}! বলো, আজকের অভিযান কোন দিকে?`,
          `হাই${name ? ` ${name}` : ''}! আড্ডা, অঙ্ক, নাকি কোনো কাজ—তুমি বেছে নাও।`,
        ]),
        variant([
          `Hey${name ? ` ${name}` : ''}! What are we figuring out today?`,
          `Hello${name ? ` ${name}` : ''}! Pick a topic and I’ll do my best offline impression of a genius.`,
          `Hi${name ? ` ${name}` : ''}! Need a hand, a joke, or just a chat?`,
        ]),
        'greeting',
      );
    }

    if (
      /(?:what do you remember|তুমি কী মনে রেখেছ|কি মনে রেখেছ|কী মনে রেখেছ)/i.test(
        normalized,
      )
    ) {
      const facts = memory?.facts ?? [];
      return reply(
        facts.length
          ? `এই ডিভাইসে মনে রেখেছি:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'এখনো আলাদা করে কিছু মনে রাখিনি। চাইলে “মনে রাখো, আমি…” বলে কোনো পছন্দ জানাতে পারো।',
        facts.length
          ? `Saved on this device:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'I haven’t saved any facts yet. Say “remember that I…” to save a preference locally.',
        'memory',
      );
    }

    if (/(?:what were we (?:discussing|talking about)|আগে কী বলছিলাম|আমরা কী নিয়ে কথা বলছিলাম|আমরা কি নিয়ে কথা বলছিলাম)/i.test(normalized)) {
      const topics = memory?.recentTopics ?? [];
      return reply(
        topics.length
          ? `সাম্প্রতিক কথা ছিল:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'এই ডিভাইসে এখনো সাম্প্রতিক কথার প্রসঙ্গ জমেনি।',
        topics.length
          ? `Recently, we talked about:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'There isn’t any recent conversation context saved on this device yet.',
        'memory',
      );
    }

    if (/(?:how are you|how'?s it going|কেমন আছো|কেমন আছেন|আজকে কেমন|কি খবর|কী খবর)/i.test(normalized)) {
      return reply(
        variant([
          'আমার মানুষের মতো অনুভূতি নেই, তবে তোমার সঙ্গে আড্ডা দিতে আর কাজে লাগতে প্রস্তুত। তোমার খবর কী?',
          'আমি অনুভূতি পাই না—তবে অফলাইনেও বেশ ফুরফুরে! তোমার দিনটা কেমন যাচ্ছে?',
          'মানুষের মতো ভালো-মন্দ লাগা নেই, কিন্তু সাহায্য করতে একদম রেডি। আজ কী চলছে?',
        ]),
        variant([
          'I don’t have feelings like a person, but I’m ready to chat and help. How are you doing?',
          'No human moods on my side, but I’m here and ready. How’s your day going?',
          'I’m not conscious, but I can still be a pretty good conversation buddy. What’s up?',
        ]),
        'casual',
      );
    }

    if (/(?:আড্ডা|গল্প করি|চলো কথা বলি|chat with me|let'?s chat|talk to me)/i.test(normalized)) {
      return reply(
        variant([
          'চল! আজকের দিনের সবচেয়ে মজার বা অদ্ভুত ঘটনাটা কী?',
          'আড্ডা জমুক। খাবার, সিনেমা, ভ্রমণ—কোন বিষয় দিয়ে শুরু করব?',
          'আমি প্রস্তুত। তুমি একটা বিষয় ছুড়ে দাও, আমি কথার বলটা ধরছি!',
        ]),
        variant([
          'I’m in. What was the most interesting thing about your day?',
          'Let’s chat. Food, movies, travel, or a wonderfully specific question?',
          'Deal. Toss me a topic and I’ll keep the conversation going offline.',
        ]),
        'casual',
      );
    }

    if (
      /^(?:hi|hello|hey|thanks|thank you|ধন্যবাদ|থ্যাংকস|বিদায়|বিদায়|বাই|bye)[!. ]*$/i.test(
        normalized,
      )
    ) {
      return reply(
        variant([
          'স্বাগতম! দরকার হলে আবার ডাক দিও।',
          'ধন্যবাদ তোমাকেও! আড্ডার দরজা খোলা থাকল।',
          'বাই! কাজটা হলে কৃতিত্ব তোমার, না হলে দোষটা নেটওয়ার্কের—যদিও আমি অফলাইন!',
        ]),
        variant([
          'Anytime. I’ll be right here when you need me.',
          'Thanks for chatting. The offline door is always open.',
          'See you! If anything goes wrong, we can blame the math. Mostly.',
        ]),
        'casual',
      );
    }

    if (
      /(?:help|what can you do|commands|সাহায্য|কী করতে পারো|কি করতে পারো|কমান্ড)/.test(
        normalized,
      )
    ) {
      return reply(
        'আমি সময়-তারিখ বলতে, ছোট অঙ্ক কষতে, আড্ডা দিতে, কৌতুক বলতে, মনে রাখতে বলা পছন্দ এই ডিভাইসে রাখতে, Android অ্যাপ খুলতে এবং অনুমতি দিলে পরিচিতিকে কলের প্রস্তুতি নিতে পারি।',
        'Offline: time/date, simple math, casual chat, jokes, local memories, Android app launching, and contact calls with Android permission and confirmation.',
        'help',
      );
    }

    if (/(?:time|সময়|সময়|কটা বাজে)/.test(normalized)) {
      const time = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        hour: 'numeric',
        minute: '2-digit',
      }).format(now);
      return reply(
        `এখন ${time}। ঘড়ি বলল, আমি শুধু সময় বলি—চাপ নিও না!`,
        `It’s ${time}. The clock says I should mention: no rush.`,
        'time',
      );
    }

    if (/(?:date|today|আজ|তারিখ|কোন বার)/.test(normalized)) {
      const date = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }).format(now);
      return reply(`আজ ${date}।`, `Today is ${date}.`, 'date');
    }

    if (/(?:joke|কৌতুক|জোক|হাসাও|মজার কথা)/.test(normalized)) {
      return reply(
        variant([
          'কম্পিউটার ডাক্তারকে বলল, “আমার ভাইরাস হয়েছে।” ডাক্তার বললেন, “তাহলে আজ একটু অফলাইনে থাকুন!”',
          'একটা ফোন আরেকটাকে বলল, “তোমার চার্জ কেমন?” সে বলল, “সম্পর্কটা ১% ব্যাটারির মতো—যেকোনো সময় শেষ!”',
          'শিক্ষক: ২ আর ২ কত? ছাত্র: ৪। শিক্ষক: খুব ভালো! ক্যালকুলেটর: এত প্রশংসা আমি কোনোদিন পাইনি।',
        ]),
        variant([
          'Why did the phone go to therapy? Too many unresolved notifications.',
          'I told my calculator a joke. It said the punchline didn’t add up.',
          'My offline mode and I have a lot in common: we both avoid unnecessary connections.',
        ]),
        'joke',
      );
    }

    if (
      /(?:who are you|are you (?:real|conscious|alive)|তুমি কে|তুমি কি মানুষ|তুমি কি বাস্তব)/i.test(
        normalized,
      )
    ) {
      return reply(
        'আমি আবির AI—একটি সফটওয়্যার সহকারী। মানুষের মতো চেতনা বা অনুভূতি নেই, তবে অফলাইনে যতটা পারি সাহায্য করি।',
        'I’m Abir AI, a software assistant. I’m not conscious or alive, but I can help with offline tasks and conversation.',
        'casual',
      );
    }

    const answer = calculate(normalized);
    if (answer !== null) {
      const value = Number.isInteger(answer)
        ? String(answer)
        : String(Number(answer.toFixed(4)));
      return reply(
        `উত্তর ${new Intl.NumberFormat('bn-BD').format(answer)}। অঙ্কটা বেশ ভদ্র ছিল!`,
        `That’s ${value}. This sum behaved nicely.`,
        'calculator',
      );
    }

    return reply(
      'এটা অফলাইনে ঠিক বুঝতে পারিনি। আরেকটু অন্যভাবে বলবে? চাইলে আড্ডা, সময়-তারিখ, ছোট অঙ্ক, অ্যাপ খোলা বা পরিচিতিকে কলের কথা বলতে পারো।',
      'I’m not sure I understood that offline. Could you rephrase it? I can chat, tell time/date, solve simple sums, open apps, or help call a contact.',
      'fallback',
    );
  },
};

const defaultExtensions = [offlineCommandExtension];

export async function getAssistantReply(
  request: AssistantRequest,
  extensions: AssistantExtension[] = defaultExtensions,
): Promise<AssistantReply> {
  for (const extension of extensions) {
    const result = await extension.handle(request);
    if (result) return result;
  }

  return {
    text:
      request.language === 'bn'
        ? 'এই অনুরোধটি এখনো অফলাইনে সামলাতে পারি না। “সাহায্য” লিখে কমান্ডগুলো দেখো!'
        : 'I can’t handle that one offline yet. Type “help” to see what I can do.',
    intent: 'fallback',
  };
}
