import { Platform } from 'react-native';
import { PermissionsAndroid } from 'react-native';
import * as IntentLauncher from 'expo-intent-launcher';
import type { AssistantLanguage } from './offlineBrain';
import { getOfflineSpeechRecognitionAvailability } from './androidActions';

type BrowserRecognitionResult = {
  results: ArrayLike<ArrayLike<{ transcript: string }>>;
};

type BrowserRecognition = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: BrowserRecognitionResult) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechWindow = Window & {
  SpeechRecognition?: new () => BrowserRecognition;
  webkitSpeechRecognition?: new () => BrowserRecognition;
};

export async function listenForText(
  language: AssistantLanguage,
): Promise<string | null> {
  const locale = language === 'bn' ? 'bn-BD' : 'en-US';

  if (Platform.OS === 'android') {
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
      throw new Error(
        language === 'bn'
          ? 'ভয়েস ইনপুটের জন্য মাইক্রোফোন অনুমতি প্রয়োজন। সেটিংসে অনুমতি দিয়ে আবার চেষ্টা করো।'
          : 'Microphone permission is needed for voice input. Allow it in settings and try again.',
      );
    }

    const offlineAvailable =
      await getOfflineSpeechRecognitionAvailability();
    if (!offlineAvailable) {
      throw new Error(
        language === 'bn'
          ? 'এই ফোনে অফলাইন স্পিচ রিকগনিশন পাওয়া যাচ্ছে না। Android 12 বা নতুন সংস্করণ এবং ডাউনলোড করা অফলাইন ভাষা মডেল আছে কি না দেখো।'
          : 'Offline speech recognition is unavailable. Check for Android 12 or newer and an installed offline language pack.',
      );
    }

    const result = await IntentLauncher.startActivityAsync(
      'android.speech.action.RECOGNIZE_SPEECH',
      {
        extra: {
          'android.speech.extra.LANGUAGE_MODEL': 'free_form',
          'android.speech.extra.LANGUAGE': locale,
          'android.speech.extra.PROMPT':
            language === 'bn' ? 'আবির AI-কে বলুন' : 'Speak to Abir AI',
          'android.speech.extra.MAX_RESULTS': 1,
          'android.speech.extra.PREFER_OFFLINE': true,
        },
      },
    );

    const returnedExtras = result.extra as Record<string, unknown> | undefined;
    const recognized = returnedExtras?.['android.speech.extra.RESULTS'] as
      | string[]
      | undefined;
    return recognized?.[0]?.trim() || null;
  }

  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    const speechWindow = window as SpeechWindow;
    const Recognition =
      speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;
    if (!Recognition) {
      throw new Error('This browser does not support speech recognition.');
    }

    return new Promise<string | null>((resolve, reject) => {
      const recognition = new Recognition();
      recognition.lang = locale;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      recognition.onresult = (event) =>
        resolve(event.results[0]?.[0]?.transcript.trim() || null);
      recognition.onerror = (event) =>
        reject(new Error(`Speech recognition failed: ${event.error}`));
      recognition.onend = () => resolve(null);
      recognition.start();
    });
  }

  throw new Error('Voice input is currently supported on Android and web.');
}
