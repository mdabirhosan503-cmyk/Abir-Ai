export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Intentionally disabled: offline chat never sends messages to a server.
export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  enabled: false,
  async respond() {
    return null;
  },
};
