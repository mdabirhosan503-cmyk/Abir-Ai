package expo.modules.abirapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.net.Uri
import java.util.Locale

class WakeWordService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private var recognizer: SpeechRecognizer? = null
  private var stopping = false

  private val restartRunnable = Runnable { startRecognition() }

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
    val notification = Notification.Builder(this, CHANNEL_ID)
      .setContentTitle("Abir AI")
      .setContentText("“Abir” বললে সক্রিয় হবে")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setOngoing(true)
      .setCategory(Notification.CATEGORY_SERVICE)
      .build()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
    startRecognition()
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = getSystemService(NotificationManager::class.java)
      manager.createNotificationChannel(
        NotificationChannel(
          CHANNEL_ID,
          "Abir AI voice assistant",
          NotificationManager.IMPORTANCE_LOW
        ).apply {
          description = "Keeps Abir AI ready for the wake word."
        }
      )
    }
  }

  private fun containsWakeWord(text: String): Boolean {
    val normalized = text.trim().lowercase(Locale.ROOT)
    return normalized.contains("abir") ||
      normalized.contains("এবির") ||
      normalized.contains("আবির") ||
      normalized.contains("আদিরাবির") ||
      normalized.contains("আদির আবির") ||
      normalized.contains("adiraabir") ||
      normalized.contains("adira abir")
  }

  private fun afterWakeWord(text: String): String {
    return text.trim()
      .replaceFirst(Regex("(?i).*?abir\\s*"), "")
      .replaceFirst(Regex("এবির\\s*"), "")
      .replaceFirst(Regex("আবির\\s*"), "")
      .trim(' ', ',', '-', '—', ':')
  }

  private fun openAbir(command: String) {
    val uri = Uri.parse("abir-ai://wake").buildUpon()
      .apply { if (command.isNotBlank()) appendQueryParameter("text", command) }
      .build()
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
    try {
      startActivity(intent)
    } catch (_: Exception) {
      val fallback = packageManager.getLaunchIntentForPackage(packageName)
      fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      if (fallback != null) startActivity(fallback)
    }
  }

  private fun startRecognition() {
    if (stopping || !SpeechRecognizer.isRecognitionAvailable(this)) return
    recognizer?.destroy()
    recognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
      SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
    } else {
      SpeechRecognizer.createSpeechRecognizer(this)
    }.apply {
      setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { scheduleRestart(300) }
        override fun onError(error: Int) { scheduleRestart(600) }
        override fun onResults(results: Bundle?) {
          val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
          val match = matches.firstOrNull { containsWakeWord(it) }
          if (match != null) {
            openAbir(afterWakeWord(match))
            scheduleRestart(1200)
          } else {
            scheduleRestart(250)
          }
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
      })
    }

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
    }
    try {
      recognizer?.startListening(intent)
    } catch (_: Exception) {
      scheduleRestart(1000)
    }
  }

  private fun scheduleRestart(delay: Long) {
    if (stopping) return
    handler.removeCallbacks(restartRunnable)
    handler.postDelayed(restartRunnable, delay)
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    stopping = false
    if (recognizer == null) startRecognition()
    return START_STICKY
  }

  override fun onDestroy() {
    stopping = true
    handler.removeCallbacksAndMessages(null)
    recognizer?.destroy()
    recognizer = null
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  companion object {
    const val ACTION_START = "expo.modules.abirapp.action.START_WAKE_WORD"
    const val ACTION_STOP = "expo.modules.abirapp.action.STOP_WAKE_WORD"
    private const val CHANNEL_ID = "abir_ai_wake_word"
    private const val NOTIFICATION_ID = 4401
  }
}
