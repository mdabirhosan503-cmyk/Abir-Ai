import type { AssistantMemory } from './localMemory';
import { extractAppQuery, extractCallQuery, extractDirectPhoneNumber, extractUniversalSearchRequest, normalizeAssistantCommand } from './intentParser';
import { detectAssistantLanguage, repairCommonSpeech, repairSpeechTranscript, scoreLocalIntent } from './localIntelligence';
import { analyzeOfflineText, convertOfflineUnit, learnLocalAlias, planOfflineTasks, resolveLocalAlias, summarizeLocalContext } from './offlinePlus';
import { getAdvancedOfflineReply } from './offlineAdvanced';
import { getOfflineSystemsReply } from './offlineSystems';
import { getMegaOfflineReply } from './offlineMegaSystems';
import { offlineIntelligencePackExtension } from './offlineIntelligencePack';
import { offlineUltimateExtension } from './offlineUltimatePack';
import { offlineEvolutionExtension } from './offlineEvolutionPack';
import { offlineModernFeaturesExtension } from './offlineModernFeatures';
import { offlineNextGenExtension } from './offlineNextGen';
import { offlineExpansionExtension } from './offlineExpansion';
import { offlineModernUpgradeExtension } from './offlineModernUpgrade';
import { OFFLINE_100_FEATURES, OFFLINE_100_FEATURE_COUNT, getOffline100Feature } from './offline100Features';

export type AssistantLanguage = 'bn' | 'en';

export interface AssistantRequest {
  text: string;
  language: AssistantLanguage;
  now?: Date;
  memory?: AssistantMemory;
  conversationContext?: Array<{ role: 'user' | 'assistant'; text: string }>;
}

export type AssistantIntent =
  | 'greeting'
  | 'casual'
  | 'help'
  | 'time'
  | 'date'
  | 'joke'
  | 'calculator'
  | 'coding'
  | 'clear-history'
  | 'open-app'
  | 'device-action'
  | 'screen-read'
  | 'universal-screen-control'
  | 'screen-control'
  | 'call-contact'
  | 'call-via-app'
  | 'memory'
  | 'location'
  | 'diagnostics'
  | 'reminder'
  | 'undo'
  | 'notes'
  | 'routine'
  | 'unit-converter'
  | 'text-analysis'
  | 'task-plan'
  | 'fallback';

export interface AssistantReply {
  text: string;
  intent: AssistantIntent;
  appQuery?: string;
  contactQuery?: string;
  appCallTarget?: 'whatsapp' | 'messenger' | 'imo';
  automationQuery?: string;
  screenAction?: 'click' | 'type' | 'scroll';
  screenTarget?: string;
  deviceValue?: number;
  reminderText?: string;
  reminderDelayMs?: number;
  noteText?: string;
  noteQuery?: string;
  routineName?: string;
  routineCommand?: string;
  plannedTasks?: string[];
  deviceAction?:
    | 'back'
    | 'home'
    | 'recents'
    | 'notifications'
    | 'quick-settings'
    | 'power-menu'
    | 'lock-screen'
    | 'wake-screen'
    | 'screenshot'
    | 'split-screen'
    | 'volume-up'
    | 'volume-down'
    | 'volume-mute'
    | 'flashlight-on'
    | 'flashlight-off'
    | 'media-play'
    | 'media-pause'
    | 'media-next'
    | 'media-previous'
    | 'vibrate'
    | 'ringer-normal'
    | 'settings'
    | 'wifi-settings'
    | 'bluetooth-settings'
    | 'mobile-data-panel';
}

export interface AssistantExtension {
  id: string;
  handle(request: AssistantRequest): Promise<AssistantReply | null>;
}

const hasBengali = (text: string) => /[\u0980-\u09FF]/.test(text);
let responseCursor = 0;

function variant<T>(items: T[]) {
  const selected = items[responseCursor % items.length];
  responseCursor += 1;
  return selected;
}


function normalizeSpokenBangla(text: string) {
  return repairCommonSpeech(normalizeAssistantCommand(text))
    .toLowerCase()
    .replace(/[।!?;,]+/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/ইউটিউব/g, 'youtube')
    .replace(/হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ/g, 'whatsapp')
    .replace(/মেসেঞ্জার/g, 'messenger')
    .replace(/ইমো/g, 'imo')
    .replace(/গুগল ক্রোম/g, 'chrome')
    .replace(/খুলে দাও|খুলে দেন|খুলে দিবা|খুলে দিবেন/g, 'খোলো')
    .replace(/চালিয়ে দাও|চালিয়ে দাও|চালু করে দাও|চালু করো/g, 'চালাও')
    .replace(/করো না|করে দাও|দিয়ে দাও|দিয়ে দাও/g, 'দাও')
    .trim();
}

function normalizeNumerals(text: string) {
  return repairCommonSpeech(normalizeAssistantCommand(text))
    .replace(/(?:^|\s)(?:hey|hello|hi|abir|abira|adiraabir|adira abir|এবির|আবির|আদিরাবির|আদির আবির)(?=\s|$)/giu, ' ')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

function calculate(text: string): number | null {
  let expression = text
    .replace(/^(?:calculate|solve|what is|কত|গণনা করো|হিসাব করো|যোগ করো|বিয়োগ করো|বিয়োগ করো|গুণ করো|ভাগ করো)\s*/i, '')
    .replace(/×|x/gi, '*')
    .replace(/÷/g, '/')
    .replace(/শতকরা/g, '%')
    .replace(/শতাংশ/g, '%')
    .replace(/যোগ/g, '+')
    .replace(/বিয়োগ|বিয়োগ/g, '-')
    .replace(/গুণ/g, '*')
    .replace(/ভাগ/g, '/')
    .replace(/সমান\s*কত/g, '')
    .trim();

  // Accept common spoken forms such as “১০ যোগ ৫ গুণ ২” and parentheses.
  expression = expression.replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  expression = expression.replace(/[^0-9+\-*/%.()\s]/g, ' ');
  expression = expression.replace(/\s+/g, ' ').trim();
  if (!expression || !/[0-9]/.test(expression)) return null;

  const tokens = expression.match(/\d+(?:\.\d+)?|[()+\-*/%]/g);
  if (!tokens) return null;
  let index = 0;

  const parsePrimary = (): number | null => {
    const token = tokens[index];
    if (token === undefined) return null;
    if (token === '(') {
      index += 1;
      const value = parseAddSub();
      if (tokens[index] !== ')') return null;
      index += 1;
      return value;
    }
    if (/^\d/.test(token)) {
      index += 1;
      return Number(token);
    }
    return null;
  };

  const parseUnary = (): number | null => {
    if (tokens[index] === '+') {
      index += 1;
      return parseUnary();
    }
    if (tokens[index] === '-') {
      index += 1;
      const value = parseUnary();
      return value === null ? null : -value;
    }
    return parsePrimary();
  };

  const parseMulDiv = (): number | null => {
    let value = parseUnary();
    if (value === null) return null;
    while (index < tokens.length && ['*', '/', '%'].includes(tokens[index])) {
      const op = tokens[index++];
      const right = parseUnary();
      if (right === null || (op === '/' && right === 0)) return null;
      if (op === '*') value *= right;
      else if (op === '/') value /= right;
      else value %= right;
    }
    return value;
  };

  const parseAddSub = (): number | null => {
    let value = parseMulDiv();
    if (value === null) return null;
    while (index < tokens.length && ['+', '-'].includes(tokens[index])) {
      const op = tokens[index++];
      const right = parseMulDiv();
      if (right === null) return null;
      value = op === '+' ? value + right : value - right;
    }
    return value;
  };

  const result = parseAddSub();
  if (result === null || index !== tokens.length || !Number.isFinite(result)) return null;
  return result;
}

function convertUnit(text: string): { value: number; unit: string } | null {
  const normalized = text
    .replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)))
    .toLowerCase();
  const match = normalized.match(/(-?\d+(?:\.\d+)?)\s*(km|kilometer|kilometers|কিলোমিটার|m|meter|meters|মিটার|cm|centimeter|centimeters|সেন্টিমিটার|kg|kilogram|kilograms|কেজি|কিলোগ্রাম|g|gram|grams|গ্রাম|mile|miles|মাইল|c|°c|ফারেনহাইট|fahrenheit|f|°f|celsius|সেলসিয়াস|সেলসিয়াস)/i);
  if (!match) return null;
  const value = Number(match[1]);
  const unit = match[2].toLowerCase();
  if (['km','kilometer','kilometers','কিলোমিটার'].includes(unit)) return { value: value * 1000, unit: 'মিটার' };
  if (['m','meter','meters','মিটার'].includes(unit)) return { value, unit: 'মিটার' };
  if (['cm','centimeter','centimeters','সেন্টিমিটার'].includes(unit)) return { value: value / 100, unit: 'মিটার' };
  if (['kg','kilogram','kilograms','কেজি','কিলোগ্রাম'].includes(unit)) return { value, unit: 'কেজি' };
  if (['g','gram','grams','গ্রাম'].includes(unit)) return { value: value / 1000, unit: 'কেজি' };
  if (['mile','miles','মাইল'].includes(unit)) return { value: value * 1.609344, unit: 'কিলোমিটার' };
  if (['c','°c','celsius','সেলসিয়াস','সেলসিয়াস'].includes(unit)) return { value: value * 9 / 5 + 32, unit: '°F' };
  if (['f','°f','fahrenheit','ফারেনহাইট'].includes(unit)) return { value: (value - 32) * 5 / 9, unit: '°C' };
  return null;
}


function resolveFollowUp(text: string, context?: Array<{ role: 'user' | 'assistant'; text: string }>) {
  if (!context?.length) return text;
  const contextSummary = summarizeLocalContext(context);
  void contextSummary;
  const n = normalizeAssistantCommand(text).toLowerCase();
  const latestUser = [...context].reverse().find(item => item.role === 'user')?.text ?? '';
  const latestAssistant = [...context].reverse().find(item => item.role === 'assistant')?.text ?? '';
  const followUp = /^(?:এটা|ওটা|ওইটা|এটি|সেটা|আগেরটা|ওই অ্যাপ|that|this|it|the app|the website|the code|আগের কথাটা|ঠিক আছে|yes|হ্যাঁ|হ্যা|okay|ok)$/iu.test(n)
    || /(?:এটা|ওটা|ওইটা|that|this|it)\s+(?:খোলো|open|চালু|run|করো|do it|বানাও|build)/iu.test(n);
  if (!followUp) return text;
  if (latestUser) return `${latestUser} ${text}`;
  return latestAssistant ? `${latestAssistant} ${text}` : text;
}

function codingAnswer(text: string, bengali: boolean): string | null {
  const t = text.toLowerCase();
  const asksCode = /(?:কোড|coding|code|program|programming|প্রোগ্রাম|স্ক্রিপ্ট|script)/i.test(t);
  if (!asksCode) return null;

  if (/(?:website|ওয়েবসাইট|ওয়েবসাইট|web site|landing page|portfolio|পোর্টফোলিও)/i.test(t) && /(?:বানাও|বানিয়ে|বানিয়ে|build|make|create|code|কোড)/i.test(t)) {
    return bengali
      ? 'বস, offline-এ আমি একটি সম্পূর্ণ starter website-এর কাঠামো দিতে পারি।\n\nindex.html\n```html\n<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Abir Project</title></head><body><main><h1>স্বাগতম</h1><p>তোমার ওয়েবসাইট প্রস্তুত।</p></main></body></html>\n```\n\nবড় production website হলে online Gemini mode-এ আমি বহু-file architecture, responsive UI, JavaScript logic, API এবং testing plan তৈরি করব।'
      : 'Boss, offline I can create a runnable starter website with HTML/CSS/JS structure. For a full production site, online Gemini mode can generate the multi-file architecture, responsive UI, logic, API integration, and testing plan.';
  }

  if (/(?:android app|অ্যান্ড্রয়েড অ্যাপ|অ্যান্ড্রয়েড অ্যাপ|mobile app|মোবাইল অ্যাপ|অ্যাপ বানাও|অ্যাপ বানিয়ে|অ্যাপ বানিয়ে|build app|make app)/i.test(t)) {
    return bengali
      ? 'বস, Android app-এর জন্য offline-এ architecture, screen plan, Kotlin/Expo starter code ও file structure দিতে পারি। Online থাকলে Gemini coding-agent mode-এ requirements থেকে multi-file runnable project, debugging ও build steps তৈরি করতে পারি।'
      : 'Boss, I can plan an Android app offline and provide Kotlin/Expo starter code plus file structure. Online, Gemini coding-agent mode can turn requirements into a multi-file runnable project with debugging and build steps.';
  }

  if (/(?:python|পাইথন)/i.test(t)) {
    return bengali
      ? 'বস, Python-এর একটা সহজ উদাহরণ:\n\n```python\nname = input("তোমার নাম: ")\nprint(f"হ্যালো {name}!")\n```\n\nআর নির্দিষ্ট Python প্রোগ্রাম বললে অনলাইনে থাকলে আমি সেটাও লিখে দিতে পারি।'
      : 'Boss, here is a simple Python example:\n\n```python\nname = input("Your name: ")\nprint(f"Hello {name}!")\n```\n\nGive me a specific Python task and, when online, I can generate the full program.';
  }
  if (/(?:html|ওয়েবসাইট|ওয়েবসাইট)/i.test(t)) {
    return bengali
      ? 'বস, একটি সহজ HTML পেজ:\n\n```html\n<!doctype html>\n<html>\n<head><meta charset="utf-8"><title>My Page</title></head>\n<body><h1>হ্যালো বস!</h1></body>\n</html>\n```'
      : 'Boss, here is a simple HTML page:\n\n```html\n<!doctype html>\n<html><head><meta charset="utf-8"><title>My Page</title></head><body><h1>Hello Boss!</h1></body></html>\n```';
  }
  if (/(?:javascript|জাভাস্ক্রিপ্ট|js)/i.test(t)) {
    return bengali
      ? 'বস, JavaScript-এর সহজ উদাহরণ:\n\n```javascript\nconst name = "Boss";\nconsole.log(`Hello ${name}!`);\n```'
      : 'Boss, a simple JavaScript example:\n\n```javascript\nconst name = "Boss";\nconsole.log(`Hello ${name}!`);\n```';
  }
  if (/(?:kotlin|কটলিন|android app|অ্যান্ড্রয়েড অ্যাপ|অ্যান্ড্রয়েড অ্যাপ)/i.test(t)) {
    return bengali
      ? 'বস, Android/Kotlin-এর সহজ উদাহরণ:\n\n```kotlin\nfun main() {\n    println("Hello Boss!")\n}\n```\n\nপুরো Android feature বা app code চাইলে নির্দিষ্ট কাজটা বললে অনলাইনে Gemini দিয়ে তৈরি করা যাবে।'
      : 'Boss, a simple Kotlin example:\n\n```kotlin\nfun main() {\n    println("Hello Boss!")\n}\n```\n\nFor a full Android feature or app, describe the exact task and Gemini can generate it when online.';
  }
  if (/(?:app|application|অ্যাপ|অ্যাপস|ওয়েবসাইট|ওয়েবসাইট|website|site|project|প্রজেক্ট|প্রজেক্ট বানাও|বানিয়ে দাও|build|make)/i.test(t)) {
    return bengali
      ? 'বস, আমি offline-এ ছোট app/website-এর পরিকল্পনা, folder structure ও basic starter code তৈরি করতে পারি। বড় বা সম্পূর্ণ runnable project বানাতে online Gemini ব্যবহার করলে আমি requirements বুঝে একাধিক file-এর code, setup এবং testing steps একসাথে তৈরি করতে পারব।'
      : 'Boss, offline I can plan a small app/website and create a folder structure with starter code. For a larger runnable project, online Gemini lets me turn your requirements into multiple files with code, setup, and testing steps.';
  }
  return bengali
    ? 'বস, আমি offline-এ basic coding example, project plan ও code explanation দিতে পারি। নির্দিষ্ট কাজ বললে, যেমন “Python-এ calculator বানাও” বা “একটা simple website বানাও”, আমি starter code তৈরি করব। বড় বা সম্পূর্ণ project-এর জন্য online Gemini-তে আমি coding-agent mode-এ architecture, file structure, code, setup ও debugging steps তৈরি করতে পারি।'
    : 'Boss, offline I can provide basic coding examples, project plans, and explanations. Say something specific like “build a Python calculator” or “make a simple website” and I can create starter code. For larger complete projects, online Gemini can work in coding-agent mode with architecture, file structure, code, setup, and debugging steps.';
}

function rememberedName(memory?: AssistantMemory) {
  const fact = memory?.facts.find((item) =>
    /^(?:my name is|আমার নাম)\s*/i.test(item),
  );
  return fact?.replace(/^(?:my name is|আমার নাম)\s*/i, '').trim() || null;
}


/**
 * Lightweight offline reasoning layer.
 * It does not pretend to be conscious: it scores intent, ambiguity and risk,
 * then chooses the safest useful local action before online fallback.
 */
function thinkOffline(text: string) {
  const scored = scoreLocalIntent(text);
  return {
    normalized: scored.normalized,
    confidence: scored.confidence,
    ambiguous: scored.ambiguous,
    destructive: scored.destructive,
  };
}

function smartGreeting(text: string, bengali: boolean, memory?: AssistantMemory) {
  const t = normalizeAssistantCommand(text).toLowerCase();
  if (!/^(?:হ্যালো|হাই|সালাম|আসসালামু আলাইকুম|hello|hi|hey|yo|হ্যালো আবির|hi abir|hello abir|abir|abir ai)$/iu.test(t)) return null;
  const name = rememberedName(memory);
  return bengali
    ? `হ্যালো${name ? ` ${name}` : ''}! আমি আবির, তোমার AI Assistant। আমি মোবাইল কন্ট্রোল করতে পারি এবং অনলাইন ও অফলাইন—দুইভাবেই কাজ করতে পারি।`
    : `Hello${name ? ` ${name}` : ''}! I’m Abir, your AI assistant. I can control your phone and work both online and offline.`;
}

export const offline100FeatureExtension: AssistantExtension = {
  id: 'offline-100-feature-pack',
  async handle({ text, language }) {
    const t = normalizeAssistantCommand(text).toLowerCase();
    const asksCount = /(?:কয়টা|কত|how many|count).*(?:offline|ফিচার|feature)|(?:offline|অফলাইন).*(?:100|একশ|ফিচার|feature).*(?:আছে|কী কী|কি কি|list|show|দেখাও|দেখিয়ে)/iu.test(t);
    if (asksCount) {
      return {
        text: language === 'bn'
          ? `বস, আমার Offline 100 Feature Pack-এ ঠিক ${OFFLINE_100_FEATURE_COUNT}টা capability আছে। ২০০-item local memory limit আগের মতোই আছে।`
          : `Boss, the Offline 100 Feature Pack contains exactly ${OFFLINE_100_FEATURE_COUNT} capabilities. The 200-item local memory limit is unchanged.`,
        intent: 'help',
      };
    }

    const featureMatch = t.match(/(?:feature|ফিচার)\s*(?:#|নম্বর|number)?\s*(\d{1,3})/iu);
    if (featureMatch) {
      const feature = getOffline100Feature(Number(featureMatch[1]));
      if (!feature) {
        return {
          text: language === 'bn' ? 'বস, ১ থেকে ১০০-এর মধ্যে feature number বলো।' : 'Boss, choose a feature number from 1 to 100.',
          intent: 'help',
        };
      }
      return {
        text: language === 'bn'
          ? `বস, ${feature.number}. ${feature.bengali} — ${feature.note}`
          : `Boss, ${feature.number}. ${feature.name} — ${feature.note}`,
        intent: 'help',
      };
    }

    if (/(?:list|show|দেখাও|দেখিয়ে দাও).*(?:100|একশ).*(?:feature|ফিচার)|(?:100|একশ).*(?:feature|ফিচার).*(?:list|তালিকা)/iu.test(t)) {
      const first = OFFLINE_100_FEATURES.slice(0, 12).map((feature) => `${feature.number}. ${language === 'bn' ? feature.bengali : feature.name}`).join('\n');
      return {
        text: language === 'bn'
          ? `বস, মোট ${OFFLINE_100_FEATURE_COUNT}টা আছে। প্রথম ১২টা:\n${first}\nবাকি feature-গুলোও project-এর Offline 100 registry-তে রাখা আছে।`
          : `Boss, there are ${OFFLINE_100_FEATURE_COUNT} total. First 12:\n${first}\nThe remaining features are also stored in the Offline 100 registry.`,
        intent: 'help',
      };
    }

    return null;
  },
};

export const offlineMegaSystemsExtension: AssistantExtension = {
  id: 'offline-4-12-mega-systems',
  async handle(request) {
    return getMegaOfflineReply(request);
  },
};

export const offlineSystemsExtension: AssistantExtension = {
  id: 'offline-4-11-local-systems',
  async handle(request) {
    return getOfflineSystemsReply(request);
  },
};

export const offlineAdvancedExtension: AssistantExtension = {
  id: 'offline-advanced-system-engine',
  async handle(request) {
    return getAdvancedOfflineReply(request);
  },
};

export const offlineCommandExtension: AssistantExtension = {
  id: 'offline-command-and-conversation-brain',
  async handle({ text, language, now = new Date(), memory, conversationContext }) {
    const resolvedText = resolveFollowUp(text, conversationContext);
    const aliasResolved = await resolveLocalAlias(resolvedText);
    const effectiveText = aliasResolved ?? resolvedText;
    const thought = thinkOffline(effectiveText);
    const normalized = normalizeNumerals(effectiveText);
    // Keep Bengali output stable even if Android speech recognition briefly returns an English token.
    const detectedLanguage = detectAssistantLanguage(text, language);
    const bengali = detectedLanguage === 'bn' || hasBengali(text);
    const reply = (bn: string, en: string, intent: AssistantIntent) => ({
      text: bengali
        ? (bn.startsWith('বস') ? bn : `বস, ${bn}`)
        : (en.startsWith('Boss') ? en : `Boss, ${en}`),
      intent,
    });

    const plannedTasks = planOfflineTasks(normalized);
    if (plannedTasks.length > 1) {
      return { text: bengali ? `বস, ${plannedTasks.length}টা কাজ ধাপে ধাপে করব।` : `Boss, I’ll handle ${plannedTasks.length} tasks step by step.`, intent: 'task-plan', plannedTasks };
    }

    const learnAlias = normalized.match(/^(?:শিখে রাখো|এই কমান্ড মনে রাখো|learn command|learn alias)\s+(.+?)\s*(?:মানে|means|as|=|->)\s*(.+)$/iu);
    if (learnAlias) {
      return { text: bengali ? `ঠিক আছে, “${learnAlias[1].trim()}” কমান্ডের অর্থ শিখে রাখলাম।` : `Okay, I learned what “${learnAlias[1].trim()}” means.`, intent: 'memory' as AssistantIntent, noteText: learnAlias[1].trim(), noteQuery: learnAlias[2].trim() };
    }

    const noteAdd = normalized.match(/^(?:নোট করে রাখো|নোট রাখো|save note|take a note|note this)\s*[:：-]?\s*(.+)$/iu);
    if (noteAdd?.[1]) return { text: bengali ? 'ঠিক আছে, নোটটা এই ডিভাইসে সেভ করলাম।' : 'Okay, I saved the note on this device.', intent: 'notes', noteText: noteAdd[1].trim() };
    const noteSearch = normalized.match(/^(?:নোট খুঁজে দাও|নোট দেখাও|search notes|find note)\s*[:：-]?\s*(.*)$/iu);
    if (noteSearch) return { text: bengali ? 'লোকাল নোটগুলো খুঁজছি…' : 'Searching local notes…', intent: 'notes', noteQuery: noteSearch[1]?.trim() ?? '' };

    const routineSave = normalized.match(/^(?:রুটিন বানাও|save routine|create routine)\s+(.+?)\s*(?:[:：]|=|->|মানে)\s*(.+)$/iu);
    if (routineSave) return { text: bengali ? `রুটিন “${routineSave[1].trim()}” সেভ করছি।` : `Saving routine “${routineSave[1].trim()}”.`, intent: 'routine', routineName: routineSave[1].trim(), routineCommand: routineSave[2].trim() };
    const routineRun = normalized.match(/^(?:রুটিন চালাও|run routine|start routine)\s+(.+)$/iu);
    if (routineRun) return { text: bengali ? `রুটিন “${routineRun[1].trim()}” চালানোর প্রস্তুতি নিচ্ছি।` : `Preparing routine “${routineRun[1].trim()}”.`, intent: 'routine', routineName: routineRun[1].trim() };

    const unitMatch = normalized.match(/(?:convert|কনভার্ট|রূপান্তর)\s+(-?\d+(?:\.\d+)?)\s*([a-z°]+|কিলোমিটার|মিটার|সেন্টিমিটার|মাইল|কেজি|কিলোগ্রাম|গ্রাম|পাউন্ড|সেলসিয়াস|সেলসিয়াস|ফারেনহাইট|লিটার|মিলিলিটার)\s+(?:to|into|থেকে|এ|তে)\s*([a-z°]+|কিলোমিটার|মিটার|সেন্টিমিটার|মাইল|কেজি|কিলোগ্রাম|গ্রাম|পাউন্ড|সেলসিয়াস|সেলসিয়াস|ফারেনহাইট|লিটার|মিলিলিটার)/iu);
    if (unitMatch) {
      const converted = convertOfflineUnit(Number(unitMatch[1]), unitMatch[2], unitMatch[3]);
      if (converted !== null) return { text: bengali ? `রূপান্তরের ফল: ${Number(converted.toFixed(6))} ${unitMatch[3]}` : `Converted: ${Number(converted.toFixed(6))} ${unitMatch[3]}`, intent: 'unit-converter' as AssistantIntent };
    }

    const textAnalysis = normalized.match(/^(?:analyze text|text analysis|লেখা বিশ্লেষণ|টেক্সট বিশ্লেষণ)\s*[:：-]?\s*(.+)$/iu);
    if (textAnalysis) {
      const a = analyzeOfflineText(textAnalysis[1]);
      return { text: bengali ? `শব্দ ${a.words}, বাক্য ${a.sentences}, অক্ষর ${a.characters}।` : `Words ${a.words}, sentences ${a.sentences}, characters ${a.characters}.`, intent: 'text-analysis' };
    }

    const diagnostics = /(?:battery|charge|battery level|storage|free space|ram|memory usage|device status|phone status|network status|নেটওয়ার্ক|ব্যাটারি|চার্জ|স্টোরেজ|ফাঁকা জায়গা|র‍্যাম|ফোনের অবস্থা|ডিভাইসের অবস্থা)/iu.test(normalized);
    if (diagnostics) return { text: bengali ? 'ডিভাইসের বর্তমান অবস্থা দেখছি…' : 'Checking your device status…', intent: 'diagnostics' as AssistantIntent };

    const reminderMatch = normalized.match(/(?:remind me|set reminder|reminder|মনে করিয়ে দাও|মনে করিয়ে দাও|মনে করাও|রিমাইন্ডার)\s+(?:in|পর|পরে)?\s*(\d+)\s*(second|seconds|sec|সেকেন্ড|minute|minutes|min|মিনিট|hour|hours|hr|ঘণ্টা|ঘন্টা)\s+(?:to|that|যে|যাতে)?\s*(.+)$/iu);
    if (reminderMatch) {
      const amount = Number(reminderMatch[1]);
      const unit = reminderMatch[2].toLowerCase();
      const multiplier = /second|sec|সেকেন্ড/i.test(unit) ? 1000 : /hour|hr|ঘণ্টা|ঘন্টা/i.test(unit) ? 3600000 : 60000;
      return {
        text: bengali ? `ঠিক আছে, ${amount} ${unit}-এর মধ্যে মনে করিয়ে দেব।` : `Okay, I’ll remind you in ${amount} ${unit}.`,
        intent: 'reminder' as AssistantIntent,
        reminderText: reminderMatch[3].trim(),
        reminderDelayMs: Math.max(1000, Math.min(amount * multiplier, 7 * 24 * 3600000)),
      };
    }

    if (/^(?:undo|undo that|আগের কাজটা বাতিল করো|আগের কাজ বাতিল করো|পেছনের কাজটা ফেরত নাও)$/iu.test(normalized)) {
      return { text: bengali ? 'আগের reversible কাজটা ফিরিয়ে দেওয়ার চেষ্টা করছি…' : 'I’ll try to undo the last reversible action…', intent: 'undo' as AssistantIntent };
    }

    const greeting = smartGreeting(text, bengali, memory);
    if (greeting) return { text: bengali ? `বস, ${greeting}` : `Boss, ${greeting}`, intent: 'greeting' as AssistantIntent };

    // If a request is genuinely ambiguous, prefer a short clarification rather
    // than performing a random device action. Clear commands continue normally.
    if (thought.ambiguous && conversationContext?.length) {
      return reply(
        'কোন কাজটা বোঝাচ্ছো—আগের কাজটাই করব, নাকি অন্য কিছু?',
        'Which action do you mean—the previous one, or something else?',
        'casual',
      );
    }

    // Offline planning hint for multi-step requests. The actual device handlers
    // still execute only supported deterministic actions, so an unsafe/destructive
    // phrase is never executed just because it appeared inside a compound sentence.
    if (/(?:এবং|তারপর|পরে|and then|then|after that|also)/iu.test(normalized) && thought.confidence >= 0.54) {
      const parts = normalized.split(/\s+(?:এবং|তারপর|পরে|and then|then|after that|also)\s+/iu).filter(Boolean);
      if (parts.length > 1 && !thought.destructive) {
        const first = parts[0];
        if (first && /(?:open|launch|খোলো|চালু|volume|ভলিউম|screen|স্ক্রিন|flashlight|ফ্ল্যাশ|back|home|হোম|পিছনে)/iu.test(first)) {
          // Fall through with the first task; context remains available for the next turn.
          // This makes compound speech predictable instead of sending the whole sentence
          // to an online model when a local action is already obvious.
        }
      }
    }

    const directPhoneNumber = extractDirectPhoneNumber(text);
    const appCallMatch = resolvedText.match(/^(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)\s*(?:এ|তে|-এ|-তে|e|te)?\s+(.+?)\s+(?:কে|এর কাছে)?\s*(?:call|কল|phone|ফোন|video call|voice call|audio call)(?:\s+(?:dao|দাও|করো|করুন|please|koro))?\s*$/iu)
      || resolvedText.match(/^(.+?)\s+(?:কে|এর কাছে)?\s*(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)\s*(?:এ|তে|-এ|-তে)?\s+(?:call|কল|phone|ফোন|video call|voice call|audio call)(?:\s+(?:dao|দাও|করো|করুন|please|koro))?\s*$/iu);
    if (appCallMatch) {
      const appWord = resolvedText.match(/^(whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)/iu)?.[1]?.toLowerCase()
        ?? resolvedText.match(/(whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)/iu)?.[1]?.toLowerCase()
        ?? '';
      const appCallTarget = /imo|ইমু/i.test(appWord) ? 'imo' : /messenger|মেসেঞ্জার/i.test(appWord) ? 'messenger' : 'whatsapp';
      const contactQuery = /^(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)/iu.test(resolvedText)
        ? appCallMatch[1].replace(/\s+(?:কে|এর কাছে)$/u, '').trim()
        : appCallMatch[1].replace(/\s+(?:কে|এর কাছে)?\s*(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ|messenger|মেসেঞ্জার|imo|ইমু)\s*(?:এ|তে|-এ|-তে)?\s*$/iu, '').trim();
      if (contactQuery) {
        return {
          text: language === 'bn' ? `${appCallTarget === 'whatsapp' ? 'WhatsApp' : appCallTarget === 'messenger' ? 'Messenger' : 'IMO'}-এ ${contactQuery}-কে কল দেওয়ার চেষ্টা করছি…` : `Trying to call ${contactQuery} on ${appCallTarget}.`,
          intent: 'call-via-app',
          contactQuery,
          appCallTarget,
        };
      }
    }

    const callQuery = extractCallQuery(text);
    if (directPhoneNumber) {
      return {
        ...reply(
          `${directPhoneNumber}-এ কল দিচ্ছি…`,
          `Calling ${directPhoneNumber}…`,
          'call-contact',
        ),
        contactQuery: directPhoneNumber,
      };
    }

    if (callQuery) {
      return {
        ...reply(
          `${callQuery}-এর নম্বর খুঁজছি…`,
          `Looking for ${callQuery} in your contacts…`,
          'call-contact',
        ),
        contactQuery: callQuery,
      };
    }

    const requestedVolume = (() => {
      const m = normalized.match(/(?:volume|ভলিউম|শব্দ)\s*(?:to|at|করে|করো|এ|এতে)?\s*([0-9]{1,3})\s*(?:%|percent|শতাংশ)?/i);
      if (!m) return null;
      const value = Number(m[1]);
      return Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : null;
    })();

    const deviceAction = (() => {
      if (requestedVolume !== null) return 'volume-set' as const;
      if (/(?:back|go back|go backwards|পিছনে|পেছনে|আগের পেজ|আগের পাতায়|আগের পৃষ্ঠায়)/i.test(normalized)) return 'back' as const;
      if (/(?:home|go home|home screen|হোমে|হোম স্ক্রিনে|মূল স্ক্রিনে)/i.test(normalized)) return 'home' as const;
      if (/(?:recent apps|recents|recent|সাম্প্রতিক অ্যাপ|রিসেন্ট অ্যাপ|আগের অ্যাপগুলো|আগের অ্যাপ|recent app)/i.test(normalized)) return 'recents' as const;
      if (/(?:notifications|notification panel|notification shade|নোটিফিকেশন|বিজ্ঞপ্তি|নোটিফিকেশন প্যানেল)/i.test(normalized)) return 'notifications' as const;
      if (/(?:quick settings|quick panel|control center|কুইক সেটিংস|কুইক প্যানেল|কন্ট্রোল সেন্টার)/i.test(normalized)) return 'quick-settings' as const;
      if (/(?:power menu|power dialog|পাওয়ার মেনু|পাওয়ার মেনু|পাওয়ার অপশন|পাওয়ার অপশন|পাওয়ার বাটন মেনু)/i.test(normalized)) return 'power-menu' as const;
      if (/(?:screen on|turn on screen|wake screen|wake up the screen|স্ক্রিন অন|স্ক্রিন চালু|স্ক্রিন জ্বালাও|স্ক্রিনটা জ্বালাও|স্ক্রিন খুলে দাও|স্ক্রিন চালু করো|ফোনের স্ক্রিন অন)/i.test(normalized)) return 'wake-screen' as const;
      if (/(?:lock screen|screen lock|lock the phone|ফোনটা লক|স্ক্রিন লক|স্ক্রিন বন্ধ|স্ক্রিন অফ|স্ক্রিন অফ করো|ফোন লক)/i.test(normalized)) return 'lock-screen' as const;
      if (/(?:screenshot|screen shot|capture screen|স্ক্রিনশট|স্ক্রিন শট|স্ক্রিনের ছবি|স্ক্রিন ক্যাপচার)/i.test(normalized)) return 'screenshot' as const;
      if (/(?:split screen|split-screen|দুই অ্যাপ পাশাপাশি|স্প্লিট স্ক্রিন|দুইটা অ্যাপ একসাথে)/i.test(normalized)) return 'split-screen' as const;

      if (/(?:flashlight|torch|ফ্ল্যাশলাইট|ফ্লাশলাইট|টর্চ).*(?:on|চালু|জ্বালাও|জ্বালিয়ে|জ্বালিয়ে)/i.test(normalized)
        || /(?:on|চালু|জ্বালাও).*(?:flashlight|torch|ফ্ল্যাশলাইট|ফ্লাশলাইট|টর্চ)/i.test(normalized)) return 'flashlight-on' as const;
      if (/(?:flashlight|torch|ফ্ল্যাশলাইট|ফ্লাশলাইট|টর্চ).*(?:off|বন্ধ|নিভাও|নিভিয়ে|নিভিয়ে)/i.test(normalized)
        || /(?:off|বন্ধ|নিভাও).*(?:flashlight|torch|ফ্ল্যাশলাইট|ফ্লাশলাইট|টর্চ)/i.test(normalized)) return 'flashlight-off' as const;

      if (/(?:play|resume|media play|মিডিয়া চালাও|মিডিয়া চালাও|গান চালাও|প্লে করো)/i.test(normalized)) return 'media-play' as const;
      if (/(?:pause|media pause|থামাও|পজ করো|গান থামাও)/i.test(normalized)) return 'media-pause' as const;
      if (/(?:next|next track|পরের গান|পরেরটা|পরের ট্র্যাক)/i.test(normalized)) return 'media-next' as const;
      if (/(?:previous|prev|previous track|আগের গান|আগের ট্র্যাক|আগেরটা)/i.test(normalized)) return 'media-previous' as const;

      if (/(?:volume up|increase volume|turn.*volume.*up|sound up|raise.*volume|শব্দ বাড়াও|শব্দ বাড়াও|শব্দটা.*বাড়|ভলিউম বাড়াও|ভলিউম বাড়াও|ভলিউমটা.*বাড়|ভলিউম.*বাড়াইতে|ভলিউম.*বাড়াতে|ভলিউম.*বাড়ায়|ভলিউম.*বাড়াইয়া|ভলিউম.*বাড়িয়ে|ভলিউম.*উঁচু|ভলিউম.*জোর|ভলিউম.*বাড়িয়ে|ভলিউম.*বাড়াইয়া|শব্দ.*বাড়াইতে|শব্দ.*বাড়াতে|শব্দ.*বাড়িয়ে|ভলিউমটা.*বাড়|ভলিউম.*বাড়াই|ভলিউম.*বাড়াতে|ভলিউম.*বাড়িয়ে দাও|শব্দ.*বাড়িয়ে দাও)/i.test(normalized)) return 'volume-up' as const;
      if (/(?:volume down|decrease volume|turn.*volume.*down|sound down|lower.*volume|শব্দ কমাও|ভলিউম কমাও|ভলিউমটা.*কম|শব্দটা.*কম|ভলিউম.*কমাইতে|ভলিউম.*কমাতে|ভলিউম.*কমায়|ভলিউম.*কমাইয়া|ভলিউম.*নিচু|ভলিউম.*আস্তে|ভলিউম.*কমিয়ে|ভলিউম.*কমাইয়া|শব্দ.*কমাইতে|শব্দ.*কমাতে|ভলিউম.*কমান|ভলিউম.*কমিয়ে দাও|ভলিউম.*কমানো|শব্দ.*কমিয়ে দাও)/i.test(normalized)) return 'volume-down' as const;
      if (/(?:mute|silent|turn.*sound.*off|শব্দ বন্ধ|মিউট|সাইলেন্ট|নীরব)/i.test(normalized)) return 'volume-mute' as const;
      if (/(?:vibrate|vibration|ভাইব্রেশন|কম্পন)/i.test(normalized)) return 'vibrate' as const;
      if (/(?:ringer normal|normal sound|রিংটোন স্বাভাবিক|স্বাভাবিক শব্দ)/i.test(normalized)) return 'ringer-normal' as const;

      if (/(?:wifi settings|wi-fi settings|wifi panel|open wifi|ওয়াইফাই|ওয়াইফাই|ওয়াই-ফাই|ওয়াই-ফাই|wifi-তে যাও|wifi চালু|ওয়াইফাই চালু|ওয়াইফাই চালু)/i.test(normalized)) return 'wifi-settings' as const;
      if (/(?:bluetooth settings|bluetooth panel|open bluetooth|ব্লুটুথ|bluetooth-এ যাও|ব্লুটুথ চালু)/i.test(normalized)) return 'bluetooth-settings' as const;
      if (/(?:mobile data|mobile internet|cellular data|data settings|open data|ডাটা|ডেটা|মোবাইল ডাটা|মোবাইল ডেটা|ইন্টারনেট চালু|মোবাইল ইন্টারনেট)/i.test(normalized)) return 'mobile-data-panel' as const;
      if (/(?:open settings|phone settings|android settings|settings kholo|সেটিংস খোলো|সেটিংস খুলে|ফোনের সেটিংস|সেটিংস এ যাও|সেটিংসে যাও)/i.test(normalized)) return 'settings' as const;
      return null;
    })();

    if (deviceAction) {
      const labels: Record<typeof deviceAction, [string,string]> = {
        back: ['পিছনে যাচ্ছি।','Going back.'],
        home: ['হোম স্ক্রিনে যাচ্ছি।','Going to the home screen.'],
        recents: ['সাম্প্রতিক অ্যাপ দেখাচ্ছি।','Opening recent apps.'],
        notifications: ['নোটিফিকেশন প্যানেল খুলছি।','Opening notifications.'],
        'quick-settings': ['কুইক সেটিংস খুলছি।','Opening quick settings.'],
        'power-menu': ['পাওয়ার মেনু খুলছি।','Opening the power menu.'],
        'lock-screen': ['ফোন লক করছি।','Locking the screen.'],
        'wake-screen': ['স্ক্রিন অন করছি।','Waking the screen.'],
        screenshot: ['স্ক্রিনশট নিচ্ছি।','Taking a screenshot.'],
        'split-screen': ['স্প্লিট স্ক্রিন চালু করার চেষ্টা করছি।','Trying to enter split-screen mode.'],
        'volume-up': ['ভলিউম বাড়াচ্ছি।','Increasing volume.'],
        'volume-down': ['ভলিউম কমাচ্ছি।','Decreasing volume.'],
        'volume-mute': ['মিডিয়া ভলিউম মিউট করছি।','Muting media volume.'],
        'flashlight-on': ['ফ্ল্যাশলাইট চালু করছি।','Turning the flashlight on.'],
        'flashlight-off': ['ফ্ল্যাশলাইট বন্ধ করছি।','Turning the flashlight off.'],
        'media-play': ['মিডিয়া চালু করছি।','Playing media.'],
        'media-pause': ['মিডিয়া থামাচ্ছি।','Pausing media.'],
        'media-next': ['পরের ট্র্যাকে যাচ্ছি।','Skipping to the next track.'],
        'media-previous': ['আগের ট্র্যাকে যাচ্ছি।','Going to the previous track.'],
        'vibrate': ['ফোন ভাইব্রেশনে দিচ্ছি।','Switching to vibrate mode.'],
        'ringer-normal': ['রিংটোন স্বাভাবিক করছি।','Restoring normal ringer mode.'],
        'volume-set': [requestedVolume !== null ? `মিডিয়া ভলিউম ${requestedVolume}% করছি।` : 'মিডিয়া ভলিউম সেট করছি।', 'Setting media volume.'],
        settings: ['সেটিংস কন্ট্রোল আমার কাছে খোলা নেই। তুমি অন্য কাজের কমান্ড দাও।','General Settings control is not exposed to me. Give me another command.'],
        'wifi-settings': ['Wi-Fi কন্ট্রোল প্যানেল খুলছি।','Opening the Wi-Fi control panel.'],
        'bluetooth-settings': ['Bluetooth কন্ট্রোল প্যানেল খুলছি।','Opening the Bluetooth control panel.'],
        'mobile-data-panel': ['মোবাইল ডাটা কন্ট্রোল প্যানেল খুলছি।','Opening the mobile-data control panel.'],
      };
      const [bn,en] = labels[deviceAction];
      return { ...reply(bn,en,'device-action'), deviceAction };
    }

    if (/(?:read (?:the )?screen|what(?:'s| is) on screen|স্ক্রিনে কী আছে|স্ক্রিনটা পড়ে শোনাও|স্ক্রিন পড়ো|স্ক্রিনের লেখা বলো)/i.test(normalized)) {
      return { ...reply('স্ক্রিনের লেখা পড়ছি…','Reading the current screen…','screen-read') };
    }

    // Smart offline intent repair: understand indirect/polite phrasing and
    // common mixed-language wording before falling back to Gemini online.
    const repaired = normalized
      .replace(/(?:তুমি|আপনি|তুই)\s+(?:কি|কী)\s+/u, '')
      .replace(/(?:আমার জন্য|আমাকে)\s+/u, '')
      .replace(/(?:একটু|দয়া করে|দয়া করে|প্লিজ|please|kindly)\s+/giu, '')
      .trim();

    if (/(?:আবার বলো|আবার বল|পুনরায় বল|পুনরায় বল|repeat that|say that again|say it again|again please)/i.test(repaired)) {
      return reply(
        'অবশ্যই—শেষ কথাটা আবার বলছি।',
        'Sure — I’ll repeat that.',
        'casual',
      );
    }

    if (/(?:থামো|চুপ|চুপ করো|stop talking|stop speaking|be quiet|শব্দ বন্ধ করো)/i.test(repaired)) {
      return reply('ঠিক আছে। কথা বলা থামালাম।', 'Okay. I stopped speaking.', 'casual');
    }

    // More natural screen-control grammar: users can omit the word “screen”.
    const naturalScreen = (() => {
      const click = repaired.match(/(?:click|tap|press|চাপ|ট্যাপ|ক্লিক)\s+(?:on\s+)?(.+?)(?:\s+(?:please|দাও|করো|করুন))?$/iu);
      if (click?.[1] && !/(?:volume|শব্দ|ভলিউম|app|অ্যাপ|খোলো|open)/i.test(click[1])) {
        return { action: 'click' as const, target: click[1].trim() };
      }
      const scroll = repaired.match(/(?:scroll|স্ক্রল|swipe|সোয়াইপ|সোয়াইপ)\s*(up|down|left|right|উপরে|নিচে|বামে|ডানে)/iu);
      if (scroll?.[1]) {
        const dir = /up|উপরে/i.test(scroll[1]) ? 'up' : /down|নিচে/i.test(scroll[1]) ? 'down' : /left|বামে/i.test(scroll[1]) ? 'left' : 'right';
        return { action: 'scroll' as const, target: dir };
      }
      return null;
    })();
    if (naturalScreen) {
      return {
        ...reply(naturalScreen.action === 'click' ? `স্ক্রিনে ${naturalScreen.target}-এ চাপার চেষ্টা করছি…` : `${naturalScreen.target === 'up' ? 'উপরে' : naturalScreen.target === 'down' ? 'নিচে' : naturalScreen.target === 'left' ? 'বামে' : 'ডানে'} স্ক্রল করছি…`, naturalScreen.action === 'click' ? `Trying to tap ${naturalScreen.target}…` : `Scrolling ${naturalScreen.target}…`, 'screen-control'),
        screenAction: naturalScreen.action,
        screenTarget: naturalScreen.target,
      };
    }

    // Universal screen control: natural Bangla/Banglish commands for Accessibility.
    // Examples: "স্ক্রিনে OK চাপো", "ওই বাটনে ক্লিক করো", "এটা লিখে দাও", "নিচে স্ক্রল করো".
    const screenControl = (() => {
      const click = repaired.match(/(?:স্ক্রিনে|screen)\s+(.+?)\s+(?:চাপো|চাপ দাও|ক্লিক করো|click|tap|ট্যাপ করো|চাপতে)/iu);
      if (click?.[1]) return { action: 'click' as const, target: click[1].trim() };
      const type = repaired.match(/(?:এটা|ওটা|এইটা|text|লেখা|বার্তা)\s*(?:লিখে দাও|লিখো|টাইপ করো|type|write)(?:\s*[:：-]?\s*)(.*)$/iu);
      if (type?.[1]) return { action: 'type' as const, target: type[1].trim() };
      const type2 = repaired.match(/(?:লিখে দাও|টাইপ করে দাও|type this|write this)\s*[:：-]?\s*(.+)$/iu);
      if (type2?.[1]) return { action: 'type' as const, target: type2[1].trim() };
      if (/(?:উপরে|up|স্ক্রল up|স্ক্রল উপরে|উপরে স্ক্রল)/iu.test(repaired)) return { action: 'scroll' as const, target: 'up' };
      if (/(?:নিচে|down|স্ক্রল down|স্ক্রল নিচে|নিচে স্ক্রল)/iu.test(repaired)) return { action: 'scroll' as const, target: 'down' };
      if (/(?:বামে|left|বাম দিকে স্ক্রল)/iu.test(repaired)) return { action: 'scroll' as const, target: 'left' };
      if (/(?:ডানে|right|ডান দিকে স্ক্রল)/iu.test(repaired)) return { action: 'scroll' as const, target: 'right' };
      return null;
    })();
    if (screenControl) {
      return {
        ...reply(
          screenControl.action === 'click' ? `স্ক্রিনে ${screenControl.target} চাপার চেষ্টা করছি…` : screenControl.action === 'type' ? 'স্ক্রিনের সক্রিয় ঘরে লেখাটি দেওয়ার চেষ্টা করছি…' : `${screenControl.target === 'up' ? 'উপরে' : screenControl.target === 'down' ? 'নিচে' : screenControl.target === 'left' ? 'বামে' : 'ডানে'} স্ক্রল করছি…`,
          screenControl.action === 'click' ? `Trying to tap ${screenControl.target} on screen…` : screenControl.action === 'type' ? 'Trying to type into the focused field…' : `Scrolling ${screenControl.target}…`,
          'screen-control'
        ),
        screenAction: screenControl.action,
        screenTarget: screenControl.target,
      };
    }

    const universalSearch = extractUniversalSearchRequest(repaired);
    if (universalSearch) {
      return {
        text:
          language === 'bn'
            ? `${universalSearch.appQuery}-এ "${universalSearch.searchQuery}" খুঁজে চালু করার চেষ্টা করছি…`
            : `I’ll open ${universalSearch.appQuery}, search for "${universalSearch.searchQuery}", and open the result.`,
        intent: 'universal-screen-control',
        appQuery: universalSearch.appQuery,
        automationQuery: universalSearch.searchQuery,
      };
    }

    const appQuery = extractAppQuery(repaired);
    if (appQuery) {
      return {
        ...reply(
          'ইনস্টল করা অ্যাপটি খুঁজছি…',
          'Looking for that installed app…',
          'open-app',
        ),
        appQuery,
      };
    }

    if (/^(?:clear|clear chat|reset chat|চ্যাট মুছো|সব মুছে দাও)$/.test(normalized)) {
      return reply(
        'ঠিক আছে, পুরোনো কথাগুলো সরিয়ে দিলাম। এবার নতুন করে শুরু করি!',
        'Done. I cleared the old messages. Fresh start!',
        'clear-history',
      );
    }

    if (
      /^(?:hi|hello|hey|good morning|good evening|হাই|হ্যালো|আসসালামু আলাইকুম|সালাম)$/.test(
        normalized,
      )
    ) {
      const name = rememberedName(memory);
      return reply(
        variant([
          `হ্যালো${name ? ` ${name}` : ''}! আজ কী নিয়ে একটু বুদ্ধি খাটাব?`,
          `সালাম${name ? ` ${name}` : ''}! বলো, আজকের অভিযান কোন দিকে?`,
          `হাই${name ? ` ${name}` : ''}! আড্ডা, অঙ্ক, নাকি কোনো কাজ—তুমি বেছে নাও।`,
        ]),
        variant([
          `Hey${name ? ` ${name}` : ''}! What are we figuring out today?`,
          `Hello${name ? ` ${name}` : ''}! Pick a topic and I’ll do my best offline impression of a genius.`,
          `Hi${name ? ` ${name}` : ''}! Need a hand, a joke, or just a chat?`,
        ]),
        'greeting',
      );
    }

    if (
      /(?:what do you remember|তুমি কী মনে রেখেছ|কি মনে রেখেছ|কী মনে রেখেছ)/i.test(
        normalized,
      )
    ) {
      const facts = memory?.facts ?? [];
      return reply(
        facts.length
          ? `এই ডিভাইসে মনে রেখেছি:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'এখনো আলাদা করে কিছু মনে রাখিনি। চাইলে “মনে রাখো, আমি…” বলে কোনো পছন্দ জানাতে পারো।',
        facts.length
          ? `Saved on this device:\n${facts.map((fact) => `• ${fact}`).join('\n')}`
          : 'I haven’t saved any facts yet. Say “remember that I…” to save a preference locally.',
        'memory',
      );
    }

    if (/(?:what were we (?:discussing|talking about)|আগে কী বলছিলাম|আমরা কী নিয়ে কথা বলছিলাম|আমরা কি নিয়ে কথা বলছিলাম)/i.test(normalized)) {
      const topics = memory?.recentTopics ?? [];
      return reply(
        topics.length
          ? `সাম্প্রতিক কথা ছিল:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'এই ডিভাইসে এখনো সাম্প্রতিক কথার প্রসঙ্গ জমেনি।',
        topics.length
          ? `Recently, we talked about:\n${topics.slice(-3).map((topic) => `• ${topic}`).join('\n')}`
          : 'There isn’t any recent conversation context saved on this device yet.',
        'memory',
      );
    }

    if (/(?:how are you|how'?s it going|কেমন আছো|কেমন আছেন|আজকে কেমন|কি খবর|কী খবর)/i.test(normalized)) {
      return reply(
        variant([
          'আমার মানুষের মতো অনুভূতি নেই, তবে তোমার সঙ্গে আড্ডা দিতে আর কাজে লাগতে প্রস্তুত। তোমার খবর কী?',
          'আমি অনুভূতি পাই না—তবে অফলাইনেও বেশ ফুরফুরে! তোমার দিনটা কেমন যাচ্ছে?',
          'মানুষের মতো ভালো-মন্দ লাগা নেই, কিন্তু সাহায্য করতে একদম রেডি। আজ কী চলছে?',
        ]),
        variant([
          'I don’t have feelings like a person, but I’m ready to chat and help. How are you doing?',
          'No human moods on my side, but I’m here and ready. How’s your day going?',
          'I’m not conscious, but I can still be a pretty good conversation buddy. What’s up?',
        ]),
        'casual',
      );
    }

    if (/(?:আড্ডা|গল্প করি|চলো কথা বলি|chat with me|let'?s chat|talk to me)/i.test(normalized)) {
      return reply(
        variant([
          'চল! আজকের দিনের সবচেয়ে মজার বা অদ্ভুত ঘটনাটা কী?',
          'আড্ডা জমুক। খাবার, সিনেমা, ভ্রমণ—কোন বিষয় দিয়ে শুরু করব?',
          'আমি প্রস্তুত। তুমি একটা বিষয় ছুড়ে দাও, আমি কথার বলটা ধরছি!',
        ]),
        variant([
          'I’m in. What was the most interesting thing about your day?',
          'Let’s chat. Food, movies, travel, or a wonderfully specific question?',
          'Deal. Toss me a topic and I’ll keep the conversation going offline.',
        ]),
        'casual',
      );
    }

    if (
      /^(?:hi|hello|hey|thanks|thank you|ধন্যবাদ|থ্যাংকস|বিদায়|বিদায়|বাই|bye)[!. ]*$/i.test(
        normalized,
      )
    ) {
      return reply(
        variant([
          'স্বাগতম! দরকার হলে আবার ডাক দিও।',
          'ধন্যবাদ তোমাকেও! আড্ডার দরজা খোলা থাকল।',
          'বাই! কাজটা হলে কৃতিত্ব তোমার, না হলে দোষটা নেটওয়ার্কের—যদিও আমি অফলাইন!',
        ]),
        variant([
          'Anytime. I’ll be right here when you need me.',
          'Thanks for chatting. The offline door is always open.',
          'See you! If anything goes wrong, we can blame the math. Mostly.',
        ]),
        'casual',
      );
    }

    if (
      /(?:help|what can you do|commands|সাহায্য|কী করতে পারো|কি করতে পারো|কমান্ড)/.test(
        normalized,
      )
    ) {
      return reply(
        'আমি সময়-তারিখ, অঙ্ক, একক রূপান্তর, আড্ডা, স্মৃতি, অ্যাপ খোলা, ভলিউম/ফ্ল্যাশ/মিডিয়া, হোম-ব্যাক-রিসেন্ট-নোটিফিকেশন, স্ক্রিনশট, Wi‑Fi/Bluetooth/ইন্টারনেট প্যানেল, স্ক্রিনের লেখা পড়া এবং অনুমতি থাকলে কল/মেসেজ ও স্ক্রিনে ক্লিক-টাইপ করার কাজ করতে পারি।',
        'Offline: time/date, multi-step arithmetic, common unit conversion, casual chat, jokes, local memories, Android app launching, and contact/direct-number calls with Android permission and confirmation.',
        'help',
      );
    }

    if (/(?:তোমার নাম কী|তোমার নাম কি|who are you|what is your name|what's your name)/i.test(normalized)) {
      return reply(
        'আমার নাম আবির AI। আমি এই ফোনের Android Assistant। আমি offline ও online—দুইভাবেই কাজ করি; নেট না থাকলেও অনেক সাধারণ কথা, অঙ্ক, সময়-তারিখ, স্মৃতি আর ফোনের অনুমোদিত কমান্ড সামলাতে পারি।',
        'I’m Abir AI, your on-device assistant. I can still handle many everyday conversations, calculations, time/date, memory, and device commands offline.',
        'casual',
      );
    }

    if (/(?:তুমি কি অফলাইনে কাজ করতে পারো|অফলাইনে কাজ করো|can you work offline|do you work offline)/i.test(normalized)) {
      return reply(
        'হ্যাঁ। আমার লোকাল ব্রেইন ইন্টারনেট ছাড়াই সাধারণ কথা, অঙ্ক, সময়-তারিখ, স্মৃতি আর কিছু ডিভাইস কমান্ড বুঝতে পারে। তবে ওয়েবের খবর বা অনলাইন AI দরকার এমন প্রশ্নে ইন্টারনেট লাগবে।',
        'Yes. My local brain can handle everyday chat, math, time/date, memory, and supported device commands without internet. Web information and some advanced AI tasks still need a connection.',
        'help',
      );
    }

    if (/(?:শুভ সকাল|সুপ্রভাত|good morning)/i.test(normalized)) {
      return reply('সুপ্রভাত! আজকের কাজটা বলো, আবির প্রস্তুত।', 'Good morning! Tell me what you want to do.', 'greeting');
    }

    if (/(?:শুভ রাত্রি|শুভ রাত|good night)/i.test(normalized)) {
      return reply('শুভ রাত্রি! ভালো থেকো। দরকার হলে আবার “আবির” বলে ডাকবে।', 'Good night! I’ll be here when you call me.', 'casual');
    }

    if (/(?:ধন্যবাদ|অনেক ধন্যবাদ|thanks|thank you)/i.test(normalized)) {
      return reply('স্বাগতম! 😊', 'You’re welcome!', 'casual');
    }

    if (/(?:বাংলাদেশের রাজধানী|capital of bangladesh|ঢাকার রাজধানী)/i.test(normalized)) {
      return reply('বাংলাদেশের রাজধানী ঢাকা।', 'The capital of Bangladesh is Dhaka.', 'casual');
    }

    if (/(?:বাংলাদেশের মুদ্রা|currency of bangladesh|টাকার নাম কী)/i.test(normalized)) {
      return reply('বাংলাদেশের মুদ্রা হলো টাকা, যার আন্তর্জাতিক কোড BDT।', 'Bangladesh uses the taka, with the international code BDT.', 'casual');
    }

    if (/(?:১\s*কিলোমিটার|1\s*kilometer|এক কিলোমিটার).*(?:কত মিটার|how many meters)/i.test(normalized)) {
      return reply('১ কিলোমিটার = ১,০০০ মিটার।', '1 kilometer equals 1,000 meters.', 'calculator');
    }

    const conversion = convertUnit(normalized);
    if (conversion && /(?:কত|convert|রূপান্তর|সমান|equals|in)/i.test(normalized)) {
      const formatted = Number.isInteger(conversion.value) ? String(conversion.value) : String(Number(conversion.value.toFixed(4)));
      return reply(
        `${formatted} ${conversion.unit}।`,
        `${formatted} ${conversion.unit}.`,
        'calculator',
      );
    }

    if (/(?:time|সময়|সময়|কটা বাজে)/.test(normalized)) {
      const time = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        hour: 'numeric',
        minute: '2-digit',
      }).format(now);
      return reply(
        `এখন ${time}। ঘড়ি বলল, আমি শুধু সময় বলি—চাপ নিও না!`,
        `It’s ${time}. The clock says I should mention: no rush.`,
        'time',
      );
    }

    if (/(?:date|today|আজ|তারিখ|কোন বার)/.test(normalized)) {
      const date = new Intl.DateTimeFormat(bengali ? 'bn-BD' : 'en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }).format(now);
      return reply(`আজ ${date}।`, `Today is ${date}.`, 'date');
    }

    if (/(?:joke|কৌতুক|জোক|হাসাও|মজার কথা)/.test(normalized)) {
      return reply(
        variant([
          'কম্পিউটার ডাক্তারকে বলল, “আমার ভাইরাস হয়েছে।” ডাক্তার বললেন, “তাহলে আজ একটু অফলাইনে থাকুন!”',
          'একটা ফোন আরেকটাকে বলল, “তোমার চার্জ কেমন?” সে বলল, “সম্পর্কটা ১% ব্যাটারির মতো—যেকোনো সময় শেষ!”',
          'শিক্ষক: ২ আর ২ কত? ছাত্র: ৪। শিক্ষক: খুব ভালো! ক্যালকুলেটর: এত প্রশংসা আমি কোনোদিন পাইনি।',
        ]),
        variant([
          'Why did the phone go to therapy? Too many unresolved notifications.',
          'I told my calculator a joke. It said the punchline didn’t add up.',
          'My offline mode and I have a lot in common: we both avoid unnecessary connections.',
        ]),
        'joke',
      );
    }

    if (/(?:তোমার মালিকের নাম|তোমার মালিক কে|মালিকের নাম|owner(?:'s)? name|who is your owner|who owns you)/i.test(normalized)) {
      return reply(
        'আমার মালিকের নাম আবির।',
        'My owner’s name is Abir.',
        'casual',
      );
    }

    if (/(?:আমি কোথায় আছি|আমি কোথায় আছি|আমার অবস্থান কোথায়|আমার অবস্থান কোথায়|আমার লোকেশন কোথায়|আমার লোকেশন কোথায়|where am i|where am i now|what is my location|my location)/i.test(normalized)) {
      return {
        text: bengali ? 'তোমার বর্তমান GPS অবস্থান খুঁজছি…' : 'I’m checking your current GPS location…',
        intent: 'location' as AssistantIntent,
      };
    }

    if (
      /(?:who are you|are you (?:real|conscious|alive)|তুমি কে|তুমি কি মানুষ|তুমি কি বাস্তব)/i.test(
        normalized,
      )
    ) {
      return reply(
        'আমি আবির AI—একটি সফটওয়্যার সহকারী। মানুষের মতো চেতনা বা অনুভূতি নেই; আমি offline ও online—দুইভাবেই সাহায্য করি।',
        'I’m Abir AI, your Android Assistant. I can work both offline and online, and I can handle supported phone tasks without internet when Android allows it.',
        'casual',
      );
    }

    // Smart offline conversation layer: deterministic, friendly, and privacy-first.
    // It intentionally avoids pretending to know live/web facts when offline.
    if (/(?:তুমি কি আমাকে চিনতে পারো|আমাকে চিনতে পারো|do you know me|do you remember me)/i.test(normalized)) {
      const name = rememberedName(memory);
      return reply(
        name
          ? `হ্যাঁ, ${name}—এই ডিভাইসে তুমি যে তথ্য আমাকে মনে রাখতে বলেছো, সেখান থেকে তোমাকে চিনতে পারি। তবে আমি তোমার ব্যক্তিগত তথ্য নিজে থেকে সংগ্রহ করি না।`
          : 'তুমি আমাকে যেসব তথ্য এই ডিভাইসে মনে রাখতে বলবে, সেগুলো থেকেই তোমাকে চিনতে পারব। আমি নিজে থেকে ব্যক্তিগত তথ্য সংগ্রহ করি না।',
        name
          ? `Yes, ${name}. I can use what you chose to save on this device, but I don’t collect personal information on my own.`
          : 'I can remember information you explicitly save on this device. I do not collect personal information on my own.',
        'memory',
      );
    }

    if (/(?:তুমি কত বছরের|তোমার বয়স|তোমার বয়স|আমার বয়স কত|আমার বয়স কত|বয়স কত|বয়স কত|how old are you|your age|what is your age)/i.test(normalized)) {
      return reply(
        'আমার মানুষের মতো বয়স নেই। আমি সফটওয়্যার—তবে তোমার সঙ্গে কাজ করার জন্য সবসময় প্রস্তুত।',
        'I don’t have a human age. I’m software, but I’m always ready to help.',
        'casual',
      );
    }

    if (/(?:কে বানিয়েছে|কে তোমাকে বানিয়েছে|কে তোমাকে তৈরি করেছে|who made you|who created you|who built you)/i.test(normalized)) {
      return reply(
        'হ্যালো! আমি Abir AI—তোমার Android Assistant। আমি offline ও online—দুইভাবেই কাজ করি। আমি offline ও online—দুইভাবেই কাজ করতে পারি এবং Android যতটা অনুমতি দেয় ততটা ফোনে সাহায্য করতে পারি।',
        'I’m Abir AI, the assistant inside this app. I’m built from the code and rules of this project.',
        'casual',
      );
    }

    if (/(?:তুমি কি আমাকে ভালোবাসো|তুমি কি আমাকে পছন্দ করো|do you love me|do you like me)/i.test(normalized)) {
      return reply(
        'আমি মানুষের মতো ভালোবাসা অনুভব করি না। তবে তোমার সঙ্গে সম্মানজনকভাবে কথা বলতে এবং কাজে সাহায্য করতে পারি।',
        'I don’t feel love like a person does, but I can always treat you respectfully and help you.',
        'casual',
      );
    }

    if (/(?:তুমি বোকা|তুমি একটা বোকা|you are stupid|you are dumb)/i.test(normalized)) {
      return reply(
        'হাহা, আজ হয়তো আমার উত্তরটা ভালো হয়নি! 😄 তুমি আবার প্রশ্নটা বলো—আমি আরও ভালোভাবে চেষ্টা করি।',
        'Fair enough 😄 I may have missed that one. Ask again and I’ll try a better answer.',
        'casual',
      );
    }

    if (/(?:ভালো করেছ|দারুণ|সাবাশ|great job|good job|well done|nice)/i.test(normalized)) {
      return reply(
        'ধন্যবাদ! 😄 এবার পরের কাজটা বলো।',
        'Thanks! 😄 What should we tackle next?',
        'casual',
      );
    }

    if (/(?:দুঃখিত|সরি|sorry|my bad)/i.test(normalized)) {
      return reply(
        'কোনো সমস্যা নেই। আবার শুরু করি—কী করতে হবে বলো।',
        'No problem. Let’s start again. What do you need?',
        'casual',
      );
    }

    if (/^(?:হ্যাঁ|হ্যা|জি|জী|yes|yeah|yep|ঠিক আছে|আচ্ছা|okay|ok)$/i.test(normalized)) {
      return reply(
        'ঠিক আছে। 👍 এখন কী করতে হবে বলো।',
        'Got it. 👍 Tell me what you want to do next.',
        'casual',
      );
    }

    if (/^(?:না|নাহ|no|nope)$/i.test(normalized)) {
      return reply(
        'ঠিক আছে। কোনো সমস্যা নেই। অন্য কিছু করতে চাইলে বলো।',
        'Okay, no problem. Tell me if you want to do something else.',
        'casual',
      );
    }

    if (/(?:বিরক্ত লাগছে|বোর লাগছে|i am bored|i’m bored|im bored)/i.test(normalized)) {
      return reply(
        'চলো একটা কাজ করি! 😄 চাইলে আমি কৌতুক বলি, অঙ্ক দিই, সাধারণ জ্ঞান প্রশ্ন করি, অথবা তোমার সঙ্গে আড্ডা দিই।',
        'Let’s do something! 😄 I can tell a joke, give you a puzzle, ask a trivia question, or just chat.',
        'casual',
      );
    }

    if (/(?:কি খবর|কী খবর|what’s up|what is up|whats up)/i.test(normalized)) {
      return reply(
        'এই তো, তোমার কমান্ডের অপেক্ষায় আছি। 😄 তুমি যা বলবে, অফলাইনে যতটা পারি বুঝে কাজ করব।',
        'I’m here and ready for your next command. 😄 I’ll do my best offline.',
        'casual',
      );
    }

    if (/(?:আবহাওয়া|আবহাওয়া|weather|বৃষ্টি হবে কি|বৃষ্টি হবে কিনা)/i.test(normalized)) {
      return reply(
        'আমি অফলাইনে লাইভ আবহাওয়া দেখতে পারি না। ইন্টারনেট থাকলে বর্তমান আবহাওয়া দেখে বলতে পারব।',
        'I can’t see live weather while offline. With internet access, I can check the current weather.',
        'help',
      );
    }

    if (/(?:ইন্টারনেট নেই|নেট নেই|offline|অফলাইন)/i.test(normalized)) {
      return reply(
        'সমস্যা নেই। ইন্টারনেট ছাড়াও আমি কথা বলা, স্মৃতি, অঙ্ক এবং Android-এর অনুমোদিত অনেক control চালাতে পারি।',
        'No problem. I can keep working offline too—conversation, memory, calculations, and supported Android controls are available without internet.',
        'help',
      );
    }

    if (/(?:একটা ধাঁধা|ধাঁধা বল|riddle|puzzle)/i.test(normalized)) {
      return reply(
        'ধাঁধা: এমন কী জিনিস, যত কাটবে তত বড় হবে? উত্তর চাইলে বলো “উত্তর বলো”।',
        'Riddle: What gets bigger the more you cut it? Say “tell me the answer” when you want the answer.',
        'casual',
      );
    }

    if (/(?:উত্তর বলো|ধাঁধার উত্তর|tell me the answer|answer please)/i.test(normalized)) {
      return reply(
        'উত্তর: গর্ত। যত কাটবে, গর্ত তত বড় হবে। 😄',
        'Answer: a hole. The more you cut, the bigger it gets. 😄',
        'casual',
      );
    }

    if (/(?:বাংলাদেশের জাতীয় ফুল|বাংলাদেশের জাতীয় ফুল)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় ফুল শাপলা।', 'The national flower of Bangladesh is the water lily.', 'casual');
    }

    if (/(?:বাংলাদেশের জাতীয় পাখি|বাংলাদেশের জাতীয় পাখি)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় পাখি দোয়েল।', 'The national bird of Bangladesh is the Oriental magpie-robin.', 'casual');
    }

    if (/(?:বাংলাদেশের জাতীয় ফল|বাংলাদেশের জাতীয় ফল)/i.test(normalized)) {
      return reply('বাংলাদেশের জাতীয় ফল কাঁঠাল।', 'The national fruit of Bangladesh is jackfruit.', 'casual');
    }

    const codeReply = codingAnswer(normalized, bengali);
    if (codeReply) {
      return { text: codeReply, intent: 'coding' };
    }

    const answer = calculate(normalized);
    if (answer !== null) {
      const value = Number.isInteger(answer)
        ? String(answer)
        : String(Number(answer.toFixed(4)));
      return reply(
        `উত্তর ${new Intl.NumberFormat('bn-BD').format(answer)}। অঙ্কটা বেশ ভদ্র ছিল!`,
        `That’s ${value}. This sum behaved nicely.`,
        'calculator',
      );
    }

    return reply(
      'এটা অফলাইনে পুরোপুরি বুঝতে পারিনি। বাংলা, English বা mixed ভাষায় আবার বলো—আমি intent, app, contact, phone control, coding আর follow-up context মিলিয়ে চেষ্টা করব।',
      'I didn’t quite catch the intent. Rephrase it naturally—I can handle Bengali, English, or mixed phrasing.',
      'fallback',
    );
  },
};

const defaultExtensions = [offline100FeatureExtension, offlineModernUpgradeExtension, offlineExpansionExtension, offlineNextGenExtension, offlineEvolutionExtension, offlineUltimateExtension, offlineIntelligencePackExtension, offlineMegaSystemsExtension, offlineSystemsExtension, offlineAdvancedExtension, offlineCommandExtension, offlineModernFeaturesExtension];

export async function getAssistantReply(
  request: AssistantRequest,
  extensions: AssistantExtension[] = defaultExtensions,
): Promise<AssistantReply> {
  for (const extension of extensions) {
    const result = await extension.handle(request);
    if (result) return result;
  }

  return {
    text:
      request.language === 'bn'
        ? 'এই কাজটা এখনো আমার অফলাইন কমান্ডে নেই। চাইলে কথাটা আরেকভাবে বলো—আমি বাংলা, English আর mixed command বুঝে চেষ্টা করব।'
        : 'I don’t have that action in my offline command set yet. Rephrase it in Bengali, English, or mixed language and I’ll try again.',
    intent: 'fallback',
  };
}
