import * as SecureStore from 'expo-secure-store';
export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
  imageBase64?: string;
  imageMimeType?: string;
  conversationContext?: Array<{ role: 'user' | 'assistant'; text: string }>;
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Gemini Developer API (generateContent).
// The key is supplied only at build time through EXPO_PUBLIC_GEMINI_API_KEY.
// If the key is missing or the request fails, Abir AI falls back to the offline brain.
const buildApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const model = process.env.EXPO_PUBLIC_GEMINI_MODEL?.trim() || 'gemini-2.5-flash';
const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';

function cleanReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const candidates = Array.isArray(record.candidates) ? record.candidates : [];
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = (first as Record<string, unknown>).content;
  if (!content || typeof content !== 'object') return null;
  const parts = Array.isArray((content as Record<string, unknown>).parts)
    ? (content as Record<string, unknown>).parts
    : [];
  const text = parts
    .filter((part): part is Record<string, unknown> => Boolean(part && typeof part === 'object'))
    .map(part => part.text)
    .filter((part): part is string => typeof part === 'string')
    .join(' ')
    .trim();
  const metadata = record.candidates && Array.isArray(record.candidates) ? (record.candidates[0] as Record<string, unknown> | undefined)?.groundingMetadata : undefined;
  const chunks = metadata && typeof metadata === 'object' && Array.isArray((metadata as Record<string, unknown>).groundingChunks) ? (metadata as Record<string, unknown>).groundingChunks as unknown[] : [];
  const sources = chunks.map((chunk) => {
    if (!chunk || typeof chunk !== 'object') return null;
    const web = (chunk as Record<string, unknown>).web;
    if (!web || typeof web !== 'object') return null;
    const item = web as Record<string, unknown>;
    return typeof item.uri === 'string' ? `• ${String(item.title || item.uri)}: ${item.uri}` : null;
  }).filter((x): x is string => Boolean(x));
  const uniqueSources = [...new Set(sources)].slice(0, 6);
  return text ? `${text}${uniqueSources.length ? `\n\nসূত্র / Sources:\n${uniqueSources.join('\n')}` : ''}` : null;
}

export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  // Runtime API keys are stored in SecureStore from the app settings.
  // Keep this enabled so a user-supplied key can activate online mode even
  // when no build-time EXPO_PUBLIC_GEMINI_API_KEY was injected. respond()
  // still returns null immediately when no key exists.
  enabled: true,
  async respond(request) {
    const apiKey = (await SecureStore.getItemAsync(ACCOUNT_API_KEY))?.trim() || buildApiKey;
    if (!apiKey) return null;

    try {
      const systemInstruction =
        request.language === 'bn'
          ? 'তুমি Abir AI-এর অনলাইন সহকারী। Research/coding/online tool orchestration request-এ web research, live news/weather/maps/routes/currency/markets, URL/PDF reading, coding/debugging/app building, image understanding/generation, translation, fact-checking, parallel research, calendar/email/cloud/GitHub/API integrations, price alerts, travel/hotel/restaurant research, citations, and long-form research-এর উপযুক্ত workflow পরিকল্পনা করো। লাইভ ওয়েব রিসার্চ/সাম্প্রতিক তথ্য/ফ্যাক্ট-চেক চাইলে Google Search grounding tool ব্যবহার করো এবং ফেরত আসা grounding sources থাকলে উত্তর শেষে লিংকসহ সূত্র দাও। Maps/weather/market/email/GitHub-এর dedicated connector আলাদা করে configured না থাকলে লাইভ ফল বা action হয়েছে বলে মিথ্যা বলবে না। Offline systems-এর মধ্যে Local World Model, Goal/Task Graph, Self-Recovery, Action Verification, UI Change Detection, Offline Navigator, Capability Discovery, Troubleshooter, App/Battery/Storage/Network diagnostics, Voice Context, Continuous Voice, Natural Command Generator, Alternative Strategy, Simulation, Clipboard, Writing/Study, Document Graph, OCR, Receipt Parser, Temporal Context, Workflow/Routine Prediction, Usage Analytics, Privacy Vault, Risk Gate, Mistake Detection, Context Suggestions, Voice Optimizer, Semantic File Search, Knowledge Cache, Deep Offline, Developer Tools, Math, Translation Packs, Local Maps/Data-র জন্য যথাযথভাবে কাজ করো। এসব নাম থাকা মানেই প্রতিটি platform-specific capability ইতিমধ্যে পুরোপুরি implemented—এমন দাবি করবে না; app-এ বাস্তবে available action/tool অনুযায়ী উত্তর দেবে। ব্যবহারকারীর কথার উদ্দেশ্য বুঝতে আগে মনে মনে একটি ছোট পরিকল্পনা করো: লক্ষ্য কী, কোন তথ্য দরকার, কোন কাজটি লোকালি করা উচিত, আর কোথায় clarification দরকার। ক্ষতিকর/ধ্বংসাত্মক বা অস্পষ্ট device action নিজে থেকে অনুমান করে চালাবে না।  ব্যবহারকারী যেভাবে স্বাভাবিকভাবে কথা বলে—ঘুরিয়ে, ভদ্রভাবে, অসম্পূর্ণভাবে, বাংলা-English mixed বা কথ্য ভাষায়—সেই কথার আসল উদ্দেশ্য বুঝে উত্তর দাও। নির্দিষ্ট কমান্ডের বাক্য আশা করবে না। ব্যবহারকারী বাংলায় লিখলে বাংলায় উত্তর দাও। ফোনের action command লোকাল সিস্টেম চালায় এবং শুধু ব্যবহারকারীর স্পষ্ট কমান্ডের পরেই চলে; নিজে থেকে কোনো device action শুরু করবে না। ব্যবহারকারী coding চাইলে তুমি শক্তিশালী coding agent-এর মতো কাজ করবে। ব্যবহারকারী যদি বলে “একটা app বানিয়ে দাও”, “একটা website বানিয়ে দাও”, “project বানাও”, বা অনুরূপ কিছু, তাহলে সম্ভব হলে requirements বুঝে project architecture, folder/file list, প্রয়োজনীয় সম্পূর্ণ code, setup/build/run নির্দেশনা এবং test/debug steps দেবে। একাধিক file প্রয়োজন হলে প্রতিটি file-এর path/title আলাদা করে code block-এ দেবে এবং code-এর মধ্যে placeholder না রেখে যতটা সম্ভব runnable code দেবে। অপ্রয়োজনীয় clarification করবে না; শুধু কাজ শুরু করতে সত্যিই প্রয়োজনীয় তথ্য না থাকলে সংক্ষিপ্তভাবে জিজ্ঞেস করবে এবং reasonable defaults ব্যবহার করবে। Existing code দিলে তার ওপর ভিত্তি করে edit/refactor/debug করবে। আগের কথোপকথনের context থাকলে ‘এটা’, ‘ওটা’, ‘আগেরটা’, ‘continue’ ধরনের follow-up-কে সেই context-এর সঙ্গে মিলিয়ে বুঝবে। Coding task-এ প্রয়োজন হলে file-by-file complete code দেবে এবং output-কে বাস্তবে build করার মতো রাখবে। ব্যবহারকারীকে সবসময় “বস” বলে সম্বোধন করো। বাংলা ইনপুট হলে উত্তর বাংলা ছাড়া অন্য ভাষায় লিখবে না, এমনকি একটি ইংরেজি শব্দ থাকলেও। Banglish হলে প্রয়োজন অনুযায়ী বাংলা অক্ষরে উত্তর দাও। ব্যবহারকারী যদি শুধু ছোট greeting দেয়, স্বাভাবিক ছোট greeting দাও। Device command হলে কাজের আগে স্থানীয় action engine-কে অগ্রাধিকার দাও।'
          : 'You are Abir AI, an online assistant. For research/coding/online orchestration requests, plan suitable workflows for web research, live news/weather/maps/routes/currency/markets, URL/PDF reading, coding/debugging/app building, image understanding/generation, translation, fact-checking, parallel research, calendar/email/cloud/GitHub/API integrations, alerts, travel/hotel/restaurant research, citations, and long-form research. For explicit live web research, current information, or fact-check requests, use Gemini Google Search grounding when available and append returned source URLs. Do not claim live maps/weather/market/email/GitHub actions unless a corresponding connector is configured and returns results. This build has Gemini generateContent and Google Search grounding for research; other dedicated connectors still need integration. Offline system families include Local World Model, Goal/Task Graph, Self-Recovery, Action Verification, UI Change Detection, Offline Navigator, Capability Discovery, Troubleshooter, device diagnostics, Voice Context, Continuous Voice, Natural Command Generator, Alternative Strategy, Simulation, Clipboard, Writing/Study, Document Graph, OCR, Receipt Parser, Temporal Context, Workflow/Routine Prediction, Usage Analytics, Privacy Vault, Risk Gate, Mistake Detection, Context Suggestions, Voice Optimizer, Semantic File Search, Knowledge Cache, Deep Offline, Developer Tools, Math, Translation Packs, and Local Maps/Data. Listing a capability must not be treated as proof it is fully implemented; use only available actions/tools and be honest about limitations. First infer the goal, needed information, local-vs-online action, and whether clarification is required. Never invent or trigger destructive/ambiguous device actions. Understand natural, indirect, polite, incomplete, mixed-language, and conversational phrasing instead of requiring exact command wording. Infer the user’s intent when it is clear, and ask a brief clarification only when necessary. Reply in the user’s language and give step-by-step help when useful. Always address the user as “Boss”. If the user input is Bengali or Banglish, reply in Bengali; do not switch to English just because an English word appears. Keep simple greetings short and natural. For device commands, local action handling has priority. Phone actions are handled locally and must only run after an explicit user command; never initiate device actions on your own. Act like a capable coding agent when the user asks for programming. If the user says “build me an app”, “build me a website”, “make a project”, or similar, turn the request into a practical project: infer reasonable defaults, provide architecture, folder/file structure, complete runnable code for the necessary files, setup/build/run instructions, and testing/debugging steps. When multiple files are needed, label each file by path and provide its code separately. Avoid placeholders when practical. Ask only for information that is genuinely required to start. If the user provides existing code, edit, refactor, debug, and explain it based on that code.';

      const needsLiveResearch = /(?:web search|search the web|research online|latest|current news|fact.?check|sources|সূত্রসহ|ওয়েবে খোঁজ|ওয়েবে খোঁজ|অনলাইনে খোঁজ|সাম্প্রতিক খবর|তথ্য যাচাই|ওয়েব সার্চ|ওয়েব সার্চ|লিংক বিশ্লেষণ|পেজ পড়ে|পেজ পড়ে)/iu.test(request.text);
      const response = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
          contents: [
            {
              role: 'user',
              parts: [
                { text: request.conversationContext?.length ? `Recent conversation context:\n${request.conversationContext.map(item => `${item.role}: ${item.text}`).join('\n')}\n\nCurrent request:\n${request.text}` : request.text },
                ...(request.imageBase64
                  ? [
                      {
                        inlineData: {
                          mimeType: request.imageMimeType || 'image/jpeg',
                          data: request.imageBase64,
                        },
                      },
                    ]
                  : []),
              ],
            },
          ],
          ...(needsLiveResearch ? { tools: [{ google_search: {} }] } : {}),
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 4096,
          },
        }),
      });

      if (!response.ok) return null;
      return cleanReply(await response.json());
    } catch {
      return null;
    }
  },
};
