import { Platform } from 'react-native';
import { PermissionsAndroid } from 'react-native';
import type { AssistantLanguage } from './offlineBrain';
import { getOfflineSpeechRecognitionAvailability, recognizeAndroidSpeech } from './androidActions';

type BrowserRecognitionResult = {
  results: ArrayLike<ArrayLike<{ transcript: string }>>;
};

type BrowserRecognition = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: BrowserRecognitionResult) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechWindow = Window & {
  SpeechRecognition?: new () => BrowserRecognition;
  webkitSpeechRecognition?: new () => BrowserRecognition;
};

export async function listenForText(
  language: AssistantLanguage,
): Promise<string | null> {
  const preferredLocale = language === 'bn' ? 'bn-BD' : 'en-US';

  if (Platform.OS === 'android') {
    const permission = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
      throw new Error(
        language === 'bn'
          ? 'ভয়েস ইনপুটের জন্য মাইক্রোফোন অনুমতি প্রয়োজন। সেটিংসে অনুমতি দিয়ে আবার চেষ্টা করো।'
          : 'Microphone permission is needed for voice input. Allow it in settings and try again.',
      );
    }

    const rankCandidates = (values: string[]) => {
      const commandWords = /open|launch|start|call|phone|dial|whatsapp|youtube|messenger|instagram|facebook|volume|sound|increase|decrease|settings|wifi|bluetooth|home|back|recent|notification|screenshot|screen|camera|read|age|খোলো|খুলে|ওপেন|চালু|হোয়াটস|হোয়াটস|ইউটিউব|মেসেঞ্জার|কল|ফোন|নাম্বার|ভলিউম|শব্দ|বাড়াও|বাড়াও|বাড়াইতে|বাড়াতে|কমাও|কমাইতে|সেটিংস|হোম|পিছনে|রিসেন্ট|নোটিফিকেশন|স্ক্রিন|ক্যামেরা|পড়|পড়|বয়স|বয়স/i;
      return values
        .map((value, index) => {
          const text = value.trim();
          const commandScore = commandWords.test(text) ? 30 : 0;
          const bengaliScore = /[\u0980-\u09FF]/.test(text) ? 12 : 0;
          const mixedLanguageScore = /[\u0980-\u09FF]/.test(text) && /[A-Za-z]/.test(text) ? 6 : 0;
          return { text, score: commandScore + bengaliScore + mixedLanguageScore + Math.max(0, 8 - index) };
        })
        .filter(item => item.text)
        .sort((a, b) => b.score - a.score);
    };

    // First choice: real Android on-device recognition. Try both Bengali and
    // English so mixed speech such as “আবির YouTube খুলে দাও” has a chance
    // even when only one offline language pack is installed.
    const offlineAvailable = await getOfflineSpeechRecognitionAvailability();
    if (offlineAvailable) {
      const native = await import('./androidActions');
      const locales = preferredLocale === 'bn-BD' ? ['bn-BD', 'en-US'] : ['en-US', 'bn-BD'];
      const allCandidates: string[] = [];
      for (const candidateLocale of locales) {
        const candidates = await native.recognizeOfflineSpeech(candidateLocale);
        allCandidates.push(...candidates.filter(Boolean));
        if (allCandidates.length && rankCandidates(allCandidates)[0]?.score >= 20) break;
      }
      const best = rankCandidates(allCandidates)[0]?.text;
      if (best) return best;
    }

    // Reliable fallback: use the normal Android speech service with network
    // allowed. This is important when an on-device Bengali/English model is
    // available in principle but the actual language pack is missing.
    const fallbackLocales = preferredLocale === 'bn-BD'
      ? ['bn-BD', 'en-US']
      : ['en-US', 'bn-BD'];

    for (let attempt = 0; attempt < 2; attempt += 1) {
      for (const locale of fallbackLocales) {
        const candidates = await recognizeAndroidSpeech(locale, false);
        const ranked = rankCandidates(candidates);
        const best = ranked[0]?.text;
        if (best) return best;
      }
    }
    return null;
  }

  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    const speechWindow = window as SpeechWindow;
    const Recognition =
      speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;
    if (!Recognition) {
      throw new Error('This browser does not support speech recognition.');
    }

    return new Promise<string | null>((resolve, reject) => {
      const recognition = new Recognition();
      recognition.lang = preferredLocale;
      recognition.interimResults = false;
      recognition.maxAlternatives = 5;
      recognition.onresult = (event) => {
        const candidates: string[] = [];
        for (let i = 0; i < event.results.length; i += 1) {
          for (let j = 0; j < event.results[i].length; j += 1) {
            const value = event.results[i][j]?.transcript?.trim();
            if (value) candidates.push(value);
          }
        }
        resolve(candidates[0] || null);
      };
      recognition.onerror = (event) =>
        reject(new Error(`Speech recognition failed: ${event.error}`));
      recognition.onend = () => resolve(null);
      recognition.start();
    });
  }

  throw new Error('Voice input is currently supported on Android and web.');
}

export async function listenForOfflineText(
  language: AssistantLanguage,
): Promise<string | null> {
  if (Platform.OS !== 'android') return null;
  const permission = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
  );
  if (permission !== PermissionsAndroid.RESULTS.GRANTED) {
    throw new Error(
      language === 'bn'
        ? 'ভয়েস নিরাপত্তার জন্য মাইক্রোফোন অনুমতি প্রয়োজন।'
        : 'Microphone permission is required for voice security.',
    );
  }
  const available = await getOfflineSpeechRecognitionAvailability();
  if (!available) return null;
  const locales = language === 'bn' ? ['bn-BD', 'en-US'] : ['en-US', 'bn-BD'];
  const results: string[] = [];
  for (const locale of locales) {
    const candidates = await recognizeAndroidSpeech(locale, true);
    results.push(...candidates.filter(Boolean));
  }
  return results[0]?.trim() || null;
}
