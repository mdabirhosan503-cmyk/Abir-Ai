import * as Speech from 'expo-speech';
import type { AssistantLanguage } from './offlineBrain';
import { chooseSpeechVoice, type SpeechVoice } from './voiceSelection';
import type { VoiceGenderPreference } from './voicePreferences';

export type SpeechStartOptions = {
  text: string;
  language: AssistantLanguage;
  voiceGender: VoiceGenderPreference;
  voices: SpeechVoice[];
  onDone?: () => void;
  onError?: () => void;
};

export async function speakAssistantText({
  text,
  language,
  voiceGender,
  voices,
  onDone,
  onError,
}: SpeechStartOptions) {
  const selection = chooseSpeechVoice(voices, voiceGender, language);
  await Speech.stop();
  const requestedLanguage = language === 'bn' ? 'bn-BD' : 'en-US';
  // When Android does not have a Bengali voice, pairing an English voice ID
  // with bn-BD can make some TTS engines fail silently. Let the selected voice
  // decide its own language in that case.
  const speechLanguage = selection.voice && !selection.languageMatched
    ? selection.voice.language
    : requestedLanguage;

  let fallbackUsed = false;
  const handleError = () => {
    if (selection.voice && !fallbackUsed) {
      fallbackUsed = true;
      try {
        Speech.speak(text, {
          language: speechLanguage,
          pitch: 1.02,
          rate: 0.94,
          onDone,
          onStopped: onDone,
          onError,
        });
        return;
      } catch {
        // Fall through to the caller's error callback.
      }
    }
    onError?.();
  };

  Speech.speak(text, {
    language: speechLanguage,
    ...(selection.voice ? { voice: selection.voice.identifier } : {}),
    pitch: 1.02,
    rate: 0.94,
    onDone,
    onStopped: onDone,
    onError: handleError,
  });
  return selection;
}
