export function normalizeAssistantCommand(text: string) {
  return text
    .normalize('NFKC')
    .replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)))
    .replace(/[!?।,;:]+/g, ' ')
    // Conversational Bengali/English → compact command language.
    // This lets offline mode understand polite, indirect phrases instead of
    // requiring the user to speak like a fixed command list.
    .replace(/(?:একটু|দয়া করে|দয়া করে|অনুগ্রহ করে|প্লিজ|please|kindly|ভাই|শুনো|শুনুন|hey|hello|hi)\b/gi, ' ')
    .replace(/(?:খুলে\s+(?:দিতে|দেওয়ার|দেওয়ার)\s+পারবে|খুলে\s+দাও|খুলে\s+দিন|খুলে\s+দিও)/giu, 'খোলো')
    .replace(/(?:চালু\s+করে\s+(?:দিতে|দেওয়ার|দেওয়ার)\s+পারবে|চালু\s+করে\s+দাও|চালু\s+করে\s+দিন)/giu, 'চালু করো')
    .replace(/(?:করতে\s+পারবে|করতে\s+পারো|করতে\s+পারি|করতে\s+পারবেন)/giu, 'করো')
    .replace(/(?:দিতে\s+পারবে|দিতে\s+পারো|দিতে\s+পারবেন)/giu, 'দাও')
    .replace(/(?:পারবে\s+কি|পারবে|পারো|পারবেন)\b/giu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function extractAppQuery(text: string) {
  const cleaned = normalizeAssistantCommand(text);
  const openingRequested =
    /(?:\bopen\b|\blaunch\b|\bstart\b|\bgo\s+to\b|\bshow\b|\brun\b|ওপেন|খোলো|খুলুন|খুলে|চালু|ঢুকো|যাও|দেখাও|চালাও)/i.test(cleaned);
  if (!openingRequested) return null;

  const query = cleaned
    .replace(/(?:hey|hello|hi|please|kindly|can you|could you|would you|abir|abira|adiraabir|adira abir|এবির|আবির|আদিরাবির|আদির আবির|আদিরাবিরকে)/gi, ' ')
    .replace(/(?:আমাকে|একটু|দয়া করে|দয়া করে|ভাই|প্লিজ|অনুগ্রহ করে|এখন|এখানে|আমার জন্য|আমার|please|kindly|for me|now|the|my|app)/gi, ' ')
    .replace(/(?:open|launch|start|go\s+to|show|run)/gi, ' ')
    .replace(/(?:ওপেন|খুলে দাও|খুলে দিন|খুলে দিও|খুলুন|খোলো|খুলে|চালু করে দাও|চালু করো|চালু করুন|চালু|চালাও|ঢুকো|দেখাও|যাও|দাও|দিন|দিয়ে দাও|দিতে|করতে|পারবে|পারো|পারবেন|কি|কী|অ্যাপটি|অ্যাপ|টা|টি|টাকে|এখন|এখানে)/gi, ' ')
    .replace(/[?!।,;:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractCallQuery(text: string) {
  const english = text.match(
    /^\s*(?:please\s+)?(?:call|phone|dial|ring)\s+(?:my\s+)?(.+?)\s*$/i,
  );

  // Natural Bengali forms, e.g.
  // "Ashik নামে নাম্বারে কল দাও", "Ashik-কে কল করো",
  // "Ashik এর কাছে ফোন দাও", "আম্মুকে কল করো".
  const bengali = text.match(
    /^\s*(?:আমাকে\s+)?(.+?)(?:\s+নামে)?(?:\s+নাম্বারে|\s+নম্বরে|\s+এর\s+কাছে|\s+কে)?\s+(?:কল|ফোন|ডায়াল|ডায়াল)(?:\s+(?:দাও|দিন|দিতে পারো|করো|করুন|করবে|দিতে পারবে))?\s*$/u,
  );

  const prefix = text.match(
    /^\s*(?:আমাকে\s*)?(?:কল|ফোন|ডায়াল|ডায়াল)\s+(?:(?:করো|করুন|দাও|দিন)\s+)?(.+?)\s*$/u,
  );

  const rawQuery = english?.[1] ?? bengali?.[1] ?? prefix?.[1];
  if (!rawQuery) return null;

  const query = rawQuery
    .replace(/\b(?:please|now|my)\b/gi, ' ')
    .replace(/[-–—]?\s*কে$/u, ' ')
    .replace(
      /(?:দয়া করে|দয়া করে|একটু|আমার|নামে|নাম্বারে|নম্বরে|এর|কাছে|কে|কল|ফোন|ডায়াল|ডায়াল|করো|করুন|দাও|দিন|দিতে পারো|দিতে পারবে|করবে|এখন)/gu,
      ' ',
    )
    .replace(/[?!।,.:;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return query || null;
}

export function extractDirectPhoneNumber(text: string) {
  const normalizedDigits = text.replace(/[০-৯]/g, (digit) =>
    String('০১২৩৪৫৬৭৮৯'.indexOf(digit)),
  );

  const match = normalizedDigits.match(/(?:^|\s|["“'‘(])((?:\+?\d[\d\s().-]{7,}\d))(?:$|\s|["”'’)]|[-–—])/);
  if (!match) return null;

  const number = match[1].replace(/[^+\d]/g, '');
  const digitsOnly = number.replace(/\D/g, '');
  if (digitsOnly.length < 8 || digitsOnly.length > 15) return null;
  return number;
}
