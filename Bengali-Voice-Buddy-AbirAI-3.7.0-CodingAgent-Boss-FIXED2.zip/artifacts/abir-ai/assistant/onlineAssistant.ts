import * as SecureStore from 'expo-secure-store';
export type OnlineAssistantRequest = {
  text: string;
  language: 'bn' | 'en';
  imageBase64?: string;
  imageMimeType?: string;
};

export type OptionalOnlineAssistant = {
  enabled: boolean;
  respond(request: OnlineAssistantRequest): Promise<string | null>;
};

// Gemini Developer API (generateContent).
// The key is supplied only at build time through EXPO_PUBLIC_GEMINI_API_KEY.
// If the key is missing or the request fails, Abir AI falls back to the offline brain.
const buildApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY?.trim() ?? '';
const model = process.env.EXPO_PUBLIC_GEMINI_MODEL?.trim() || 'gemini-2.5-flash';
const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
const ACCOUNT_API_KEY = 'abir-ai-account-api-key-v2';

function cleanReply(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Record<string, unknown>;
  const candidates = Array.isArray(record.candidates) ? record.candidates : [];
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = (first as Record<string, unknown>).content;
  if (!content || typeof content !== 'object') return null;
  const parts = Array.isArray((content as Record<string, unknown>).parts)
    ? (content as Record<string, unknown>).parts
    : [];
  const text = parts
    .filter((part): part is Record<string, unknown> => Boolean(part && typeof part === 'object'))
    .map(part => part.text)
    .filter((part): part is string => typeof part === 'string')
    .join(' ')
    .trim();
  return text || null;
}

export const optionalOnlineAssistant: OptionalOnlineAssistant = {
  enabled: Boolean(buildApiKey),
  async respond(request) {
    const apiKey = (await SecureStore.getItemAsync(ACCOUNT_API_KEY))?.trim() || buildApiKey;
    if (!apiKey) return null;

    try {
      const systemInstruction =
        request.language === 'bn'
          ? 'তুমি Abir AI-এর অনলাইন সহকারী। ব্যবহারকারী যেভাবে স্বাভাবিকভাবে কথা বলে—ঘুরিয়ে, ভদ্রভাবে, অসম্পূর্ণভাবে, বাংলা-English mixed বা কথ্য ভাষায়—সেই কথার আসল উদ্দেশ্য বুঝে উত্তর দাও। নির্দিষ্ট কমান্ডের বাক্য আশা করবে না। ব্যবহারকারী বাংলায় লিখলে বাংলায় উত্তর দাও। ফোনের action command লোকাল সিস্টেম চালায় এবং শুধু ব্যবহারকারীর স্পষ্ট কমান্ডের পরেই চলে; নিজে থেকে কোনো device action শুরু করবে না। ব্যবহারকারী coding চাইলে তুমি শক্তিশালী coding agent-এর মতো কাজ করবে। ব্যবহারকারী যদি বলে “একটা app বানিয়ে দাও”, “একটা website বানিয়ে দাও”, “project বানাও”, বা অনুরূপ কিছু, তাহলে সম্ভব হলে requirements বুঝে project architecture, folder/file list, প্রয়োজনীয় সম্পূর্ণ code, setup/build/run নির্দেশনা এবং test/debug steps দেবে। একাধিক file প্রয়োজন হলে প্রতিটি file-এর path/title আলাদা করে code block-এ দেবে এবং code-এর মধ্যে placeholder না রেখে যতটা সম্ভব runnable code দেবে। অপ্রয়োজনীয় clarification করবে না; শুধু কাজ শুরু করতে সত্যিই প্রয়োজনীয় তথ্য না থাকলে সংক্ষিপ্তভাবে জিজ্ঞেস করবে এবং reasonable defaults ব্যবহার করবে। Existing code দিলে তার ওপর ভিত্তি করে edit/refactor/debug করবে। ব্যবহারকারীকে সবসময় “বস” বলে সম্বোধন করো।'
          : 'You are Abir AI, an online assistant. Understand natural, indirect, polite, incomplete, mixed-language, and conversational phrasing instead of requiring exact command wording. Infer the user’s intent when it is clear, and ask a brief clarification only when necessary. Reply in the user’s language and give step-by-step help when useful. Always address the user as “Boss”. Phone actions are handled locally and must only run after an explicit user command; never initiate device actions on your own. Act like a capable coding agent when the user asks for programming. If the user says “build me an app”, “build me a website”, “make a project”, or similar, turn the request into a practical project: infer reasonable defaults, provide architecture, folder/file structure, complete runnable code for the necessary files, setup/build/run instructions, and testing/debugging steps. When multiple files are needed, label each file by path and provide its code separately. Avoid placeholders when practical. Ask only for information that is genuinely required to start. If the user provides existing code, edit, refactor, debug, and explain it based on that code.';

      const response = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
          contents: [
            {
              role: 'user',
              parts: [
                { text: request.text },
                ...(request.imageBase64
                  ? [
                      {
                        inlineData: {
                          mimeType: request.imageMimeType || 'image/jpeg',
                          data: request.imageBase64,
                        },
                      },
                    ]
                  : []),
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 4096,
          },
        }),
      });

      if (!response.ok) return null;
      return cleanReply(await response.json());
    } catch {
      return null;
    }
  },
};
